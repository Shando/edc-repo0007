package com.bliss.core;

import java.io.*;

public class ROM extends Memory
{
    public ROM(int[] image, int location) {
        this(image, location, -1);
    }

    public ROM(int[] image, int location, int bank) {
        super(bank);
        this.image = image;
        this.location = location;
    }

    public void reset() {
        //ROM can't be changed, so there's nothing to reset
    }

    public void save(SaveOutputStream sos) {}

    public void load(LoadInputStream sos) {}

    public int getLocation() {
        return location;
    }

    public int peek(int location) {
        return image[location-this.location];
    }

    public void poke(int location, int value) {
    }

    public int getSize() {
        return image.length;
    }

    public static ROM loadROM(String resourceName, boolean is16bit)
            throws IOException
    {
        return new ROM(loadROMImage(resourceName, is16bit), 0);
    }

    public static int[] loadROMImage(String resourceName, boolean is16bit)
            throws IOException
    {
/*
        ClassLoader cl = ROM.class.getClassLoader();
        InputStream is;
        if (cl != null)
            is = cl.getResourceAsStream(resourceName);
        else
            is = ClassLoader.getSystemResourceAsStream(resourceName);
*/
        InputStream is = ROM.class.getResourceAsStream(resourceName);
        if (is == null)
            throw new IOException("Unable to locate resource: " + resourceName);

        BufferedInputStream bis = new BufferedInputStream(is, 4096);
        int[] image = loadROMImage(bis, is16bit);
        bis.close();
        return image;
    }

    public static int[] loadROMImage(InputStream is, int length,
            boolean is16bit) throws IOException
    {
        int[] image = new int[length / (is16bit ? 2 : 1)];
        for (int i = 0; i < image.length; i++) {
            int nextByte = is.read();
            if (is16bit) {
               int lowByte = is.read();
               image[i] = (nextByte << 8) | lowByte;
            }
            else
               image[i] = nextByte;
        }
        return image;
    }

    public static int[] loadROMImage(InputStream is, boolean is16bit)
            throws IOException
    {
        int[] image = new int[4096];
        int imageSize = 0;
        int nextByte;
        while ((nextByte = is.read()) != -1) {
            if (imageSize == image.length) {
                int[] newImage = new int[image.length*2];
                System.arraycopy(image, 0, newImage, 0, image.length);
                image = newImage;
            }
            if (is16bit) {
               int lowByte = is.read();
               image[imageSize] = (nextByte << 8) | lowByte;
            }
            else
               image[imageSize] = nextByte;
            imageSize++;
        }
        int[] finalImage = new int[imageSize];
        System.arraycopy(image, 0, finalImage, 0, imageSize);
        return finalImage;
    }

    protected int[] image;
    protected int   location;

}
