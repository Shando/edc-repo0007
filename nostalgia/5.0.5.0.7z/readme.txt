Nostalgia, an Intellivision Emulator

by Joe Fisher
joe@shiny-technologies.com

  Nostalgia 5.0!  This is a big milestone.  It's been over 6 years
since the first Nostalgia was released.  A lot has changed since
then, and it was time for a big facelift.

  Thanks again to all of the fine folks on the Intvprog mailing list
who have helped me over the years.  Joe Zbiciak, David Harley,
Arnauld Chevallier - you all know who you are.

  Thanks, of course, to my wonderful wife who supports my madness.

  I hope you enjoy the new Nostalgia!

-Joe


------ Version 5.0 Updates --------------------------------
  Completely new video system - changed from DirectDraw
    to Direct3d to be compatible with more video cards.
  Completely new front end with better functionality.
  Completely new input system.
  Greatly sped up scanning ROM folders.
  Changed the display FrameSkip to greatly smooth out the 
  frame skipping and allows an adaptive frakeskip model.
  Screenshots now take a proper picture of the game screen,
    including the border.
  Screenshots are now available in BMP, JPG or PNG formats.
  Audio now plays while minimized or in the background so you
    can use it as a retro jukebox!
  Sped up the beginning of the game display so you're not
    looking at a blank window for too long.
  Updated the database system making it FAR more resistant to
    errors and corrupted databases.  It also handles new
    database versions much better.
  ECS keyboard now works more reliably.
  You can now see and edit game configurations right in the GUI.
  Games can now be assigned a category for custom sorting.
  Game key help is now available in-game.  <F1> is the default.
  Fixed a bug in video emulation that prevented the 1 & 9 key
    pause combination from working properly.
  
------ Version 4.2 Updates --------------------------------
  Added a screen saver!  Press <CTRL + S> from any of the
    menus to activate it.
  Applied some optimizations to greatly increase the speed
    of the emulator engine.  This means Nostalgia will run
    at full speed on more computers.
  Added Kaillera network support!  Run from the command line
    with the -k switch, or run from inside Nostalgia.
  Fixed a GLARING bug in initial multiplayer implementation.
  Added the ability to customize other keys, like screenshot,
    sound enable, etc.  Edit controls.cfg to change them
    Valid values are found in controls.txt.
  Fixed the "Ice Trek" bug that prevented you from getting to
    the last screen.
  Fixed some odd bugs in joystick handling.
  Updated Ice Trek bug fix with Joe Z's new info.  Thanks, Joe!
  Fixed a series of bugs with the display of moving objects.
  Small updates to sound emulation for accuracy
  Fixed a bug in the way controls.cfg was saved.  Thanks to
    Rick for finding this one.

Debugger:
  Fixed a bug that prevented certain games from loading.

------ Version 4.1 Updates --------------------------------
  Game Manuals are now supported!  Manuals must be in text format, and have
    the same name as the box image file.  They go in the Manuals folder,
    which is customizable in the dbTool.  eg:
      Astrosmash - Meteor.jpg   Image
      Astrosmash - Meteor.txt   Manual
  Mousewheel is now supported in the cart loader and manual viewer screens.
  Keyboard now functions when CGC is connected.
  CGC is now enabled by default if it is connected.
  You can now use CGC or Joystick in the menu screens.
  dbTool will now save any changes to the current ROM when you press Save -
    you no longer have to press "Update Entry" if you're just editing the
    one file.
  HUGE bug in command line handling fixed.  Thanks to Jason for reporting.
  Fixed a bug in the Intellivoice / ECS switches in the database.
  
------ Version 4.0 Updates --------------------------------
  INTELLIVOICE!!!  Yes, the Intellivoice is now supported!  Drop
    in the ivoice.bin (or whatever yours in named) and listen to
    that sweet, sweet robitic voice.
  You can now have Nostalgia automatically update your video frame
    skip.  This will allow Nostalgia to adjust its frame rate to 
    match your hardware speed.  Enabled by default.
  ECS and Intellivoice are now controlled by switches in the game
    database.  You will not have to manually enable them.  They can
    still be manually forced on/off via command line switches.
  You can now select an option to go directly to the load cart
    screen, skipping the main menu entirely.  Thanks, David!
  New command line switches:
    -IVOICE -NOIVOICE : force the Intellivoice on or off.
    -l : Go directly to the cart loader screen.
  ".itv" added to the list of acceptable cartridge extensions.
  Tremendously improved error reporting inside the game.  You'll
    now have more information on why your favorite game won't load.

Debugger updates:
  Massive improvement to tracing interface.  You can now specify
    an arbitrary number of log and break points.  They will be
    saved in triggers.cfg, which is human-readable and editable.
  You can now view the logfile via a button on the main interface.
    You can also set a flag to have the logfile pop up after 
    each run.
  Tracing now handles Intellivoice instructions.  The jumps even
    tell you which subroutine in ROM you're jumping into.
  HUGE increase in speed in the trace dump operation.
  Added options to change how memory gets initialized on startup.
  
------ Version 3.9 Updates --------------------------------
  The game folder is no longer rescanned every time Nostalgia is run.
    It is only rescanned if the folder contents have changed.
  There is now a database management tool for maintaining and updating
    the database.
  The MiniExec and MiniGrom have been renamed so they don't overwrite any
    existing Exec and Grom files.
  Better handling of .cfg files.  Now supporting Write Only Memory.
  Keyboard Navigation in the menus.  Thanks, James!
  Added Hardware Stretch.  Now you can use a high rez video mode
    and stretch the image full screen for that fuzzy, retro
    bad TV feeling!  Does not work well on some video cards.
  Added the ability to edit the game palette.  Think my color choices
    need some tweaking?  Head into Game Options and edit until your
    little heart's content.  BIG thanks to David Trammell for this idea.
  Added visual feedback to button presses.
  You can now specify a combination of two keys to map to a single input.
    For example, you can map UPARROW and LEFTARROW to together send
    the NORTHWEST command to the Intellivision.  Thanks to Rick
    Reynolds for this one!
  Palettes can be exported to a bmp file.  They can be imported via the
    command line.  -p:mypal.bmp  The new palette will be saved to the
    registry.
  Screenshots are now saved in 8 bit palettized format.  Why?  This
    allows you to take a screenshot of your favorite game and load it
    into your favorite photo editor.  You can now mess with the palette
    and see exactly what your changes will do.  Now just load that palette
    into Nostalgia, and you're set to go!
  Screenshots are now saved with a new naming convention:
    cartname_mmddHHMMSS.bmp
    mmonth, dday, HHour, MMinute, SSecond.
  New hand controller file.  Made easier to use for those working with a 
    frontend or game cab.  Default file is controls.cfg.  See controls.txt
    for a listing of possible values.
  New command line switch -c:file.ext.  This allows you to specify a
    controller file to use.  Now you can have separate files for different
    games.
  You can now export your hand controller file.  It will generate a text
    file in the captures directory.
  Fixed a bug that prevented the ECS options screen from working.
  Made mouse movement a lot smoother in Menus.
  The keyboard is now enabled when using the CGC.
  Refinements to the input system to make it more reliable and
    maintainable.
  Changed ECS and IVoice options to be checkboxes instead of popping up
    a new window.
  More video changes to speed things up.
  Changes to sound routines to fix a slight bug.
  Changes to sound handling to drop sound frames if game is running too
    slowly.
  Fixed another bug with video capture.
  Fixed some problems with the menuing system and gfx display.
  Network play has been disabled pending updates.
  Fixed some problems in the input routines that caused crashes under
    certain circumstances.
  SPACEBAR now goes to the next game in the Load Cart screen.

Debugger updates:
  HUGE increaswe in speed in the trace and trace dump operations.
  Now sound stops playing when you pause.
  General updates to robustness.

--------------------------------------
Updates since version 3.6a:
  More video optimization.
  You can now ESCAPE out of Nostalgia from the main menu.
  Fixed massive problems with AVI capture.
  Made AVI captures smoother.

Debugger updates:
  Many changes to keyboard navigation for better ease of use.

--------------------------------------
Updates since version 3.5:
  Optimized the display and input routines to more than double the frame rate!
    This will allow Nostalgia to run more smoothly on more PCs.
    Thanks to Joe Zbiciak for his contributions.
  Games that use the ECS now turn it on automatically when played.
  Added a frame rate counter.  Press <F6> to enable / disable.
  Nostalgia now supports any display mode your video card does!
    Look in the Game Options screen to try them out.
  Configuration now stored in the Regsitry.
  The command line now allows you to set the resolution in -WxH format.
    (eg. -640x480)  The format will be verified against the list of available
    modes, and error.log will tell you if it was invalid.
  Nostalgia now comes with Joe Zbiciak's MiniExec and MiniGrom so you can play
    games "right out of the box."
  There are now many homebrew games packaged with Nostalgia.  Thanks to Arnauld
    Chevallier, Joe Zbiciak and Ryan Kinnen for providing them.
    See README.HTML to find out more about them.
  Added a Windows Installer.
  Added throttling for play with no sound.
  Added option and hotkey <F4> to turn sound on/off.
  Added notification of MiniExec support.  Games can be marked supported in
    "Add to Database" button on the Load Cartridge screen.
  Made the display more accurate to a real Intellivision.  Thanks to Steve
    Orth, Arnauld Chevallier, and Joe Zbiciak.
  Fixed usability issues with the menuing system like:
    Notification of delays when loading the cartridge list.
    Pageup/Pagedown support in the scrollbars for choosing Rom/Image folders.
    Display of Rom/Image files while browsing for Rom/Image folders.
  Fixed a bug that caused a crash when opening up large numbers of roms.
  Fixed a bug in Nostalgia's database preventing Super Soccer from running.
  Fixed a bug that caused the sound to disappear after loading many games.
  Fixed 2 bugs that caused crashes under certain conditions.
  Fixed a bug that kept Tron Solar Sailer from working.  Thanks Steve Orth
    and Joe Z.
  Fixed a bug that caused games like Mission X to seem to wrap around the
    screen.  Thanks to Marco Turconi for finding this one.
  Fixed gross inaccuracies in the sound and video emulation.  Thanks, Joe Z.

Debugger-specific updates:
  Improvements to the speed of the debugger.
  Debugger can now run in 16, 24 or 32 bit display modes, not just 16.
  The debugger now remembers the last game you chose so you don't have to
    reselect the game to re-run it every time.
  Games are now properly loaded from the command line in the debugger.
  The trace window now follows along when stepping rather than reloading
    every time.
  Added optional throttling when sound is off.
  Added a help dialog to the debugger, <F1>.
  Debugger now keeps track of the last folder you opened a rom from.
  Fixed a debugger bug preventing <F10> from working as expected.
  Fixed a debugger bug causing a crash on exit.
  Fixed a bug preventing the debugger from finding the EXEC and GROM files.

--------------------------------------
Updates since version 3.3:
  Added the ability to run with nonstandard EXEC and GROM files, such as the
    miniexec and minigrom provided with Joe Zbiciak's SDK-1600. Just name the
    files "exec.bin" and "grom.bin" and drop them in the folder with Nostalgia.
    Added the ability to use either joystick to move the mouse cursor.  Thanks
    to Steve Hoogerhyde for suggesting this one.
  Greatly enhanced keyboard navigation in the menus.  <ESC> now goes back a
    menu or selects "Cancel".  <ENTER> selects "Save".
  Fixed a bug in the colorstack display routine.  Thanks to Joe Zbiciak for
    discovering this and mysteriously knowing exactly where the problem was.
  Fixed a bug Chuck Whitby was kind enough to find for me.  What a guy!
  Fixed a bug that was preventing Chess in Triple Action from working.

--------------------------------------
Updates since version 3.2:
  AVI format movies can now be recorded while playing a game!  By pressing <F8>, 
    all screen activity and sound is recorded to an AVI file at a maximum of
    15 frames per second.
  Screen captures are now saved in Windows Bitmap format.
  Screenshots and other captures now reside in their own directory.
    \nostalgia\captures\
  Captures are now named based on the game you're playing.  For example, a sound
    caputre while playing Atlantis might look like:
      Atlantis00001.wav
  Multiple captures are now possible, up to 99999 separate captures of a type per
    game.  For example, if you took 3 screenshots while playing Snafu, they would
    be saved as:
      Snafu00001.bmp
      Snafu00002.bmp
      Snafu00003.bmp
  Old capture files will never be overwritten by Nostalgia.  A new filename is
    chosen each time.
  Command line options have been redone for flexibility. See "Command Line Options"
    below for more information.

--------------------------------------
Updates since version 3.1:
  Added Sound Capture capability!  Now, by pressing <F10>, whatever sounds and 
    music are playing in the game get recorded to a wave file.  Capture those cool
    Snafu snake noises, or use some Astrosmash sounds on your desktop! 
  A big "Thank You" to Jorg Schafer for this feature. 
  Ein grosses "danken Ihnen" zu Jorg Schafer f�r diese Eigenschaft. 
  Added 2 command line options:
    A rom may now be specified on the command line in quotes 
      (nostalgia "c:\roms\digdug.bin") to allow the use of frontends for Nostalgia. 
      Thanks to Remi Juneau for this one.
    The screen resolution may be specified on the command line.
      320, 640, 800, 1024.


--------------------------------------
Updates since version 3.0:
  Fixed a bug in the Networking that was preventing Network play.
  Fixed type ahead to work with numeric game names (4-Tris, etc)
  Added "Home" and "End" capability to Load Cartridge screen.
  Changed the way video memory is used to fix a problem that was causing Nostalgia
    to stop working unexpectedly on some video cards.
  Generally reworked code for more efficiency, especially the core chip code.

--------------------------------------
Updates since version 2.5:
  Added ECS support!  Keyboard and music keyboard are supported.
  Added a real Windows help file.
  Made more improvemnts to the menuing system.
  Added "Type Ahead" to the Load Cartridge screen.  You may now press the first
   letter of the game you want to play to jump to it in the list.
  Made improvements to the way joysticks are handled to allow multiple joysticks
   with the same name to function properly.
  Fixed a big, ugly bug in the joystick routine that was causing a dump from
    the game under certain circumstances.  Thanks to Michael Mellor for catching
    this one.
  Changed the quick save and restore to properly save and restore ECS and 
   ROM format games.

Debugger-specific updates:
  Added the ability to look at the main memory map, the cartridge map or ECS ROM.
  Added selections for ECS support and Intellivoice support (Intellivoice not
   actually supported, yet)

--------------------------------------
Updates since version 2.2: 
  Added the ability to open games that aren't in Nostalgia's database.  Any game that
   is in ROM format or has a config (.cfg) file with it can be opened.
  Complete support for Intellicart ROM format.
  Complete support for Intellicart ROM bankswitching.
  Removed a lot of annoyances in Nostalgia.  Having to press a key at the splash
   screen, the initial dialog box, and other nitpicky things.
--------------------------------------
Updates since version 2.0: 
  Added the "Add File to Database" button.  This allows a new game to be added to
  Nostalgia's database.
  Added preliminary support for Intellicart ROM file format.
  Overhauled the sound system.
  Added support for the Classic Game Controller interface (more on this later).
--------------------------------------
Updates since version 1.0: 
  Added support for playing Nostalgia over the Internet!
  Needs *much* more testing.  There still may be sync problems, and the client player
   can't do much other than play the game.
--------------------------------------
