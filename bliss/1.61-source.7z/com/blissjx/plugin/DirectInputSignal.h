
#ifndef DIRECTINPUTSIGNAL_H
#define DIRECTINPUTSIGNAL_H

#include <windows.h>

class DirectInputDevice;

class DirectInputSignal
{
    friend class DirectInputDevice;

    public:
        DirectInputSignal(const DirectInputSignal&);
        ~DirectInputSignal();
        const CHAR* getDescription();
        const CHAR* getConfigKey();

    private:
        DirectInputSignal(UINT64, UINT64, const CHAR*);
        
        CHAR* description;
        CHAR  configKey[256];
        UINT64 deviceID;
        UINT64 controlID;

};

#endif
