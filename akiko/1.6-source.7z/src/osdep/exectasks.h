 /*
  * UAE - The Un*x Amiga Emulator
  *
  * Stack magic definitions for autoconf.c
  *
  * Copyright 1997 Bernd Schmidt
  */

#include <setjmp.h>

#undef CAN_DO_STACK_MAGIC

#if defined __GNUC__ && defined __GNUC_MINOR__
#if defined __i386__ && (__GNUC__ > 2 || __GNUC_MINOR__ >= 7)
#define CAN_DO_STACK_MAGIC
#endif
#endif

#if defined _MSC_VER && !defined( _WIN32_WCE )
#define CAN_DO_STACK_MAGIC
#endif
