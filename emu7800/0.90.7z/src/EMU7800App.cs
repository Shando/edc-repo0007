/*
 * EMU7800App.cs
 * 
 * Main application class for EMU7800.
 * 
 * Copyright (c) 2004-2005 Mike Murphy
 * 
 */

using System;
using System.Collections.Specialized;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using EMU7800.Host;
using EMU7800.Machine;
using EMU7800.UI;

namespace EMU7800
{
    public sealed class EMU7800App : IDisposable
    {
        public static string Title
        {
            get
            {
                var myAss = Assembly.GetExecutingAssembly();
                var obj = myAss.GetCustomAttributes(typeof(AssemblyTitleAttribute), false);
                var attr = (AssemblyTitleAttribute)obj[0];
                return attr.Title;
            }
        }

        public static string Version
        {
            get
            {
                var myAss = Assembly.GetExecutingAssembly();
                return myAss.GetName().Version.ToString();
            }
        }

        public static string Copyright
        {
            get
            {
                var myAss = Assembly.GetExecutingAssembly();
                var obj = myAss.GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);
                var attr = (AssemblyCopyrightAttribute)obj[0];
                return attr.Copyright;
            }
        }

        public static Version ClrVersion
        {
            [DebuggerStepThrough]
            get { return Environment.Version; }
        }
        public static OperatingSystem OSVersion
        {
            [DebuggerStepThrough]
            get { return Environment.OSVersion; }
        }

        private readonly ROMProperties ROMProperties;

        public EMU7800App()
        {
            EMUTraceListener.Instance.Start();

            ROMProperties = new ROMProperties();

            Trace.Write(Title);
            Trace.Write(" v");
            Trace.Write(Version);
            Debug.Write(" DEBUG");
            Trace.WriteLine("");
            Trace.WriteLine(Copyright);

            Trace.Write("CLR Version: ");
            Trace.WriteLine(ClrVersion);

            Trace.Write("OS Version: ");
            Trace.WriteLine(OSVersion);

            Trace.Write("High resolution timer available: ");
            Trace.WriteLine(Stopwatch.IsHighResolution ? "yes" : "no");

            Trace.Write("Timer frequency ");
            Trace.Write(Stopwatch.Frequency);
            Trace.WriteLine(" ticks per second");

            NameValueCollection hostsConfig = null;
            try
            {
                hostsConfig = ConfigurationManager.GetSection("EMU7800/HostTypes") as NameValueCollection;
            }
            catch (ConfigurationErrorsException ex)
            {
                Trace.WriteLine(ex);
            }

            if (hostsConfig != null)
            {
                foreach (string hostName in hostsConfig)
                {
                    try
                    {
                        var type = Type.GetType(hostsConfig[hostName]);
                        if (type != null)
                        {
                            var host = Activator.CreateInstance(type) as HostBase;
                            if (host != null)
                            {
                                HostBase.RegisterHost(hostName, host);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        if (Utility.IsCriticalException(ex))
                        {
                            throw;
                        }
                        Trace.WriteLine(ex.Message);
                    }
                }
            }

            Trace.WriteLine("Available Hosts:");
            foreach (var name in HostBase.RegisteredHostNames)
            {
                Trace.WriteLine(name);
            }
        }

        public void Run(string[] args)
        {
            if (args.Length > 0 && File.Exists(args[0]))
            {
                var fi = new FileInfo(args[0]);
                var gameSettings = ROMProperties.GetGameSettings(Utility.ComputeMD5Digest(fi));
                gameSettings.FileInfo = fi;
                using (var M = MachineBase.New(gameSettings, Cart.New(gameSettings), new InputAdapter()))
                {
                    try
                    {
                        HostBase.New(args.Length > 1 ? args[1] : GlobalSettings.Instance.HostSelect).Run(M);
                    }
                    catch (Exception ex)
                    {
                        if (Utility.IsCriticalException(ex))
                        {
                            throw;
                        }
                        MessageBox.Show(ex.ToString(), Title, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                Trace.WriteLine("Command-line usage: EMU7800.exe <rom filename> [host select string]");
                Trace.WriteLine("Launching GUI interface...");
                Application.Run(new ControlPanelForm(ROMProperties));
                GlobalSettings.Instance.Save();
            }
        }

        public void Dispose()
        {
        }

        [STAThread]
        public static void Main(string[] args)
        {
            using (var app = new EMU7800App())
            {
                app.Run(args);
            }
        }
    }
}