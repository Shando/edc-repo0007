/*
 * HostGdi
 *
 * A GDI-based Host.
 *
 * Copyright (c) 2003-2007 Mike Murphy
 *
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Windows.Forms;
using EMU7800.Machine;

namespace EMU7800.Host.Gdi
{
    public class HostGdiForm : Form
    {
        private HostGdi H { get; set; }
        private MachineBase M { get; set; }

        byte[] _ScanlineBuffer;
        Rectangulator _Rectangulator;
        bool _ReqRefresh;

        Font _TextFont;
        SolidBrush _TextBrush;
        Graphics _RGraphics;
        readonly SolidBrush _SBrush = new SolidBrush(Color.Black);

        Dictionary<Keys, HostInput> _KeyBindings;

        Stopwatch _Stopwatch;
        const int FRAME_SAMPLES = 120;
        long _startOfCycleTick, _endOfCycleTick;
        int _FrameRectangleCount;
        readonly int[] _RunMachineTicks = new int[FRAME_SAMPLES];
        readonly int[] _WaitTicks = new int[FRAME_SAMPLES];
        readonly int[] _Rectangles = new int[FRAME_SAMPLES];

        private HostGdiForm()
        {
            InitializeComponent();
        }

        public HostGdiForm(HostGdi host) : this()
        {
            if (host == null) throw new ArgumentNullException("host");
            H = host;
        }

        public void Run(MachineBase m)
        {
            Trace.WriteLine("GDI Host startup");

            M = m;

            Text = EMU7800App.Title;

            _ScanlineBuffer = new byte[M.VisiblePitch];
            var r = new Rectangulator(M.VisiblePitch, M.Scanlines);
            r.UpdateRect += OnUpdateRect;
            r.Palette = M.GetPalette();
            r.PixelAspectXRatio = 320 / M.VisiblePitch;
            r.OffsetLeft = 0;
            r.ClipTop = M.FirstScanline;
            r.ClipHeight = 240;
            r.UpdateTransformationParameters();
            _Rectangulator = r;

            ShowInTaskbar = true;
            FormBorderStyle = FormBorderStyle.Sizable;
            CenterToScreen();

            ClientSize = new Size(640, 480);
            MinimumSize = new Size(320 + 8, 240 + 27);
        
            // Enable double-buffering to avoid flicker
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.DoubleBuffer, true);

            _TextFont = new Font("Courier New", 18);
            _TextBrush = new SolidBrush(Color.White);

            InitializeKeyBindings();

            Paint += OnPaint;
            Layout += OnLayout;
            Closing += OnClosing;

            MouseDown += (sender, e) => OnMouseClick(e, true);
            MouseUp += (sender, e) => OnMouseClick(e, false);
            MouseMove += (sender, e) => OnMouseMove_(e);

            KeyDown += (sender, e) => OnKeyPress(e, true);
            KeyUp += (sender, e) => OnKeyPress(e, false);
            KeyPreview = true;

            Show();

            _ReqRefresh = true;

            Run();

            Trace.WriteLine("GDI Host shutdown");

            Close();
        }

        void Run()
        {
            _Stopwatch = new Stopwatch();
            _Stopwatch.Start();
            _endOfCycleTick = _Stopwatch.ElapsedTicks;

            while (true)
            {
                _startOfCycleTick = _endOfCycleTick;

                _FrameRectangleCount = 0;

                Application.DoEvents();

                if (H.Ended || !Created)
                {
                    break;
                }

                if (_ReqRefresh)
                {
                    _RGraphics.Clear(Color.Black);
                    _Rectangulator.DrawEntireFrame(H.Paused);
                    _ReqRefresh = false;
                }

                if (!H.Paused && !M.MachineHalt)
                {
                    M.RunFrame();
                    SubmitFrameToRectangulator();
                }
                else if (H.Paused)
                {
                    for (var i = 0; i < M.SoundFrameBuffer.Length; i++)
                    {
                        M.SoundFrameBuffer[i] = 0;
                    }
                }

                ShowPostedMsg();

                var endOfRunMachineTick = _Stopwatch.ElapsedTicks;

                while (H.EnqueueAudio(M.SoundFrameBuffer) == 1)
                {
                }

                _endOfCycleTick = _Stopwatch.ElapsedTicks;

                var statIndex = (int)M.FrameNumber % FRAME_SAMPLES;
                _RunMachineTicks[statIndex] = (int)(endOfRunMachineTick - _startOfCycleTick);
                _WaitTicks[statIndex] = (int)(_endOfCycleTick - endOfRunMachineTick);
                if (_FrameRectangleCount != 0)
                {
                    _Rectangles[statIndex] = _FrameRectangleCount;
                }
            }

            H.CloseAudio();
        }

        void InitializeKeyBindings()
        {
            _KeyBindings = new Dictionary<Keys, HostInput>
            {
                {Keys.Escape,       HostInput.End},
                {Keys.P,            HostInput.Pause},
                {Keys.ControlKey,   HostInput.Fire},
                {Keys.Menu,         HostInput.Fire2},
                {Keys.Left,         HostInput.Left},
                {Keys.Up,           HostInput.Up},
                {Keys.Right,        HostInput.Right},
                {Keys.Down,         HostInput.Down},
                {Keys.NumPad7,      HostInput.NumPad7},
                {Keys.NumPad8,      HostInput.NumPad8},
                {Keys.NumPad9,      HostInput.NumPad9},
                {Keys.NumPad4,      HostInput.NumPad4},
                {Keys.NumPad5,      HostInput.NumPad5},
                {Keys.NumPad6,      HostInput.NumPad6},
                {Keys.NumPad1,      HostInput.NumPad1},
                {Keys.NumPad2,      HostInput.NumPad2},
                {Keys.NumPad3,      HostInput.NumPad3},
                {Keys.Multiply,     HostInput.NumPadMult},
                {Keys.NumPad0,      HostInput.NumPad0},
                {Keys.Divide,       HostInput.NumPadDiv},
                {Keys.D1,           HostInput.LeftDifficulty},
                {Keys.D2,           HostInput.RightDifficulty},
                {Keys.F1,           HostInput.SetKeyboardToPlayer1},
                {Keys.F2,           HostInput.SetKeyboardToPlayer2},
                {Keys.F3,           HostInput.SetKeyboardToPlayer3},
                {Keys.F4,           HostInput.SetKeyboardToPlayer4},
                {Keys.F5,           HostInput.PanLeft},
                {Keys.F6,           HostInput.PanRight},
                {Keys.F7,           HostInput.PanUp},
                {Keys.F8,           HostInput.PanDown},
                {Keys.F11,          HostInput.SaveMachine},
                {Keys.F12,          HostInput.Unknown},
                {Keys.C,            HostInput.Color},
                {Keys.F,            HostInput.Unknown},
                {Keys.M,            HostInput.Mute},
                {Keys.R,            HostInput.Reset},
                {Keys.S,            HostInput.Select}
            };
        }

        void OnMouseClick(MouseEventArgs e, bool down)
        {
            if (!H.Paused && e.Button == MouseButtons.Left)
            {
                H.RaiseInput(HostInput.Fire, down);
            }
        }

        void OnMouseMove_(MouseEventArgs e)
        {
            H.RaiseLightGunInput(Width, e.X, e.Y);
            H.RaisePaddleInput(Width, e.X);
        }

        void OnKeyPress(KeyEventArgs e, bool down)
        {
            if (_KeyBindings.ContainsKey(e.KeyCode))
            {
                switch (e.KeyCode)
                {
                    case Keys.F:
                        if (down)
                        {
                            double rmTicks = 0.0, wTicks = 0.0, avgRectPerFrame = 0.0;
                            for (var i=0; i < FRAME_SAMPLES; i++)
                            {
                                rmTicks += _RunMachineTicks[i];
                                wTicks += _WaitTicks[i];
                                avgRectPerFrame += _Rectangles[i];
                            }
                            rmTicks = rmTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
                            wTicks = wTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
                            avgRectPerFrame /= FRAME_SAMPLES;
                            double fps = 1000.0 / (rmTicks + wTicks);
                            H.PostedMsg = string.Format("{0}/{1} FPS {2:0.0}+{3:0.0}={4:0.0}/{5:0.0} ms {6:0.0} RPF", Math.Round(fps, 0), H.EffectiveFPS, rmTicks, wTicks, rmTicks + wTicks, 1000.0 / H.EffectiveFPS, avgRectPerFrame);
                        }
                        break;
                    case Keys.F5:
                        if (down)
                        {
                            _Rectangulator.OffsetLeft++;
                            _Rectangulator.UpdateTransformationParameters();
                            _ReqRefresh = true;
                        }
                        break;
                    case Keys.F6:
                        if (down)
                        {
                            _Rectangulator.OffsetLeft--;
                            _Rectangulator.UpdateTransformationParameters();
                            _ReqRefresh = true;
                        }
                        break;
                    case Keys.F7:
                        if (down)
                        {
                            _Rectangulator.ClipTop++;
                            _Rectangulator.UpdateTransformationParameters();
                            _ReqRefresh = true;
                        }
                        break;
                    case Keys.F8:
                        if (down)
                        {
                            _Rectangulator.ClipTop--;
                            _Rectangulator.UpdateTransformationParameters();
                            _ReqRefresh = true;
                        }
                        break;
                    case Keys.F12:
                        if (down)
                        {
                            H.PostedMsg = "Screenshot not supported";
                        }
                        break;
                    default:
                        H.RaiseInput(_KeyBindings[e.KeyCode], down);
                        break;
                }
            }
            else
            {
                H.RaiseInput(HostInput.Unknown, down);
            }

            e.Handled = true;
        }

        bool _RenderedTextMsg;

        void ShowPostedMsg()
        {
            if (H.PostedMsg.Length > 0)
            {
                ClearTextMsg();
                ShowTextMsg();
                _RenderedTextMsg = true;
            }
            else if (_RenderedTextMsg)
            {
                ClearTextMsg();
            }
        }

        void ShowTextMsg()
        {
            _TextBrush.Color = Color.White;
            _RGraphics = CreateGraphics();
            _RGraphics.TextRenderingHint = TextRenderingHint.SystemDefault;
            _RGraphics.DrawString(H.PostedMsg, _TextFont, _TextBrush, 0, 0);
            _RenderedTextMsg = true;
        }

        void ClearTextMsg()
        {
            _TextBrush.Color = Color.Black;
            _RGraphics.FillRectangle(_TextBrush, 0, 0, ClientSize.Width, 30);
            _RenderedTextMsg = false;
        }

        void OnLayout(object sender, LayoutEventArgs e)
        {
            _RGraphics = CreateGraphics();
            _RGraphics.CompositingMode = CompositingMode.SourceCopy;
            _RGraphics.CompositingQuality = CompositingQuality.Invalid;
            _RGraphics.SmoothingMode = SmoothingMode.None;
            _RGraphics.InterpolationMode = InterpolationMode.NearestNeighbor;

            _Rectangulator.ViewPortSize = ClientSize;
            _Rectangulator.UpdateTransformationParameters();

            _ReqRefresh = true;
        }

        void OnClosing(object sender,  CancelEventArgs e)
        {
            if (!H.Ended)
            {
                // if game is running, veto close request while arranging for game loop termination
                // this facilitates cleaning things up nicely
                H.RaiseInput(HostInput.End, true);
                e.Cancel = true;
            }
        }

        void OnPaint(object sender, PaintEventArgs e)
        {
            _ReqRefresh = true;
        }

        void SubmitFrameToRectangulator()
        {
            _Rectangulator.StartFrame();
            for (var scanline = 0; scanline < M.Scanlines; scanline++)
            {
                for (var x = 0; x < M.VisiblePitch; x++)
                {
                    _ScanlineBuffer[x] = M.VideoFrameBuffer[scanline * M.VisiblePitch + x];
                }
                // TODO: Rectangulator should be enhanced to just consume the entire VideoFrameBuffer
                _Rectangulator.InputScanline(_ScanlineBuffer, scanline, 0, M.VisiblePitch);
            }
            _Rectangulator.EndFrame();
        }

        void OnUpdateRect(DisplRect r)
        {
            _SBrush.Color = Color.FromArgb(r.Argb);
            _RGraphics.FillRectangle(_SBrush, r.Rectangle);
            _FrameRectangleCount++;
        }

        private void InitializeComponent()
        {
            var resources = new ComponentResourceManager(typeof(HostGdiForm));
            SuspendLayout();
            // 
            // HostGdiForm
            // 
            ClientSize = new Size(284, 264);
            Icon = ((Icon)(resources.GetObject("$this.Icon")));
            Name = "HostGdiForm";
            ResumeLayout(false);

        }
    }

    public class HostGdi : HostBase
    {
        private HostGdiForm F;

        public override void Run(MachineBase m)
        {
            base.Run(m);
            F = new HostGdiForm(this);
            try
            {
                F.Run(M);
            }
            finally
            {
                F.Dispose();
                F = null;
            }
        }
    }
}