/*
 * EMU][ Apple ][-class emulator
 * Copyright (C) 2002, 2003 by the EMU][ Project/Dapple ][ Team
 *
 * This component last revised 2003.0610 (0.30 Final)
 *
 * Component:  Header file for Dapple shared components
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#define structpack __attribute__((packed))

typedef enum {USA, France, Germany, UK, Denmark1, Sweden, Italy, Spain,
              Japan, Norway, Denmark2, None} Charset;
typedef unsigned char byte;
typedef unsigned short int word;


/* type of apple */
#define APPLEII 1
#define APPLEIIE 2
#define APPLEIIC 4

/* window size of standard menus */
#define WINDOWXSIZE 512
#define WINDOWYSIZE 256

/* rgb values */
#define RGBBLACK        0x000000
#define RGBDARK         0x202020
#define RGBLIGHT        0xc0c0c0
#define RGBWHITE        0xffffff
#define RGBLBLUE        0x3050ff
/* slot drive lights */
#define SLOTX1 628
#define SLOTX2 632
#define SLOT5Y 10
#define SLOT6Y 14
#define RGBLGHTON 0xff0000
#define RGBLGHTOFF 0x404040


/* cpu65c02.c */
#define STATEHALT  0x01
#define STATERESET 0x02
#define STATENMI   0x04
#define STATEIRQ   0x08
#define STATEBRK   0x10
#define STATETRACE 0x20
#define STATEBPT   0x40
#define STATEGURU  0x80


/* video.c */
/* Color definitions */

/* Lo-res graphics */
#define COL_LGR0 0xc0
#define COL_LGR1 0xc1
#define COL_LGR2 0xc2
#define COL_LGR3 0xc3
#define COL_LGR4 0xc4
#define COL_LGR5 0xc5
#define COL_LGR6 0xc6
#define COL_LGR7 0xc7
#define COL_LGR8 0xc8
#define COL_LGR9 0xc9
#define COL_LGRA 0xca
#define COL_LGRB 0xcb
#define COL_LGRC 0xcc
#define COL_LGRD 0xcd
#define COL_LGRE 0xce
#define COL_LGRF 0xcf

/* Hi-res graphics */
#define COL_HGR0 0xd0
#define COL_HGR1 0xd1
#define COL_HGR2 0xd2
#define COL_HGR3 0xd3
#define COL_HGR4 0xd4
#define COL_HGR5 0xd5
#define COL_HGR6 0xd6
#define COL_HGR7 0xd7

/* Text mode */
#define COL_TXT_WHT0 0xd8
#define COL_TXT_WHT1 0xd9
#define COL_TXT_GRN0 0xda
#define COL_TXT_GRN1 0xdb
#define COL_TXT_AMB0 0xdc
#define COL_TXT_AMB1 0xdd


/* disk.c */
typedef struct {
  unsigned char slot            structpack;
  unsigned char drive           structpack;
  unsigned char path[260]       structpack;
  unsigned char type            structpack;
  int           volume          structpack;
  unsigned int  phase           structpack;
  unsigned int  tracksize       structpack;
  unsigned int  track           structpack;
  unsigned int  bytepointer     structpack;
  unsigned char access          structpack;
  unsigned char changed         structpack;
  unsigned char writeprotected  structpack;
  unsigned char data[233472]    structpack;
} drivedisk;
