
#ifndef JOYPAD_H
#define JOYPAD_H

class JoyPad
{



};

#endif
