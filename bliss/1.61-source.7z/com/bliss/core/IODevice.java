package com.bliss.core;

import com.bliss.core.devices.*;

public interface IODevice
{

    public void reset();

    public void poll();

    public int getControlCount();

    public int getControlID(int controlNum);

    public String getControlDescription(int controlNum);

    public void setInputDevice(InputDevice inputDevice);

    public int getInputValue();

    public void setOutputValue(int value);

}
