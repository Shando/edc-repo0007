/*
 * DirectInput
 *
 * Utility class for acquiring input using DirectInput
 *
 * Copyright (c) 2007 Mike Murphy
 *
 */
using System;
using System.Diagnostics;
using EMU7800.Host.DirectX;

namespace EMU7800.Host
{
    public delegate void JoystickChangedHandler(int joystickno, bool left, bool right, bool up, bool down, bool fire, bool fire2);
    public delegate void StelladaptorPaddleChangedHandler(int paddleno, int val, bool fire);
    public delegate void MousePaddleChangedHandler(int val, bool fire);
    public delegate void MouseChangedHandler(int dx, int dy, bool fire);
    public delegate void KeyboardChangedHandler(Key key, bool down);

    internal class DirectInput : IDisposable
    {
        #region Fields

        private const int
            JOYSTICK_RANGE    = 1000,
            JOYSTICK_DEADZONE = 100;

        private struct LastJoystickInput
        {
            public bool Left, Right, Up, Down, Fire, Fire2;
        };

        private struct LastPaddleInput
        {
            public int Val;
            public bool Fire;
        };

        private readonly LastJoystickInput[] _LastJoystickInput = new LastJoystickInput[2];
        private readonly LastPaddleInput[] _LastStelladaptorPaddleInput = new LastPaddleInput[2];
        private LastPaddleInput _LastMousePaddleInput;
        private readonly bool[] _LastKeyboardInput = new bool[0x100];

        #endregion

        #region Public Members

        public JoystickChangedHandler JoystickChanged;
        public StelladaptorPaddleChangedHandler StelladaptorPaddleChanged;
        public MousePaddleChangedHandler MousePaddleChanged;
        public MouseChangedHandler MouseChanged;
        public KeyboardChangedHandler KeyboardChanged;

        public int MousePaddleRange { get; private set; }

        public static int StelladaptorPaddleRange
        {
            [DebuggerStepThrough]
            get { return JOYSTICK_RANGE << 1; }
        }

        public bool IsStelladaptor(int deviceno)
        {
            return DirectInputNativeMethods.IsStelladaptor(deviceno);
        }

        public bool Poll(bool reacquireIfNecessary)
        {
            if (!DirectInputNativeMethods.Poll(reacquireIfNecessary)) return false;

            if (DirectInputNativeMethods.IsStelladaptor(0))
            {
                RaiseStelladaptorPaddleChangedIfNecessary(0);
                RaiseStelladaptorPaddleChangedIfNecessary(1);
            }
            RaiseJoystickChangedIfNecessary(0);

            if (DirectInputNativeMethods.IsStelladaptor(1))
            {
                RaiseStelladaptorPaddleChangedIfNecessary(2);
                RaiseStelladaptorPaddleChangedIfNecessary(3);
            }
            RaiseJoystickChangedIfNecessary(1);

            RaiseMousePaddleChangedIfNecessary();
            RaiseMouseChangedIfNecessary();

            RaiseKeyboardChanged();

            return true;
        }

        #endregion

        #region Constructor and Dispose Members

        private DirectInput()
        {
        }

        public DirectInput(IntPtr handle, bool fullScreen)
        {
            MousePaddleRange = JOYSTICK_RANGE;
            if (!DirectInputNativeMethods.Initialize(handle, fullScreen, JOYSTICK_RANGE))
            {
                var message = string.Format("Unable to initialize DirectInput: HR={0:X8}", DirectInputNativeMethods.HResult);
                throw new ApplicationException(message);
            }
        }

        public void Dispose()
        {
            DirectInputNativeMethods.Shutdown();
        }

        #endregion

        #region Helpers

        void RaiseJoystickChangedIfNecessary(int deviceno)
        {
            if (JoystickChanged == null) return;

            int x, y;
            DirectInputNativeMethods.ReadJoystickPosition(deviceno, out x, out y);

            var left = x < -JOYSTICK_DEADZONE;
            var right = x > JOYSTICK_DEADZONE;
            var up = y < -JOYSTICK_DEADZONE;
            var down = y > JOYSTICK_DEADZONE;

            var fire1 = DirectInputNativeMethods.ReadJoystickButtonState(deviceno, 0);
            var fire2 = DirectInputNativeMethods.ReadJoystickButtonState(deviceno, 1);

            if (left == _LastJoystickInput[deviceno].Left
                && right == _LastJoystickInput[deviceno].Right
                && up == _LastJoystickInput[deviceno].Up
                && down == _LastJoystickInput[deviceno].Down
                && fire1 == _LastJoystickInput[deviceno].Fire
                && fire2 == _LastJoystickInput[deviceno].Fire2) return;

            _LastJoystickInput[deviceno].Left = left;
            _LastJoystickInput[deviceno].Right = right;
            _LastJoystickInput[deviceno].Up = up;
            _LastJoystickInput[deviceno].Down = down;
            _LastJoystickInput[deviceno].Fire = fire1;
            _LastJoystickInput[deviceno].Fire2 = fire2;
            JoystickChanged(deviceno, left, right, up, down, fire1, fire2);
        }

        void RaiseStelladaptorPaddleChangedIfNecessary(int paddleno)
        {
            if (StelladaptorPaddleChanged == null) return;

            var deviceno = paddleno >> 1;
            paddleno &= 3;

            int x, y;
            DirectInputNativeMethods.ReadJoystickPosition(deviceno, out x, out y);

            var val = (((paddleno & 1) == 0) ? x : y) + JOYSTICK_RANGE;
            var fire = DirectInputNativeMethods.ReadJoystickButtonState(deviceno, paddleno & 1);

            if (val == _LastStelladaptorPaddleInput[paddleno].Val
                && fire == _LastStelladaptorPaddleInput[paddleno].Fire) return;

            _LastStelladaptorPaddleInput[paddleno].Val = val;
            _LastStelladaptorPaddleInput[paddleno].Fire = fire;
            StelladaptorPaddleChanged(paddleno, val, fire);
        }

        void RaiseMousePaddleChangedIfNecessary()
        {
            if (MousePaddleChanged == null) return;

            int dx, dy;
            DirectInputNativeMethods.ReadMouseMovement(out dx, out dy);

            var val = dx;
            var fire = DirectInputNativeMethods.ReadMouseButtonState(0);

            if (val == 0 && fire == _LastMousePaddleInput.Fire) return;

            _LastMousePaddleInput.Val += val;
            _LastMousePaddleInput.Fire = fire;

            if (_LastMousePaddleInput.Val < 0) _LastMousePaddleInput.Val = 0;
            else if (_LastMousePaddleInput.Val > MousePaddleRange) _LastMousePaddleInput.Val = MousePaddleRange;

            MousePaddleChanged(_LastMousePaddleInput.Val, _LastMousePaddleInput.Fire);
        }

        void RaiseMouseChangedIfNecessary()
        {
            if (MouseChanged == null) return;

            int dx, dy;
            DirectInputNativeMethods.ReadMouseMovement(out dx, out dy);

            MouseChanged(dx, dy, DirectInputNativeMethods.ReadMouseButtonState(0));
        }

        void RaiseKeyboardChanged()
        {
            if (KeyboardChanged == null) return;

            for (var i = 0; i < 0x100; i++)
            {
                var down = DirectInputNativeMethods.ReadKeyState(i);
                if (down ^ _LastKeyboardInput[i]) KeyboardChanged((Key)i, down);
                _LastKeyboardInput[i] = down;
            }
        }

        #endregion
    }
}
