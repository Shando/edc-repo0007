
#include <windows.h>
#include <jni.h>

extern "C" {

//main entry point for the dll
BOOL WINAPI DllMain(HANDLE hInst, ULONG ul_reason_for_call, LPVOID lpReserved)
{
    return TRUE;
}

}

