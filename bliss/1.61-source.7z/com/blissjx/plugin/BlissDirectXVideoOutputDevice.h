
#ifndef _DIRECTXVIDEOOUTPUTDEVICE_H_
#define _DIRECTXVIDEOOUTPUTDEVICE_H_

#include <D3d8.h>
#include <D3dx8tex.h>
#include <D3d8types.h>
#include <jni.h>

extern "C"
{

//struct to hold instance data
struct DirectXVideoOutputDeviceClass
{
    //reference to the jvm
    JavaVM* jvm;

    //reference to the env for the DirectX thread
    JNIEnv* env;

    //reference to the current Intellivision
    jobject inty;

    //reference to the current image data
    jbyteArray imageData;

    //display parameters
    D3DPRESENT_PARAMETERS presentation;
    UINT      resolutionX;
    UINT      resolutionY;
    UINT      refreshRate;
    D3DFORMAT displayFormat;
    BOOL      fullScreen;
    BOOL      filtered;

    //display device data
    HWND                    m_hWnd;
    DWORD                   m_directXThreadID;
    HANDLE                  m_hDirectXThreadHandle;
    HANDLE                  m_hEventObject;
    IDirect3D8*             m_pD3D;
    IDirect3DDevice8*       m_pd3dDevice;
    IDirect3DVertexBuffer8* m_pVB;
    IDirect3DTexture8*      m_pMemTexture;
    WORD*                   m_pMemPalette;
    D3DSURFACE_DESC         m_pMemDesc;
    IDirect3DTexture8*      m_pCardTexture;

};

}

#endif

