/* faux1 terminal Apple 1 emulator
 * Portions Copyright (C) 2012 James M. Reneau (renejm@users.sourceforge.net)
 *
 * napple1 ncurses Apple 1 emulator
 * Copyright (C) 2008 Nobu Hatano
 *
 * Pom1 Apple 1 Emulator
 * Copyright (C) 2000 Verhille Arnaud
 * Copyright (C) 2006 John D. Corrado
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
/*
 * Memory maap of faux1
 * 
 * Apple I 8K mode & faux1 64K mode, common usage
 * -----------------------------------------------------------------------
 * $0000           Ststem & User Space 
 * $0100 - $01FF   System Stack
 * $0200 - $027F   Input Buffer used by monitor
 * $0FFF
 * -----------------------------------------------------------------------
 * $D010	KBD	Keyboard input register. b7 is always 1 by hardware.
 * 		Read KBD will automatcically clear KBDCR's b7.
 * $D011	KBDCR	When key is pressed, b7 is set by hardware.
 * $D012	DSP	Bit b6..b0 is output character for the terminal.
 *	        Writing to DSP will set b7 by hardware.
 *              The termianl clear b7 after the character is accepted.
 * $D013	DSPCR	Unused.
 * -----------------------------------------------------------------------
 * $E000        Apple I Integer BASIC
 * $E2B3        Re-entry address
 * $EFFF
 * -----------------------------------------------------------------------
 * $FF00        Monitor
 * $FFEF	Echo
 * $FFFF	
 * ----------------------------------------------------------------------- 
 */
/* Apple I 8K mode memory map
 * --------------------------------- 
 * Start Type
 * addr
 * --------------------------------- 
 * $0000 4KB RAM
 * $1000 unused
 * $D010 Display and Keyboard I/O
 * $D014 unused
 * $E000 4KB RAM
 * $F000 unused
 * $FF00 256B ROM^ (Woz Monitor)
 * ---------------------------------
 * ^ ROM can be written by Load core  
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "pia6820.h"
#include "memory.h"
#include "screen.h"
#include "keyboard.h"
#include "strings.h"


#define MEMMAX 0xFFFF

static unsigned char mem[65536];
static int mode = 32; /* 8 = Apple I 8K mode, 32 = napple1 32K mode */

void flipMode(void)
{
	if (mode == 8)
		mode = 32;
	else 
		mode = 8;

	fprintf(stdout, MEMORY_MODE, mode);
}

int memMode(void) 
{
	return mode;
}

int loadROMFile(char *filename, unsigned short address, unsigned short length, char showmessage)
{
	// return 0 for fail 1 for success
	size_t s = 0;
	FILE *fd = fopen(filename, "rb");
	char input[256];
	
	if (!fd) {
		printf(MEMORY_FILEERROR, filename);
		return 0;
	}

	if (showmessage) {
		printf(MEMORY_ROMLOADPROMPT, filename, address);
		stringInput("", input,256);
		if (input[0] != 'y') return 0;
	}

	s = fread(&mem[address], 1, length, fd);
	if (s) {
		if (showmessage) printf(MEMORY_ROMGOOD, filename, address);
	} else {
		printf(MEMORY_FILEERROR, filename);
		return 0;
	}
	return 1;
}

int loadBasic(void)
{
	return loadROMFile("rom/basic.rom", 0xE000, 4096, 0);
}

int loadMonitor(void)
{
	return loadROMFile("rom/monitor.rom", 0xFF00, 256, 0);

}

void resetMemory(void)
{
	if (memMode() > 8)
		memset(mem, 0, 0xE000); /* rom is starting from 0xE000 */
	else
		memset(mem, 0, 0x10000 - 256); /* rom is within tail 256b */
}

unsigned char memRead(unsigned short address)
{
	if (address == 0xD013)
		return readDspCr();
	if (address == 0xD012)
		return readDsp();
	if (address == 0xD011)
		return readKbdCr();
	if (address == 0xD010) {
		unsigned char c = readKbd();
		return c;
	}


	return mem[address];
}

void memWrite(unsigned short address, unsigned char value)
{
	if (address < 0x1000)	
		mem[address] = value;
	else if (address < 0x8000 && (memMode() > 8) )
		mem[address] = value;
	else if (address == 0xD013)
		writeDspCr(value);
	else if (address == 0xD012)
		writeDsp(value);
	else if (address == 0xD011)
		writeKbdCr(value);
	else if (address == 0xD010)
		writeKbd(value);
	else if (address >= 0xE000 && address < 0xF000 && memMode() == 8)
		mem[address] = value;
	else
		;

	return;
}

int loadMemory(void)
{
	unsigned int address = 0x300;
	char filename[256];
	char type[256];

	if(!stringInput(MEMORY_FILETYPEPROMPT, type, 256)) return 0;
	
	if(!stringInput(MEMORY_FILENAMEPROMPT, filename, 256)) return 0;

	if ((type[0]&0x1f)==('A'&0x1f)) {

		 if (!loadMemoryASCII(filename)) return 0;

	} else {
		if(!stringInput(MEMORY_FILEADRESSPROMPT, type, 256)) return 0;
		if (sscanf(type, "%4X", &address) < 1) {
			fprintf(stderr, MEMORY_ADRESSSTARTERROR);
			return 0;
		}

		if (!loadMemoryBinary(filename, address)) return 0;

	}
	printf(MEMORY_FILEGOOD,filename);

	return 1;
}

int loadMemoryBinary(char *filename, unsigned short address) {
	// binary file read
	unsigned int i, size;

	FILE* fd = fopen(filename, "rb");
	if (!fd) {
		fprintf(stderr, MEMORY_FILEERROR, filename);
		return 0;
	}
										
	fseek(fd, 0, SEEK_END);
	size = (unsigned short)ftell(fd);
	fseek(fd, 0, SEEK_SET);

	for (i = 0; i < size; i++)
		memWrite(address+i, (unsigned char)fgetc(fd));
	
	fclose(fd);

	return 1;

}

int loadMemoryASCII(char *filename) {
	// ascii
	// file format must be
	// XXXX: xx xx xx xx 4 digit, 2 digit and spaces MUST be there)
	//
	// return 1 on success, 0 on failure
	//
	unsigned int i, address = 0x300, length;
	unsigned int value;
	char buffer[1024];

	FILE *fd = fopen(filename, "r");
	if (!fd) {
		fprintf(stderr, MEMORY_FILEERROR, filename);
		return 0;
	}
	while (!feof(fd)) {
		i = 0;
		if (!fgets(buffer, 1024, fd)) continue;
		length = strlen(buffer);
		// trim crap
		if (length>i && buffer[length-1]< 0x20) {
			length--;
			buffer[length] = 0x00;
		}
		if (buffer[0] == '/' || buffer[0] == '\n' || buffer[0] == 0x00) continue;
		if (buffer[0] != ':') {
			if (sscanf(buffer, "%4X", &address) < 1) continue;
			i = 6;
		} else {
			i = 2;
		}
		//printf("%4X %4X %4X - '%s'\n",address, length, i, buffer);
		// now get digits
		for (; i < length; i += 3) {			
			if (sscanf(&buffer[i], "%2X", &value) < 1) break;
			memWrite(address++, value);
		}
	}
	fclose(fd);
	return 1;
}
/*
static int saveMemoryFunc(void)
{
	unsigned short i, j, k, end, length;
	unsigned char *fbrut;
	char *strFile;

	if (step == 1)
	{
		strcpy(filename, buffer);

		drawString("Enter (A)scii or (B)inary:");

		max = 1;
	}
	else if (step == 2)
	{
		type = buffer[0];

		if (type != 'A' && type != 'a' && type != 'B' && type != 'b')
		{
			fprintf(stderr, "Invalid character for mode\n");
			return 0;
		}
									
		drawString("Enter starting address:");

		max = 4;
	}
	else if (step == 3)
	{	
		if (sscanf(buffer, "%4X", &start) < 1)
		{
			fprintf(stderr, "Invalid address for start\n");
			return 0;
		}

		drawString("Enter ending address:");
	}
	else if (step == 4)
	{
		if (sscanf(buffer, "%4X", &end) < 1)
		{
			fprintf(stderr, "Invalid address for end\n");
			return 0;
		}

		if (type == 'A' || type == 'a')
		{
			fd = fopen(filename, "w");

			if (!fd)
			{
				fprintf(stderr, "Could not open %s\n", filename);
				return 0;
			}

			fbrut = dumpMemory(start, end);

			strcpy(buffer, "// Pom1 Save - ");

			strFile = strrchr(filename, '/');

			if (!strFile)
			{
				strFile = strrchr(filename, '\\');

				if (!strFile)
					strFile = filename;
				else
					strFile++;
			}
			else
				strFile++;

			strcat(buffer, strFile);

			length = end - start + 1;

			for (i = 0, j = start; i < length; i++, k += 3)
			{
				if (i % 8 == 0)
				{
					fputs(buffer, fd);
					sprintf(buffer, "\n%04X: ", j);
					j += 8;
					k = 7;
				}

				sprintf(&buffer[k], "%02X ", fbrut[i]);
			}
			
			fputs(buffer, fd);
		}
		else
		{
			fd = fopen(filename, "wb");

			if (!fd)
			{
				fprintf(stderr, "Could not open %s\n", filename);
				return 0;
			}

			fbrut = dumpMemory(start, end);

			fwrite(fbrut, 1, end - start + 1, fd);
		}

		free(fbrut);

		fclose(fd);
		fd = NULL;

		return 0;
	}

	return 1;
}

void saveMemory(void)
{
	max = 1024;

	inputLoop("Enter file to save:", &saveMemoryFunc);
}

*/

