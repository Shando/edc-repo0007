package com.bliss.core;

import java.beans.*;

public interface ChoiceOption extends Option
{

    public Object[] getChoices();

}
