package com.blissj.app;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;

public class IconTableCellRenderer extends BlissTableCellRenderer
{

    public Component getTableCellRendererComponent(JTable table, Object value,
            boolean isSelected, boolean hasFocus, int row, int column) 
    {
        Component c = super.getTableCellRendererComponent(table, "", isSelected,
                hasFocus, row, column);
        setIcon((Icon)value);
        return c;
    }
 

}
