
WinUAE Akiko enhanced edition
=============================

General
=======

This is a special WinUAE version with extra functions
for the CD32/CDTV emulator Akiko. See http://www.airsoftsoftwair.com/
for more information.


Notes on the source
===================

The following source files were modified:

chg: win32.c (notify code)
chg: main.c (init and shut down code for Akiko added)
add: cd32.c
add: include/cd32.h 
chg: uaelib.c (calltrap(70) launches the Akiko control from the
               Amiga side)


Author
======

The CD32 stuff (cd32.c, include/cd32.h) was added by me,
Andreas Falkenhahn. Please see the other readme's for the
rest of the credits :)

--
Andreas Falkenhahn <andreas@airsoftsoftwair.de>
