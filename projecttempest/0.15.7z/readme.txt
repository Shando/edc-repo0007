
		Project Tempest v0.15 (13 October 2002)
		---------------------------------------


What is Project Tempest ?
-------------------------

Project Tempest is worlds first working Atari Jaguar emulator. It currently runs several
commercial games.


What is emulated ?
------------------

MC68000:    	Completely. Using Turbo68K by Bart Trzynadlowski

GPU: 	    	All the opcodes are emulated.

DSP:	    	Most of the opcodes are emulated. Interrupts are not correct. 
                 	Sound output is not implemented.

Object Processor: 	Everything is emulated, except 32-bit object and GPU objects

Blitter:		Most operations are emulated. Still very buggy and crashes many games.


System Requirements
--------------------

Pentium III/Athlon 800+ MHz
128MB RAM
DirectX 3 or higher
Windows 9x/ME/2000/XP

A faster processor is seriously recommended !

What's New IN Version 0.15
--------------------------

* DX8 Video System should work on all systems now!
* Implemented line-based renderer. More Accurate, a little slower.
* New controller code. Totally configurable, supports two Jaguar joypads.


How to use the emulator
------------------------

To load commercial games, select Open ROM from File menu. To start the game, press F2 or Start from
emulation menu.

To load homebrewn games and demos, select Open BIN from File menu. Write the addresses required and
press F2 or Start from emulation menu.

To stop the emulation, press F3 or Stop from emulation menu.


Settings
--------

Boot from Boot ROM: Keep this disabled, booting from Boot ROM doesn't work yet.
Disable DSP Emulation: This should usually be enabled. Only some games require DSP to be emulated.


Controls
--------

The emulator has a fixed key layout:

Jaguar Button   |   PC Keyboard

    A		    A
    B		    S
    C		    D
    Option		    O
    Pause		    P
    Up		    Up Arrow
    Down		    Down Arrow
    Left		    Left Arrow
    Right		    Right Arrow
    0...9		    0...9 on Numeric Keypad
    *		    * on Numeric Keypad
    #		    / on Numeric Keypad

Also in Pinball Fantasies, Shifts and Ctrls are mapped as the flipper keys.


Credits
-------

Emulator programming by Ville Linde

Website and support by The Fox (emuunlim@emuunlim.com)
Website design by Malc Jennings    