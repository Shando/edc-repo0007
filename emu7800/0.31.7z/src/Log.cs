/*
 * Log.cs
 * 
 * Logger for the entire application.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */ 

using System;
using System.Text;

namespace EMU7800 {

public delegate void LogUpdatedHandler(string msgs);

public class Log {
	public static event LogUpdatedHandler LogUpdated;
	private static StringBuilder MessageSpool = new StringBuilder();	private static bool LoggerStarted = false;	public static void StartLogger() {		LoggerStarted = true;		FlushSpool();	}	public static void Msg(String fmt, params Object[] objs) {		MessageSpool.AppendFormat(fmt, objs);		FlushSpool();	}	private static void FlushSpool() {		if (LogUpdated != null && LoggerStarted && MessageSpool.Length > 0) {			LogUpdated(MessageSpool.ToString().Replace("\n",				Environment.NewLine));			MessageSpool = new StringBuilder();		}	}}
}
