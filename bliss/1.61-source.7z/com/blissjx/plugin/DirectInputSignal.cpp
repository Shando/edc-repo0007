
#include <string.h>
#include <stdlib.h>
#include "DirectInputSignal.h"

DirectInputSignal::DirectInputSignal(UINT64 did, UINT64 cid,
        const CHAR* desc)
    : deviceID(did),
      controlID(cid)
{
    description = new CHAR[strlen(desc)];
    strcpy(description, desc);
    configKey[0] = NULL;
    CHAR buffer[20];
    itoa((int)deviceID, buffer, 10);
    strcpy(configKey, buffer);
    strcat(configKey, ":");
    itoa((int)controlID, buffer, 10);
    strcat(configKey, buffer);
    strcat(configKey, ":");
    strcat(configKey, description);
}

DirectInputSignal::DirectInputSignal(const DirectInputSignal& dis)
    : deviceID(dis.deviceID),
      controlID(dis.controlID)
{
    description = new CHAR[strlen(dis.description)];
    strcpy(description, dis.description);
    strcpy(configKey, dis.configKey);
}

DirectInputSignal::~DirectInputSignal()
{
    delete[] description;
}

const CHAR* DirectInputSignal::getDescription()
{
    return description;
}

const CHAR* DirectInputSignal::getConfigKey()
{
    return configKey;
}
