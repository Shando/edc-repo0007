/*
 * Audio.cs
 * 
 * .NET interface to the EMU7800Audio.dll
 * 
 * Copyright (c) 2004 Mike Murphy
 * 
 */
using System;
using System.Runtime.InteropServices;
using System.Security;

namespace EMU7800 {

public class Audio {
	public static void winmmEnqueueAndWait(byte[] buf) {
		while (winmmEnqueue(buf, buf.Length) > 0) {}
	}

	public static void sdlEnqueueAndWait(byte[] buf) {
		while (sdlEnqueue(buf, buf.Length) > 0) {}
		
	}

	[DllImport("EMU7800Audio.dll", CallingConvention=CallingConvention.Cdecl)]
	public static extern int winmmOpen(int samplerate, int soundframesize, int queuelen);
	[DllImport("EMU7800Audio.dll", CallingConvention=CallingConvention.Cdecl)]
	public static extern void winmmSetVolume(int left, int right);
	[DllImport("EMU7800Audio.dll", CallingConvention=CallingConvention.Cdecl)]
	public static extern uint winmmGetVolume();
	[DllImport("EMU7800Audio.dll", CallingConvention=CallingConvention.Cdecl)]
	private static extern int winmmEnqueue(byte[] buf, int len);
	[DllImport("EMU7800Audio.dll", CallingConvention=CallingConvention.Cdecl)]
	public static extern void winmmClose();

	[DllImport("EMU7800Audio.dll", CallingConvention=CallingConvention.Cdecl)]
	public static extern int sdlOpen(int samplerate, int soundframesize, int queuelen);
	[DllImport("EMU7800Audio.dll", CallingConvention=CallingConvention.Cdecl)]
	private static extern int sdlEnqueue(byte[] buf, int len);
	[DllImport("EMU7800Audio.dll", CallingConvention=CallingConvention.Cdecl)]
	public static extern void sdlClose();
}
}
