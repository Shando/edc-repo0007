/*
 * BIOS7800.cs
 * 
 * The BIOS of the Atari 7800.
 * 
 * Copyright (c) 2004 Mike Murphy
 * 
 */
using System;
using System.IO;

namespace EMU7800 {

[Serializable]
public sealed class BIOS7800 : IDevice {
	private byte[] ROM = new byte[0x1000];

	public void Reset() {}

	public void Map(AddressSpace mem) {}

	public byte this[ushort addr] {
		get {
			return ROM[addr & 0x0fff];
		}
		set {}
	}

	public BIOS7800(MachineType MachineType) {
		switch (MachineType) {
		case MachineType.A7800NTSC:
			LoadBIOS("b32526ea179dc9ab9b2e5f8a2662b298");
			break;
		case MachineType.A7800PAL:
			LoadBIOS("397bb566584be7b9764e7a68974c4263");
			break;
		default:
			throw new Exception("Can't construct BIOS for non-7800 machine type");
		}
	}

	private void LoadBIOS(string md5sum) {
		byte[] bios = null;

		foreach (FileInfo fi in new DirectoryInfo(Globals.ROMDirectory).GetFiles()) {
			if (fi.Extension != ".rom") {
				continue;
			}
			try {
				BinaryReader r = new BinaryReader(File.OpenRead(fi.FullName));
				bios = r.ReadBytes((int)fi.Length);
				r.Close();
				if (md5sum != MD5.ComputeMD5Digest(bios)) {
					bios = null;
				}
			} catch {}
			if (bios != null) {
				break;
			}
		}

		if (bios == null) {
			throw new Exception("7800 BIOS not found in ROM directory");
		}

		int len = ROM.Length;
		int d = ROM.Length;
		int s = bios.Length;
		while (len-- > 0) {
			ROM[--d] = bios[--s];
		}
	}
}
}