/*
 * SettingsPage.cs
 * 
 * A TabPage that permits major game setting changes
 * 
 * Copyright (c) 2003, 2004 Mike Murphy
 * 
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace EMU7800 {
	
public class SettingsPage : TabPage {
	private ControlPanelForm ControlPanelForm;

	private Label lblHostSelect;
	private ComboBox cmbHostSelect;

	private Label lblFrameRateAdjust;
	private NumericUpDown nudFrameRateAdjust;

	private Label lblNumSoundBuffers;
	private NumericUpDown nudNumSoundBuffers;

	private Label lblSoundVolume;
	private NumericUpDown nudSoundVolume;

	private Label lblSkip7800BIOS;
	private CheckBox cbxSkip7800BIOS;

	private Label lblDeactivateMouseInput;
	private CheckBox cbxDeactivateMouseInput;

	private Button btnLoadMachineState;
	private OpenFileDialog ofdFileSelect;

	public SettingsPage(ControlPanelForm f) {
		ControlPanelForm = f;
		Text = "Settings";

		lblHostSelect = new Label();
		lblHostSelect.Text = "Host Select:";
		lblHostSelect.Location = new Point(15, 15);
		lblHostSelect.Size = new Size(210, 15);
		new ToolTip().SetToolTip(lblHostSelect,
			"Select the video/audio driver for the emulator.");

		cmbHostSelect = new ComboBox();
		cmbHostSelect.Text = "";
		cmbHostSelect.Location = new Point(15, 30);
		cmbHostSelect.Size = new Size(210, 15);
		cmbHostSelect.Items.Add("Windows GDI");
		cmbHostSelect.Items.Add("Simple DirectMedia Layer (SDL)");
		cmbHostSelect.SelectedIndex = (int)EMU7800App.Instance.Settings.HostSelect;
		cmbHostSelect.SelectedIndexChanged += new EventHandler(OnSelectedIndexChanged);

		lblFrameRateAdjust = new Label();
		lblFrameRateAdjust.Text = "Frame Rate Adjust (+/-):";
		lblFrameRateAdjust.Location = new Point(15, 60);
		lblFrameRateAdjust.Size = new Size(150, 15);
		new ToolTip().SetToolTip(lblFrameRateAdjust, 
			"Adjust the framerate faster or slower from the default rate.");

		nudFrameRateAdjust = new NumericUpDown();
		nudFrameRateAdjust.Location = new Point(170, 60);
		nudFrameRateAdjust.Size = new Size(55, 15);
		nudFrameRateAdjust.ReadOnly = true;
		nudFrameRateAdjust.Increment = 1;
		nudFrameRateAdjust.Minimum = -40;
		nudFrameRateAdjust.Maximum = 40;
		nudFrameRateAdjust.DataBindings.Add("Value", EMU7800App.Instance.Settings, "FrameRateAdjust");

		lblNumSoundBuffers = new Label();
		lblNumSoundBuffers.Text = "Sound Queue Length:";
		lblNumSoundBuffers.Location = new Point(15, 90);
		lblNumSoundBuffers.Size = new Size(150, 15);
		new ToolTip().SetToolTip(lblNumSoundBuffers,
			"Adjust the number of sound frames contained in the queue.");

		nudNumSoundBuffers = new NumericUpDown();
		nudNumSoundBuffers.Location = new Point(170, 90);
		nudNumSoundBuffers.Size = new Size(55, 15);
		nudNumSoundBuffers.ReadOnly = true;
		nudNumSoundBuffers.Increment = 1;
		nudNumSoundBuffers.Minimum = 2;
		nudNumSoundBuffers.Maximum = 30;
		nudNumSoundBuffers.DataBindings.Add("Value", EMU7800App.Instance.Settings, "NumSoundBuffers");

		lblSoundVolume = new Label();
		lblSoundVolume.Text = "Sound Volume:";
		lblSoundVolume.Location = new Point(15, 120);
		lblSoundVolume.Size = new Size(150, 15);
		new ToolTip().SetToolTip(lblSoundVolume,
			"Sound volume control.");

		nudSoundVolume = new NumericUpDown();
		nudSoundVolume.Location = new Point(170, 120);
		nudSoundVolume.Size = new Size(55, 15);
		nudSoundVolume.ReadOnly = true;
		nudSoundVolume.Increment = 1;
		nudSoundVolume.Minimum = 1;
		nudSoundVolume.Maximum = 16;
		nudSoundVolume.DataBindings.Add("Value", EMU7800App.Instance.Settings, "SoundVolume");

		lblSkip7800BIOS = new Label();
		lblSkip7800BIOS.Text = "Skip BIOS (7800 Emulation):";
		lblSkip7800BIOS.Location = new Point(15, 150);
		lblSkip7800BIOS.Size = new Size(150, 15);
		new ToolTip().SetToolTip(lblSkip7800BIOS,
			"Atari 7800 specific: Skip the execution of the BIOS on ROM startup.");

		cbxSkip7800BIOS = new CheckBox();
		cbxSkip7800BIOS.Location = new Point(170, 150);
		cbxSkip7800BIOS.DataBindings.Add("Checked", EMU7800App.Instance.Settings, "Skip7800BIOS");

		lblDeactivateMouseInput = new Label();
		lblDeactivateMouseInput.Text = "Deactivate Mouse Input";
		lblDeactivateMouseInput.Location = new Point(15, 180);
		lblDeactivateMouseInput.Size = new Size(150, 15);
		new ToolTip().SetToolTip(lblDeactivateMouseInput,
			"Deactivate paddle emulation from mouse input, enables listening for real paddles on the Stelladaptor.");

		cbxDeactivateMouseInput = new CheckBox();
		cbxDeactivateMouseInput.Location = new Point (170, 180);
		cbxDeactivateMouseInput.DataBindings.Add("Checked", EMU7800App.Instance.Settings, "DeactivateMouseInput");

		btnLoadMachineState = new Button();
		btnLoadMachineState.Text = "Load Machine State";
		btnLoadMachineState.Location = new Point(15, 230);
		btnLoadMachineState.Size = new Size(210, 30);
		btnLoadMachineState.Click += new EventHandler(OnButtonClick);

		Controls.AddRange(new Control[] {
			lblHostSelect, cmbHostSelect,
			lblFrameRateAdjust, nudFrameRateAdjust,
			lblNumSoundBuffers, nudNumSoundBuffers,
			lblSoundVolume, nudSoundVolume,
			lblSkip7800BIOS, cbxSkip7800BIOS,
			lblDeactivateMouseInput, cbxDeactivateMouseInput,
			btnLoadMachineState});
	}

	private void OnSelectedIndexChanged(object sender, EventArgs e) {	
		EMU7800App.Instance.Settings.HostSelect = (HostType)cmbHostSelect.SelectedIndex;
	}

	private void OnButtonClick(object sender, EventArgs e) {
		ofdFileSelect = new OpenFileDialog();
		ofdFileSelect.Title = "Select EMU Machine State";
		ofdFileSelect.Filter = "Machine States (*.emu)|*.emu" ;
		ofdFileSelect.FilterIndex = 1;

		ofdFileSelect.InitialDirectory = EMU7800App.Instance.Settings.OutputDirectory;
		if (ofdFileSelect.ShowDialog() == DialogResult.OK) {
			try {
				EMU7800App.Instance.M = Machine.Deserialize(ofdFileSelect.FileName);
				ControlPanelForm.StartButtonEnabled = false;
				ControlPanelForm.ResumeButtonEnabled = true;
				ControlPanelForm.CurrGameSettings = null;
				Log.Msg("machine state restored\n");
			} catch (Exception ex) {
				ControlPanelForm.StartButtonEnabled = false;
				ControlPanelForm.ResumeButtonEnabled = false;
				Log.Msg("error restoring machine state: {0}\n", ex.ToString());
			}
		}
	}
}
}