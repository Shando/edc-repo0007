package com.blissjweb.applet;

import java.awt.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import com.bliss.core.*;
import com.bliss.core.cartridge.*;
import com.bliss.core.devices.*;
import com.blissjweb.plugin.*;

public class BlissJWeb extends Applet
{

    public void init() {
        //create the Intellivision emulator
        inty = new Intellivision();

        //try to load the executive ROM
        String execResource = getParameter("execfile");
        if (execResource == null || execResource.length() == 0)
            execResource = "exec.bin";
        try {
            URL url = new URL(getDocumentBase(), execResource);
            InputStream is = url.openStream();
            int[] execImage = ROM.loadROMImage(is, true);
            is.close();
            inty.setExecImage(execImage);
        }
        catch (IOException ioe) {
            System.err.println("ERROR: Unable to load Executive ROM: " +
                    execResource);
            return;
        }

        //try to load the GROM
        String gromResource = getParameter("gromfile");
        if (gromResource == null || gromResource.length() == 0)
            gromResource = "grom.bin";
        try {
            URL url = new URL(getDocumentBase(), gromResource);
            InputStream is = url.openStream();
            int[] gromImage = ROM.loadROMImage(is, false);
            is.close();
            inty.setGROMImage(gromImage);
        }
        catch (IOException ioe) {
            System.err.println("ERROR: Unable to load GROM: " +
                    gromResource);
            return;
        }

        //check the audio enabled parameter
        boolean audioEnabled = true;
        String param = getParameter("audioenabled");
        if (param != null && param.trim().equalsIgnoreCase("false"))
            audioEnabled = false;
        inty.setAudioEnabled(audioEnabled);

        //check the audio mixing quality parameter
        boolean highQualityMixing = true;
        param = getParameter("audiomixingquality");
        if (param != null && param.trim().equalsIgnoreCase("low"))
            highQualityMixing = false;
        inty.setHighQualityAudioMixing(highQualityMixing);

        //check the audio accuracy parameter
        int audioAccuracy = 3; //lowest quality
        param = getParameter("audioaccuracy");
        if (param != null) {
            param = param.trim().toLowerCase();
            if (param.equals("low"))
                audioAccuracy = 4;
            else if (param.equals("moderate"))
                audioAccuracy = 3;
            else if (param.equals("high"))
                audioAccuracy = 2;
            else if (param.equals("highest"))
                audioAccuracy = 1;
        }
        inty.setAudioAccuracy(audioAccuracy);

        //check the frame skip parameter
        int frameSkip = 3;
        param = getParameter("frameskip");
        if (param != null) {
            try {
                int value = Integer.parseInt(param);
                if (value >= 0 && value <= 5)
                    frameSkip = value;
            }
            catch (NumberFormatException ignored) {}
        }
        inty.setFrameSkip(frameSkip);

        inty.setPlugIn(new AppletPlugIn(this));

        //finally, ensure the user specified a cartridge filename
        String cartResource = getParameter("cartfile");
        if (cartResource != null && cartResource.length() > 0) {
            loadCartFile(cartResource);
        }
    }

    public void loadCartFile(String filename) {
        inty.turnOff(true);
        repaint();
        inty.removeCartridge();

        Cartridge cart = null;
        try {
            URL url = new URL(getDocumentBase(), filename);
            InputStream is = url.openStream();
            cart = Cartridge.loadCartridge(is);
            is.close();
        }
        catch (IOException ioe) {
            System.err.println("ERROR: Unable to load cartridge: " +
                    filename);
            return;
        }

        //try to load the ECS ROM, if necessary
        if (cart.requiresECS() && ecsImage == null) {
            String ecsResource = getParameter("ecsfile");
            if (ecsResource == null || ecsResource.length() == 0)
                ecsResource = "ecs.bin";
            try {
                URL url = new URL(getDocumentBase(), ecsResource);
                InputStream is = url.openStream();
                ecsImage = ROM.loadROMImage(is, false);
                is.close();
                inty.enableECSSupport(ecsImage);
            }
            catch (IOException ioe) {
                System.err.println("ERROR: Unable to load ECS ROM: " +
                        ecsResource);
                ecsImage = new int[0];
                return;
            }
        }

        //try to load the Intellivoice ROM, if necessary
        if (cart.usesIntellivoice() && ivoiceImage == null) {
            String ivoiceResource = getParameter("ivoicefile");
            if (ivoiceResource == null || ivoiceResource.length() == 0)
                ivoiceResource = "ivoice.bin";
            try {
                URL url = new URL(getDocumentBase(), ivoiceResource);
                InputStream is = url.openStream();
                ivoiceImage = ROM.loadROMImage(is, false);
                is.close();
                inty.enableIntellivoiceSupport(ivoiceImage);
            }
            catch (IOException ioe) {
                //oh, well.  I guess they just won't hear the Intellivoice
                ivoiceImage = new int[0];
            }
        }

        inty.insertCartridge(cart);
        inty.turnOn();
    }

    public void start() {
        inty.turnOn();
    }

    public void stop() {
        inty.turnOff();
    }

    public void destroy() {
        inty.turnOff();
    }

    private Intellivision inty;
    private int[] ecsImage;
    private int[] ivoiceImage;

}
