package com.bliss.core.devices;

import java.awt.image.*;

public interface VideoOutputDevice extends Device
{

    public void displayImage(byte[] image, boolean hasChanged);

}
