static uae_u32 MANGLE(pci_mem_lget) (uaecptr) REGPARAM;
static uae_u32 MANGLE(pci_mem_wget) (uaecptr) REGPARAM;
static uae_u32 MANGLE(pci_mem_bget) (uaecptr) REGPARAM;
static void MANGLE(pci_mem_lput) (uaecptr, uae_u32) REGPARAM;
static void MANGLE(pci_mem_wput) (uaecptr, uae_u32) REGPARAM;
static void MANGLE(pci_mem_bput) (uaecptr, uae_u32) REGPARAM;
static int MANGLE(pci_mem_check) (uaecptr addr, uae_u32 size) REGPARAM;
static uae_u8* MANGLE(pci_mem_xlate) (uaecptr addr) REGPARAM;



uae_u32 REGPARAM2 MANGLE(pci_mem_lget) (uaecptr addr)
{
    uae_u32 *m;

    addr -= pa[ADAPTER_NUM].pci_window_base & PCI_MEM_MASK;
    addr &= PCI_MEM_MASK;
    m = (uae_u32 *)(pa[ADAPTER_NUM].pci_memory + addr);

    if (oinka) {
	printf("PCI: Get %08x at %08x\n",do_get_mem_long (m),addr);
    }
    return (do_get_mem_long (m));
}

uae_u32 REGPARAM2 MANGLE(pci_mem_wget) (uaecptr addr)
{
    uae_u16 *m;

    addr -= pa[ADAPTER_NUM].pci_window_base & PCI_MEM_MASK;
    addr &= PCI_MEM_MASK;
    m = (uae_u16 *)(pa[ADAPTER_NUM].pci_memory + addr);

    if (oinka) {
	printf("PCI: WGet %04x at %08x\n",do_get_mem_word (m),addr);
    }
    return (do_get_mem_word (m));
}

uae_u32 REGPARAM2 MANGLE(pci_mem_bget) (uaecptr addr)
{
    addr -= pa[ADAPTER_NUM].pci_window_base & PCI_MEM_MASK;
    addr &= PCI_MEM_MASK;
    if (oinka) {
	printf("PCI: BGet %02x at %08x\n",pa[ADAPTER_NUM].pci_memory[addr],addr);
    }
    return pa[ADAPTER_NUM].pci_memory[addr];
}

void REGPARAM2 MANGLE(pci_mem_lput) (uaecptr addr, uae_u32 l)
{
    uae_u32 *m;

    if (oinka) {
	printf("PCI: Put %08x at %08x\n",l,addr);
    }

    addr -= pa[ADAPTER_NUM].pci_window_base & PCI_MEM_MASK;
    addr &= PCI_MEM_MASK;
    m = (uae_u32 *)(pa[ADAPTER_NUM].pci_memory + addr);
    do_put_mem_long (m, l);
}

void REGPARAM2 MANGLE(pci_mem_wput) (uaecptr addr, uae_u32 w)
{
    uae_u16 *m;

    if (oinka) {
	printf("PCI: WPut %04x at %08x\n",w,addr);
    }
    addr -= pa[ADAPTER_NUM].pci_window_base & PCI_MEM_MASK;
    addr &= PCI_MEM_MASK;
    m = (uae_u16 *)(pa[ADAPTER_NUM].pci_memory + addr);
    do_put_mem_word (m, w);
}

void REGPARAM2 MANGLE(pci_mem_bput) (uaecptr addr, uae_u32 b)
{
    if (oinka) {
	printf("PCI: BPut %02x at %08x\n",b,addr);
    }
    addr -= pa[ADAPTER_NUM].pci_window_base & PCI_MEM_MASK;
    addr &= PCI_MEM_MASK;
    pa[ADAPTER_NUM].pci_memory[addr] = b;
}

int REGPARAM2 MANGLE(pci_mem_check) (uaecptr addr, uae_u32 size)
{
    addr -= pa[ADAPTER_NUM].pci_window_base & PCI_MEM_MASK;
    addr &= PCI_MEM_MASK;
    return (addr + size) <= (NUMBANKS<<16);
}

uae_u8 REGPARAM2 * MANGLE(pci_mem_xlate) (uaecptr addr)
{
    addr -= pa[ADAPTER_NUM].pci_window_base & PCI_MEM_MASK;
    addr &= PCI_MEM_MASK;
    return pa[ADAPTER_NUM].pci_memory + addr;
}


addrbank MANGLE(pci_mem_bank) = {
    MANGLE(pci_mem_lget), MANGLE(pci_mem_wget), MANGLE(pci_mem_bget),
    MANGLE(pci_mem_lput), MANGLE(pci_mem_wput), MANGLE(pci_mem_bput),
    MANGLE(pci_mem_xlate), MANGLE(pci_mem_check), NULL
};



static uae_u32 MANGLE(pci_io_lget) (uaecptr) REGPARAM;
static uae_u32 MANGLE(pci_io_wget) (uaecptr) REGPARAM;
static uae_u32 MANGLE(pci_io_bget) (uaecptr) REGPARAM;
static void MANGLE(pci_io_lput) (uaecptr, uae_u32) REGPARAM;
static void MANGLE(pci_io_wput) (uaecptr, uae_u32) REGPARAM;
static void MANGLE(pci_io_bput) (uaecptr, uae_u32) REGPARAM;
static int MANGLE(pci_io_check) (uaecptr addr, uae_u32 size) REGPARAM;

uae_u32 REGPARAM2 MANGLE(pci_io_lget) (uaecptr addr)
{
    uae_u32 *m;
    uae_u32 l;

    special_mem|=S_READ;
    addr -= pa[ADAPTER_NUM].pci_io_base & PCI_IO_MASK;
    addr &= PCI_IO_MASK;

    prepare_io(addr);
    l=pci_inl(addr,ADAPTER_NUM);
    done_io(addr);

    if (oinka) {
	printf("PCI-IO: Get %08x at %08x\n",l,addr);
    }
    return l;
}

uae_u32 REGPARAM2 MANGLE(pci_io_wget) (uaecptr addr)
{
    uae_u16 *m;
    uae_u16 w;

    special_mem|=S_READ;
    addr -= pa[ADAPTER_NUM].pci_io_base & PCI_IO_MASK;
    addr &= PCI_IO_MASK;

    prepare_io(addr);
    w=pci_inw(addr,ADAPTER_NUM);
    done_io(addr);

    if (oinka) {
	printf("PCI-IO: WGet %04x at %08x\n",w,addr);
    }
    return w;
}

uae_u32 REGPARAM2 MANGLE(pci_io_bget) (uaecptr addr)
{
    uae_u8 b;

    special_mem|=S_READ;
    addr -= pa[ADAPTER_NUM].pci_io_base & PCI_IO_MASK;
    addr &= PCI_IO_MASK;

    prepare_io(addr);
    b=pci_inb(addr,ADAPTER_NUM);
    done_io(addr);

    if (oinka) {
	printf("PCI-IO: BGet %02x at %08x\n",b,addr);
    }
    return b;
}

void REGPARAM2 MANGLE(pci_io_lput) (uaecptr addr, uae_u32 l)
{
    uae_u32 *m;

    special_mem|=S_WRITE;
    if (oinka) {
	printf("PCI-IO: Put %08x at %08x\n",l,addr);
    }

    addr -= pa[ADAPTER_NUM].pci_io_base & PCI_IO_MASK;
    addr &= PCI_IO_MASK;

    prepare_io(addr);
    pci_outl(l,addr,ADAPTER_NUM);
    done_io(addr);
}

void REGPARAM2 MANGLE(pci_io_wput) (uaecptr addr, uae_u32 w)
{
    uae_u16 *m;

    special_mem|=S_WRITE;
    if (oinka) {
	printf("PCI-IO: WPut %04x at %08x\n",w,addr);
    }
    addr -= pa[ADAPTER_NUM].pci_io_base & PCI_IO_MASK;
    addr &= PCI_IO_MASK;

    prepare_io(addr);
    pci_outw(w,addr,ADAPTER_NUM);
    done_io(addr);
}

void REGPARAM2 MANGLE(pci_io_bput) (uaecptr addr, uae_u32 b)
{
    special_mem|=S_WRITE;
    if (oinka) {
	printf("PCI-IO: BPut %02x at %08x\n",b,addr);
    }
    addr -= pa[ADAPTER_NUM].pci_io_base & PCI_IO_MASK;
    addr &= PCI_IO_MASK;
    
    prepare_io(addr);
    pci_outb(b,addr,ADAPTER_NUM);
    done_io(addr);
}

int REGPARAM2 MANGLE(pci_io_check) (uaecptr addr, uae_u32 size)
{
    return 0;
}

addrbank MANGLE(pci_io_bank) = {
    MANGLE(pci_io_lget), MANGLE(pci_io_wget), MANGLE(pci_io_bget),
    MANGLE(pci_io_lput), MANGLE(pci_io_wput), MANGLE(pci_io_bput),
    default_xlate, MANGLE(pci_io_check), NULL
};


static uae_u32 MANGLE(SetBank)(void)
{
    return SetBankInternal(m68k_dreg(regs,0),ADAPTER_NUM); 
}

static uae_u32 MANGLE(FindDev)(uae_u32 n)
{
    return FindDevInternal(ADAPTER_NUM);
}



