/*
 * ControlPanelForm.cs
 * 
 * The main user interface form.
 * 
 * Copyright (c) 2005 Mike Murphy
 * 
 */
using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using EMU7800.Host;
using EMU7800.Machine;
using System.Drawing;

namespace EMU7800.UI
{
    public partial class ControlPanelForm : Form
    {
        #region Fields

        ROMProperties ROMProperties { get; set; }
        GameSettings CurrGameSettings { get; set; }
        MachineBase M { get; set; }
        string ReadMeUri { get; set; }

        #endregion

        #region GlobalSetting Properties

        static int ControlPanelFormWidthGlobalSetting
        {
            get
            {
                int w;
                if (!int.TryParse(GlobalSettings.Instance.GetUserValue("ControlPanelFormWidth"), out w)) w = 0;
                return w;
            }
            set { GlobalSettings.Instance.SetUserValue("ControlPanelFormWidth", value); }
        }

        static int ControlPanelFormHeightGlobalSetting
        {
            get
            {
                int h;
                if (!int.TryParse(GlobalSettings.Instance.GetUserValue("ControlPanelFormHeight"), out h)) h = 0;
                return h;
            }
            set { GlobalSettings.Instance.SetUserValue("ControlPanelFormHeight", value); }
        }

        static Size ControlPanelFormSizeGlobalSetting
        {
            get
            {
                var w = ControlPanelFormWidthGlobalSetting;
                var h = ControlPanelFormHeightGlobalSetting;
                return new Size(w < 500 ? 500 : w, h < 500 ? 500 : h);
            }
            set
            {
                ControlPanelFormWidthGlobalSetting = value.Width;
                ControlPanelFormHeightGlobalSetting = value.Height;
            }
        }

        #endregion

        #region Constructors

        private ControlPanelForm()
        {
            InitializeComponent();
        }

        public ControlPanelForm(ROMProperties romProperties) : this()
        {
            var items = new string[HostBase.RegisteredHostNames.Count];
            HostBase.RegisteredHostNames.CopyTo(items, 0);
            comboboxHostSelect.Items.AddRange(items);

            ROMProperties = romProperties;

            ResetGameTitleLabel();

            // Game Programs TabPage
            groupboxGameTitle.Text = string.Empty;
            labelGameTitle.Text = EMU7800App.Copyright;
            StartButtonEnabled = true;
            ResumeButtonEnabled = true;

            // Settings TabPage
            comboboxHostSelect.SelectedItem = GlobalSettings.Instance.HostSelect;
            if (comboboxHostSelect.SelectedIndex < 0) comboboxHostSelect.SelectedIndex = 0;
            numericupdownFrameRateAdjust.DataBindings.Add("Value", GlobalSettings.Instance, "FrameRateAdjust");
            checkboxSkip7800Bios.DataBindings.Add("Checked", GlobalSettings.Instance, "Skip7800BIOS");
            checkboxHSC7800.DataBindings.Add("Checked", GlobalSettings.Instance, "Use7800HSC");

            // Help TabPage
            var fn = Path.Combine(Directory.GetCurrentDirectory(), "README\\README.html");
            ReadMeUri = File.Exists(fn) ? fn : null;
            linklabelReadMe.Enabled = ReadMeUri != null;
            if (ReadMeUri != null)
            {
                linklabelReadMe_Clicked(this, null);
            }
            else
            {
                Trace.WriteLine("README not found at: " + fn);
            }
        }

        #endregion

        #region Event Handlers

        void ControlPanelForm_Load(object sender, EventArgs e)
        {
            Size = ControlPanelFormSizeGlobalSetting;

            LoadComboBoxRomDirs();
            AddRomDirToComboBoxIfNecessary(GlobalSettings.Instance.RomDirectory);
            InitializeKeyBindingsComboBoxes();
            Show();
            // triggers LoadTreeView(); prior Show() ensures appearance on progress bar
            comboboxRomDir.SelectedIndex = 0;
        }

        void buttonStart_Click(object sender, EventArgs e)
        {
            Start(new InputAdapter());
        }

        void buttonResume_Click(object sender, EventArgs e)
        {
            Resume();
        }

        void buttonQuit_Click(object sender, EventArgs e)
        {
            SaveComboBoxRomDirs();
            Application.Exit();
        }

        void ControlPanelForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            ControlPanelFormSizeGlobalSetting = Size;
        }

        #endregion

        #region Helpers

        bool StartButtonEnabled
        {
            // not used
            // get { return buttonStart.Enabled; }
            set { buttonStart.Enabled = value && CurrGameSettings != null; }
        }

        bool ResumeButtonEnabled
        {
            // not used
            // get { return buttonResume.Enabled; }
            set { buttonResume.Enabled = value && M != null; }
        }

        void Start(InputAdapter ia)
        {
            if (M != null) M.Dispose();

            Hide();
            try
            {
                M = MachineBase.New(CurrGameSettings, Cart.New(CurrGameSettings), ia);
                HostBase.New(GlobalSettings.Instance.HostSelect).Run(M);
            }
            catch (Exception ex)
            {
                if (Utility.IsCriticalException(ex)) throw;
                Trace.WriteLine(ex);
                MessageBox.Show(ex.ToString(), "Machine/Host Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            finally
            {
                Show();
            }

            StartButtonEnabled = true;
            ResumeButtonEnabled = true;
        }

        void Resume()
        {
            Hide();
            try
            {
                HostBase.New(GlobalSettings.Instance.HostSelect).Run(M);
            }
            catch (Exception ex)
            {
                if (Utility.IsCriticalException(ex)) throw;
                Trace.WriteLine(ex);
                MessageBox.Show(ex.ToString(), "Host Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Show();
            }
            StartButtonEnabled = true;
            ResumeButtonEnabled = true;
        }

        void ResetGameTitleLabel()
        {
            groupboxGameTitle.Text = string.Empty;
            labelGameTitle.Text = EMU7800App.Copyright;
            linklabelGameHelp.Visible = false;
        }

        void UpdateGameTitleLabel()
        {
            var gs = CurrGameSettings;
            if (gs == null || (gs.Title ?? string.Empty).Trim().Length <= 0) return;
            groupboxGameTitle.Text = "Selected Game Program";
            labelGameTitle.Text = gs.Title.Trim();
            linklabelGameHelp.Text = labelGameTitle.Text + " Game Help";
            linklabelGameHelp.Visible = gs.HelpUri != null;
        }

        #endregion
    }
}