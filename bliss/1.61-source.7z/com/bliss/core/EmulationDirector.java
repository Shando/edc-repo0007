package com.bliss.core;

import java.io.IOException;
import com.bliss.core.devices.*;

/**
 * This class enables the ability for the user to control the emulation
 * while it's running, including things like exiting, pausing, saving,
 * loading, taking screenshots, etc.
 *
 * @author Kyle Davis
 */
public class EmulationDirector
{

    public EmulationDirector(Intellivision inty) {
        this.inty = inty;
    }

    public void setFrameSkip(int frameSkip) {
        this.frameSkip = frameSkip;
    }

    public int getFrameSkip() {
        return frameSkip;
    }

    public void changePlugIn(PlugIn plugIn) {
        this.plugIn = plugIn;
        if (this.plugIn == null) {
            this.clockDevice = null;
            this.inputDevice = null;
            this.videoOutputDevice = null;
        }
        else {
            this.clockDevice = plugIn.getClockDevice();
            this.inputDevice = plugIn.getInputDevice();
            this.videoOutputDevice = plugIn.getVideoOutputDevice();
        }
    }

    public void reset() {
        for (int i = 0; i < buttonPressed.length; i++)
            buttonPressed[i] = false;

        startTime = clockDevice.getTick();
        missedFrameBuffer = clockDevice.getTickFrequency()/4;
        frameCount = 0;
        frameSkipCounter = frameSkip;
        skippedChange = false;
    }

    public void pollInput() {
        //poll the input device
        inputDevice.poll();

        //check to see if the user is trying to stop the emulation
        if (plugIn.stopRequested()) {
            inty.turnOff();
            return;
        }

        inty.player1Controller.poll();
        inty.player2Controller.poll();

        if (inty.ecsInUse)
            inty.ecs.keyboard.poll();

        if (inputDevice.getControlValue(CONTROL_IDS[0]) ==
                InputDevice.SIGNAL_ON)
        {
            if (!buttonPressed[0]) {
                buttonPressed[0] = true;
                boolean paused = inty.processorBus.isPaused();
                inty.processorBus.setPaused(!paused);
                inty.stic.setMessage((!paused ? pausedMessage : null));
            }
        }
        else
            buttonPressed[0] = false;
        
        if (inputDevice.getControlValue(CONTROL_IDS[1]) ==
                InputDevice.SIGNAL_ON)
        {
            if (!buttonPressed[1]) {
                buttonPressed[1] = true;
                try {
                    inty.saveGame();
                    inty.stic.setMessage(savedMessage, 1);
                }
                catch (IOException ioe) {
                    inty.stic.setMessage(saveFailedMessage, 1);
                }
            }
        }
        else
            buttonPressed[1] = false;
        
        if (inputDevice.getControlValue(CONTROL_IDS[2]) ==
                InputDevice.SIGNAL_ON)
        {
            if (!buttonPressed[2]) {
                buttonPressed[2] = true;
                try {
                    inty.loadGame();
                    inty.stic.setMessage(loadedMessage, 1);
                }
                catch (IOException ioe) {
                    inty.stic.setMessage(loadFailedMessage, 1);
                }
            }
        }
        else
            buttonPressed[2] = false;
        
        //check the reset button
        if (inputDevice.getControlValue(CONTROL_IDS[3]) ==
                InputDevice.SIGNAL_ON)
            inty.reset();
        
        if (inputDevice.getControlValue(CONTROL_IDS[4]) ==
                InputDevice.SIGNAL_ON)
        {
            if (!buttonPressed[4]) {
                buttonPressed[4] = true;
                try {
                    inty.writeSnapshot();
                }
                catch (IOException ioe) {
                    inty.stic.setMessage(screenCaptureFailedMessage, 1);
                }
            }
        }
        else
            buttonPressed[4] = false;
    }

    public void displayImage(boolean changed) {
        if (!changed && !skippedChange) {
            videoOutputDevice.displayImage(stagingBankData, false);
        }
        else {
            //display the frame now if we're on if it's a frame we should
            //not skip
            frameSkipCounter++;
            if (frameSkipCounter > frameSkip) {
                frameSkipCounter = 0;
    
                //time the display of this next frame
                long nextDisplayTime = startTime +
                        ((frameCount * clockDevice.getTickFrequency())/60);
    
                //wait for it.  waaaiiit fooorrr iiitt.  :-)
                long tick = clockDevice.getTick();
                if (tick < (nextDisplayTime + missedFrameBuffer)) {
                    while (clockDevice.getTick() < nextDisplayTime);
                }
                else {
                    startTime = tick;
                    frameCount = 0;
                }
                videoOutputDevice.displayImage(stagingBankData, true);
                skippedChange = false;
            }
            else
                skippedChange |= true;
        }

        frameCount++;
    }

    public int getControlCount() {
        return CONTROL_IDS.length;
    }

    public String getControlDescription(int controlNum) {
        return Intellivision.RESOURCES.getString(descriptionKeys[controlNum]);
    }

    void setImageBank(byte[] stagingBankData) {
        this.stagingBankData = stagingBankData;
    }

    private Intellivision      inty;
    private PlugIn             plugIn;
    private ClockDevice        clockDevice;
    private InputDevice        inputDevice;
    private VideoOutputDevice  videoOutputDevice;
    private boolean[]          buttonPressed = new boolean[CONTROL_IDS.length];
    protected long             startTime;
    protected long             missedFrameBuffer;
    protected int              frameCount;
    protected int              frameSkipCounter;
    protected int              frameSkip = 1;
    protected boolean          skippedChange;
    protected byte[]           stagingBankData;

    private final static int[] CONTROL_IDS = {
            InputDevice.EMULATOR_PAUSE,
            InputDevice.EMULATOR_SAVE,
            InputDevice.EMULATOR_LOAD,
            InputDevice.EMULATOR_RESET,
            InputDevice.EMULATOR_SCREENSHOT
        };

    private final static String pausedMessage = Intellivision.
            RESOURCES.getString("MessagePaused");
    private final static String savedMessage = Intellivision.
            RESOURCES.getString("MessageSaved");
    private final static String saveFailedMessage = Intellivision.
            RESOURCES.getString("MessageSaveFailed");
    private final static String loadedMessage = Intellivision.
            RESOURCES.getString("MessageLoaded");
    private final static String loadFailedMessage = Intellivision.
            RESOURCES.getString("MessageLoadFailed");
    private final static String screenCaptureFailedMessage = Intellivision.
            RESOURCES.getString("MessageScreenCaptureFailed");

    private final static String[] descriptionKeys = {
            "ControllerPause",
            "ControllerSave",
            "ControllerLoad",
            "ControllerReset",
            "ControllerScreenshot"
        };

}
