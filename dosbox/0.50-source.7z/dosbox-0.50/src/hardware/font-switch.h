switch (bit_mask) {
	case 0:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 1:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 2:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 3:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 4:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 5:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 6:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 7:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 8:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 9:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 10:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 11:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 12:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 13:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 14:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 15:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 16:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 17:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 18:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 19:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 20:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 21:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 22:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 23:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 24:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 25:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 26:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 27:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 28:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 29:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 30:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 31:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 32:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 33:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 34:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 35:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 36:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 37:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 38:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 39:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 40:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 41:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 42:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 43:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 44:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 45:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 46:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 47:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 48:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 49:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 50:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 51:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 52:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 53:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 54:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 55:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 56:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 57:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 58:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 59:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 60:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 61:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 62:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 63:
		*(draw+0)=bg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 64:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 65:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 66:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 67:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 68:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 69:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 70:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 71:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 72:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 73:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 74:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 75:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 76:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 77:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 78:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 79:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 80:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 81:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 82:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 83:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 84:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 85:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 86:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 87:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 88:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 89:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 90:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 91:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 92:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 93:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 94:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 95:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 96:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 97:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 98:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 99:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 100:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 101:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 102:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 103:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 104:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 105:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 106:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 107:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 108:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 109:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 110:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 111:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 112:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 113:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 114:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 115:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 116:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 117:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 118:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 119:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 120:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 121:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 122:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 123:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 124:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 125:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 126:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 127:
		*(draw+0)=bg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 128:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 129:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 130:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 131:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 132:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 133:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 134:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 135:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 136:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 137:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 138:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 139:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 140:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 141:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 142:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 143:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 144:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 145:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 146:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 147:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 148:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 149:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 150:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 151:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 152:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 153:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 154:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 155:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 156:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 157:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 158:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 159:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 160:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 161:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 162:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 163:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 164:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 165:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 166:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 167:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 168:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 169:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 170:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 171:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 172:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 173:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 174:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 175:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 176:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 177:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 178:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 179:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 180:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 181:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 182:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 183:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 184:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 185:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 186:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 187:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 188:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 189:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 190:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 191:
		*(draw+0)=fg;
		*(draw+1)=bg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 192:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 193:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 194:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 195:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 196:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 197:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 198:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 199:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 200:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 201:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 202:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 203:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 204:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 205:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 206:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 207:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 208:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 209:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 210:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 211:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 212:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 213:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 214:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 215:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 216:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 217:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 218:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 219:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 220:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 221:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 222:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 223:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=bg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 224:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 225:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 226:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 227:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 228:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 229:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 230:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 231:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 232:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 233:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 234:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 235:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 236:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 237:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 238:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 239:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=bg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 240:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 241:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 242:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 243:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 244:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 245:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 246:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 247:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=bg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 248:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 249:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 250:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 251:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=bg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
	case 252:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=bg;
	break;
	case 253:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=bg;
		*(draw+7)=fg;
	break;
	case 254:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=bg;
	break;
	case 255:
		*(draw+0)=fg;
		*(draw+1)=fg;
		*(draw+2)=fg;
		*(draw+3)=fg;
		*(draw+4)=fg;
		*(draw+5)=fg;
		*(draw+6)=fg;
		*(draw+7)=fg;
	break;
}
