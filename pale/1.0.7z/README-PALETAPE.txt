

PALETAPE


A Lynx tape reader program



Ver 1.0

Date: 15 June 2003

Author: Pete Todd


Lynx Tape Format:

---------------------------------------------
Sync - Zeroes for about 7 seconds

A5 byte

" byte

<filename>

" byte

Sync - Zeroes for about 7 seconds

A5 byte

Program Header - length, start etc.

Program

CRC & Execution address
---------------------------------------------




Tape Recording
==============

Paletape expects sound files saved in .RAW format
as recordings at 22050 Hz and 8 bits UNSIGNED.

Record the lynx tape using your favourite program,
you can chop out the sync zeroes as the program
automatically re-syncs itself, leaving them in
won't harm though (as long as there's no glitches!)

Needless to say, you want to check your system
records with low noise, and adjust the recording 
level to around 80% of full range on the peaks.



PaleTape usage
==============

paletape <RAW infile> <TAP outfile> <verbose (0/1)> <threshold (00-FF)> <TAPE Speed (0-5)> <Tape format (0-2)>
 [ <sync marker - A5 default> ]

for example: paletape pblaster.raw pblaster.tap 0 7b 0 0

retrieves the power blaster MLOAD program, use tape format 0 for most
normal basic or machine code binary programs.

Formats:

0 - Standard Lynx format for BASIC and MLOAD'ed Binaries
1 - Same as above, but where the name is missing
2 - The data format used by Level 9 - basically as type 1 but with different header info



Basically you are looking for an A5 byte as the first byte read off the tape

You can see an example of the correct A5 byte (for a TAPE 0 recording) in
the image "A5BYTE.JPG" in this package. This should also give you an idea 
of the sort of sound file we're looking for here, the ones are the wide pulses,
this program times the width of these vs the zeroes. The time measured is from
where the signal drops below the threshold until the time it rises again.


Known Issues:

1. Only TAPE speeds 0 and 5 are tested - I have no files to check the timings with for the others :(




 