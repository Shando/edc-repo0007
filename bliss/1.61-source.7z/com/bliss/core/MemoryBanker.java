package com.bliss.core;

import java.io.*;

public class MemoryBanker extends Memory
{

    public MemoryBanker(int location, int size) {
        this.location = location;
        this.size = size;
        this.triggerLocation = (location+size)-1;
        unmappedMemory = new UnmappedMemory(location, size);
        for (int i = 0; i < bankedMemories.length; i++)
            bankedMemories[i] = unmappedMemory;

        pageChangeValue = (location & 0xF000) | 0x0A50;
        currentBank = 0;
    }

    public void setMemoryBank(int bank, Memory m) {
        if (m == null)
            m = unmappedMemory;
        bankedMemories[bank] = m;
    }

    public Memory getMemoryBank(int bank) {
        return (bankedMemories[bank] == unmappedMemory ? null
                : bankedMemories[bank]);
    }

    public void reset() {
        currentBank = 0;
    }

    public void save(SaveOutputStream sos) throws IOException {
        sos.writeInt(currentBank);
    }

    public void load(LoadInputStream lis) throws IOException {
        currentBank = lis.readInt(0, 0xF);
    }

    public int getLocation() {
        return location;
    }

    public int getSize() {
        return size;
    }

    public void poke(int address, int value) {
        if (address == triggerLocation && (value & 0xFFF0) == pageChangeValue)
            currentBank = (value & 0x0F);
        else
            bankedMemories[currentBank].poke(address, value);
    }

    public int peek(int address) {
        return bankedMemories[currentBank].peek(address);
    }

    private int location;
    private int size;
    private int triggerLocation;
    private int pageChangeValue;
    private int currentBank;
    private Memory[] bankedMemories = new Memory[16];

    //we'll use this for unmapped memory references
    private Memory unmappedMemory;

    private static class UnmappedMemory extends Memory {
            private UnmappedMemory(int location, int size) {
            }
            public void reset() {}
            public void save(SaveOutputStream sos) throws IOException {}
            public void load(LoadInputStream lis) throws IOException {}
            public int getLocation() {
                return location;
            }
            public int getSize() {
                return size;
            }
            public void poke(int location, int value) {
            }
            public int peek(int location) {
                return UNMAPPED_PEEK;
            }
            private int location;
            private int size;
        };

}
