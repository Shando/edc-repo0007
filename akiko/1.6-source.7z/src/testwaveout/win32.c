#include <windows.h>

int PASCAL WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine,
		    int nCmdShow)
{
    extern int init_sound( void );
    extern void close_sound( void );

    if( init_sound() )
        close_sound();
    return FALSE;
}

