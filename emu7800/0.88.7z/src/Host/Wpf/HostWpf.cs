/*
 * HostWPF
 *
 * A WPF-based Host.
 *
 * Copyright (c) 2007 Mike Murphy
 *
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using EMU7800.Machine;

namespace EMU7800.Host.Wpf
{
    public sealed class HostWpfWindow : Window, IDisposable
    {
        private const int WIDTH = 320, HEIGHT = 240;

        private HostWpf H { get; set; }
        private MachineBase M { get; set; }

        private FontRenderer _FontRenderer;
        private int[] _Palette;

        private readonly Image _Image;
        private readonly WriteableBitmap _Wb;
        private readonly byte[] _Fb;
        private readonly int _Stride;
        private readonly Int32Rect _Rect;

        private readonly DispatcherFrame _Frame;
        private readonly DispatcherOperationCallback _PullFrameCallback;
        private readonly Thread _CycleThread;

        private Size _CurrentWindowSize;

        private Dictionary<Key, HostInput> _KeyBindings;

        private Stopwatch _Stopwatch;
        private const int FRAME_SAMPLES = 120;
        private long _startOfCycleTick, _endOfCycleTick;
        private long _frameBudgetTicks, _sleepableTicks;
        private readonly long _ticksPerMillisec = Stopwatch.Frequency / 1000;
        private readonly int[] _RunMachineTicks = new int[FRAME_SAMPLES];
        private readonly int[] _WaitTicks = new int[FRAME_SAMPLES];

        private DirectInput _DirectInput;
        private bool _JoysticksSwapped, _LeftPaddlesSwapped, _RightPaddlesSwapped;
        private int MouseX, MouseY;
        private bool ShowMouseCursor;	// For lightgun emulation

        private HostWpfWindow()
        {
        }

        public HostWpfWindow(HostWpf host) : this()
        {
            if (host == null) throw new ArgumentNullException("host");

            H = host;

            Title = EMU7800App.Title;
            Background = Brushes.Black.Clone();

            var ms = new MemoryStream();
            HostWpfResources.EMUIcon.Save(ms);
            Icon = BitmapFrame.Create(ms);

            _Frame = new DispatcherFrame();
            _PullFrameCallback = PullFrame;
            _CycleThread = new Thread(RunCycles);

            _Wb = new WriteableBitmap(WIDTH, HEIGHT, 96, 96, PixelFormats.Bgr32, null);
            var bytesPerPixel = (_Wb.Format.BitsPerPixel + 7) / 8;
            _Stride = _Wb.PixelWidth * bytesPerPixel;
            _Rect = new Int32Rect(0, 0, _Wb.PixelWidth, _Wb.PixelHeight);
            _Fb = new byte[_Stride * _Wb.PixelHeight];

            _Image = new Image {Stretch = Stretch.Uniform, Source = _Wb};

            Content = _Image;
        }

        public void Run(MachineBase m)
        {
            Trace.WriteLine("WPF Host startup");
            M = m;
            try
            {
                _DirectInput = new DirectInput(new WindowInteropHelper(this).Handle);
            }
            catch (Exception ex)
            {
                if (Utility.IsCriticalException(ex))
                {
                    throw;
                }
                _DirectInput = null;
            }

            _FontRenderer = new FontRenderer(M.VideoFrameBuffer, M.VisiblePitch);
            _Palette = M.GetPalette();
            ShowMouseCursor = M.InputAdapter.GetController(0) == Controller.Lightgun;

            InitializeKeyBindings();

            Deactivated += delegate { H.RaiseInput(HostInput.Pause, true); };
            Closing += OnClosing;
            KeyUp += OnKeyPress;
            KeyDown += OnKeyPress;
            MouseDown += OnMouseButtonPressed;
            MouseUp += OnMouseButtonPressed;
            SizeChanged += delegate(object sender, SizeChangedEventArgs e) { _CurrentWindowSize = e.NewSize; };

            if (_DirectInput != null)
            {
                AssignDirectInputDelegates(0);
                AssignDirectInputDelegates(1);
            }

            Show();

            _CycleThread.Start();

            _Frame.Continue = true;
            Dispatcher.PushFrame(_Frame);

            if (_DirectInput != null)
            {
                _DirectInput.Dispose();
            }

            Close();

            Trace.WriteLine("WPF Host shutdown");
        }

        private object ExitFrame(object ignoredArg)
        {
            _Frame.Continue = false;
            return null;
        }

        private void OnClosing(object sender, CancelEventArgs e)
        {
            if (!H.Ended)
            {
                e.Cancel = true;
                H.RaiseInput(HostInput.End, true);
            }
        }

        private void RunCycles()
        {
            _frameBudgetTicks = Stopwatch.Frequency / M.FrameHZ;
            _sleepableTicks = _frameBudgetTicks - GlobalSettings.Instance.CpuSpin * _ticksPerMillisec;

            _Stopwatch = new Stopwatch();
            _Stopwatch.Start();

            _endOfCycleTick = _Stopwatch.ElapsedTicks;

            while (!H.Ended && !M.MachineHalt)
            {
                RunCycle();
            }

            H.CloseAudio();

            _Frame.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new DispatcherOperationCallback(ExitFrame), _Frame);
        }

        private void RunCycle()
        {
            _startOfCycleTick = _endOfCycleTick;

            if (H.Paused)
            {
                for (var i = 0; i < M.SoundFrameBuffer.Length; i++)
                {
                    M.SoundFrameBuffer[i] = 0;
                }
            }
            else
            {
                M.RunFrame();
            }

            _Frame.Dispatcher.BeginInvoke(DispatcherPriority.Normal, _PullFrameCallback, _Frame);

            var endOfRunMachineTick = _Stopwatch.ElapsedTicks;

            var sleepTicks = (int)((_sleepableTicks - (endOfRunMachineTick - _startOfCycleTick)) / _ticksPerMillisec);
            if (sleepTicks > 0)
            {
                Thread.Sleep(sleepTicks);
            }

            while (H.EnqueueAudio(M.SoundFrameBuffer) == 1)
            {
            }

            _endOfCycleTick = _Stopwatch.ElapsedTicks;

            var statIndex = (int)M.FrameNumber % FRAME_SAMPLES;
            _RunMachineTicks[statIndex] = (int)(endOfRunMachineTick - _startOfCycleTick);
            _WaitTicks[statIndex] = (int)(_endOfCycleTick - endOfRunMachineTick);
        }

        private void InitializeKeyBindings()
        {
            _KeyBindings = new Dictionary<Key, HostInput>
            {
                { Key.Escape, HostInput.End },
                { Key.LeftCtrl, HostInput.Fire },
                { Key.RightCtrl, HostInput.Fire },
                { Key.System, HostInput.Fire2 },
                { Key.Left, HostInput.Left },
                { Key.Up, HostInput.Up },
                { Key.Right, HostInput.Right },
                { Key.Down, HostInput.Down },
                { Key.NumPad7, HostInput.NumPad7 },
                { Key.NumPad8, HostInput.NumPad8 },
                { Key.NumPad9, HostInput.NumPad9 },
                { Key.NumPad4, HostInput.NumPad4 },
                { Key.NumPad5, HostInput.NumPad5 },
                { Key.NumPad6, HostInput.NumPad6 },
                { Key.NumPad1, HostInput.NumPad1 },
                { Key.NumPad2, HostInput.NumPad2 },
                { Key.NumPad3, HostInput.NumPad3 },
                { Key.Multiply, HostInput.NumPadMult },
                { Key.NumPad0, HostInput.NumPad0 },
                { Key.Divide, HostInput.NumPadDiv },
                { Key.D1, HostInput.LeftDifficulty },
                { Key.D2, HostInput.RightDifficulty },
                { Key.F1, HostInput.SetKeyboardToPlayer1 },
                { Key.F2, HostInput.SetKeyboardToPlayer2 },
                { Key.F3, HostInput.SetKeyboardToPlayer3 },
                { Key.F4, HostInput.SetKeyboardToPlayer4 },
                { Key.F5, HostInput.PanLeft },
                { Key.F6, HostInput.PanRight },
                { Key.F7, HostInput.PanUp },
                { Key.F8, HostInput.PanDown },
                { Key.F11, HostInput.SaveMachine },
                { Key.F12, HostInput.Unknown },
                { Key.C, HostInput.Color },
                { Key.F, HostInput.Unknown },
                { Key.M, HostInput.Mute },
                { Key.P, HostInput.Pause },
                { Key.R, HostInput.Reset },
                { Key.S, HostInput.Select },
                { Key.Q, HostInput.Unknown },
                { Key.W, HostInput.Unknown },
                { Key.E, HostInput.Unknown },
            };
        }

        private void OnKeyPress(object sender, KeyEventArgs e)
        {
            if (_KeyBindings.ContainsKey(e.Key))
            {
                switch (e.Key)
                {
                    case Key.F:
                        if (e.IsDown)
                        {
                            double rmTicks = 0.0, wTicks = 0.0;
                            for (int i = 0; i < FRAME_SAMPLES; i++)
                            {
                                rmTicks += _RunMachineTicks[i];
                                wTicks += _WaitTicks[i];
                            }
                            rmTicks = rmTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
                            wTicks = wTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
                            double fps = 1000.0 / (rmTicks + wTicks);
                            H.PostedMsg = string.Format("{0}/{1} FPS {2:0.0}+{3:0.0}={4:0.0}/{5:0.0} ms", Math.Round(fps, 0), H.EffectiveFPS, rmTicks, wTicks, rmTicks + wTicks, 1000.0 / H.EffectiveFPS);
                        }
                        break;
                    case Key.Q:
                        if (e.IsDown && _DirectInput != null && _DirectInput.IsStelladaptor(0))
                        {
                            _LeftPaddlesSwapped = !_LeftPaddlesSwapped;
                            H.PostedMsg = String.Format("Left Paddles {0}wapped", _LeftPaddlesSwapped ? "S" : "Uns");
                        }
                        break;
                    case Key.W:
                        if (e.IsDown)
                        {
                            _JoysticksSwapped = !_JoysticksSwapped;
                            H.PostedMsg = String.Format("Game Controllers {0}wapped", _JoysticksSwapped ? "S" : "Uns");
                        }
                        break;
                    case Key.E:
                        if (e.IsDown)
                        {
                            _RightPaddlesSwapped = !_RightPaddlesSwapped;
                            H.PostedMsg = String.Format("Right Paddles {0}wapped", _RightPaddlesSwapped ? "S" : "Uns");
                        }
                        break;
                    case Key.F12:
                        if (e.IsDown)
                        {
                            try
                            {
                                var fn = string.Format("emu7800 screenshot {0:yyyy} {0:MM}-{0:dd} {0:HH}{0:mm}{0:ss}.bmp", DateTime.Now);
                                using (var fs = new FileStream(Path.Combine(GlobalSettings.Instance.OutputDirectory, fn), FileMode.Create))
                                {
                                    var src = BitmapSource.Create(WIDTH, HEIGHT, 96, 96, PixelFormats.Bgr32, null, _Fb, _Stride);
                                    var encoder = new BmpBitmapEncoder();
                                    encoder.Frames.Add(BitmapFrame.Create(BitmapFrame.Create(src)));
                                    encoder.Save(fs);
                                    fs.Flush();
                                    fs.Close();
                                }
                                Trace.WriteLine("Screenshot taken: " + fn);
                                H.PostedMsg = "Screenshot taken";
                            }
                            catch (Exception ex)
                            {
                                if (ex is InvalidOperationException || ex is NotSupportedException)
                                {
                                    Trace.WriteLine("Error while taking screenshot: " + ex);
                                    H.PostedMsg = "Screenshot failed";
                                }
                                else
                                {
                                    throw;
                                }
                            }
                        }
                        break;
                    default:
                        H.RaiseInput(_KeyBindings[e.Key], e.IsDown);
                        break;
                }
            }
            else
            {
                H.RaiseInput(HostInput.Unknown, e.IsDown);
            }
            e.Handled = true;
        }

        private void OnMouseButtonPressed(object sender, MouseButtonEventArgs e)
        {
            if (!H.Paused)
            {
                H.RaiseInput(HostInput.Fire, e.LeftButton.Equals(MouseButtonState.Pressed));
            }
        }

        private object PullFrame(object ignoredArg)
        {
            if (H.PostedMsg.Length > 0)
            {
                _FontRenderer.DrawText(H.PostedMsg, 2, H.ClipStart + 4, 10, 0);
            }

            int si = H.ClipStart * M.VisiblePitch + H.LeftOffset;
            int di = 0;

            for (int i = 0; i < HEIGHT; i++)
            {
                int dj = di;
                for (int j = 0; j < M.VisiblePitch; j++)
                {
                    while (si < 0)
                    {
                        si += M.VideoFrameBuffer.Length;
                    }
                    while (si >= M.VideoFrameBuffer.Length)
                    {
                        si -= M.VideoFrameBuffer.Length;
                    }
                    var pixel = _Palette[M.VideoFrameBuffer[si++]];
                    var r = (byte)((pixel & 0xff0000) >> 16);
                    var g = (byte)((pixel & 0xff00) >> 8);
                    var b = (byte)((pixel & 0xff));
                    _Fb[dj++] = b;
                    _Fb[dj++] = g;
                    _Fb[dj++] = r;
                    dj++;
                    if (M.VisiblePitch == (WIDTH >> 1))
                    {
                        _Fb[dj++] = b;
                        _Fb[dj++] = g;
                        _Fb[dj++] = r;
                        dj++;
                    }
                }
                di += _Stride;
            }

            if (ShowMouseCursor)
            {
                di = (MouseY * WIDTH + MouseX) << 2;
                _Fb[di+0] = 0xff;
                _Fb[di+1] = 0xff;
                _Fb[di+2] = 0xff;
            }

            _Wb.WritePixels(_Rect, _Fb, _Stride, 0);

            // this probably should have its own dispatched method, but we'll just sneek it in here instead
            if (_DirectInput != null)
            {
                _DirectInput.Poll();
            }

            return null;
        }

        void AssignDirectInputDelegates(int deviceno)
        {
            switch (M.InputAdapter.GetController(deviceno))
            {
                case Controller.Joystick:
                case Controller.ProLineJoystick:
                case Controller.BoosterGrip:
                case Controller.Driving:
                    _DirectInput.JoystickChanged = OnJoystickChanged;
                    break;
                case Controller.Lightgun:
                    _DirectInput.MouseChanged = OnMouseChanged;
                    break;
                case Controller.Paddles:
                    if (_DirectInput.IsStelladaptor(deviceno))
                    {
                        _DirectInput.MousePaddleChanged = null;
                        _DirectInput.MouseChanged = null;
                        _DirectInput.StelladaptorPaddleChanged = OnStelladaptorPaddleChanged;
                    }
                    else
                    {
                        _DirectInput.MousePaddleChanged = OnMousePaddleChanged;
                    }
                    break;
            }
        }

        void OnJoystickChanged(int deviceno, bool left, bool right, bool up, bool down, bool fire, bool fire2)
        {
            deviceno ^= (_JoysticksSwapped ? 1 : 0);
            H.RaiseInput(deviceno, HostInput.Left, left);
            H.RaiseInput(deviceno, HostInput.Right, right);
            H.RaiseInput(deviceno, HostInput.Up, up);
            H.RaiseInput(deviceno, HostInput.Down, down);
            H.RaiseInput(deviceno, HostInput.Fire, fire);
            H.RaiseInput(deviceno, HostInput.Fire2, fire2);
        }

        void OnMouseChanged(int x, int y, bool fire)
        {
            MouseX += x;
            if (MouseX < 0)
            {
                MouseX = 0;
            }
            else
            {
                MouseX %= WIDTH;
            }
            MouseY += y;
            if (MouseY < 0)
            {
                MouseY = 0;
            }
            else
            {
                MouseY %= HEIGHT;
            }
            H.RaiseLightGunInput((int)_CurrentWindowSize.Width, MouseX, MouseY);
        }

        void OnStelladaptorPaddleChanged(int paddleno, int val, bool fire)
        {
            paddleno ^= (_JoysticksSwapped ? 2 : 0);
            if (paddleno <= 1)
            {
                paddleno ^= (_LeftPaddlesSwapped ? 1 : 0);
            }
            else
            {
                paddleno ^= (_RightPaddlesSwapped ? 1 : 0);
            }
            H.RaisePaddleInput(paddleno, DirectInput.StelladaptorPaddleRange, val);
            H.RaiseInput(paddleno, HostInput.Fire, fire);
        }

        void OnMousePaddleChanged(int val, bool fire)
        {
            H.RaisePaddleInput(_DirectInput.MousePaddleRange, val);
            H.RaiseInput(HostInput.Fire, fire);
        }

        #region IDisposable Members

        public void Dispose()
        {
            if (_DirectInput != null)
            {
                _DirectInput.Dispose();
            }
            Close();
        }

        #endregion
    }

    public class HostWpf : HostBase
    {
        private HostWpfWindow W;

        public override void Run(MachineBase m)
        {
            base.Run(m);
            W = new HostWpfWindow(this);
            try
            {
                W.Run(M);
            }
            finally
            {
                W.Dispose();
                W = null;
            }
        }
    }
}
