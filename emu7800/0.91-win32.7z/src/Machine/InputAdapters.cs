/*
 * InputAdapter.cs
 *
 * Class containing the input state of the console and its controllers,
 * mapping emulator input devices to external input.
 *
 * Copyright (c) 2003, 2004 Mike Murphy
 *
 */
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization;

namespace EMU7800.Machine
{
    public enum Controller
    {
        None, Joystick, Paddles, Keypad, Driving, BoosterGrip, ProLineJoystick, Lightgun
    }

    public enum ConsoleSwitch
    {
        GameReset, GameSelect, GameBW, LDifficultyA, RDifficultyA
    }

    public enum ControllerAction
    {
        Up, Down, Left, Right, Trigger, Trigger2,
        Keypad1, Keypad2, Keypad3,
        Keypad4, Keypad5, Keypad6,
        Keypad7, Keypad8, Keypad9,
        KeypadA, Keypad0, KeypadP
    }

    #region InputAdapter Class

    [Serializable]
    public class InputAdapter : IDeserializationCallback
    {
        #region Fields

        public const int
            PaddleOhmMin = 100000,
            PaddleOhmMax = 800000;

        // Indexed by device number
        private readonly Controller[] _Controllers = new Controller[2];
        private readonly int[] _ControllerActions = new int[4];
        private readonly int[] _Ohms = new int[4];
        private readonly int[] _LightgunPos = new int[4];
        private readonly byte[] _DrivingCounters = new byte[2];

        #endregion

        protected byte ConsoleSwitches { get; set; }
        protected byte KeypadState { get; set; }
        protected bool InputChanged { get; set; }
        protected bool IgnoreInput { get; set; }

        public bool this[ConsoleSwitch conSwitch]
        {
            get { return (ConsoleSwitches & (1 << (int)conSwitch)) != 0; }
            set
            {
                if (!IgnoreInput)
                {
                    if (value)
                    {
                        ConsoleSwitches |= (byte)(1 << (byte)conSwitch);
                    }
                    else
                    {
                        ConsoleSwitches &= (byte)~(1 << (byte)conSwitch);
                    }
                    InputChanged = true;
                }
            }
        }

        public bool this[int playerno, ControllerAction action]
        {
            get { return (GetControllerAction(playerno) & (1 << (int)action)) != 0; }
            set
            {
                if (!IgnoreInput)
                {
                    if (value)
                    {
                        _ControllerActions[playerno] |= (1 << (int)action);
                    }
                    else
                    {
                        _ControllerActions[playerno] &= ~(1 << (int)action);
                    }
                    InputChanged = true;
                }
            }
        }

        public Controller GetController(int deviceno)
        {
            return _Controllers[deviceno];
        }

        public void SetController(int deviceno, Controller value)
        {
            _Controllers[deviceno] = value;
        }

        public int GetControllerAction(int deviceno)
        {
            return _ControllerActions[deviceno];
        }

        public void SetControllerAction(int deviceno, int value)
        {
            _ControllerActions[deviceno] = value;
        }

        public int GetOhms(int deviceno)
        {
            return _Ohms[deviceno];
        }

        public void SetOhms(int deviceno, int ohms)
        {
            if (!IgnoreInput)
            {
                if (deviceno < 4)
                {
                    _Ohms[deviceno] = ohms;
                    InputChanged = true;
                }
            }
        }

        public void SetLightgunPos(int deviceno, int scanline, int hpos)
        {
            if (!IgnoreInput)
            {
                if (deviceno < 2)
                {
                    _LightgunPos[deviceno << 1] = scanline;
                    _LightgunPos[(deviceno << 1) + 1] = hpos;
                    InputChanged = true;
                }
            }
        }

        public byte GetDrivingCounter(int deviceno)
        {
            return _DrivingCounters[deviceno];
        }

        public void SetDrivingCounter(int deviceno, byte value)
        {
            _DrivingCounters[deviceno] = value;
        }

        //	PortA/TIA: Controller Jacks
        //
        //            Left Jack                Right Jack
        //          -------------             -------------
        //          \ 1 2 3 4 5 /             \ 1 2 3 4 5 /
        //           \ 6 7 8 9 /               \ 6 7 8 9 /
        //            ---------                 ---------
        //  
        //	pin 1   D4 PIA SWCHA           D0 PIA SWCHA
        //	pin 2   D5 PIA SWCHA           D1 PIA SWCHA
        //	pin 3   D6 PIA SWCHA           D2 PIA SWCHA
        //	pin 4   D7 PIA SWCHA           D3 PIA SWCHA
        //	pin 5   D7 TIA INPT1 (Dumped)  D7 TIA INPT3 (Dumped)
        //	pin 6   D7 TIA INPT4 (Latched) D7 TIA INPT5 (Latched)
        //	pin 7   +5                     +5
        //	pin 8   GND                    GND
        //	pin 9   D7 TIA INPT0 (Dumped)  D7 TIA INPT2 (Dumped)
        //
        public byte ReadPortA()
        {
            var porta = 0;

            switch (GetController(0))
            {
                case Controller.Joystick:
                case Controller.ProLineJoystick:
                case Controller.BoosterGrip:
                    porta |= this[0, ControllerAction.Up] ? 0 : (1 << 4);
                    porta |= this[0, ControllerAction.Down] ? 0 : (1 << 5);
                    porta |= this[0, ControllerAction.Left] ? 0 : (1 << 6);
                    porta |= this[0, ControllerAction.Right] ? 0 : (1 << 7);
                    break;
                case Controller.Driving:
                    porta |= GetDrivingState(0) << 4;
                    break;
                case Controller.Paddles:
                    porta |= this[0, ControllerAction.Trigger] ? 0 : (1 << 7);
                    porta |= this[1, ControllerAction.Trigger] ? 0 : (1 << 6);
                    break;
                case Controller.Lightgun:
                    porta |= this[0, ControllerAction.Trigger] ? 0 : (1 << 4);
                    break;
            }

            switch (GetController(1))
            {
                case Controller.Joystick:
                case Controller.ProLineJoystick:
                case Controller.BoosterGrip:
                    porta |= this[1, ControllerAction.Up] ? 0 : (1 << 0);
                    porta |= this[1, ControllerAction.Down] ? 0 : (1 << 1);
                    porta |= this[1, ControllerAction.Left] ? 0 : (1 << 2);
                    porta |= this[1, ControllerAction.Right] ? 0 : (1 << 3);
                    break;
                case Controller.Driving:
                    porta |= GetDrivingState(1);
                    break;
                case Controller.Paddles:
                    porta |= this[2, ControllerAction.Trigger] ? 0 : (1 << 3);
                    porta |= this[3, ControllerAction.Trigger] ? 0 : (1 << 2);
                    break;
                case Controller.Lightgun:
                    porta |= this[1, ControllerAction.Trigger] ? 0 : (1 << 0);
                    break;
            }
            return (byte)porta;
        }

        public void WritePortA(byte porta)
        {
            KeypadState = porta;
        }

        //	PortB: Console Switches
        //   
        //	D0 PIA SWCHB  Game Reset 0=on
        //	D1 PIA SWCHB  Game Select 0=on
        //	D2 (unused)
        //	D3 PIA SWCHB  Console Color 1=Color, 0=B/W
        //	D4 (unused)
        //	D5 (unused)
        //	D6 PIA SWCHB  Left Difficulty A 1=A (pro), 0=B (novice)
        //	D7 PIA SWCHB  Right Difficulty A 1=A (pro), 0=B (novice)  
        //
        public byte ReadPortB()
        {
            var portb = 0;
            portb |= this[ConsoleSwitch.GameReset] ? 0 : (1 << 0);
            portb |= this[ConsoleSwitch.GameSelect] ? 0 : (1 << 1);
            portb |= this[ConsoleSwitch.GameBW] ? 0 : (1 << 3);
            portb |= this[ConsoleSwitch.LDifficultyA] ? (1 << 6) : 0;
            portb |= this[ConsoleSwitch.RDifficultyA] ? (1 << 7) : 0;
            return (byte)portb;
        }

        public int ReadINPT0() { return INPTDumped(0); }
        public int ReadINPT1() { return INPTDumped(1); }
        public int ReadINPT2() { return INPTDumped(2); }
        public int ReadINPT3() { return INPTDumped(3); }
        public bool ReadINPT4(int scanline, int hpos) { return INPTLatched(4, scanline, hpos); }
        public bool ReadINPT5(int scanline, int hpos) { return INPTLatched(5, scanline, hpos); }

        public override string ToString()
        {
            return "InputAdapter";
        }

        public void ClearAllInput()
        {
            ConsoleSwitches = 0;
            KeypadState = 0;
            for (var deviceno = 0; deviceno < 4; deviceno++)
            {
                _ControllerActions[deviceno] = 0;
                _Ohms[deviceno] = 0;
                _LightgunPos[deviceno] = 0;
                _DrivingCounters[deviceno >> 1] = 0;
            }
            InputChanged = true;
        }

        public virtual void OnDeserialization(object sender)
        {
            ClearAllInput();
        }

        public void Reset()
        {
            ClearAllInput();
        }

        public void Checkpoint(long frameNumber)
        {
            DoCheckpoint(frameNumber);
            InputChanged = false;
        }

        protected virtual void DoCheckpoint(long frameNumber) { }

        public InputAdapter()
        {
            IgnoreInput = false;
        }

        #region Helpers

        int INPTDumped(int inpt)
        {
            var val = Int32.MaxValue;

            // controller = inpt/2: left=0, right=1
            switch (GetController(inpt >> 1))
            {
                case Controller.Paddles:
                    // playerno = inpt
                    val = _Ohms[inpt];
                    break;
                case Controller.ProLineJoystick:
                    // playerno = inpt/2
                    switch (inpt)
                    {
                        case 0:
                            val = this[0, ControllerAction.Trigger] ? 0 : Int32.MaxValue;
                            break;
                        case 1:
                            val = this[0, ControllerAction.Trigger2] ? 0 : Int32.MaxValue;
                            break;
                        case 2:
                            val = this[1, ControllerAction.Trigger] ? 0 : Int32.MaxValue;
                            break;
                        case 3:
                            val = this[1, ControllerAction.Trigger2] ? 0 : Int32.MaxValue;
                            break;
                    }
                    break;
                case Controller.BoosterGrip:
                    // playerno = inpt
                    val = this[inpt, ControllerAction.Trigger2] ? 0 : Int32.MaxValue;
                    break;
                case Controller.Keypad:
                    val = GetKeypadStateDumped(inpt);
                    break;
            }
            return val;
        }

        bool INPTLatched(int inpt, int scanline, int hpos)
        {
            var deviceno = inpt - 4;
            var val = false;

            switch (GetController(deviceno))
            {
                case Controller.Joystick:
                case Controller.ProLineJoystick:
                case Controller.Driving:
                case Controller.BoosterGrip:
                    val = this[deviceno, ControllerAction.Trigger];
                    break;
                case Controller.Keypad:
                    val = GetKeypadStateLatched(deviceno);
                    break;
                case Controller.Lightgun:
                    if (scanline >= _LightgunPos[deviceno << 1]
                        && hpos >= _LightgunPos[(deviceno << 1) + 1])
                        val = true;
                    break;
            }
            return val;
        }

        readonly byte[] rotGrayCodes = new byte[] { 0x0f, 0x0d, 0x0c, 0x0e };

        byte GetDrivingState(int deviceno)
        {
            if (this[deviceno, ControllerAction.Left])
            {
                SetDrivingCounter(deviceno, (byte)(GetDrivingCounter(deviceno) - 1));
            }
            if (this[deviceno, ControllerAction.Right])
            {
                SetDrivingCounter(deviceno, (byte)(GetDrivingCounter(deviceno) + 1));
            }
            return rotGrayCodes[(GetDrivingCounter(deviceno) / 20) & 0x03];
        }

        bool GetKeypadStateLatched(int deviceno)
        {
            ControllerAction action;

            if ((KeypadState & 0x01) == 0)
            {
                action = ControllerAction.Keypad3;
            }
            else if ((KeypadState & 0x02) == 0)
            {
                action = ControllerAction.Keypad6;
            }
            else if ((KeypadState & 0x04) == 0)
            {
                action = ControllerAction.Keypad9;
            }
            else if ((KeypadState & 0x08) == 0)
            {
                action = ControllerAction.KeypadP;
            }
            else
            {
                return false;
            }
            return this[deviceno, action];
        }

        int GetKeypadStateDumped(int inpt)
        {
            ControllerAction action;

            switch (inpt)
            {
                case 0:
                case 2:
                    if ((KeypadState & 0x01) == 0)
                    {
                        action = ControllerAction.Keypad1;
                    }
                    else if ((KeypadState & 0x02) == 0)
                    {
                        action = ControllerAction.Keypad4;
                    }
                    else if ((KeypadState & 0x04) == 0)
                    {
                        action = ControllerAction.Keypad7;
                    }
                    else if ((KeypadState & 0x08) == 0)
                    {
                        action = ControllerAction.KeypadA;
                    }
                    else
                    {
                        return Int32.MaxValue;
                    }
                    break;
                case 1:
                case 3:
                    if ((KeypadState & 0x01) == 0)
                    {
                        action = ControllerAction.Keypad2;
                    }
                    else if ((KeypadState & 0x02) == 0)
                    {
                        action = ControllerAction.Keypad5;
                    }
                    else if ((KeypadState & 0x04) == 0)
                    {
                        action = ControllerAction.Keypad8;
                    }
                    else if ((KeypadState & 0x08) == 0)
                    {
                        action = ControllerAction.Keypad0;
                    }
                    else
                    {
                        return Int32.MaxValue;
                    }
                    break;
                default:
                    return Int32.MaxValue;
            }
            // playerno = inpt/2
            return this[inpt >> 1, action] ? Int32.MaxValue : 0;
        }

        #endregion
    }

    #endregion

    #region PlaybackInputAdapter Class

    /*
     * PlaybackInputAdapter
     * 
     * An InputAdapter extension providing input playback support 
     * 
     * FIXME: Lightgun needs to be included
     * 
     */
    public sealed class PlaybackInputAdapter : InputAdapter, IDisposable
    {
        public event EventHandler<EventArgs> EofListeners;

        public string CartMD5 { get; private set; }

        long NextPlaybackFrameNumber;
        BinaryReader _BR;

        public override string ToString()
        {
            return "PlaybackInputAdapter";
        }

        void LogPlaybackStatusMsg(string msg)
        {
            Trace.WriteLine(this + ": " + msg);
        }

        protected override void DoCheckpoint(long frameNumber)
        {
            if (_BR == null) return;
            
            while (NextPlaybackFrameNumber <= frameNumber)
            {
                try
                {
                    ConsoleSwitches = _BR.ReadByte();
                    KeypadState = _BR.ReadByte();
                    for (var deviceno = 0; deviceno < 4; deviceno++)
                    {
                        SetControllerAction(deviceno, _BR.ReadInt32());
                    }
                    for (var playerno = 0; playerno < 4; playerno++)
                    {
                        SetOhms(playerno, _BR.ReadInt32());
                    }
                    for (var playerno = 0; playerno < 2; playerno++)
                    {
                        SetDrivingCounter(playerno, _BR.ReadByte());
                    }
                    NextPlaybackFrameNumber = _BR.ReadInt64();
                }
                catch (EndOfStreamException)
                {
                    StopPlayback();
                    if (EofListeners != null)
                    {
                        EofListeners(this, null);
                    }
                    break;
                }
                catch (IOException ex)
                {
                    LogPlaybackStatusMsg(ex.Message);
                    StopPlayback();
                    break;
                }
            }
        }

        public void StopPlayback()
        {
            if (_BR == null) return;

            _BR.Close();
            _BR = null;
            IgnoreInput = false;
            ClearAllInput();
            LogPlaybackStatusMsg("Stopped");
        }

        public PlaybackInputAdapter(string fn)
        {
            IgnoreInput = true;
            string fver, emu7800;
            try
            {
                _BR = new BinaryReader(File.OpenRead(fn));
                fver = _BR.ReadString();
                CartMD5 = _BR.ReadString();
                emu7800 = _BR.ReadString();
                NextPlaybackFrameNumber = _BR.ReadInt64();
            }
            catch (IOException ex)
            {
                LogPlaybackStatusMsg(ex.Message);
                StopPlayback();
                return;
            }
            if (!fver.Equals("1", StringComparison.Ordinal) || !emu7800.Equals("EMU7800", StringComparison.Ordinal))
            {
                throw new InvalidOperationException("bad file format");
            }
            LogPlaybackStatusMsg("Started");
        }

        #region IDisposable Members

        public void Dispose()
        {
            if (_BR != null)
            {
                _BR.Close();
                _BR = null;
            }
        }

        #endregion
    }

    #endregion

    #region RecordInputAdapter Class

    /*
     * RecordInputAdapter
     * 
     * An InputAdapter extension providing input recording support 
     * 
     * FIXME: Lightgun needs to be included
     * 
     */
    public sealed class RecordInputAdapter : InputAdapter, IDisposable
    {
        BinaryWriter _BW;

        public override string ToString()
        {
            return "RecordInputAdapter";
        }

        void LogRecordingStatusMsg(string msg)
        {
            Trace.Write(this);
            Trace.Write(": ");
            Trace.WriteLine(msg);
        }

        protected override void DoCheckpoint(long frameNumber)
        {
            if (_BW == null || !InputChanged) return;
            
            try
            {
                _BW.Write(frameNumber);
                _BW.Write(ConsoleSwitches);
                _BW.Write(KeypadState);
                for (var deviceno = 0; deviceno < 4; deviceno++)
                {
                    _BW.Write(GetControllerAction(deviceno));
                }
                for (var playerno = 0; playerno < 4; playerno++)
                {
                    _BW.Write(GetOhms(playerno));
                }
                for (var playerno = 0; playerno < 2; playerno++)
                {
                    _BW.Write(GetDrivingCounter(playerno));
                }
            }
            catch (IOException ex)
            {
                LogRecordingStatusMsg(ex.Message);
                StopRecording();
            }
        }

        public void StopRecording()
        {
            if (_BW == null) return;

            _BW.Flush();
            _BW.Close();
            _BW = null;
            LogRecordingStatusMsg("Stopped");
        }

        public RecordInputAdapter(string fn, string cartMD5)
        {
            try
            {
                _BW = new BinaryWriter(File.Create(fn));
                _BW.Write("1");
                _BW.Write(cartMD5);
                _BW.Write("EMU7800");
                _BW.Flush();
            }
            catch (IOException ex)
            {
                LogRecordingStatusMsg(ex.Message);
                StopRecording();
                return;
            }
            LogRecordingStatusMsg("Started");
        }

        #region IDisposable Members

        public void Dispose()
        {
            if (_BW != null)
            {
                _BW.Flush();
                _BW.Close();
                _BW = null;
            }
        }

        #endregion
    }

    #endregion
}