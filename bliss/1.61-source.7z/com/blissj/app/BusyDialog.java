package com.blissj.app;

import java.awt.*;
import javax.swing.*;

public class BusyDialog extends JWindow
{

    public BusyDialog(JFrame owner) {
        super(owner);
        initUI();
    }

    private void initUI() {
        Container contentPane = getContentPane();

        label = new JLabel();
        label.setAlignmentX(JLabel.CENTER_ALIGNMENT);
        contentPane.add(label, BorderLayout.CENTER);
    }

    public void displayMessage(String message) {
        label.setText(message);
        pack();
        BlissUtilities.centerWindowOverParent(this);
        setVisible(true);
    }

    private JLabel  label;

}
