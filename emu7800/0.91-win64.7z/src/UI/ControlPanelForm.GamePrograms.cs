using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Forms;
using EMU7800.Machine;

namespace EMU7800.UI
{
    partial class ControlPanelForm
    {
        #region Fields

        TreeNode treenodeTitle, treenodeUnknown;
        bool DoubleClickReady;
        int RomFileCount;
        Dictionary<string, TreeNode> manuIndex, yearIndex, rareIndex, machIndex, contIndex;
#if DEBUG
        Dictionary<string, TreeNode> cartIndex;
#endif

        #endregion

        #region Event Handlers

        void comboboxRomDir_SelectedValueChanged(object sender, EventArgs e)
        {
            backgroundworkerTreeViewLoader.RunWorkerAsync(comboboxRomDir.Text.Trim());
        }

        void buttonBrowse_Click(object sender, EventArgs e)
        {
            var ofdROMSelect = new OpenFileDialog
            {
                Title = "Select ROM File",
                Filter = "ROMs (*.bin)|*.bin|A78 ROMs (*.a78)|*.a78",
                FilterIndex = 1
            };

            var romDir = comboboxRomDir.Text.Trim();
            ofdROMSelect.InitialDirectory = Directory.Exists(romDir) ? romDir : GlobalSettings.Instance.RomDirectory;

            if (ofdROMSelect.ShowDialog() != DialogResult.OK) return;
            Application.DoEvents();
            GameSelectByFileName(ofdROMSelect.FileName);
        }

        void treeviewRomList_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                e.Handled = true;
                SetSelection(treeviewRomList.SelectedNode);
                treeviewRomList_NodeMouseDoubleClick(sender, null);
            }
        }

        void treeviewRomList_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            SetSelection(e.Node);
        }

        void treeviewRomList_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (DoubleClickReady && CurrGameSettings.FileInfo != null)
            {
                buttonStart_Click(sender, e);
            }
            DoubleClickReady = false;
        }

        #endregion

        #region BackgroundWorkerTreeViewLoader

        private void backgroundworkerTreeViewLoader_DoWork(object sender, DoWorkEventArgs e)
        {
            var worker = (BackgroundWorker)sender;

            RomFileCount = 0;

            worker.ReportProgress(-1);
            if (worker.CancellationPending)
            {
                e.Cancel = true;
                return;
            }

            var newRomDir = (e.Argument as string) ?? string.Empty;
            FileInfo[] romFiles;
            try
            {
                romFiles = new DirectoryInfo(newRomDir).GetFiles();
            }
            catch (IOException)
            {
                e.Cancel = true;
                return;
            }

            worker.ReportProgress(0, romFiles);
            if (worker.CancellationPending)
            {
                e.Cancel = true;
                return;
            }

            foreach (var fi in romFiles)
            {
                var gs = ROMProperties.GetGameSettingsFromFile(fi);
                if (gs != null) RomFileCount++;

                worker.ReportProgress(1, gs);
                if (worker.CancellationPending)
                {
                    e.Cancel = true;
                    return;
                }
            }

            e.Result = newRomDir;
        }

        private void backgroundworkerTreeViewLoader_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            if (e.ProgressPercentage < 0)
            {
                Cursor = Cursors.AppStarting;

                buttonStart.Enabled = false;
                buttonResume.Enabled = false;

                comboboxRomDir.Enabled = false;
                buttonBrowse.Enabled = false;

                progressbarRomCount.Visible = false;

                labelRomCount.Text = "Examining ROM Directory...";
                labelRomCount.Visible = true;

                return;
            }

            if (e.ProgressPercentage == 0)
            {
                var romFiles = (FileInfo[])e.UserState;

                progressbarRomCount.Value = 0;
                progressbarRomCount.Minimum = 0;
                progressbarRomCount.Maximum = romFiles.Length;
                progressbarRomCount.Visible = true;

                labelRomCount.Visible = false;

                treeviewRomList.BeginUpdate();
                treeviewRomList.Nodes.Clear();

                treenodeTitle = new TreeNode("Title", 0, 1);
                treeviewRomList.Nodes.Add(treenodeTitle);

                manuIndex = AddTreeSubRoot(treeviewRomList, "Manufacturer", new[] {
                    "Absolute",
                    "Activision",
                    "Apollo",
                    "Atari",
                    "Avalon Hill",
                    "Bitcorp",
                    "Bomb",
                    "CBS Electronics",
                    "CCE",
                    "Coleco",
                    "CommaVid",
                    "Data Age",
                    "Epyx",
                    "Exus",
                    "Froggo",
                    "HomeVision",
                    "Hozer Video Games",
                    "Imagic",
                    "ITT Family Games",
                    "Konami",
                    "Mattel",
                    "Milton Bradley",
                    "Mystique",
                    "Mythicon",
                    "Panda",
                    "Parker Bros",
                    "Playaround",
                    "Sears",
                    "Sega",
                    "Spectravideo",
                    "Starsoft",
                    "Suntek",
                    "Telegames",
                    "Telesys",
                    "Tigervision",
                    "US Games",
                    "Video Gems",
                    "Xonox",
                    "Zellers",
                    "Zimag",
                    "20th Century Fox"});

                var al = new List<string>();
                for (var i = 1977; i <= DateTime.Today.Year; i++)
                {
                    al.Add(i.ToString());
                }
                yearIndex = AddTreeSubRoot(treeviewRomList, "Year", al);

                rareIndex = AddTreeSubRoot(treeviewRomList, "Rarity", new[] {
                    "Common", "Uncommon", "Rare", "Extremely Rare",
                    "Unbelievably Rare", "Prototype", "Unreleased Prototype"});

                machIndex = AddTreeSubRoot(treeviewRomList, "Machine Type", new[] {
                    GetMachineTypeString(MachineType.A2600NTSC, true),
                    GetMachineTypeString(MachineType.A2600PAL, true),
                    GetMachineTypeString(MachineType.A7800NTSC, true),
                    GetMachineTypeString(MachineType.A7800PAL, true)});

                contIndex = AddTreeSubRoot(treeviewRomList, "LController", new[] {
                    "Joystick", "ProLineJoystick", "Paddles", "Driving", "Keypad", "Lightgun", "BoosterGrip"});
#if DEBUG
                var cartList = Enum.GetNames(typeof(CartType));
                cartIndex = AddTreeSubRoot(treeviewRomList, "Cartridge Type", cartList);
#endif
                treenodeUnknown = new TreeNode("Unknown", 0, 1);
                treeviewRomList.Nodes.Add(treenodeUnknown);

                return;
            }

            if (e.ProgressPercentage > 0)
            {
                var gs = e.UserState as GameSettings;
                if (gs == null) return;

                progressbarRomCount.Value = RomFileCount;

                var tn = new TreeNode(BuildTitle(gs.Title, gs.Manufacturer, GetMachineTypeString(gs.MachineType, false), gs.Year), 2, 2)
                {
                    Tag = gs
                };
                treenodeTitle.Nodes.Add(tn);

                AddTreeNode(manuIndex, gs, gs.Manufacturer, gs.Title, GetMachineTypeString(gs.MachineType, false), gs.Year);
                AddTreeNode(yearIndex, gs, gs.Year, gs.Title, gs.Manufacturer, GetMachineTypeString(gs.MachineType, false));
                AddTreeNode(rareIndex, gs, gs.Rarity, gs.Title, gs.Manufacturer, GetMachineTypeString(gs.MachineType, false), gs.Year);
                AddTreeNode(machIndex, gs, GetMachineTypeString(gs.MachineType, true), gs.Title, gs.Manufacturer, GetMachineTypeString(gs.MachineType, false), gs.Year);
                AddTreeNode(contIndex, gs, gs.LController.ToString(), gs.Title, gs.Manufacturer, GetMachineTypeString(gs.MachineType, false), gs.Year);
#if DEBUG
                AddTreeNode(cartIndex, gs, gs.CartType.ToString(), gs.Title, gs.Manufacturer, GetMachineTypeString(gs.MachineType, false), gs.Year);
#endif
            }
        }

        private void backgroundworkerTreeViewLoader_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                labelRomCount.Text = "ROM directory does not exist.";
                treeviewRomList.Nodes.Clear();
            }
            else
            {
                for (var i = 0; i < treeviewRomList.Nodes.Count; )
                {
                    var c = treeviewRomList.Nodes[i];
                    if (PruneTree(c)) c.Remove(); else i++;
                }
                labelRomCount.Text = string.Format("{0} ROM file{1} recognized", RomFileCount, (RomFileCount != 1 ? "s" : ""));
                treeviewRomList.Sorted = true;

                GlobalSettings.Instance.RomDirectory = (string)e.Result;
            }

            treeviewRomList.EndUpdate();
            treeviewRomList.Update();

            progressbarRomCount.Visible = false;
            labelRomCount.Visible = true;

            comboboxRomDir.Enabled = true;
            buttonBrowse.Enabled = true;

            Cursor = Cursors.Arrow;
        }

        #endregion


        #region Helpers

        void GameSelectByFileName(string fn)
        {
            var fi = new FileInfo(fn);

            AddRomDirToComboBoxIfNecessary(fi.DirectoryName);

            // this will reload the TreeView via cmbROMDir_SelectedValueChanged
            comboboxRomDir.SelectedItem = fi.DirectoryName;

            var recog = SelectTitle(fi.FullName);
            if (!recog)
            {
                MessageBox.Show("Use Console Tab to specify custom attributes.", "ROM Not Recognized", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                var gs = ROMProperties.GetGameSettings(Utility.ComputeMD5Digest(fi));
                gs.FileInfo = fi;
                Trace.WriteLine("-------");
                Trace.WriteLine("Unrecognized ROM: prefilled GameSettings fields as follows:");
                Trace.WriteLine(gs);
                CurrGameSettings = gs;
                UpdateGameTitleLabel();
            }
        }

        void AddRomDirToComboBoxIfNecessary(string romDir)
        {
            romDir = romDir.Trim();
            foreach (string item in comboboxRomDir.Items)
            {
                if (item.Equals(romDir, StringComparison.OrdinalIgnoreCase)) return;
            }
            comboboxRomDir.Items.Add(romDir);
        }

        void LoadComboBoxRomDirs()
        {
            var romDirectories = GlobalSettings.Instance.GetUserValue("ROMDirectories");
            foreach (var romDir in romDirectories.Split(';'))
            {
                if (romDir.Trim().Length.Equals(0)) continue;
                AddRomDirToComboBoxIfNecessary(romDir);
            }
        }

        void SaveComboBoxRomDirs()
        {
            var sb = new StringBuilder();
            if (comboboxRomDir.SelectedItem != null)
            {
                // this will cause the subsequent foreach to add a dup, but it will be filtered on the next load.
                // this keeps the currently selected romdir at the top of the list.
                sb.Append(comboboxRomDir.SelectedItem);
            }
            foreach (string item in comboboxRomDir.Items)
            {
                if (!sb.Length.Equals(0)) sb.Append(';');
                sb.Append(item);
            }
            GlobalSettings.Instance.SetUserValue("ROMDirectories", sb.ToString());
        }

        void SetSelection(TreeNode n)
        {
            DoubleClickReady = false;
            if (n == null || n.Tag == null) return;

            DoubleClickReady = true;

            var gs = n.Tag as GameSettings;
            if (gs != CurrGameSettings)
            {
                CurrGameSettings = gs;
                Trace.WriteLine(CurrGameSettings.ToString());
            }

            UpdateGameTitleLabel();
            StartButtonEnabled = true;
            ResumeButtonEnabled = false;
        }

        // Remove TreeNodes that have no dependencies
        static bool PruneTree(TreeNode p)
        {
            var score = 0;
            if (p.Nodes.Count > 0)
            {
                for (var i = 0; i < p.Nodes.Count; )
                {
                    var c = p.Nodes[i];
                    if (PruneTree(c))
                    {
                        c.Remove();
                    }
                    else
                    {
                        score++;
                        i++;
                    }
                }
            }
            return (score == 0 && p.Tag == null);
        }

        bool SelectTitle(string fullName)
        {
            var fi = new FileInfo(fullName);
            var md5 = Utility.ComputeMD5Digest(fi);
            if (md5 == null)
            {
                return false;
            }
            foreach (TreeNode tn in treenodeTitle.Nodes)
            {
                if (tn.Tag != null && md5 == ((GameSettings)tn.Tag).MD5)
                {
                    treeviewRomList.SelectedNode = tn;
                    return true;
                }
            }
            foreach (TreeNode tn in treenodeUnknown.Nodes)
            {
                if (tn.Tag != null && md5 == ((GameSettings)tn.Tag).MD5)
                {
                    treeviewRomList.SelectedNode = tn;
                    return true;
                }
            }
            return false;
        }

        static Dictionary<string, TreeNode> AddTreeSubRoot(TreeView root, string label, IEnumerable<string> subList)
        {
            var tnparent = new TreeNode(label, 0, 1);
            root.Nodes.Add(tnparent);
            var index = new Dictionary<string, TreeNode>();
            TreeNode tn;
            foreach (var s in subList)
            {
                tn = new TreeNode(s, 0, 1);
                tnparent.Nodes.Add(tn);
                index.Add(s, tn);
            }
            tn = new TreeNode("Other", 0, 1);
            tnparent.Nodes.Add(tn);
            index.Add("Other", tn);
            return index;
        }

        static void AddTreeNode(IDictionary<string, TreeNode> index, GameSettings gs, string key, params string[] titlebits)
        {
            var tn = new TreeNode(BuildTitle(titlebits), 2, 2) { Tag = gs };
            if (key == null || !index.ContainsKey(key))
            {
                key = "Other";
            }
            index[key].Nodes.Add(tn);
        }

        static string BuildTitle(params string[] titlebits)
        {
            var title = new StringBuilder();

            for (var i = 0; i < titlebits.Length; i++)
            {
                if (string.IsNullOrEmpty(titlebits[i])) continue;
                if (i > 0)
                {
                    title.Append(", ");
                }
                title.Append(titlebits[i]);
            }
            return title.ToString();
        }

        static string GetMachineTypeString(MachineType machineType, bool verbose)
        {
            var mts = string.Empty;

            switch (machineType)
            {
                case MachineType.A2600NTSC:
                    mts = verbose ? "VCS (2600) NTSC (N.American)" : "VCS";
                    break;
                case MachineType.A2600PAL:
                    mts = verbose ? "VCS (2600) PAL (European)" : "VCS PAL";
                    break;
                case MachineType.A7800NTSC:
                    mts = verbose ? "ProSystem (7800) NTSC (N.American)" : "ProSystem";
                    break;
                case MachineType.A7800PAL:
                    mts = verbose ? "ProSystem (7800) PAL (European)" : "ProSystem PAL";
                    break;
            }

            return mts;
        }

        #endregion
    }
}