
#ifndef SIGNALLINE_H
#define SIGNALLINE_H

#include "osd/types.h"

class SignalLine
{
    public:
        SignalLine() : isHigh(FALSE) { }
        BOOL isHigh;

};

#endif
