/* faux1 terminal Apple 1 emulator
 * Portions Copyright (C) 2012 James M. Reneau (renejm@users.sourceforge.net)
 *
 * napple1 ncurses Apple 1 emulator
 * Copyright (C) 2008 Nobu Hatano
 *
 * Pom1 Apple 1 Emulator
 * Copyright (C) 2000 Verhille Arnaud
 * Copyright (C) 2006 John D. Corrado
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */
#include "m6502.h"
#include "pia6820.h"
#include "memory.h"
#include "keyboard.h"
#include "screen.h"
#include "strings.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <fcntl.h>

#ifdef _WIN32
	#include <conio.h>
#else
	#include <termios.h>
	#include <unistd.h>
	#include <sys/select.h>
	struct termios terminalRaw = {0};
	struct termios terminalOriginal = {0};
#endif


#define KEYBUFLEN 65536

static char keybuf[KEYBUFLEN];
static int keybufhead = 0;
static int keybuftail = 0;
 
void terminalSetupMode(void) {
#ifdef _WIN32
#else
	// load terminalOriginal and Raw and set them up
        if (tcgetattr(0, &terminalRaw) < 0)
                perror("tcsetattr()");
	memcpy((void *) &terminalOriginal, (void *) &terminalRaw, sizeof(terminalOriginal));
        terminalRaw.c_lflag &= ~ICANON;
        terminalRaw.c_lflag &= ~ECHO;
        terminalRaw.c_cc[VMIN] = 1;
        terminalRaw.c_cc[VTIME] = 0;
#endif
}

void terminalRawMode(void) {
#ifdef _WIN32
#else
	// switch to baked mode
       if (tcsetattr(0, TCSANOW, &terminalRaw) < 0) perror(KEYBOARD_RAWERROR);
#endif
}

void terminalNormalMode(void) {
#ifdef _WIN32
#else
	// switch back to original mode
       if (tcsetattr(0, TCSANOW, &terminalOriginal) < 0) perror(KEYBOARD_ORIGINALERROR);
#endif
}


/*
 http://stackoverflow.com/questions/421860/c-c-capture-characters-from-standard-input-without-waiting-for-enter-to-be-pr with help from other places*/
char getrawchar(void) {
        char buf = 0;
#ifdef _WIN32
	if (kbhit()) buf=getch();
#else
        struct timeval chartimeout = { 0L, 0L };
 	// see if there is a char to read
	fd_set fds;
    	FD_ZERO(&fds);
    	FD_SET(0, &fds);
    	if (select(1, &fds, NULL, NULL, &chartimeout)) {
	        if (read(0, &buf, 1) < 0) perror (KEYBOARD_READERROR);
	}
#endif
        return (buf);
}

int stringInput(char* prompt, char* buffer, int length) {
	terminalNormalMode();
	if (prompt) printf("%s",prompt);
	fflush(stdout);
	fgets(buffer,length,stdin);
	// trim crap off of end
	while(buffer[0]!=0x00&&buffer[strlen(buffer)-1]< 0x20) {
		buffer[strlen(buffer)-1]=0x00;
	}
	terminalRawMode();
	if (buffer[0] == 0x00) return 0;
	return 1;
}

int handleInput(void)
{
	char tmp;

	// put out char from buffer if we can
	//printf("??%i %i\n",keybufhead, keybuftail);
	if (keybufhead!=keybuftail) {
		if (readKbdCrND()!=0xA7) {
			tmp = keybuf[keybuftail];
			keybuftail = (keybuftail + 1) % KEYBUFLEN;
			writeKbd((unsigned char)(tmp + 0x80));
			writeKbdCr(0xA7);
			//printf(">>%i %i %c\n",keybufhead, keybuftail, tmp);
		} 
	}

	// read all of the keys into the type ahead buffer
	while ((tmp = getrawchar())!=0) {
		if (tmp == ('L' & 0x1f)) {
			loadMemory();
			resetPia6820();
			resetM6502();
			keybufhead = keybuftail = 0;
			return 1;
		} else if (tmp == ('R' & 0x1f)) {
			resetScreen();
			resetPia6820();
			resetM6502();
			keybufhead = keybuftail = 0;
			return 1;
		} else if (tmp == ('H' & 0x1f)) {
	 		resetScreen();
			resetPia6820();
			resetMemory();
			resetM6502();
			keybufhead = keybuftail = 0;
			return 1;
		} else if (tmp == ('X' & 0x1f)) {
			return 0;
		} else if (tmp == ('E' & 0x1f)) {
			flipMode();
			resetScreen();
			resetPia6820();
			resetM6502();
			keybufhead = keybuftail = 0;
			return 1;
		} else if (tmp == ('V' & 0x1f)) {
			showM6502();
			return 1;
		} 

		// put current char on the type ahead buffer
		keyboardBufferChar(tmp);
	}

	return 1;
}

void keyboardBufferChar(char c) {
	if (c == '\n') {
		c = '\r';
	} else if (c == '\b') {
		c = 0x5f;
	} else if (c >= 'a' && c <= 'z') {
		c = c - 'a' + 'A';
	}
	keybuf[keybufhead] = c;
	keybufhead = (keybufhead + 1) % KEYBUFLEN;
}

void keyboardBufferString(char* s) {
	int len = strlen(s);
	int i;
	for(i=0; i<len; i++) {
		keyboardBufferChar(s[i]);
	}
}

