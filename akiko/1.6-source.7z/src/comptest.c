#include "sysconfig.h"
#include "sysdeps.h"
#include "memory.h"
#include "readcpu.h"
#include "custom.h"
#include "config.h"
#include "options.h"
#include "uae.h"

#include <newcpu.h>
#include <compemu.h>
#include "comptbl.h"

uae_u16 there[100000];
struct regstruct regs, lastint_regs;
uae_u8 here[100000];
int special_mem=0;

struct flag_struct regflags;

uae_u8* comp_pc_p;
int areg_byteinc[] = { 1,1,1,1,1,1,1,2 };
int imm8_table[] = { 8,1,2,3,4,5,6,7 };
addrbank *mem_banks[65536];
uae_u8* baseaddr[65536];

uae_u32 start_pc;
uae_u8* start_pc_p;
struct uae_prefs currprefs, changed_prefs;
uae_u32 optlev;

char* name[]={"eax","ecx","edx","ebx","esp","ebp","esi","edi"};

/* 68040 */
struct cputbl op_smalltbl_0_nf[65536];
extern struct cputbl op_smalltbl_0_comp_nf[];
extern struct cputbl op_smalltbl_0_comp_ff[];
/* 68020 + 68881 */
struct cputbl op_smalltbl_1_nf[65536];
/* 68020 */
struct cputbl op_smalltbl_2_nf[65536];
/* 68010 */
struct cputbl op_smalltbl_3_nf[65536];
/* 68000 */
struct cputbl op_smalltbl_4_nf[65536];
/* 68000 slow but compatible.  */
struct cputbl op_smalltbl_5_nf[65536];

cpuop_func *cpufunctbl[65536];
signed long pissoff;
void write_log_standard (const char *fmt, ...) {};
unsigned long REGPARAM2 op_illg_1 (uae_u32 opcode)
{
    return 4;
}


cpuop_func *compfunctbl[65536];
cpuop_func *nfcompfunctbl[65536];
int canbang=1;
int have_done_picasso=1;

static __inline__ unsigned int cft_map (unsigned int f)
{
    return ((f >> 8) & 255) | ((f & 255) << 8);
}


static void dome(uae_u16 x)
{
  uae_u16 op=x;
  fprintf(stderr,"handler for %04x is %04x (%p)\n",x,table68k[op].handler,compfunctbl[op]);
  if (!compfunctbl[op]) {
    fprintf(stderr,"No handler: %04x\n",x);
    exit(1);
  }
  compfunctbl[op](op);
}

static void domenf(uae_u16 x)
{
  uae_u16 op=x;
  fprintf(stderr,"handler for %04x is %04x (%p)\n",x,table68k[op].handler,nfcompfunctbl[op]);
  if (!nfcompfunctbl[op]) {
    fprintf(stderr,"No handler: %04x\n",x);
    exit(1);
  }
  nfcompfunctbl[op](op);
}


int main(int argc, char** argv)
{
  uae_u8* c;
  uae_u8* l;
  int i;

  currprefs.comptrustbyte=0;
  currprefs.comptrustword=0;
  currprefs.comptrustlong=0;
  currprefs.comptrustnaddr=0;
  optlev=7;

  for (i=0;i<65536;i++)
    there[i]=0x2175;

  read_table68k();
  do_merges();
  build_comp();

  init_comp();
  set_target(here);
  comp_pc_p=(uae_u8*)there;
  regs.pc_p=comp_pc_p;

  dome(0x2000);
  freescratch();
#if 0
  fprintf(stderr,"comp_pc_p is %08p\n",comp_pc_p);
  domenf(0x5888);
  freescratch();
  domenf(0x2028);
  freescratch();
  domenf(0x2149);
  freescratch();
  domenf(0xc188);
  freescratch();
  domenf(0x48d1);
  freescratch();
  domenf(0x2089);
  freescratch();
  dome(0xb7fc);
  freescratch();
  dome(0x670e);
  freescratch();
  dome(0x2013);
  freescratch();
  dome(0x2681);
  freescratch();
  dome(0x4e71);
  freescratch();
  dome(0xb290);
  freescratch();
  dome(0x6704);
  freescratch();
  dome(0xb293);
  freescratch();
  dome(0x67e4);
  freescratch();
  dome(0x2680);
  freescratch();
  dome(0x47eb);
  freescratch();
  dome(0xb7fc);
  freescratch();
  dome(0x670e);
  freescratch();
  dome(0x900c);
  freescratch();
  dome(0x8110);
  freescratch();
  dome(0x8210);
  freescratch();
  dome(0xf941);
  freescratch();
  dome(0xbc30);
  freescratch();
  dome(0xbc30);
  freescratch();
  dome(0xdf4c);
  freescratch();

#endif
// %%% BRIAN KING WAS HERE %%%
#if 0
  flush();
#else
  flush(1);
#endif

  l=get_target();
  c=here;
  while (c<l) {
    printf("\t.byte 0x%02x\n",*c);
    c++;
  }
  fprintf(stderr,"baseaddr is %p\n",baseaddr);
  return 0;
}
