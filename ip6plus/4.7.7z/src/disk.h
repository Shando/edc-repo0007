/** iP6: PC-6000/6600 series emualtor ************************/
/**                                                         **/
/**                           disk.h                        **/
/**                                                         **/
/*                     Inteligent  disk unit                 */
/*************************************************************/
/* written by windy */
void disk_out( byte Port, byte Value);
byte disk_inp( byte Port);


void exec_command(void);
