/*
 * PerfTimer.cs
 *
 * Provides access to the Windows high performance timer.
 *
 * Copyright (c) 2003 Mike Murphy
 *
 */

using System;
using System.Runtime.InteropServices;

namespace EMU7800 {

public class PerfTimer {
	
	// Retrieves the system's performance counter frequency 
	[DllImport("kernel32")]
	private static extern bool QueryPerformanceFrequency(ref long Frequency);
	
	// Retrieves the current number of ticks for this system
	[DllImport("kernel32")]
	private static extern bool QueryPerformanceCounter(ref long Count);

	private static long ticksPerSecond;

	static PerfTimer() {
		QueryPerformanceFrequency(ref ticksPerSecond);
	}

	public static long TicksPerSecond {
		get {
			return ticksPerSecond;
		}
	}

	public static long Ticks {
		get {
			long ticks = 0;
			QueryPerformanceCounter(ref ticks);
			return ticks;
		}
	}
}
}