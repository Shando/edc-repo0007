

#if AGA

#define attach_2nda attach_2nda_aga
#define attach_2ndb attach_2ndb_aga
#define walk_sprites walk_sprites_aga
#define do_sprite_collisions do_sprite_collisions_aga
#define render_sprite render_sprite_aga
#define TYPE uae_u64

#else

#define attach_2nda attach_2nda_ecs
#define attach_2ndb attach_2ndb_ecs
#define walk_sprites walk_sprites_ecs
#define do_sprite_collisions do_sprite_collisions_ecs
#define render_sprite render_sprite_ecs
#define TYPE uae_u16

#endif

static TYPE attach_2nda, attach_2ndb;

static void do_sprite_collisions (struct sprite_draw *spd, int prev_overlap, int i, int nr_spr, TYPE *dataa, TYPE *datab)
{
    int j;
    int sprxp = spd[i].linepos;
    TYPE mask2 = 0;
    int sbit = 1 << spd[i].num;
    int attach_compare = -1;

#if AGA
    *dataa = spd[i].dataa_aga;
    *datab = spd[i].datab_aga;
#else
    *dataa = spd[i].dataa_ecs;
    *datab = spd[i].datab_ecs;
#endif

    attach_2nda = attach_2ndb = 0;
    if ((spd[i].num & 1) == 1 && (spd[i].ctl & 0x80) == 0x80)
	attach_compare = spd[i].num - 1;

    for (j = prev_overlap; j < i; j++) {
	TYPE mask1a, mask1b;
	int off;

	if (spd[i].num < spd[j].num)
	    continue;

	off = sprxp - spd[j].linepos;
	off <<= sprx_shift;
#if AGA
	mask1a = spd[j].dataa_aga;
	mask1b = spd[j].datab_aga;
#else
        mask1a = spd[j].dataa_ecs;
        mask1b = spd[j].datab_ecs;
#endif
	mask1a >>= off;
	mask1b >>= off;

	/* If j is an attachment for i, then j doesn't block i */
	if (spd[j].num == attach_compare) {
	    attach_2nda |= mask1a;
	    attach_2ndb |= mask1b;
	} else {
	    mask1a |= mask1b;
	    if ((*dataa & mask1a) || (*datab & mask1a))
		clxdat |= clxtab[(sbit | (1 << spd[j].num)) & clx_sprmask];
	    mask2 |= mask1a;
	}
    }
    for (j = i+1; j < nr_spr; j++) {
	TYPE mask1a, mask1b;
	int off = spd[j].linepos - sprxp;

	if (off >= sprite_width || spd[i].num < spd[j].num)
	    break;

	off <<= sprx_shift;
#if AGA
	mask1a = spd[j].dataa_aga;
	mask1b = spd[j].datab_aga;
#else
	mask1a = spd[j].dataa_ecs;
	mask1b = spd[j].datab_ecs;
#endif
	mask1a <<= off;
	mask1b <<= off;

	/* If j is an attachment for i, then j doesn't block i */
	if (spd[j].num == attach_compare) {
	    attach_2nda |= mask1a;
	    attach_2ndb |= mask1b;
	} else {
	    mask1a |= mask1b;
	    if ((*dataa & mask1a) || (*datab & mask1a))
		clxdat |= clxtab[(sbit | (1 << spd[j].num)) & clx_sprmask];
	    mask2 |= mask1a;
	}
    }
    
    *dataa &= ~mask2;
    *datab &= ~mask2;
}

/* We use the compiler's inlining ability to ensure that HAM, ATTCH and
   SPRX_INC are in effect compile time constants.  That will cause some
   unnecessary code to be optimized away.
   Don't touch this if you don't know what you are doing.  */
static void render_sprite (int spr, int sprxp, TYPE dataa, TYPE datab, int ham, int attch, int sprx_inc)
{
    TYPE datcda, datcdb;
    int basecol = sbasecol[spr & 1];
    uae_u8 *dst;
#if AGA
    uae_u8 xor_val;
#endif

    if (!attch)
	basecol += (spr & ~1) * 2;
    if (attch) {
	datcda = attach_2nda;
	datcdb = attach_2ndb;
    }
#if AGA
    xor_val = (uae_u8)(dp_for_drawing->bplcon4 >> 8);
    if (bpldualpf)
        dst = spriteagadpfpixels;
	else
	dst = pixdata.apixels;
#else
    dst = pixdata.apixels;
    if (bpldualpf) basecol |= 128;
#endif
    dst += pixels_offset;

    for (; attch ? dataa | datab | datcda | datcdb : dataa | datab; sprxp += sprx_inc) {
	int col = (int) ( (dataa & 1) | ((datab & 1) << 1) );
	dataa >>= 1;
	datab >>= 1;
	if (attch) {
	    col <<= 2;
	    col |= (datcda & 1) | ((datcdb & 1) << 1);
	    datcda >>= 1;
	    datcdb >>= 1;
	}
	if (col) {
	    col |= basecol;
#if AGA
	    col ^= xor_val;
#endif
	    if (ham) {
		col = color_reg_get (&colors_for_drawing, col);
		ham_linebuf[sprxp + pixels_offset] = col;
		if (sprx_inc == 2) {
		    ham_linebuf[sprxp + pixels_offset + 1] = col;
		}
	    } else {
		dst[sprxp] = col;
		if (sprx_inc == 2) {
		    dst[sprxp + 1] = col;
		}
	    }
	}
    }
}

STATIC_INLINE void walk_sprites (struct sprite_draw *spd, int nr_spr)
{
    int i, prev_overlap;
    int last_sprite_pos = -64;
    TYPE plane1 = 0, plane2 = 0;

    prev_overlap = 0;
    for (i = 0; i < nr_spr; i++) {
	int sprxp = spd[i].linepos;
	int m = 1 << spd[i].num;
	TYPE dataa, datab;
	while (prev_overlap < i && spd[prev_overlap].linepos + sprite_width <= sprxp)
	    prev_overlap++;
	do_sprite_collisions (spd, prev_overlap, i, nr_spr, &dataa, &datab);
	if (currprefs.gfx_lores == 2)
	    sprxp >>= 1;
	if ((bpldualpf && plfpri[1] < 256) || (plfpri[2] < 256)) {
	    if (sprxp != last_sprite_pos) {
		int ok = last_sprite_pos - sprxp + real_sprite_width;
		int ok2;
		if (ok <= 0) {
		    ok = ok2 = 0;
		    plane1 = 0;
		    plane2 = 0;
		} else {
		    ok2 = ok << sprx_shift;
		    plane1 >>= real_sprite_width - ok2;
		    plane2 >>= real_sprite_width - ok2;
		}
		last_sprite_pos = sprxp;

		if (bpldualpf) {
		    TYPE mask = 1 << ok2;
		    int p = sprxp + ok;

		    for (; mask; mask <<= 1, p += sprx_inc) {
			int data = pixdata.apixels[p + pixels_offset];
			if (dblpf_2nd2[data] == 2)
			    plane2 |= mask;
			if (dblpf_2nd1[data] == 1)
			    plane1 |= mask;
		    }
		} else {
		    TYPE mask = 1 << ok2;
		    int p = sprxp + ok;

		    for (; mask; mask <<= 1, p += sprx_inc) {
			if (pixdata.apixels[p + pixels_offset])
			    plane2 |= mask;
		    }
		}
	    }
	    if (bpldualpf && m >= plfpri[1]) {
		dataa &= ~plane1;
		datab &= ~plane1;
		attach_2nda &= ~plane1;
		attach_2ndb &= ~plane1;
	    }
	    if (m >= plfpri[2]) {
		dataa &= ~plane2;
		datab &= ~plane2;
		attach_2nda &= ~plane2;
		attach_2ndb &= ~plane2;
	    }
	}
	/* If this seems strange to you, see the comment near render_sprite
	   about inlining.  If it still seems strange, don't touch any of
	   this.  */
	if ((spd[i].num & 1) == 1 && (spd[i].ctl & 0x80) == 0x80) {
	    /* Attached sprite */
	    if (bplham) {
		if (sprx_inc == 1) {
		    render_sprite (spd[i].num, sprxp, dataa, datab, 1, 1, 1);
		} else {
		    render_sprite (spd[i].num, sprxp, dataa, datab, 1, 1, 2);
		}
	    } else {
		if (sprx_inc == 1) {
		    render_sprite (spd[i].num, sprxp, dataa, datab, 0, 1, 1);
		} else {
		    render_sprite (spd[i].num, sprxp, dataa, datab, 0, 1, 2);
		}
	    }
	    /* This still leaves one attached sprite bug, but at the moment I'm too lazy */
	    if (i + 1 < nr_spr && spd[i+1].num == spd[i].num - 1 && spd[i+1].linepos == spd[i].linepos)
		i++;
	} else {
	    if (0 && bplham) {
		if (sprx_inc == 1) {
		    render_sprite (spd[i].num, sprxp, dataa, datab, 1, 0, 1);
		} else {
		    render_sprite (spd[i].num, sprxp, dataa, datab, 1, 0, 2);
		}
	    } else {
		if (sprx_inc == 1) {
		    render_sprite (spd[i].num, sprxp, dataa, datab, 0, 0, 1);
		} else {
		    render_sprite (spd[i].num, sprxp, dataa, datab, 0, 0, 2);
		}
	    }
	}
    }
}

#undef attach_2nda
#undef attach_2ndb
#undef walk_sprites
#undef do_sprite_collisions
#undef render_sprite
#undef AGA
#undef TYPE