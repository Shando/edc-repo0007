package com.bliss.core;

import java.io.IOException;

public abstract class Memory
{

    protected Memory() {
        this(-1);
    }

    protected Memory(int bank) {
        this.bank = bank;
    }

    public abstract void reset();

    public abstract void save(SaveOutputStream sos) throws IOException;

    public abstract void load(LoadInputStream lis) throws IOException;

    public abstract int getLocation();

    public abstract int getSize();

    public abstract int peek(int location);

    public abstract void poke(int location, int value);

    public boolean isBanked() {
        return (bank != -1);
    }

    public int getBank() {
        return bank;
    }

    private int bank;

    public final static int UNMAPPED_PEEK = 0xFFFF;

}
