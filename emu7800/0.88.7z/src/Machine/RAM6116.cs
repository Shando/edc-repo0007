/*
 * RAM6116.cs
 *
 * Implements a 6116 RAM device found in the 7800.
 *
 * Copyright (c) 2004 Mike Murphy
 *
 */
using System;

namespace EMU7800.Machine
{
    [Serializable]
    public class RAM6116 : IDevice
    {
        readonly byte[] RAM = new byte[0x800];

        public void Reset() {}
        public void Map(AddressSpace addrSpace) {}

        public byte this[ushort addr]
        {
            get { return RAM[addr & 0x07ff]; }
            set { RAM[addr & 0x07ff] = value; }
        }
    }
}