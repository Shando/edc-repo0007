/*
 * HostGdi
 *
 * A GDI-based Host.
 *
 * Copyright (c) 2003-2007 Mike Murphy
 *
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Threading;
using System.Windows.Forms;
using EMU7800.Host.DirectX;
using EMU7800.Machine;

namespace EMU7800.Host.Gdi
{
    public class HostGdiForm : Form
    {
        private HostGdi H { get; set; }
        private MachineBase M { get; set; }

        byte[] _ScanlineBuffer;
        Rectangulator _Rectangulator;
        bool _ReqRefresh;

        Font _TextFont;
        SolidBrush _TextBrush;
        Graphics _RGraphics;
        readonly SolidBrush _SBrush = new SolidBrush(Color.Black);

        Dictionary<Keys, HostInput> _KeyBindings;

        readonly Stopwatch _Stopwatch = new Stopwatch();
        const int FRAME_SAMPLES = 120;
        int _FrameRectangleCount, _UsedAudioBuffers;
        long _FrameDuration, _FrameSleepableDuration;
        readonly int[] _RunMachineTicks = new int[FRAME_SAMPLES];
        readonly int[] _WaitTicks = new int[FRAME_SAMPLES];
        readonly int[] _Rectangles = new int[FRAME_SAMPLES];

        private HostGdiForm()
        {
            InitializeComponent();
        }

        public HostGdiForm(HostGdi host) : this()
        {
            if (host == null) throw new ArgumentNullException("host");
            H = host;
        }

        public void Run(MachineBase m)
        {
            Trace.WriteLine("GDI Host startup");

            M = m;

            Text = EMU7800App.Title;

            _ScanlineBuffer = new byte[M.VisiblePitch];
            var r = new Rectangulator(M.VisiblePitch, M.Scanlines);
            r.UpdateRect += OnUpdateRect;
            r.Palette = M.GetPalette();
            r.PixelAspectXRatio = 320 / M.VisiblePitch;
            r.OffsetLeft = 0;
            r.ClipTop = M.FirstScanline;
            r.ClipHeight = 240;
            r.UpdateTransformationParameters();
            _Rectangulator = r;

            ShowInTaskbar = true;
            FormBorderStyle = FormBorderStyle.Sizable;
            CenterToScreen();

            ClientSize = new Size(640, 480);
            MinimumSize = new Size(320 + 8, 240 + 27);
        
            // Enable double-buffering to avoid flicker
            SetStyle(ControlStyles.UserPaint, true);
            SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            SetStyle(ControlStyles.DoubleBuffer, true);

            _TextFont = new Font("Courier New", 18);
            _TextBrush = new SolidBrush(Color.White);

            _FrameDuration = Stopwatch.Frequency / H.EffectiveFPS;
            _FrameSleepableDuration = _FrameDuration - 4*Stopwatch.Frequency/1000;

            InitializeKeyBindings();

            Paint += OnPaint;
            Layout += OnLayout;
            Closing += OnClosing;

            MouseDown += (sender, e) => OnMouseClick(e, true);
            MouseUp += (sender, e) => OnMouseClick(e, false);
            MouseMove += (sender, e) => OnMouseMove_(e);

            KeyDown += (sender, e) => OnKeyPress(e, true);
            KeyUp += (sender, e) => OnKeyPress(e, false);
            KeyPreview = true;

            Show();

            _ReqRefresh = true;

            Run();

            Trace.WriteLine("GDI Host shutdown");

            Close();
        }

        void Run()
        {
            while (true)
            {
                _Stopwatch.Reset();
                _Stopwatch.Start();

                _FrameRectangleCount = 0;

                Application.DoEvents();

                if (H.Ended || !Created)
                {
                    break;
                }

                if (_ReqRefresh)
                {
                    _RGraphics.Clear(Color.Black);
                    _Rectangulator.DrawEntireFrame(H.Paused);
                    _ReqRefresh = false;
                }

                if (!H.Paused && !M.MachineHalt)
                {
                    M.RunFrame();
                    SubmitFrameToRectangulator();
                }
                else if (H.Paused)
                {
                    for (var i = 0; i < M.SoundFrameBuffer.Length; i++)
                    {
                        M.SoundFrameBuffer[i] = 0;
                    }
                }

                var endOfRunMachineTick = _Stopwatch.ElapsedTicks;

                ShowPostedMsg();

                _UsedAudioBuffers = H.EnqueueAudio(M.SoundFrameBuffer);

                while (_Stopwatch.ElapsedTicks < _FrameSleepableDuration) Thread.Sleep(1);
                while (_Stopwatch.ElapsedTicks < _FrameDuration) { }

                var endOfCycleTick = _Stopwatch.ElapsedTicks;

                var statIndex = (int)M.FrameNumber % FRAME_SAMPLES;
                _RunMachineTicks[statIndex] = (int)endOfRunMachineTick;
                _WaitTicks[statIndex] = (int)(endOfCycleTick - endOfRunMachineTick);
                if (_FrameRectangleCount != 0) _Rectangles[statIndex] = _FrameRectangleCount;
            }

            H.CloseAudio();
        }

        void InitializeKeyBindings()
        {
            _KeyBindings = new Dictionary<Keys, HostInput>
            {
                {Keys.Escape,       HostInput.End},
                {Keys.P,            HostInput.Pause},
                {Keys.Z,            HostInput.Fire},
                {Keys.X,            HostInput.Fire2},
                {Keys.Left,         HostInput.Left},
                {Keys.Up,           HostInput.Up},
                {Keys.Right,        HostInput.Right},
                {Keys.Down,         HostInput.Down},
                {Keys.NumPad7,      HostInput.NumPad7},
                {Keys.NumPad8,      HostInput.NumPad8},
                {Keys.NumPad9,      HostInput.NumPad9},
                {Keys.NumPad4,      HostInput.NumPad4},
                {Keys.NumPad5,      HostInput.NumPad5},
                {Keys.NumPad6,      HostInput.NumPad6},
                {Keys.NumPad1,      HostInput.NumPad1},
                {Keys.NumPad2,      HostInput.NumPad2},
                {Keys.NumPad3,      HostInput.NumPad3},
                {Keys.Multiply,     HostInput.NumPadMult},
                {Keys.NumPad0,      HostInput.NumPad0},
                {Keys.Divide,       HostInput.NumPadDiv},
                {Keys.D1,           HostInput.LeftDifficulty},
                {Keys.D2,           HostInput.RightDifficulty},
                {Keys.F1,           HostInput.SetKeyboardToPlayer1},
                {Keys.F2,           HostInput.SetKeyboardToPlayer2},
                {Keys.F3,           HostInput.SetKeyboardToPlayer3},
                {Keys.F4,           HostInput.SetKeyboardToPlayer4},
                {Keys.F5,           HostInput.PanLeft},
                {Keys.F6,           HostInput.PanRight},
                {Keys.F7,           HostInput.PanUp},
                {Keys.F8,           HostInput.PanDown},
                {Keys.F11,          HostInput.SaveMachine},
                {Keys.F12,          HostInput.TakeScreenshot},
                {Keys.C,            HostInput.Color},
                {Keys.F,            HostInput.ShowFrameStats},
                {Keys.M,            HostInput.Mute},
                {Keys.R,            HostInput.Reset},
                {Keys.S,            HostInput.Select}
            };

            // this may not be complete or 100% accurate--more effort required
            var keyToKeysMapping = new Dictionary<Key, Keys>
            {
                {Key.A,             Keys.A},
                {Key.Add,           Keys.Add},
                {Key.Apps,          Keys.Apps},
                {Key.B,             Keys.B},
                {Key.Back,          Keys.Back},
                {Key.C,             Keys.C},
                {Key.CapsLock,      Keys.CapsLock},
                {Key.D,             Keys.D},
                {Key.D0,            Keys.D0},
                {Key.D1,            Keys.D1},
                {Key.D2,            Keys.D2},
                {Key.D3,            Keys.D3},
                {Key.D4,            Keys.D4},
                {Key.D5,            Keys.D5},
                {Key.D6,            Keys.D6},
                {Key.D7,            Keys.D7},
                {Key.D8,            Keys.D8},
                {Key.D9,            Keys.D9},
                {Key.Decimal,       Keys.Decimal},
                {Key.Delete,        Keys.Delete},
                {Key.Divide,        Keys.Divide},
                {Key.Down,          Keys.Down},
                {Key.E,             Keys.E},
                {Key.End,           Keys.End},
                {Key.Return,        Keys.Enter},
                {Key.Escape,        Keys.Escape},
                {Key.F,             Keys.F},
                {Key.F1,            Keys.F1},
                {Key.F2,            Keys.F2},
                {Key.F3,            Keys.F3},
                {Key.F4,            Keys.F4},
                {Key.F5,            Keys.F5},
                {Key.F6,            Keys.F6},
                {Key.F7,            Keys.F7},
                {Key.F8,            Keys.F8},
                {Key.F9,            Keys.F9},
                {Key.F10,           Keys.F10},
                {Key.F11,           Keys.F11},
                {Key.F12,           Keys.F12},
                {Key.F13,           Keys.F13},
                {Key.F14,           Keys.F14},
                {Key.F15,           Keys.F15},
                {Key.G,             Keys.G},
                {Key.H,             Keys.H},
                {Key.Home,          Keys.Home},
                {Key.I,             Keys.I},
                {Key.Insert,        Keys.Insert},
                {Key.J,             Keys.J},
                {Key.K,             Keys.K},
                {Key.L,             Keys.L},
                {Key.LeftControl,   Keys.LControlKey},
                {Key.Left,          Keys.Left},
                {Key.LeftAlt,       Keys.LMenu},
                {Key.LeftShift,     Keys.LShiftKey},
                {Key.LeftWindows,   Keys.LWin},
                {Key.M,             Keys.M},
                {Key.Multiply,      Keys.Multiply},
                {Key.N,             Keys.N},
                {Key.Numlock,       Keys.NumLock},
                {Key.NumPad0,       Keys.NumPad0},
                {Key.NumPad1,       Keys.NumPad1},
                {Key.NumPad2,       Keys.NumPad2},
                {Key.NumPad3,       Keys.NumPad3},
                {Key.NumPad4,       Keys.NumPad4},
                {Key.NumPad5,       Keys.NumPad5},
                {Key.NumPad6,       Keys.NumPad6},
                {Key.NumPad7,       Keys.NumPad7},
                {Key.NumPad8,       Keys.NumPad8},
                {Key.NumPad9,       Keys.NumPad9},
                {Key.O,             Keys.O},
                {Key.P,             Keys.P},
                {Key.PageDown,      Keys.PageDown},
                {Key.PageUp,        Keys.PageUp},
                {Key.Pause,         Keys.Pause},
                {Key.Q,             Keys.Q},
                {Key.R,             Keys.R},
                {Key.RightControl,  Keys.RControlKey},
                {Key.Right,         Keys.Right},
                {Key.RightShift,    Keys.RShiftKey},
                {Key.RightWindows,  Keys.RWin},
                {Key.S,             Keys.S},
                {Key.Scroll,        Keys.Scroll},
                {Key.Space,         Keys.Space},
                {Key.Subtract,      Keys.Subtract},
                {Key.T,             Keys.T},
                {Key.Tab,           Keys.Tab},
                {Key.U,             Keys.U},
                {Key.Up,            Keys.Up},
                {Key.V,             Keys.V},
                {Key.W,             Keys.W},
                {Key.X,             Keys.X},
                {Key.Y,             Keys.Y},
                {Key.Z,             Keys.Z},
            };

            foreach (var keyVal in HostBase.UpdateKeyBindingsFromGlobalSettings(HostBase.CreateDefaultKeyBindings()))
            {
                Keys key;
                if (!keyToKeysMapping.TryGetValue(keyVal.Key, out key))
                {
                    Trace.WriteLine("HostGdi.InitializeKeyBindings: unable to map DirectX " + keyVal.Key + " enum to equivalent WinFroms enum");
                    continue;
                }

                var priorKey = key;
                foreach (var keysVal in _KeyBindings)
                {
                    if (!keysVal.Value.Equals(keyVal.Value)) continue;
                    priorKey = keysVal.Key;
                    break;
                }
                if (priorKey.Equals(key)) continue;

                _KeyBindings.Remove(priorKey);
                _KeyBindings.Add(key, keyVal.Value);
            }
        }

        void OnMouseClick(MouseEventArgs e, bool down)
        {
            if (!H.Paused && e.Button == MouseButtons.Left)
            {
                H.RaiseInput(HostInput.Fire, down);
            }
        }

        void OnMouseMove_(MouseEventArgs e)
        {
            H.RaiseLightGunInput(Width, e.X, e.Y);
            H.RaisePaddleInput(Width, e.X);
        }

        void OnKeyPress(KeyEventArgs e, bool down)
        {
            e.Handled = true;

            HostInput hostInput;
            if (!_KeyBindings.TryGetValue(e.KeyCode, out hostInput)) return;

            switch (hostInput)
            {
                case HostInput.ShowFrameStats:
                    if (!down) break;
                    double rmTicks = 0.0, wTicks = 0.0, avgRectPerFrame = 0.0;
                    for (var i = 0; i < FRAME_SAMPLES; i++)
                    {
                        rmTicks += _RunMachineTicks[i];
                        wTicks += _WaitTicks[i];
                        avgRectPerFrame += _Rectangles[i];
                    }
                    rmTicks = rmTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
                    wTicks = wTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
                    avgRectPerFrame /= FRAME_SAMPLES;
                    H.PostedMsg = string.Format("{0:0.0} {1:0.0} {2:0.0} {3:0} {4:0.0} RPF", rmTicks, wTicks, rmTicks + wTicks, _UsedAudioBuffers, avgRectPerFrame);
                    break;
                case HostInput.PanLeft:
                    if (!down) break;
                    _Rectangulator.OffsetLeft++;
                    _Rectangulator.UpdateTransformationParameters();
                    _ReqRefresh = true;
                    break;
                case HostInput.PanRight:
                    if (!down) break;
                    _Rectangulator.OffsetLeft--;
                    _Rectangulator.UpdateTransformationParameters();
                    _ReqRefresh = true;
                    break;
                case HostInput.PanUp:
                    if (!down) break;
                    _Rectangulator.ClipTop++;
                    _Rectangulator.UpdateTransformationParameters();
                    _ReqRefresh = true;
                    break;
                case HostInput.PanDown:
                    if (!down) break;
                    _Rectangulator.ClipTop--;
                    _Rectangulator.UpdateTransformationParameters();
                    _ReqRefresh = true;
                    break;
                default:
                    H.RaiseInput(_KeyBindings[e.KeyCode], down);
                    break;
            }
        }

        bool _RenderedTextMsg;

        void ShowPostedMsg()
        {
            if (H.PostedMsg.Length > 0)
            {
                ClearTextMsg();
                ShowTextMsg();
                _RenderedTextMsg = true;
            }
            else if (_RenderedTextMsg)
            {
                ClearTextMsg();
            }
        }

        void ShowTextMsg()
        {
            _TextBrush.Color = Color.White;
            _RGraphics = CreateGraphics();
            _RGraphics.TextRenderingHint = TextRenderingHint.SystemDefault;
            _RGraphics.DrawString(H.PostedMsg, _TextFont, _TextBrush, 0, 0);
            _RenderedTextMsg = true;
        }

        void ClearTextMsg()
        {
            _TextBrush.Color = Color.Black;
            _RGraphics.FillRectangle(_TextBrush, 0, 0, ClientSize.Width, 30);
            _RenderedTextMsg = false;
        }

        void OnLayout(object sender, LayoutEventArgs e)
        {
            _RGraphics = CreateGraphics();
            _RGraphics.CompositingMode = CompositingMode.SourceCopy;
            _RGraphics.CompositingQuality = CompositingQuality.Invalid;
            _RGraphics.SmoothingMode = SmoothingMode.None;
            _RGraphics.InterpolationMode = InterpolationMode.NearestNeighbor;

            _Rectangulator.ViewPortSize = ClientSize;
            _Rectangulator.UpdateTransformationParameters();

            _ReqRefresh = true;
        }

        void OnClosing(object sender,  CancelEventArgs e)
        {
            if (!H.Ended)
            {
                // if game is running, veto close request while arranging for game loop termination
                // this facilitates cleaning things up nicely
                H.RaiseInput(HostInput.End, true);
                e.Cancel = true;
            }
        }

        void OnPaint(object sender, PaintEventArgs e)
        {
            _ReqRefresh = true;
        }

        void SubmitFrameToRectangulator()
        {
            _Rectangulator.StartFrame();
            for (var scanline = 0; scanline < M.Scanlines; scanline++)
            {
                for (var x = 0; x < M.VisiblePitch; x++)
                {
                    _ScanlineBuffer[x] = M.VideoFrameBuffer[scanline * M.VisiblePitch + x];
                }
                // TODO: Rectangulator should be enhanced to just consume the entire VideoFrameBuffer
                _Rectangulator.InputScanline(_ScanlineBuffer, scanline, 0, M.VisiblePitch);
            }
            _Rectangulator.EndFrame();
        }

        void OnUpdateRect(DisplRect r)
        {
            _SBrush.Color = Color.FromArgb(r.Argb);
            _RGraphics.FillRectangle(_SBrush, r.Rectangle);
            _FrameRectangleCount++;
        }

        private void InitializeComponent()
        {
            var resources = new ComponentResourceManager(typeof(HostGdiForm));
            SuspendLayout();
            // 
            // HostGdiForm
            // 
            ClientSize = new Size(284, 264);
            Icon = ((Icon)(resources.GetObject("$this.Icon")));
            Name = "HostGdiForm";
            ResumeLayout(false);

        }
    }

    public class HostGdi : HostBase
    {
        private HostGdiForm F;

        public override void Run(MachineBase m)
        {
            base.Run(m);
            F = new HostGdiForm(this);
            try
            {
                F.Run(M);
            }
            finally
            {
                F.Dispose();
                F = null;
            }
        }
    }
}