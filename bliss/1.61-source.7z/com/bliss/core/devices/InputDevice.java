package com.bliss.core.devices;

import java.awt.image.*;

public interface InputDevice extends Device
{

    public void poll();

    public float getControlValue(int controlID);

    public InputSignal getInputSignal(String configString);

    public InputSignal getDefaultSignal(int controlID);

    public InputSignal getInputSignal(int controlID);

    public void setInputSignal(int controlID, InputSignal inputSignal);

    public void initConfigMode();

    public InputSignal pollForInputSignal();

    public void releaseConfigMode();

    public final static float SIGNAL_OFF = 0.0f;
    public final static float SIGNAL_ON = 1.0f;

    public final static int PLAYER_ONE_ID_START       = 1000;
    public final static int PLAYER_ONE_NORTH          = PLAYER_ONE_ID_START + 0;
    public final static int PLAYER_ONE_NORTHEAST      = PLAYER_ONE_ID_START + 1;
    public final static int PLAYER_ONE_EAST           = PLAYER_ONE_ID_START + 2;
    public final static int PLAYER_ONE_SOUTHEAST      = PLAYER_ONE_ID_START + 3;
    public final static int PLAYER_ONE_SOUTH          = PLAYER_ONE_ID_START + 4;
    public final static int PLAYER_ONE_SOUTHWEST      = PLAYER_ONE_ID_START + 5;
    public final static int PLAYER_ONE_WEST           = PLAYER_ONE_ID_START + 6;
    public final static int PLAYER_ONE_NORTHWEST      = PLAYER_ONE_ID_START + 7;
    public final static int PLAYER_ONE_BUTTON_ONE     = PLAYER_ONE_ID_START + 8;
    public final static int PLAYER_ONE_BUTTON_TWO     = PLAYER_ONE_ID_START + 9;
    public final static int PLAYER_ONE_BUTTON_THREE   = PLAYER_ONE_ID_START + 10;
    public final static int PLAYER_ONE_BUTTON_FOUR    = PLAYER_ONE_ID_START + 11;
    public final static int PLAYER_ONE_BUTTON_FIVE    = PLAYER_ONE_ID_START + 12;
    public final static int PLAYER_ONE_BUTTON_SIX     = PLAYER_ONE_ID_START + 13;
    public final static int PLAYER_ONE_KEYPAD_ONE     = PLAYER_ONE_ID_START + 14;
    public final static int PLAYER_ONE_KEYPAD_TWO     = PLAYER_ONE_ID_START + 15;
    public final static int PLAYER_ONE_KEYPAD_THREE   = PLAYER_ONE_ID_START + 16;
    public final static int PLAYER_ONE_KEYPAD_FOUR    = PLAYER_ONE_ID_START + 17;
    public final static int PLAYER_ONE_KEYPAD_FIVE    = PLAYER_ONE_ID_START + 18;
    public final static int PLAYER_ONE_KEYPAD_SIX     = PLAYER_ONE_ID_START + 19;
    public final static int PLAYER_ONE_KEYPAD_SEVEN   = PLAYER_ONE_ID_START + 20;
    public final static int PLAYER_ONE_KEYPAD_EIGHT   = PLAYER_ONE_ID_START + 21;
    public final static int PLAYER_ONE_KEYPAD_NINE    = PLAYER_ONE_ID_START + 22;
    public final static int PLAYER_ONE_KEYPAD_ZERO    = PLAYER_ONE_ID_START + 23;
    public final static int PLAYER_ONE_KEYPAD_DELETE  = PLAYER_ONE_ID_START + 24;
    public final static int PLAYER_ONE_KEYPAD_ENTER   = PLAYER_ONE_ID_START + 25;
    public final static int PLAYER_ONE_KEYPAD_ASTERIX = PLAYER_ONE_ID_START + 26;
    public final static int PLAYER_ONE_KEYPAD_POUND   = PLAYER_ONE_ID_START + 27;
    public final static int PLAYER_ONE_ID_END         = PLAYER_ONE_KEYPAD_POUND;

    public final static int PLAYER_TWO_ID_START       = 2000;
    public final static int PLAYER_TWO_NORTH          = PLAYER_TWO_ID_START + 0;
    public final static int PLAYER_TWO_NORTHEAST      = PLAYER_TWO_ID_START + 1;
    public final static int PLAYER_TWO_EAST           = PLAYER_TWO_ID_START + 2;
    public final static int PLAYER_TWO_SOUTHEAST      = PLAYER_TWO_ID_START + 3;
    public final static int PLAYER_TWO_SOUTH          = PLAYER_TWO_ID_START + 4;
    public final static int PLAYER_TWO_SOUTHWEST      = PLAYER_TWO_ID_START + 5;
    public final static int PLAYER_TWO_WEST           = PLAYER_TWO_ID_START + 6;
    public final static int PLAYER_TWO_NORTHWEST      = PLAYER_TWO_ID_START + 7;
    public final static int PLAYER_TWO_BUTTON_ONE     = PLAYER_TWO_ID_START + 8;
    public final static int PLAYER_TWO_BUTTON_TWO     = PLAYER_TWO_ID_START + 9;
    public final static int PLAYER_TWO_BUTTON_THREE   = PLAYER_TWO_ID_START + 10;
    public final static int PLAYER_TWO_BUTTON_FOUR    = PLAYER_TWO_ID_START + 11;
    public final static int PLAYER_TWO_BUTTON_FIVE    = PLAYER_TWO_ID_START + 12;
    public final static int PLAYER_TWO_BUTTON_SIX     = PLAYER_TWO_ID_START + 13;
    public final static int PLAYER_TWO_KEYPAD_ONE     = PLAYER_TWO_ID_START + 14;
    public final static int PLAYER_TWO_KEYPAD_TWO     = PLAYER_TWO_ID_START + 15;
    public final static int PLAYER_TWO_KEYPAD_THREE   = PLAYER_TWO_ID_START + 16;
    public final static int PLAYER_TWO_KEYPAD_FOUR    = PLAYER_TWO_ID_START + 17;
    public final static int PLAYER_TWO_KEYPAD_FIVE    = PLAYER_TWO_ID_START + 18;
    public final static int PLAYER_TWO_KEYPAD_SIX     = PLAYER_TWO_ID_START + 19;
    public final static int PLAYER_TWO_KEYPAD_SEVEN   = PLAYER_TWO_ID_START + 20;
    public final static int PLAYER_TWO_KEYPAD_EIGHT   = PLAYER_TWO_ID_START + 21;
    public final static int PLAYER_TWO_KEYPAD_NINE    = PLAYER_TWO_ID_START + 22;
    public final static int PLAYER_TWO_KEYPAD_ZERO    = PLAYER_TWO_ID_START + 23;
    public final static int PLAYER_TWO_KEYPAD_DELETE  = PLAYER_TWO_ID_START + 24;
    public final static int PLAYER_TWO_KEYPAD_ENTER   = PLAYER_TWO_ID_START + 25;
    public final static int PLAYER_TWO_KEYPAD_ASTERIX = PLAYER_TWO_ID_START + 26;
    public final static int PLAYER_TWO_KEYPAD_POUND   = PLAYER_TWO_ID_START + 27;
    public final static int PLAYER_TWO_ID_END         = PLAYER_TWO_KEYPAD_POUND;

    public final static int KEYBOARD_ID_START = 5000;
    public final static int KEYBOARD_A = KEYBOARD_ID_START + 0;
    public final static int KEYBOARD_B = KEYBOARD_ID_START + 1;
    public final static int KEYBOARD_C = KEYBOARD_ID_START + 2;
    public final static int KEYBOARD_D = KEYBOARD_ID_START + 3;
    public final static int KEYBOARD_E = KEYBOARD_ID_START + 4;
    public final static int KEYBOARD_F = KEYBOARD_ID_START + 5;
    public final static int KEYBOARD_G = KEYBOARD_ID_START + 6;
    public final static int KEYBOARD_H = KEYBOARD_ID_START + 7;
    public final static int KEYBOARD_I = KEYBOARD_ID_START + 8;
    public final static int KEYBOARD_J = KEYBOARD_ID_START + 9;
    public final static int KEYBOARD_K = KEYBOARD_ID_START + 10;
    public final static int KEYBOARD_L = KEYBOARD_ID_START + 11;
    public final static int KEYBOARD_M = KEYBOARD_ID_START + 12;
    public final static int KEYBOARD_N = KEYBOARD_ID_START + 13;
    public final static int KEYBOARD_O = KEYBOARD_ID_START + 14;
    public final static int KEYBOARD_P = KEYBOARD_ID_START + 15;
    public final static int KEYBOARD_Q = KEYBOARD_ID_START + 16;
    public final static int KEYBOARD_R = KEYBOARD_ID_START + 17;
    public final static int KEYBOARD_S = KEYBOARD_ID_START + 18;
    public final static int KEYBOARD_T = KEYBOARD_ID_START + 19;
    public final static int KEYBOARD_U = KEYBOARD_ID_START + 20;
    public final static int KEYBOARD_V = KEYBOARD_ID_START + 21;
    public final static int KEYBOARD_W = KEYBOARD_ID_START + 22;
    public final static int KEYBOARD_X = KEYBOARD_ID_START + 23;
    public final static int KEYBOARD_Y = KEYBOARD_ID_START + 24;
    public final static int KEYBOARD_Z = KEYBOARD_ID_START + 25;

    public final static int KEYBOARD_0 = KEYBOARD_ID_START + 26;
    public final static int KEYBOARD_1 = KEYBOARD_ID_START + 27;
    public final static int KEYBOARD_2 = KEYBOARD_ID_START + 28;
    public final static int KEYBOARD_3 = KEYBOARD_ID_START + 29;
    public final static int KEYBOARD_4 = KEYBOARD_ID_START + 30;
    public final static int KEYBOARD_5 = KEYBOARD_ID_START + 31;
    public final static int KEYBOARD_6 = KEYBOARD_ID_START + 32;
    public final static int KEYBOARD_7 = KEYBOARD_ID_START + 33;
    public final static int KEYBOARD_8 = KEYBOARD_ID_START + 34;
    public final static int KEYBOARD_9 = KEYBOARD_ID_START + 35;

    public final static int KEYBOARD_UP        = KEYBOARD_ID_START + 36;
    public final static int KEYBOARD_DOWN      = KEYBOARD_ID_START + 37;
    public final static int KEYBOARD_LEFT      = KEYBOARD_ID_START + 38;
    public final static int KEYBOARD_RIGHT     = KEYBOARD_ID_START + 39;

    public final static int KEYBOARD_COMMA     = KEYBOARD_ID_START + 40;
    public final static int KEYBOARD_PERIOD    = KEYBOARD_ID_START + 41;
    public final static int KEYBOARD_SPACE     = KEYBOARD_ID_START + 42;
    public final static int KEYBOARD_SEMICOLON = KEYBOARD_ID_START + 43;
    public final static int KEYBOARD_COLON     = KEYBOARD_ID_START + 44;
    public final static int KEYBOARD_ESCAPE    = KEYBOARD_ID_START + 45;
    public final static int KEYBOARD_ENTER     = KEYBOARD_ID_START + 46;
    public final static int KEYBOARD_CONTROL   = KEYBOARD_ID_START + 47;
    public final static int KEYBOARD_SHIFT     = KEYBOARD_ID_START + 48;
    public final static int KEYBOARD_ID_END    = KEYBOARD_SHIFT;

    public final static int MENU_ID_START = 6000;
    public final static int MENU_DISPLAY  = MENU_ID_START + 0;
    public final static int MENU_UP       = MENU_ID_START + 1;
    public final static int MENU_DOWN     = MENU_ID_START + 2;
    public final static int MENU_SELECT   = MENU_ID_START + 3;
    public final static int MENU_ID_END   = MENU_SELECT;

    public final static int EMULATOR_ID_START   = 7000;
    public final static int EMULATOR_PAUSE      = EMULATOR_ID_START + 0;
    public final static int EMULATOR_SAVE       = EMULATOR_ID_START + 1;
    public final static int EMULATOR_LOAD       = EMULATOR_ID_START + 2;
    public final static int EMULATOR_RESET      = EMULATOR_ID_START + 3;
    public final static int EMULATOR_SCREENSHOT = EMULATOR_ID_START + 4;
    public final static int EMULATOR_ID_END     = EMULATOR_SCREENSHOT;

}
