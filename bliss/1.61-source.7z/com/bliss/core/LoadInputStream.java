package com.bliss.core;

import java.io.*;

public class LoadInputStream// extends InputStream
{

    LoadInputStream(InputStream os) {
        this.os = os;
    }

    public int available() throws IOException {
        return os.available();
    }

    public void close() throws IOException {
        os.close();
    }

    public int read(int rangeStart, int rangeEnd) throws IOException {
        int read = os.read();
        if (read < rangeStart || read > rangeEnd)
            throw new IOException("Read out-of-range byte: " + read);

        return read;
    }

    public long readLong(long rangeStart, long rangeEnd) throws IOException {
        long read =
               (((long)os.read()) << 56) | (((long)os.read()) << 48) |
               (((long)os.read()) << 40) | (((long)os.read()) << 32) |
               (((long)os.read()) << 24) | (((long)os.read()) << 16) |
               (((long)os.read()) << 8) | ((long)os.read());
        if (read < rangeStart || read > rangeEnd)
            throw new IOException("Read out-of-range long: " + read);

        return read;
    }

    public int readInt( int rangeStart, int rangeEnd) throws IOException {
        int read = (((int)os.read()) << 24) | (((int)os.read()) << 16) |
               (((int)os.read()) << 8) | ((int)os.read());
        if (read < rangeStart || read > rangeEnd)
            throw new IOException("Read out-of-range integer: " + read);

        return read;
    }

    public boolean readBoolean() throws IOException {
        int read = os.read();
        if (read < 0 || read > 1)
            throw new IOException("Read out-of-range boolean: " + read);
        
        return (read == 1);
    }

    private InputStream os;
}
