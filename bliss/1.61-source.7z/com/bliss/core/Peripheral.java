package com.bliss.core;

import com.bliss.core.devices.*;

/**
 * An abstract class representing a peripheral device to the Intellivision
 * master component.
 *
 * @author Kyle Davis
 */
public interface Peripheral
{

    public int getProcessorCount();
        
    public Processor getProcessor(int i);

    public int getMemoryCount();

    public Memory getMemory(int i);

}
