 /*
  * UAE - The Un*x Amiga Emulator
  *
  * CD32 emulation support code
  *
  * (c) by Andreas Falkenhahn 2001 <andreas.falkenhahn@gmx.de>
  */

#include "sysconfig.h"
#include "sysdeps.h"

#include "cd32.h"
#include <mmsystem.h>

//#define CD32DEBUG 1

struct cd32control cd32ctl;
extern HWND hAmigaWnd;

/*
** Provisional error logger
*/
void logcd32(char *text)
{
	FILE *fh;

	fh=fopen("c:\\cd32dbg.txt","a");
	fputs(text,fh);
	fputs("\n",fh);
	fclose(fh);
}

/*
** Play a track on CD using the Windows MCI
*/ 
DWORD cd32_PlayAudio(int cmd,long offset,long len)
{
    DWORD dwReturn;
    MCI_OPEN_PARMS mciOpenParms;
    MCI_SET_PARMS mciSetParms;
    MCI_PLAY_PARMS mciPlayParms;
	FILE *fh;
	char cddrive[256];

	cd32ctl.CDAudioStopped=FALSE;

	if(!cd32ctl.wDeviceID) {

		//GetCurrentDirectory(1024,olddir);

		fh=fopen("cd32emu\\Install2001.cdd","rb");
		if(!fh) return CD32ERR_CFGFILE;
		fgets(cddrive,255,fh);
		fclose(fh);

	    mciOpenParms.lpstrDeviceType="cdaudio";
		mciOpenParms.lpstrElementName=cddrive;

		if(dwReturn=mciSendCommand(NULL,MCI_OPEN,MCI_OPEN_ELEMENT|MCI_OPEN_TYPE|MCI_OPEN_SHAREABLE,(DWORD)(LPVOID)&mciOpenParms)) return (dwReturn);

		cd32ctl.wDeviceID=mciOpenParms.wDeviceID;

	}

    if(cmd==CD32_PLAYTRACK) {
		mciSetParms.dwTimeFormat = MCI_FORMAT_TMSF;
	} else if (cmd==CD32_PLAYMSF) {
		mciSetParms.dwTimeFormat=MCI_FORMAT_MSF;
	}

    if(dwReturn=mciSendCommand(cd32ctl.wDeviceID,MCI_SET,MCI_SET_TIME_FORMAT,(DWORD)(LPVOID)&mciSetParms)) {
        mciSendCommand(cd32ctl.wDeviceID,MCI_CLOSE,0,NULL);
        return dwReturn;
    } 

    mciPlayParms.dwFrom = 0L;
    mciPlayParms.dwTo = 0L;
    mciPlayParms.dwCallback=(DWORD)hAmigaWnd;
    
	if(cmd==CD32_PLAYTRACK) {
		mciPlayParms.dwFrom=MCI_MAKE_TMSF(offset, 0, 0, 0);
        mciPlayParms.dwTo=MCI_MAKE_TMSF(offset+len, 0, 0, 0);
	} else if (cmd==CD32_PLAYMSF) {
		mciPlayParms.dwFrom=offset;
		mciPlayParms.dwTo=len;
	}

	dwReturn=mciSendCommand(cd32ctl.wDeviceID,MCI_PLAY,MCI_FROM|MCI_TO|MCI_NOTIFY,(DWORD)(LPVOID)&mciPlayParms);
    
	if(dwReturn) {
        mciSendCommand(cd32ctl.wDeviceID,MCI_CLOSE,0,NULL);
        return dwReturn;
    } else {
		cd32ctl.IsAudioPlaying=TRUE;
	}

    return 0;
}
 
/*
** Stop all CD audio
*/ 
int cd32_StopAudio(void)
{
	DWORD dwReturn;

	dwReturn=mciSendCommand(cd32ctl.wDeviceID, MCI_STOP, 0, NULL);
	if(dwReturn) {
        mciSendCommand(cd32ctl.wDeviceID,MCI_CLOSE,0,NULL);
		return dwReturn;
	}

	dwReturn=mciSendCommand(cd32ctl.wDeviceID, MCI_CLOSE,0, NULL);
	if(dwReturn) return dwReturn;

	cd32ctl.wDeviceID=0;
	cd32ctl.IsAudioPlaying=FALSE;

	return 0;
}

/*
** Pause audio and return the previous state (as required by CD_PAUSE)
*/
int cd32_PauseAudio(int pausemode)
{
	if(pausemode) {
		mciSendCommand(cd32ctl.wDeviceID,MCI_PAUSE,0,NULL);
		pausemode=0;
	} else {
		mciSendCommand(cd32ctl.wDeviceID,MCI_RESUME,0,NULL);
		pausemode=1;
	}

	// This is the previous state now
	return pausemode;
}

/*
** Shut down CD32 support
*/
void cd32_close(void)
{
	if(cd32ctl.IsAudioPlaying) {
		mciSendCommand(cd32ctl.wDeviceID, MCI_STOP, 0, NULL);
		mciSendCommand(cd32ctl.wDeviceID, MCI_CLOSE,0, NULL);
	}
}

/*
** Initialize CD32 support
*/
void cd32_init(void)
{
	memset(&cd32ctl,0,sizeof(struct cd32control));
}

/*
** Entry point for the calltrap(70) function
** (called from the Amiga side by Install2001)
*/
uae_u32 cd32_ExecuteCommand(uae_u32 cmd,uae_u32 offset,uae_u32 len)
{
	int error=0;

#ifdef CD32DEBUG
	char text[129];
#endif

	switch(cmd) {
	case CD32_PLAYTRACK:
	case CD32_PLAYMSF:
		error=cd32_PlayAudio(cmd,offset,len);
		break;
	case CD32_STOPTRACK:
		error=cd32_StopAudio();
		break;
	case CD32_PAUSE:
		return cd32_PauseAudio(len);
	case CD32_DETERMINEAUDIOEND:
		return cd32ctl.CDAudioStopped;
	default:
#ifdef CD32DEBUG
		sprintf(text,"Unsupported command #%d received!",cmd);
		logcd32(text);
#endif
		break;
	}

#ifdef CD32DEBUG
		if((error) && (error!=CD32ERR_CFGFILE)) {
			sprintf(text,"CD32: Error with command #%d (Offset: #%d, Length: #%d)",cmd,offset,len);
			logcd32(text);
			mciGetErrorString(error,text,128);
			logcd32(text);
		} else {
			logcd32("Error opening my config file!");
		}
#endif

	return 0;
}