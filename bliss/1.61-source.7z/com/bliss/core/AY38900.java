package com.bliss.core;

import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.text.*;
import java.util.zip.*;
import com.bliss.core.devices.*;

public class AY38900 extends Processor implements Peripheral
{

    public AY38900(EmulationDirector director, CP1610 cpu, SignalLine SR1,
            SignalLine SR2, SignalLine SST)
    {
        this.director = director;
        this.cpu = cpu;
        this.SR1 = SR1;
        this.SR2 = SR2;
        this.SST = SST;
        init();
    }

    public int getProcessorCount() {
        return 1;
    }

    public Processor getProcessor(int i) {
        return this;
    }

    public int getMemoryCount() {
        return memorySegments.length;
    }

    public Memory getMemory(int i) {
        return memorySegments[i];
    }

    public int getClockSpeed() {
        return Intellivision.NTSC_CLOCK_SPEED;
    }


    public void setMessage(String message) {
        setMessage(message, 0);
    }
    
    public void setMessage(String message, int numSeconds) {
        this.message = message;
        if (message != null) {
            this.messageCounter = (60 * numSeconds);
            renderMessage();
            director.displayImage(imageBufferChanged);
        }
        messageChanged = true;
    }

    public void reset() {
        //reset the registers first
        registers.reset();

        //switch to bus copy mode
        setGraphicsBusVisible(true);

        //reset the memory aliases
        for (int i = 1; i < memorySegments.length; i++)
            memorySegments[i].reset();

        //reset the sprites
        for (int i = 0; i < sprites.length; i++)
            sprites[i].reset();

        //reset the state variables
        mode = MODE_INIT;
        SR1.isHigh = true;
        SR2.isHigh = true;
        cpu.isIdle = false;
        backtab.reset();
        gram.reset();
        grom.reset();
        previousDisplayEnabled = true;
        displayEnabled         = false;
        colorStackMode         = false;
        colorModeChanged       = true;
        bordersChanged         = true;
        colorStackChanged      = true;
        offsetsChanged         = true;
        messageChanged         = true;
        imageBufferChanged     = true;

        //local register data
        borderColor = 0;
        blockLeft = blockTop = false;
        horizontalOffset = verticalOffset = 0;

        //blank the offscreen image
        for (int x = 0; x < stagingBankData.length; x++)
            stagingBankData[x] = 0;
    }

    public void save(SaveOutputStream os) throws IOException {
        os.writeInt(mode);
        os.writeBoolean(SR1.isHigh);
        os.writeBoolean(SR2.isHigh);

        os.writeBoolean(previousDisplayEnabled);
        os.writeBoolean(displayEnabled);
        os.writeBoolean(colorStackMode);
        os.write(borderColor);
        os.writeBoolean(blockLeft);
        os.writeBoolean(blockTop);
        os.writeInt(horizontalOffset);
        os.writeInt(verticalOffset);

        //backtab
        backtab.save(os);

        //GRAM
        gram.save(os);

        //registers
        registers.save(os);

        //sprites
        for (int i = 0; i < 8; i++)
            sprites[i].save(os);
    }

    public void load(LoadInputStream is) throws IOException {
        mode = is.readInt(MODE_INIT, MODE_FETCH_ROW_12);
        SR1.isHigh = is.readBoolean();
        SR2.isHigh = is.readBoolean();

        previousDisplayEnabled = is.readBoolean();
        displayEnabled = is.readBoolean();
        colorStackMode = is.readBoolean();
        borderColor = (byte)is.read(0x0, 0xF);
        blockLeft = is.readBoolean();
        blockTop = is.readBoolean();
        horizontalOffset = is.readInt(0x0, 0x7);
        verticalOffset = is.readInt(0x0, 0x7);

        //backtab
        backtab.load(is);

        //GRAM
        gram.load(is);

        //registers
        registers.load(is);

        //sprites
        for (int i = 0; i < 8; i++)
            sprites[i].load(is);

        //now we're all dirty again
        offsetsChanged = true;
        bordersChanged = true;
        colorStackChanged = true;
        colorModeChanged = true;
    }

    public int tick() {
        //move to the next mode
        mode++;

        switch (mode) {
            case MODE_VBLANK:
                renderFrame();
                displayEnabled = false;

                //the emulation director should process and display the image
                //at the beginning of each vblank
                director.pollInput();
                director.displayImage(imageBufferChanged);
                imageBufferChanged = false;
                if (messageCounter > 0) {
                    messageCounter--;
                    if (messageCounter == 0) {
                        message = null;
                        messageChanged = true;
                    }
                }
                setGraphicsBusVisible(true);

                //release SR2, allowing the CPU to run
                SR2.isHigh = true;
                cpu.isIdle = false;

                //kick the irq line
                SR1.isHigh = false;

                return TICK_LENGTH_VBLANK;

            case MODE_START_ACTIVE_DISPLAY:
                SR1.isHigh = true;

                //if the display is not enabled, skip the rest of the modes
                if (!displayEnabled) {
                    if (previousDisplayEnabled) {
                        //render a blank screen
                        for (int x = 0; x < stagingBankData.length; x++)
                            stagingBankData[x] = borderColor;
                    }
                    mode = MODE_INIT;
                    return (TICK_LENGTH_FRAME - TICK_LENGTH_VBLANK);
                }
                else {
                    previousDisplayEnabled = true;
                    SR2.isHigh = false;
                    return TICK_LENGTH_START_ACTIVE_DISPLAY;
                }

            case MODE_IDLE_ACTIVE_DISPLAY:
                //switch to bus isolation mode
                if (!SST.isHigh)
                    setGraphicsBusVisible(false);

                //release SR2
                SR2.isHigh = true;
                cpu.isIdle = false;

                return TICK_LENGTH_IDLE_ACTIVE_DISPLAY +
                        ((verticalOffset*TICK_LENGTH_SCANLINE)*2);

            case MODE_FETCH_ROW_0:
            case MODE_FETCH_ROW_1:
            case MODE_FETCH_ROW_2:
            case MODE_FETCH_ROW_3:
            case MODE_FETCH_ROW_4:
            case MODE_FETCH_ROW_5:
            case MODE_FETCH_ROW_6:
            case MODE_FETCH_ROW_7:
            case MODE_FETCH_ROW_8:
            case MODE_FETCH_ROW_9:
            case MODE_FETCH_ROW_10:
            case MODE_FETCH_ROW_11:
                SR2.isHigh = false;
                return TICK_LENGTH_FETCH_ROW;

            case MODE_RENDER_ROW_0:
            case MODE_RENDER_ROW_1:
            case MODE_RENDER_ROW_2:
            case MODE_RENDER_ROW_3:
            case MODE_RENDER_ROW_4:
            case MODE_RENDER_ROW_5:
            case MODE_RENDER_ROW_6:
            case MODE_RENDER_ROW_7:
            case MODE_RENDER_ROW_8:
            case MODE_RENDER_ROW_9:
            case MODE_RENDER_ROW_10:
                SR2.isHigh = true;
                cpu.isIdle = false;
                return TICK_LENGTH_RENDER_ROW;

            case MODE_RENDER_ROW_11:
                SR2.isHigh = true;
                cpu.isIdle = false;

                //this mode could be cut off in tick length if the vertical
                //offset is greater than 1
                switch (verticalOffset) {
                    case 0:
                        return TICK_LENGTH_RENDER_ROW;
                    case 1:
                        mode = MODE_INIT;
                        return TICK_LENGTH_RENDER_ROW - TICK_LENGTH_SCANLINE;
                    default:
                        mode = MODE_INIT;
                        return (TICK_LENGTH_RENDER_ROW - TICK_LENGTH_SCANLINE -
                                (2*(verticalOffset-1)*TICK_LENGTH_SCANLINE));
                }

            case MODE_FETCH_ROW_12:
            default:
                mode = MODE_INIT;
                SR2.isHigh = false;
                return TICK_LENGTH_SCANLINE;
        }
    }

    /**
     * Write a PNG snapshot of the current video image to the specified
     * output stream.
     */
    void writeSnapshot(OutputStream out) throws IOException {
        CRCOutputStream os = new CRCOutputStream(out);
        
        //write the PNG header
        os.write(137);
        os.write(80);
        os.write(78);
        os.write(71);
        os.write(13);
        os.write(10);
        os.write(26);
        os.write(10);

        //write the IHDR length
        int length = 13;
        os.write((length & 0xFF000000) >> 24);
        os.write((length & 0x00FF0000) >> 16);
        os.write((length & 0x0000FF00) >> 8);
        os.write(length & 0x000000FF);

        os.startCRC();

        //write the IHDR chunk header
        os.write(73);  //I
        os.write(72);  //H
        os.write(68);  //D
        os.write(82);  //R

        //write the IHDR width
        int width = 320;
        os.write((width & 0xFF000000) >> 24);
        os.write((width & 0x00FF0000) >> 16);
        os.write((width & 0x0000FF00) >> 8);
        os.write(width & 0x000000FF);
        //write the IHDR height
        int height = 192;
        os.write((height & 0xFF000000) >> 24);
        os.write((height & 0x00FF0000) >> 16);
        os.write((height & 0x0000FF00) >> 8);
        os.write(height & 0x000000FF);
        //write the IHDR bit depth
        os.write(8);
        //write the IHDR color type (paletted color)
        os.write(3);
        //write the IHDR compression method (always zero)
        os.write(0);
        //write the IHDR filter method (always zero)
        os.write(0);
        //write the IHDR interlace method (non-interlaced)
        os.write(0);

        //write the IHDR CRC
        os.writeCRC();

        //write the PLTE length
        length = 48;
        os.write((length & 0xFF000000) >> 24);
        os.write((length & 0x00FF0000) >> 16);
        os.write((length & 0x0000FF00) >> 8);
        os.write(length & 0x000000FF);

        os.startCRC();

        //write the PLTE chunk header
        os.write(80);  //P
        os.write(76);  //L
        os.write(84);  //T
        os.write(69);  //E

        //write the PLTE palette data
        for (int i = 0; i < 16; i++) {
            os.write(palette[0][i]);
            os.write(palette[1][i]);
            os.write(palette[2][i]);
        }

        //write the PLTE CRC
        os.writeCRC();

        //compress the image data
        byte[] compressInBuffer = new byte[321*192];
        for (int i = 0; i < 192; i++) {
            int nexty0 = i*320;
            int nexty1 = i*321;
            compressInBuffer[nexty1] = 0;
            for (int x = 0; x < 320; x++) {
                compressInBuffer[nexty1+x+1] =
                        (byte)(stagingBankData[nexty0+x] & 0x0F);
            }
            //System.arraycopy(stagingBankData, nexty, compressInBuffer,
                    //nexty+1, 320);
        }

        Deflater deflater = new Deflater();
        deflater.setInput(compressInBuffer);
        deflater.finish();

        byte[] totalOut = new byte[compressInBuffer.length];
        length = deflater.deflate(totalOut);
        deflater.end();

        //write the IDAT length
        os.write((length & 0xFF000000) >> 24);
        os.write((length & 0x00FF0000) >> 16);
        os.write((length & 0x0000FF00) >> 8);
        os.write(length & 0x000000FF);

        os.startCRC();

        //write the IDAT chunk header
        os.write(73);  //I
        os.write(68);  //D
        os.write(65);  //A
        os.write(84);  //T
        
        //write the IDAT data
        os.write(totalOut, 0, length);

        //write the IDAT CRC
        os.writeCRC();

        //write the IEND length
        os.write(0);
        os.write(0);
        os.write(0);
        os.write(0);

        os.startCRC();

        //write the IEND chunk header
        os.write(73);  //I
        os.write(69);  //E
        os.write(78);  //N
        os.write(68);  //D

        //write the IEND CRC
        os.writeCRC();
    }

    public void setGraphicsBusVisible(boolean visible) {
        for (int i = 1; i < memorySegments.length; i++)
            memorySegments[i].setVisible(visible);
    }

    private void renderFrame() {
        //render the next frame
        if (somethingChanged()) {
            renderBorders();
            renderBackground();
            renderSprites();
            for (int i = 0; i < 8; i++)
                sprites[i].collisionRegister = 0;
            copySpritesToStagingArea();
            renderMessage();
            determineSpriteCollisions();
            markClean();
            imageBufferChanged = true;
        }
        for (int i = 0; i < 8; i++)
            registers.memory[0x18+i] |= sprites[i].collisionRegister;
    }

    private void renderMessage() {
        if (message != null) {
            int length = message.length();
            int x = (320 - (length * 16))/2;
            int y = 88;
            //black out a square around the message
            int width = (length*8) + 4;
            for (int i = 0; i < width; i++) {
                for (int j = 0; j < 11; j++) {
                    int topPixel = ((y-3+(j*2))*320)+x-4+(i*2);
                    int bottomPixel = topPixel+320;
                    stagingBankData[topPixel] = 0;
                    stagingBankData[bottomPixel] = 0;
                    stagingBankData[topPixel+1] = 0;
                    stagingBankData[bottomPixel+1] = 0;
                }
            }
            for (int i = 0; i < length; i++) {
                renderCharacter(message.charAt(i), x, y);
                x += 16;
            }
        }
        messageChanged = false;
    }

    private void renderCharacter(char c, int x, int y) {
        int gromAddress = 0x0108 + ((c - 'A') * 8);
        for (int i = 0; i < 8; i++) {
            int nextByte = grom.peek(gromAddress+i);
            int topPixel = ((y+(i*2))*320)+x;
            int bottomPixel = topPixel+320;
            byte fgcolor = 0x07;
            if ((nextByte & 0x80) != 0) {
                stagingBankData[topPixel] = fgcolor;
                stagingBankData[bottomPixel] = fgcolor;
                stagingBankData[topPixel+1] = fgcolor;
                stagingBankData[bottomPixel+1] = fgcolor;
            }
            if ((nextByte & 0x40) != 0) {
                stagingBankData[topPixel+2] = fgcolor;
                stagingBankData[bottomPixel+2] = fgcolor;
                stagingBankData[topPixel+3] = fgcolor;
                stagingBankData[bottomPixel+3] = fgcolor;
            }
            if ((nextByte & 0x20) != 0) {
                stagingBankData[topPixel+4] = fgcolor;
                stagingBankData[bottomPixel+4] = fgcolor;
                stagingBankData[topPixel+5] = fgcolor;
                stagingBankData[bottomPixel+5] = fgcolor;
            }
            if ((nextByte & 0x10) != 0) {
                stagingBankData[topPixel+6] = fgcolor;
                stagingBankData[bottomPixel+6] = fgcolor;
                stagingBankData[topPixel+7] = fgcolor;
                stagingBankData[bottomPixel+7] = fgcolor;
            }
            if ((nextByte & 0x08) != 0) {
                stagingBankData[topPixel+8] = fgcolor;
                stagingBankData[bottomPixel+8] = fgcolor;
                stagingBankData[topPixel+9] = fgcolor;
                stagingBankData[bottomPixel+9] = fgcolor;
            }
            if ((nextByte & 0x04) != 0) {
                stagingBankData[topPixel+10] = fgcolor;
                stagingBankData[bottomPixel+10] = fgcolor;
                stagingBankData[topPixel+11] = fgcolor;
                stagingBankData[bottomPixel+11] = fgcolor;
            }
            if ((nextByte & 0x02) != 0) {
                stagingBankData[topPixel+12] = fgcolor;
                stagingBankData[bottomPixel+12] = fgcolor;
                stagingBankData[topPixel+13] = fgcolor;
                stagingBankData[bottomPixel+13] = fgcolor;
            }
            if ((nextByte & 0x01) != 0) {
                stagingBankData[topPixel+14] = fgcolor;
                stagingBankData[bottomPixel+14] = fgcolor;
                stagingBankData[topPixel+15] = fgcolor;
                stagingBankData[bottomPixel+15] = fgcolor;
            }
        }
    }

    public boolean somethingChanged() {
        return (offsetsChanged || bordersChanged || colorStackChanged ||
            colorModeChanged || backtab.isDirty() || gram.isDirty() ||
            sprites[0].changed || sprites[1].changed ||
            sprites[2].changed || sprites[3].changed ||
            sprites[4].changed || sprites[5].changed ||
            sprites[6].changed || sprites[7].changed);
    }

    private final void markClean() {
        //everything has been rendered and is now clean
        messageChanged = false;
        offsetsChanged = false;
        bordersChanged = false;
        colorStackChanged = false;
        colorModeChanged = false;
        backtab.markClean();
        gram.markClean();
        for (int i = 0; i < 8; i++)
            sprites[i].markClean();
    }

    public void setGROMImage(int[] gromImage) {
        System.arraycopy(gromImage, 0, this.gromImage, 0,
                this.gromImage.length);
        hasGROMImage = true;
    }

    public boolean hasGROMImage() {
        return hasGROMImage;
    }

    private final void init() {
        memorySegments = new MemoryAlias[9];

        //16 bit RAM used for The Background table (BACKTAB)
        backtab = new BackTabRAM(0x00F0, 0, 16);
        memorySegments[0] = new MemoryAlias(backtab, 0x0200);

        //GROM
        gromImage = new int[2048];
        grom = new ROM(gromImage, 0);
        memorySegments[1] = new MemoryAlias(grom, 0x3000);

        //GRAM
        gram = new GRAM(0x0200, 0, 8);
        memorySegments[2] = new MemoryAlias(gram, 0x3800);
        memorySegments[3] = new MemoryAlias(gram, 0x3A00);
        memorySegments[4] = new MemoryAlias(gram, 0x3C00);
        memorySegments[5] = new MemoryAlias(gram, 0x3E00);

        registers = new Registers();
        memorySegments[6] = new MemoryAlias(registers, 0x0000);
//There would normal be an alias at 0x4000, but it clashes with the ECS
//RAM, which is also at that location.  Since my memory bus implementation
//only supports one memory mapping at each location (excluding bank-switching),
//I'm commenting out this alias for now
        //memorySegments[7] = new MemoryAlias(registers, 0x4000, true);
        memorySegments[7] = new MemoryAlias(registers, 0x8000, true);
        memorySegments[8] = new MemoryAlias(registers, 0xC000, true);

        stagingBankData = new byte[61440];

        //create the sprite data holders
        sprites = new Sprite[8];
        for (int i = 0; i < 8; i++)
             sprites[i] = new Sprite();

        director.setImageBank(stagingBankData);
    }

    private final void renderBorders() {
        if (!bordersChanged && (!offsetsChanged || (blockLeft && blockTop)))
            return;

        //draw the borders, if necessary
        if (blockTop) {
            for (int x = 0; x < 320; x++) {
                stagingBankData[x] = borderColor;
                stagingBankData[x+320] = borderColor;
                stagingBankData[x+(2*320)] = borderColor;
                stagingBankData[x+(3*320)] = borderColor;
                stagingBankData[x+(4*320)] = borderColor;
                stagingBankData[x+(5*320)] = borderColor;
                stagingBankData[x+(6*320)] = borderColor;
                stagingBankData[x+(7*320)] = borderColor;
                stagingBankData[x+(184*320)] = borderColor;
                stagingBankData[x+(185*320)] = borderColor;
                stagingBankData[x+(186*320)] = borderColor;
                stagingBankData[x+(187*320)] = borderColor;
                stagingBankData[x+(188*320)] = borderColor;
                stagingBankData[x+(189*320)] = borderColor;
                stagingBankData[x+(190*320)] = borderColor;
                stagingBankData[x+(191*320)] = borderColor;
            }
        }
        else if (verticalOffset > 0) {
            for (int y = 0; y < verticalOffset; y++) {
                int offsetY = y * 640;
                for (int x = 0; x < 320; x++) {
                    stagingBankData[x+offsetY] = borderColor;
                    stagingBankData[x+offsetY+320] = borderColor;
                }
            }
        }

        if (blockLeft) {
            for (int y = 0; y < 192; y++) {
                int offsetY = y * 320;
                stagingBankData[offsetY] = borderColor;
                stagingBankData[offsetY+1] = borderColor;
                stagingBankData[offsetY+2] = borderColor;
                stagingBankData[offsetY+3] = borderColor;
                stagingBankData[offsetY+4] = borderColor;
                stagingBankData[offsetY+5] = borderColor;
                stagingBankData[offsetY+6] = borderColor;
                stagingBankData[offsetY+7] = borderColor;
                stagingBankData[offsetY+312] = borderColor;
                stagingBankData[offsetY+313] = borderColor;
                stagingBankData[offsetY+314] = borderColor;
                stagingBankData[offsetY+315] = borderColor;
                stagingBankData[offsetY+316] = borderColor;
                stagingBankData[offsetY+317] = borderColor;
                stagingBankData[offsetY+318] = borderColor;
                stagingBankData[offsetY+319] = borderColor;
            }
        }
        else if (horizontalOffset > 0) {
            for (int y = 0; y < 192; y++) {
                int offsetY = y * 320;
                for (int x = 0; x < horizontalOffset; x++) {
                    stagingBankData[x+offsetY] = borderColor;
                }
            }
        }

    }

    private final void renderBackground() {
        if (backtab.isDirty() || gram.isDirty() || colorStackChanged ||
                colorModeChanged)
        {
            if (colorStackMode)
                renderColorStackMode();
            else
                renderForegroundBackgroundMode();
        }
        copyBackgroundBufferToStagingArea();
    }

    private final void copyBackgroundBufferToStagingArea() {
        int sourceStartX = 2*(blockLeft ? (8 - horizontalOffset) : 0);
        int sourceWidthX = 2*(blockLeft ? 152 : (160 - horizontalOffset));
        int sourceStartY = 2*(blockTop ? (8 - verticalOffset) : 0 );
        int sourceEndY = sourceStartY + (2*(blockTop ? 88 :
                (96 - verticalOffset)));

        for (int y = sourceStartY; y < sourceEndY; y+=2) {
            int nextLocation = sourceStartX +
                    ((horizontalOffset - (blockLeft ? 4 : 0)) << 1) +
                    ((y + ((verticalOffset - (blockTop ? 4 : 0)) << 1)) * 320);
            System.arraycopy(backgroundDataBuffer[y], sourceStartX,
                    stagingBankData, nextLocation, sourceWidthX);
            System.arraycopy(backgroundDataBuffer[y+1], sourceStartX,
                    stagingBankData, nextLocation+320, sourceWidthX);
        }
    }

    private final void renderForegroundBackgroundMode() {
        for (int i = 0; i < 240; i++) {
            int nextCard = backtab.peek(i);
            boolean isGrom = ((nextCard & 0x0800) == 0);
            boolean renderAll = backtab.isDirty(i) || colorModeChanged;
            if (!renderAll && isGrom)
                continue;

            int memoryLocation = (nextCard & 0x01F8);
            int nextx = ((i%20)*16);
            int nexty = ((i/20)*16);
            byte fgcolor = (byte)((nextCard & 0x0007) | FOREGROUND_BIT);
            byte bgcolor = (byte)(((nextCard & 0x2000) >> 11) |
                    ((nextCard & 0x1600) >> 9));

            Memory memory = (isGrom ? (Memory)grom : (Memory)gram);
            for (int j = 0; j < 8; j++) {
                if (renderAll || (!isGrom && gram.isDirty(memoryLocation+j))) {
                     renderLine(memory.peek(memoryLocation+j), nextx, nexty,
                             fgcolor, bgcolor);
                }
                nexty += 2;
            }
        }
    }

    private final void renderColorStackMode() {
        int colorStackPointer = 0;
        //if there are any dirty color advance bits in the backtab, or if
        //the color stack or the color mode has changed, the whole scene
        //must be rendered
        boolean renderAll = backtab.areColorAdvanceBitsDirty() ||
                colorStackChanged || colorModeChanged;
        for (int h = 0; h < 240; h++) {
            int nextCard = backtab.peek(h);
            int nextx = ((h%20)*16);
            int nexty = ((h/20)*16);
            if ((nextCard & 0x1800) == 0x1000) {
                //colored squares mode
                byte colorStackColor = (byte)(registers.memory[COLORSTACK +
                        colorStackPointer] & 0x000F);
                byte color0 = (byte)(nextCard & 0x0007);
                byte color1 = (byte)((nextCard & 0x0038) >> 3);
                byte color2 = (byte)((nextCard & 0x01C0) >> 6);
                byte color3 = (byte)(((nextCard & 0x2000) >> 11) |
                            ((nextCard & 0x0600) >> 9));
                renderColoredSquares(nextx, nexty,
                        (color0 == 7 ? colorStackColor : (byte)(color0 |
                            FOREGROUND_BIT)),
                        (color1 == 7 ? colorStackColor : (byte)(color1 |
                            FOREGROUND_BIT)),
                        (color2 == 7 ? colorStackColor : (byte)(color2 |
                            FOREGROUND_BIT)),
                        (color3 == 7 ? colorStackColor : (byte)(color3 |
                            FOREGROUND_BIT)));
            }
            else {
                //color stack mode
                boolean isGrom = ((nextCard & 0x0800) == 0);
                int memoryLocation = (isGrom ? (nextCard & 0x07F8)
                            : (nextCard & 0x01F8));

                byte fgcolor = (byte)(((nextCard & 0x1000) >> 9) |
                        (nextCard & 0x0007) | FOREGROUND_BIT);

                if ((nextCard & 0x2000) != 0)
                    colorStackPointer = (colorStackPointer+1) & 0x03;
                byte bgcolor = (byte)(registers.memory[COLORSTACK +
                        colorStackPointer] & 0x000F);

                boolean backtabIsDirty = backtab.isDirty(h);
                Memory memory = (isGrom ? (Memory)grom : (Memory)gram);
                for (int j = 0; j < 8; j++) {
                    if (renderAll || backtabIsDirty ||
                            (!isGrom && gram.isDirty(memoryLocation+j)))
                    {
                        renderLine(memory.peek(memoryLocation+j), nextx, nexty,
                                fgcolor, bgcolor);
                    }
                    nexty += 2;
                }
            }
        }
    }

    private final void renderSprites() {
        Rectangle r;
        int cardNumber;
        int cardMemoryLocation;
        int pixelSize;
        int spritePixelHeight;
        boolean doubleX;
        int nextMemoryLocation;
        int nextData;
        int nextX;
        int nextY;
        int xInc;

        for (int i = 0; i < 8; i++) {
            if (!sprites[i].changed && sprites[i].isGrom)
                continue;

            cardNumber = sprites[i].cardNumber;
            if (!sprites[i].isGrom)
                cardNumber = (cardNumber & 0x003F);
            cardMemoryLocation = (cardNumber << 3);

            r = sprites[i].getBounds();
            pixelSize = (sprites[i].quadHeight ? 4 : 1) *
                    (sprites[i].doubleHeight ? 2 : 1);
            spritePixelHeight = r.height*2;
            doubleX = sprites[i].doubleWidth;
    
            for (int j = 0; j < spritePixelHeight; j++) {
                nextMemoryLocation = (cardMemoryLocation + (j/pixelSize));
                if (!sprites[i].changed &&
                        (nextMemoryLocation >= gram.getSize() ||
                            !gram.isDirty(nextMemoryLocation)))
                    continue;

                nextData = (sprites[i].isGrom
                        ? (nextMemoryLocation >= grom.getSize()
                            ? Memory.UNMAPPED_PEEK
                            : grom.peek(nextMemoryLocation))
                        : (nextMemoryLocation >= gram.getSize()
                            ? Memory.UNMAPPED_PEEK
                            : gram.peek(nextMemoryLocation)));
                nextX = (sprites[i].horizontalMirror ? (doubleX ? 15 : 7) : 0);
                nextY = (sprites[i].verticalMirror
                        ? (spritePixelHeight - j - 1) : j);
                xInc = (sprites[i].horizontalMirror ? -1: 1);
                spriteBuffers[i][nextX][nextY] = ((nextData & 0x0080) != 0);
                spriteBuffers[i][nextX + xInc][nextY] = (doubleX
                        ? ((nextData & 0x0080) != 0)
                        : ((nextData & 0x0040) != 0));
                spriteBuffers[i][nextX + (2*xInc)][nextY] = (doubleX
                        ? ((nextData & 0x0040) != 0)
                        : ((nextData & 0x0020) != 0));
                spriteBuffers[i][nextX + (3*xInc)][nextY] = (doubleX
                        ? ((nextData & 0x0040) != 0)
                        : ((nextData & 0x0010) != 0));
                spriteBuffers[i][nextX + (4*xInc)][nextY] = (doubleX
                        ? ((nextData & 0x0020) != 0)
                        : ((nextData & 0x0008) != 0));
                spriteBuffers[i][nextX + (5*xInc)][nextY] = (doubleX
                        ? ((nextData & 0x0020) != 0)
                        : ((nextData & 0x0004) != 0));
                spriteBuffers[i][nextX + (6*xInc)][nextY] = (doubleX
                        ? ((nextData & 0x0010) != 0)
                        : ((nextData & 0x0002) != 0));
                spriteBuffers[i][nextX + (7*xInc)][nextY] = (doubleX
                        ? ((nextData & 0x0010) != 0)
                        : ((nextData & 0x0001) != 0));
                if (!doubleX)
                    continue;
    
                spriteBuffers[i][nextX + (8*xInc)][nextY] =
                        ((nextData & 0x0008) != 0);
                spriteBuffers[i][nextX + (9*xInc)][nextY] =
                        ((nextData & 0x0008) != 0);
                spriteBuffers[i][nextX + (10*xInc)][nextY] =
                        ((nextData & 0x0004) != 0);
                spriteBuffers[i][nextX + (11*xInc)][nextY] =
                        ((nextData & 0x0004) != 0);
                spriteBuffers[i][nextX + (12*xInc)][nextY] =
                        ((nextData & 0x0002) != 0);
                spriteBuffers[i][nextX + (13*xInc)][nextY] =
                        ((nextData & 0x0002) != 0);
                spriteBuffers[i][nextX + (14*xInc)][nextY] =
                        ((nextData & 0x0001) != 0);
                spriteBuffers[i][nextX + (15*xInc)][nextY] =
                        ((nextData & 0x0001) != 0);
            }
    
        }
    }

    //copy the offscreen sprite buffers to the staging area
    private final void copySpritesToStagingArea() {
        for (int i = 7; i >= 0; i--) {
            boolean isVisible = (sprites[i].isVisible);
            if (sprites[i].xLocation == 0 ||
                    (!sprites[i].flagCollisions && !isVisible))
                continue;

            boolean borderCollision = false;
            boolean foregroundCollision = false;

            Rectangle r = sprites[i].getBounds();
            int spritePixelHeight = r.height*2;
            byte fgcolor = (byte)sprites[i].foregroundColor;
            int leftX = ((r.x + horizontalOffset)*2);
            int topY = ((r.y + verticalOffset)*2);
            int topLeftPixelIndex = leftX + (blockLeft ? -8 : 0) +
                    (320 * (topY + (blockTop ? -8 : 0)));

            for (int y = 0; y < spritePixelHeight; y++) {
                int nextStagingY = topY + y;
                for (int x = 0; x < r.width; x++) {
                    //if this sprite pixel is not on, then don't paint it
                    if (!spriteBuffers[i][x][y])
                        continue;
    
                    int nextStagingX = leftX + (x*2);
                    int nextPixelIndex = topLeftPixelIndex + (320*y) + (x*2);

                    //if the next pixel location is on the border, then we
                    //have a border collision and we can ignore painting it
                    if (nextStagingX < (blockLeft ? 16 : 0) ||
                            nextStagingX > 317 ||
                            nextStagingY < (blockTop ? 16 : 0) ||
                            nextStagingY > 191)
                    {
                        borderCollision = true;
                        continue;
                    }

                    int currentPixel = stagingBankData[nextPixelIndex];

                    //if the foreground bit is set, then we have a foreground
                    //collision
                    if ((currentPixel & FOREGROUND_BIT) != 0) {
                        foregroundCollision = true;

                        //if this sprite is behind the foreground, then ignore
                        //this pixel
                        if (sprites[i].behindForeground)
                            continue;
                    }
    
                    if (isVisible) {
                        stagingBankData[nextPixelIndex] = (byte)(fgcolor |
                                (currentPixel & FOREGROUND_BIT));
                        stagingBankData[nextPixelIndex+1] =
                                stagingBankData[nextPixelIndex];
                    }
                }
                nextStagingY++;
            }
    
            //update the collision bits
            if (sprites[i].flagCollisions) {
                if (foregroundCollision)
                    sprites[i].collisionRegister |= 0x0100;
                if (borderCollision)
                    sprites[i].collisionRegister |= 0x0200;
            }
        }
    }

    private final void renderColoredSquares(int x, int y, byte color0,
            byte color1, byte color2, byte color3)
    {
        int topPixel = y;
        int bottomPixel = y+1;
        for (int i = 0; i < 8; i+=2) {
            backgroundDataBuffer[topPixel][x] = color0;
            backgroundDataBuffer[topPixel][x+1] = color0;
            backgroundDataBuffer[topPixel][x+2] = color0;
            backgroundDataBuffer[topPixel][x+3] = color0;
            backgroundDataBuffer[topPixel][x+4] = color0;
            backgroundDataBuffer[topPixel][x+5] = color0;
            backgroundDataBuffer[topPixel][x+6] = color0;
            backgroundDataBuffer[topPixel][x+7] = color0;
            backgroundDataBuffer[bottomPixel][x] = color0;
            backgroundDataBuffer[bottomPixel][x+1] = color0;
            backgroundDataBuffer[bottomPixel][x+2] = color0;
            backgroundDataBuffer[bottomPixel][x+3] = color0;
            backgroundDataBuffer[bottomPixel][x+4] = color0;
            backgroundDataBuffer[bottomPixel][x+5] = color0;
            backgroundDataBuffer[bottomPixel][x+6] = color0;
            backgroundDataBuffer[bottomPixel][x+7] = color0;

            backgroundDataBuffer[topPixel][x+8] = color1;
            backgroundDataBuffer[topPixel][x+9] = color1;
            backgroundDataBuffer[topPixel][x+10] = color1;
            backgroundDataBuffer[topPixel][x+11] = color1;
            backgroundDataBuffer[topPixel][x+12] = color1;
            backgroundDataBuffer[topPixel][x+13] = color1;
            backgroundDataBuffer[topPixel][x+14] = color1;
            backgroundDataBuffer[topPixel][x+15] = color1;
            backgroundDataBuffer[bottomPixel][x+8] = color1;
            backgroundDataBuffer[bottomPixel][x+9] = color1;
            backgroundDataBuffer[bottomPixel][x+10] = color1;
            backgroundDataBuffer[bottomPixel][x+11] = color1;
            backgroundDataBuffer[bottomPixel][x+12] = color1;
            backgroundDataBuffer[bottomPixel][x+13] = color1;
            backgroundDataBuffer[bottomPixel][x+14] = color1;
            backgroundDataBuffer[bottomPixel][x+15] = color1;

            backgroundDataBuffer[topPixel+8][x] = color2;
            backgroundDataBuffer[topPixel+8][x+1] = color2;
            backgroundDataBuffer[topPixel+8][x+2] = color2;
            backgroundDataBuffer[topPixel+8][x+3] = color2;
            backgroundDataBuffer[topPixel+8][x+4] = color2;
            backgroundDataBuffer[topPixel+8][x+5] = color2;
            backgroundDataBuffer[topPixel+8][x+6] = color2;
            backgroundDataBuffer[topPixel+8][x+7] = color2;
            backgroundDataBuffer[bottomPixel+8][x] = color2;
            backgroundDataBuffer[bottomPixel+8][x+1] = color2;
            backgroundDataBuffer[bottomPixel+8][x+2] = color2;
            backgroundDataBuffer[bottomPixel+8][x+3] = color2;
            backgroundDataBuffer[bottomPixel+8][x+4] = color2;
            backgroundDataBuffer[bottomPixel+8][x+5] = color2;
            backgroundDataBuffer[bottomPixel+8][x+6] = color2;
            backgroundDataBuffer[bottomPixel+8][x+7] = color2;

            backgroundDataBuffer[topPixel+8][x+8] = color3;
            backgroundDataBuffer[topPixel+8][x+9] = color3;
            backgroundDataBuffer[topPixel+8][x+10] = color3;
            backgroundDataBuffer[topPixel+8][x+11] = color3;
            backgroundDataBuffer[topPixel+8][x+12] = color3;
            backgroundDataBuffer[topPixel+8][x+13] = color3;
            backgroundDataBuffer[topPixel+8][x+14] = color3;
            backgroundDataBuffer[topPixel+8][x+15] = color3;
            backgroundDataBuffer[bottomPixel+8][x+8] = color3;
            backgroundDataBuffer[bottomPixel+8][x+9] = color3;
            backgroundDataBuffer[bottomPixel+8][x+10] = color3;
            backgroundDataBuffer[bottomPixel+8][x+11] = color3;
            backgroundDataBuffer[bottomPixel+8][x+12] = color3;
            backgroundDataBuffer[bottomPixel+8][x+13] = color3;
            backgroundDataBuffer[bottomPixel+8][x+14] = color3;
            backgroundDataBuffer[bottomPixel+8][x+15] = color3;
            topPixel += 2;
            bottomPixel += 2;
        }
    }

    private final void renderLine(int nextByte, int x, int y,
            byte fgcolor, byte bgcolor)
    {
        int topPixel = y;
        int bottomPixel = y+1;
        byte nextPixel = (((nextByte & 0x80) == 0) ? bgcolor : fgcolor);
        backgroundDataBuffer[topPixel][x] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x] =  nextPixel;
        backgroundDataBuffer[topPixel][x+1] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x+1] =  nextPixel;
        nextPixel = (((nextByte & 0x40) == 0) ? bgcolor : fgcolor);
        backgroundDataBuffer[topPixel][x+2] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x+2] =  nextPixel;
        backgroundDataBuffer[topPixel][x+3] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x+3] =  nextPixel;
        nextPixel = (((nextByte & 0x20) == 0) ? bgcolor : fgcolor);
        backgroundDataBuffer[topPixel][x+4] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x+4] =  nextPixel;
        backgroundDataBuffer[topPixel][x+5] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x+5] =  nextPixel;
        nextPixel = (((nextByte & 0x10) == 0) ? bgcolor : fgcolor);
        backgroundDataBuffer[topPixel][x+6] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x+6] =  nextPixel;
        backgroundDataBuffer[topPixel][x+7] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x+7] =  nextPixel;
        nextPixel = (((nextByte & 0x08) == 0) ? bgcolor : fgcolor);
        backgroundDataBuffer[topPixel][x+8] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x+8] =  nextPixel;
        backgroundDataBuffer[topPixel][x+9] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x+9] =  nextPixel;
        nextPixel = (((nextByte & 0x04) == 0) ? bgcolor : fgcolor);
        backgroundDataBuffer[topPixel][x+10] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x+10] =  nextPixel;
        backgroundDataBuffer[topPixel][x+11] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x+11] =  nextPixel;
        nextPixel = (((nextByte & 0x02) == 0) ? bgcolor : fgcolor);
        backgroundDataBuffer[topPixel][x+12] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x+12] =  nextPixel;
        backgroundDataBuffer[topPixel][x+13] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x+13] =  nextPixel;
        nextPixel = (((nextByte & 0x01) == 0) ? bgcolor : fgcolor);
        backgroundDataBuffer[topPixel][x+14] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x+14] =  nextPixel;
        backgroundDataBuffer[topPixel][x+15] =  nextPixel;
        backgroundDataBuffer[bottomPixel][x+15] =  nextPixel;
    }

    private final void determineSpriteCollisions() {
        //check sprite to sprite collisions
        for (int i = 0; i < 7; i++) {
            for (int j = i+1; j < 8; j++) {
                if (!sprites[i].flagCollisions && !sprites[j].flagCollisions)
                    continue;

                if (!spritesCollide(i, j))
                    continue;

                if (sprites[i].flagCollisions)
                    sprites[i].collisionRegister |= (1 << j);

                if (sprites[j].flagCollisions)
                    sprites[j].collisionRegister |= (1 << i);
            }
        }
    }

    protected boolean spritesCollide(int spriteNum0, int spriteNum1) {
        Rectangle r0 = sprites[spriteNum0].getBounds();
        Rectangle r1 = sprites[spriteNum1].getBounds();
        if (!r0.intersects(r1))
            return false;

        //iterate over the intersecting bits to see if any touch
        int x0 = Math.max(r0.x, r1.x);
        int y0 = Math.max(r0.y, r1.y);
        int r0y = (y0-r0.y)*2;
        int r1y = (y0-r1.y)*2;
        int width = Math.min(r0.x+r0.width, r1.x+r1.width) - x0;
        int height = (Math.min(r0.y+r0.height, r1.y+r1.height) - y0) * 2;
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                if (spriteBuffers[spriteNum0][x0-r0.x+x][r0y+y] &&
                        spriteBuffers[spriteNum1][x0-r1.x+x][r1y+y])
                    return true;
            }
        }

        return false;
    }

    //display modes
    private final static int MODE_INIT                 = -1;
    private final static int MODE_VBLANK               =  0;
    private final static int MODE_START_ACTIVE_DISPLAY =  1;
    private final static int MODE_IDLE_ACTIVE_DISPLAY  =  2;
    private final static int MODE_FETCH_ROW_0          =  3;
    private final static int MODE_RENDER_ROW_0         =  4;
    private final static int MODE_FETCH_ROW_1          =  5;
    private final static int MODE_RENDER_ROW_1         =  6;
    private final static int MODE_FETCH_ROW_2          =  7;
    private final static int MODE_RENDER_ROW_2         =  8;
    private final static int MODE_FETCH_ROW_3          =  9;
    private final static int MODE_RENDER_ROW_3         = 10;
    private final static int MODE_FETCH_ROW_4          = 11;
    private final static int MODE_RENDER_ROW_4         = 12;
    private final static int MODE_FETCH_ROW_5          = 13;
    private final static int MODE_RENDER_ROW_5         = 14;
    private final static int MODE_FETCH_ROW_6          = 15;
    private final static int MODE_RENDER_ROW_6         = 16;
    private final static int MODE_FETCH_ROW_7          = 17;
    private final static int MODE_RENDER_ROW_7         = 18;
    private final static int MODE_FETCH_ROW_8          = 19;
    private final static int MODE_RENDER_ROW_8         = 20;
    private final static int MODE_FETCH_ROW_9          = 21;
    private final static int MODE_RENDER_ROW_9         = 22;
    private final static int MODE_FETCH_ROW_10         = 23;
    private final static int MODE_RENDER_ROW_10        = 24;
    private final static int MODE_FETCH_ROW_11         = 25;
    private final static int MODE_RENDER_ROW_11        = 26;
    private final static int MODE_FETCH_ROW_12         = 27;

    final static int TICK_LENGTH_SCANLINE             = 228;
    final static int TICK_LENGTH_FRAME                = 59736;
    final static int TICK_LENGTH_VBLANK               = 15162;
    final static int TICK_LENGTH_START_ACTIVE_DISPLAY = 114;
    final static int TICK_LENGTH_IDLE_ACTIVE_DISPLAY  = 456;
    final static int TICK_LENGTH_FETCH_ROW            = 456;
    final static int TICK_LENGTH_RENDER_ROW           = 3192;

    //state info
    protected MemoryAlias[]   memorySegments;
    protected int             mode = MODE_INIT;
    protected EmulationDirector director;
    protected CP1610          cpu;
    protected SignalLine      SR1;
    protected SignalLine      SR2;
    protected SignalLine      SST;
    protected BackTabRAM      backtab;
    protected GRAM            gram;
    protected int[]           gromImage;
    protected ROM             grom;
    protected Registers       registers;
    protected boolean         previousDisplayEnabled;
    protected boolean         displayEnabled;
    protected boolean         colorStackMode;
    protected boolean         colorModeChanged;
    protected boolean         bordersChanged;
    protected boolean         colorStackChanged;
    protected boolean         offsetsChanged;
    protected boolean         hasGROMImage;
    protected String          message;
    protected boolean         messageChanged;
    protected int             messageCounter;
    protected boolean         imageBufferChanged;


    //register info
    private byte    borderColor;
    private boolean blockLeft;
    private boolean blockTop;
    private int     horizontalOffset;
    private int     verticalOffset;

    //graphics rendering data
    //protected BufferedImage     stagingImageBuffer;
    protected byte[]            stagingBankData;
    protected Sprite[]          sprites;
    protected byte[][]          backgroundDataBuffer = new byte[192][320];
    protected boolean[][][]     spriteBuffers = new boolean[8][16][128];

    protected final static int BACKTAB    = 0x0200;
    protected final static int GROM       = 0x3000;
    protected final static int GRAM       = 0x3800;
    protected final static int COLORSTACK = 0x0028;

    protected final static int FOREGROUND_BIT = 0x0010;

    protected final static byte[][] palette = {
            //reds
            { (byte)0x00, (byte)0x00, (byte)0xFF, (byte)0xC9,
              (byte)0x38, (byte)0x00, (byte)0xFA, (byte)0xFF,
              (byte)0xBD, (byte)0x24, (byte)0xFF, (byte)0x54,
              (byte)0xFF, (byte)0xA4, (byte)0x75, (byte)0xB5 },
            //greens
            { (byte)0x00, (byte)0x2D, (byte)0x3D, (byte)0xCF,
              (byte)0x6B, (byte)0xA7, (byte)0xEA, (byte)0xFC,
              (byte)0xAC, (byte)0xB8, (byte)0xB4, (byte)0x6E,
              (byte)0x4E, (byte)0x96, (byte)0xCC, (byte)0x1A },
            //blues
            { (byte)0x00, (byte)0xFF, (byte)0x10, (byte)0xAB,
              (byte)0x3F, (byte)0x56, (byte)0x50, (byte)0xFF,
              (byte)0xC8, (byte)0xFF, (byte)0x1F, (byte)0x00,
              (byte)0x57, (byte)0xFF, (byte)0x80, (byte)0x58 } };

    public final static IndexColorModel   COLOR_MODEL;

    static{
        byte[] reds = new byte[32];
        byte[] greens = new byte[32];
        byte[] blues = new byte[32];
        System.arraycopy(palette[0], 0, reds, 0, 16);
        System.arraycopy(palette[0], 0, reds, 16, 16);
        System.arraycopy(palette[1], 0, greens, 0, 16);
        System.arraycopy(palette[1], 0, greens, 16, 16);
        System.arraycopy(palette[2], 0, blues, 0, 16);
        System.arraycopy(palette[2], 0, blues, 16, 16);
        COLOR_MODEL = new IndexColorModel(5, 32, reds, greens, blues);
    }

    protected class Registers extends Memory
    {
        public int getSize() {
            return memory.length;
        }

        public int getLocation() {
            return 0;
        }

        public void save(SaveOutputStream os) throws IOException {
            for (int i = 0; i < memory.length; i++)
                os.writeInt(memory[i]);
        }

        public void load(LoadInputStream is) throws IOException {
            for (int i = 0; i < memory.length; i++)
                memory[i] = is.readInt(0, 0xFFFF);
        }

        public void reset() {
            for (int i = 0; i < memory.length; i++)
                 memory[i] = 0;
        }

        public void poke(int location, int value) {
            switch(location) {
                case 0x00:
                case 0x01:
                case 0x02:
                case 0x03:
                case 0x04:
                case 0x05:
                case 0x06:
                case 0x07:
                    value = value & 0x07FF;
                    {
                    Sprite sprite = sprites[location];
                    sprite.setDoubleWidth((value & 0x0400) != 0);
                    sprite.setVisible((value & 0x0200) != 0);
                    sprite.setFlagCollisions((value & 0x0100) != 0);
                    sprite.setXLocation(value & 0x00FF);
                    }
                    break;
                case 0x08:
                case 0x09:
                case 0x0A:
                case 0x0B:
                case 0x0C:
                case 0x0D:
                case 0x0E:
                case 0x0F:
                    value = value & 0x0FFF;
                    {
                    Sprite sprite = sprites[location-0x08];
                    sprite.setVerticalMirror((value & 0x0800) != 0);
                    sprite.setHorizontalMirror((value & 0x0400) != 0);
                    sprite.setQuadHeight((value & 0x0200) != 0);
                    sprite.setDoubleHeight((value & 0x0100) != 0);
                    sprite.setDoubleYResolution((value & 0x0080) != 0);
                    sprite.setYLocation(value & 0x007F);
                    }
                    break;
                case 0x10:
                case 0x11:
                case 0x12:
                case 0x13:
                case 0x14:
                case 0x15:
                case 0x16:
                case 0x17:
                    value = value & 0x3FFF;
                    {
                    Sprite sprite = sprites[location-0x10];
                    sprite.setBehindForeground((value & 0x2000) != 0);
                    sprite.setGROM((value & 0x0800) == 0);
                    sprite.setCardNumber((value & 0x07F8) >> 3);
                    sprite.setForegroundColor(((value & 0x1000) >> 9) |
                            (value & 0x0007));
                    }
                    break;
                case 0x18:
                case 0x19:
                case 0x1A:
                case 0x1B:
                case 0x1C:
                case 0x1D:
                case 0x1E:
                case 0x1F:
                    value &= (~(1 << (location-0x18))) & 0x03FF;  
                    break;
                case 0x20:
                    displayEnabled = true;
                    break;
                case 0x21:
                    value = 0;
                    if (colorStackMode) {
                        colorStackMode = false;
                        colorModeChanged = true;
                    }
                    break;
                case 0x28:
                case 0x29:
                case 0x2A:
                case 0x2B:
                    value = value & 0x000F;
                    colorStackChanged = true;
                    break;
                case 0x2C:
                    value = value & 0x000F;
                    borderColor = (byte)value;
                    bordersChanged = true;
                    break;
                case 0x30:
                    value = value & 0x0007;
                    horizontalOffset = value;
                    offsetsChanged = true;
                    break;
                case 0x31:
                    value = value & 0x0007;
                    verticalOffset = value;
                    offsetsChanged = true;
                    break;
                case 0x32:
                    value = value & 0x0003;
                    blockLeft = (value & 0x0001) != 0;
                    blockTop = (value & 0x0002) != 0;
                    bordersChanged = true;
                    break;
                default:  //  0x22 - 0x27
                    value = 0;
                    break;
            }
            memory[location] = value;
        }

        public int peek(int location) {
            switch (location) {
                case 0x00:
                case 0x01:
                case 0x02:
                case 0x03:
                case 0x04:
                case 0x05:
                case 0x06:
                case 0x07:
                    return 0x3800 | memory[location];
                case 0x08:
                case 0x09:
                case 0x0A:
                case 0x0B:
                case 0x0C:
                case 0x0D:
                case 0x0E:
                case 0x0F:
                    return 0x3000 | memory[location];
                case 0x18:
                case 0x19:
                case 0x1A:
                case 0x1B:
                case 0x1C:
                case 0x1D:
                case 0x1E:
                case 0x1F:
                    return 0x3C00 | memory[location];
                case 0x20:
                    return 0;
                case 0x21:
                    if (location == 0x0021 && !colorStackMode) {
                        colorStackMode = true;
                        colorModeChanged = true;
                    }
                    return memory[location];
                case 0x28:
                case 0x29:
                case 0x2A:
                case 0x2B:
                case 0x2C:
                    return 0x3FF0 | memory[location];
                case 0x30:
                case 0x31:
                    return 0x3FF8 | memory[location];
                case 0x32:
                    return 0x3FFC | memory[location];
                default:
                    return memory[location];
            }
        }

        int[] memory = new int[0x40];
    }

    /**
     * A special output stream that computes CRCs as it goes along, but only
     * on the sections of the data desired, then writes and resets the CRC
     * when requested.  Necessary for PNG output.
     */
    private static class CRCOutputStream extends OutputStream
    {
        CRCOutputStream(OutputStream os) {
            this.os = os;
        }

        public void write(int next) throws IOException {
            os.write(next);
            if (calculatingCRC)
                crc.update(next);
        }

        public void startCRC() {
            calculatingCRC = true;
            crc.reset();
        }

        public void writeCRC() throws IOException {
            long crcl = crc.getValue();
            os.write(((int)(crcl & 0xFF000000)) >> 24);
            os.write(((int)(crcl & 0x00FF0000)) >> 16);
            os.write(((int)(crcl & 0x0000FF00)) >> 8);
            os.write((int)(crcl & 0x000000FF));
            calculatingCRC = false;
        }

        private OutputStream os;
        private boolean calculatingCRC = false;
        private CRC32 crc = new CRC32();
    }

}
