/*
 * WinmmNativeMethods.cs
 * 
 * .NET interface to the Windows Multimedia Library
 * 
 * Copyright (c) 2006 Mike Murphy
 * 
 */
using System;
using System.Diagnostics.CodeAnalysis;
using System.Runtime.InteropServices;
using System.Security;

namespace EMU7800.Host
{
    internal unsafe static class WinmmNativeMethods
    {
        static IntPtr Hwo = IntPtr.Zero;
        static IntPtr Storage = IntPtr.Zero;
        static int StorageSize;
        static int SoundFrameSize;
        static int QueueLen;

        const ushort WAVE_FORMAT_PCM = 1;               // PCM format for wFormatTag of WAVEFORMAT
        const uint WHDR_DONE = 0x00000001;              // done bit for dwFlags of WAVEHDR
        const uint WAVE_MAPPER = unchecked((uint)-1);   // device ID for wave device mapper

        [StructLayout(LayoutKind.Sequential)]
        internal struct WAVEFORMATEX
        {
            internal ushort wFormatTag;     // format type
            internal ushort nChannels;      // number of channels (i.e. mono, stereo...)
            internal uint nSamplesPerSec;   // sample rate
            internal uint nAvgBytesPerSec;  // for buffer estimation
            internal ushort nBlockAlign;    // block size of data
            internal ushort wBitsPerSample; // number of bits per sample of mono data
            internal ushort cbSize;         // the count in bytes of the size of extra information (after cbSize)
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct WAVEHDR
        {
            internal byte* lpData;          // pointer to locked data buffer
            internal uint dwBufferLength;   // length of data buffer
            internal uint dwBytesRecorded;  // used for input only
            internal uint* dwUser;          // for client's use
            internal uint dwFlags;          // assorted flags (see defines)
            internal uint dwLoops;          // loop control counter
            internal WAVEHDR* lpNext;       // reserved for driver
            internal uint* reserved;        // reserved for driver
        }

        internal static int Open(int freq, int soundFrameSize, int queueLen)
        {
            QueueLen = queueLen & 0x3f;
            if (QueueLen < 2)
            {
                QueueLen = 2;
            }
            
            WAVEFORMATEX wfx;
            wfx.wFormatTag = WAVE_FORMAT_PCM;
            wfx.nChannels = 1;
            wfx.wBitsPerSample = 8;
            wfx.nSamplesPerSec = (uint)freq;
            wfx.nAvgBytesPerSec = (uint)freq;
            wfx.nBlockAlign = 1;
            wfx.cbSize = 0;

            int mmResult;

            fixed (IntPtr* phwo = &Hwo)
            {
                mmResult = (int)waveOutOpen(phwo, WAVE_MAPPER, &wfx, IntPtr.Zero /* null callback */, IntPtr.Zero, 0);
            }

            if (mmResult == 0)
            {
                SoundFrameSize = soundFrameSize;
                StorageSize = QueueLen * (sizeof(WAVEHDR) + SoundFrameSize);
                Storage = Marshal.AllocHGlobal(StorageSize);
                var ptr = (byte*)Storage;
                for (var i=0; i < QueueLen; i++)
                {
                    var WaveHdr = (WAVEHDR*)ptr;
                    WaveHdr->dwBufferLength = (uint)SoundFrameSize;
                    WaveHdr->dwFlags = 0;
                    WaveHdr->lpData = ptr + sizeof(WAVEHDR);
                    for (var j=0; j < SoundFrameSize; j++)
                    {
                        WaveHdr->lpData[j] = 0;
                    }
                    waveOutPrepareHeader(Hwo, WaveHdr, (uint)sizeof(WAVEHDR));
                    waveOutWrite(Hwo, WaveHdr, (uint)sizeof(WAVEHDR));
                    ptr += sizeof(WAVEHDR);
                    ptr += SoundFrameSize;
                }
            }

            return mmResult;
        }

        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        internal static uint SetVolume(int left, int right)
        {
            var uLeft = (uint)left;
            var uRight = (uint)right;
            var nVolume = (uLeft & 0xffff) | ((uRight & 0xffff) << 16);
            return waveOutSetVolume(Hwo, nVolume);
        }

        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        internal static uint GetVolume()
        {
            uint nVolume;
            waveOutGetVolume(Hwo, &nVolume);
            return nVolume;
        }

        internal static int Enqueue(byte[] stream)
        {
            if (stream.Length != SoundFrameSize) return -1;  // bad enqueue request

            var ptr = (byte*)Storage;
            for (var i=0; i < QueueLen; i++)
            {
                var WaveHdr = (WAVEHDR*)ptr;
                if ((WaveHdr->dwFlags & WHDR_DONE) == WHDR_DONE)
                {
                    waveOutUnprepareHeader(Hwo, WaveHdr, (uint)sizeof(WAVEHDR));
                    WaveHdr->dwBufferLength = (uint)SoundFrameSize;
                    WaveHdr->dwFlags = 0;
                    WaveHdr->lpData = ptr + sizeof(WAVEHDR);
                    for (int j=0; j < SoundFrameSize; j++)
                    {
                        WaveHdr->lpData[j] = stream[j];
                    }
                    waveOutPrepareHeader(Hwo, WaveHdr, (uint)sizeof(WAVEHDR));
                    waveOutWrite(Hwo, WaveHdr, (uint)sizeof(WAVEHDR));
                    return 0;  // enqueue request complete
                }
                ptr += sizeof(WAVEHDR);
                ptr += SoundFrameSize;
            }

            return 1;  // full queue
        }

        internal static void Close()
        {
            if (Storage.Equals(IntPtr.Zero)) return;

            waveOutReset(Hwo);
            waveOutClose(Hwo);
            Marshal.FreeHGlobal(Storage);
            Storage = IntPtr.Zero;
        }

        [DllImport("winmm.dll"), SuppressUnmanagedCodeSecurity]
        private static extern uint waveOutOpen(IntPtr* phwo, uint uDeviceID, WAVEFORMATEX* pwfx, IntPtr dwcb, IntPtr dwInstance, uint dwfOpen);

        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        [DllImport("winmm.dll"), SuppressUnmanagedCodeSecurity]
        private static extern uint waveOutSetVolume(IntPtr hwo, uint dwVolume);

        [SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        [DllImport("winmm.dll"), SuppressUnmanagedCodeSecurity]
        private static extern uint waveOutGetVolume(IntPtr hwo, uint* pdwVolume);

        [DllImport("winmm.dll"), SuppressUnmanagedCodeSecurity]
        private static extern uint waveOutPrepareHeader(IntPtr hwo, WAVEHDR* wh, uint cbwh);

        [DllImport("winmm.dll"), SuppressUnmanagedCodeSecurity]
        private static extern uint waveOutUnprepareHeader(IntPtr hwo, WAVEHDR* wh, uint cbwh);

        [DllImport("winmm.dll"), SuppressUnmanagedCodeSecurity]
        private static extern uint waveOutWrite(IntPtr hwo, WAVEHDR* wh, uint cbwh);

        [DllImport("winmm.dll"), SuppressUnmanagedCodeSecurity]
        private static extern uint waveOutReset(IntPtr hwo);

        [DllImport("winmm.dll"), SuppressUnmanagedCodeSecurity]
        private static extern uint waveOutClose(IntPtr hwo);
    }
}