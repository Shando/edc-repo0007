/*
 * HostBase.cs
 * 
 * Abstraction of an emulated machine host.
 * 
 * Copyright (c) 2004-2008 Mike Murphy
 * 
 */
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Runtime.InteropServices;
using EMU7800.Host.DirectX;
using EMU7800.Machine;

namespace EMU7800.Host
{
    public enum HostInput
    {
        End,
        Pause,
        Mute,
        Fire,
        Fire2,
        Left,
        Right,
        Up,
        Down,
        NumPad1, NumPad2, NumPad3,
        NumPad4, NumPad5, NumPad6,
        NumPad7, NumPad8, NumPad9,
        NumPadMult, NumPad0, NumPadDiv,
        Reset,
        Select,
        Color,
        LeftDifficulty,
        RightDifficulty,
        SetKeyboardToPlayer1,
        SetKeyboardToPlayer2,
        SetKeyboardToPlayer3,
        SetKeyboardToPlayer4,
        PanLeft, PanRight, PanUp, PanDown,
        SaveMachine,
        TakeScreenshot,
        LeftPaddleSwap,
        GameControllerSwap,
        RightPaddleSwap,
        ShowFrameStats,
    }

    public abstract class HostBase
    {
        #region Fields

        private static readonly Dictionary<string, HostBase> _RegisteredHosts = new Dictionary<string, HostBase>();

        protected MachineBase M { get; set; }

        private long _PostedMsgExpireFrameCount;
        private bool _AudioOpened;
        private string _PostedMsg = string.Empty;

        #endregion

        #region Public Properties

        public static ReadOnlyCollection<string> RegisteredHostNames
        {
            get
            {
                var hostList = new List<string>();
                foreach (var hostName in _RegisteredHosts.Keys)
                {
                    hostList.Add(hostName);
                }
                return new ReadOnlyCollection<string>(hostList);
            }
        }

        public string PostedMsg
        {
            [DebuggerStepThrough]
            get { return (_PostedMsgExpireFrameCount > M.FrameNumber) ? _PostedMsg : string.Empty; }
            [DebuggerStepThrough]
            set
            {
                if (value != null)
                {
                    _PostedMsg = value.PadRight(32);
                    _PostedMsgExpireFrameCount = M.FrameNumber + 3*M.FrameHZ;
                }
            }
        }

        public int EffectiveFPS
        {
            [DebuggerStepThrough]
            get { return M.FrameHZ + GlobalSettings.Instance.FrameRateAdjust; }
        }

        [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
        public bool DeactivateMouseInput
        {
            [DebuggerStepThrough]
            get { return GlobalSettings.Instance.DeactivateMouseInput; }
            [DebuggerStepThrough]
            set { GlobalSettings.Instance.DeactivateMouseInput = value; }
        }

        public int CurrentKeyboardPlayerNo { get; private set; }
        public bool Muted { get; private set; }
        public bool Paused { get; private set; }
        public bool Ended { get; private set; }
        public int ClipStart { get; private set; }
        public int LeftOffset { get; private set; }

        #endregion

        #region Public Methods

        public static HostBase New(string hostName)
        {
            foreach (var registeredHostName in _RegisteredHosts.Keys)
            {
                if (registeredHostName.Equals(hostName, StringComparison.OrdinalIgnoreCase))
                {
                    return _RegisteredHosts[hostName];
                }
            }
            throw new InvalidOperationException("Host name not registered: " + hostName);
        }

        public static void RegisterHost(string hostName, HostBase host)
        {
            _RegisteredHosts.Add(hostName, host);
        }

        public void RaiseInput(HostInput input, bool down)
        {
            RaiseInput(CurrentKeyboardPlayerNo, input, down);
        }

        public void RaiseInput(int playerNo, HostInput input, bool down)
        {
            var ia = M.InputAdapter;

            if (Paused && down)
            {
                switch (input)
                {
                    case HostInput.Pause:
                    case HostInput.PanLeft:
                    case HostInput.PanRight:
                    case HostInput.PanDown:
                    case HostInput.PanUp:
                    case HostInput.LeftDifficulty:
                    case HostInput.RightDifficulty:
                    case HostInput.Color:
                    case HostInput.SaveMachine:
                    case HostInput.Mute:
                    case HostInput.End:
                        break;
                    default:
                        Paused = false;
                        PostedMsg = "Resumed";
                        break;
                }
            }

            switch (input)
            {
                case HostInput.Fire:
                    ia[playerNo, ControllerAction.Trigger] = down;
                    break;
                case HostInput.Fire2:
                    ia[playerNo, ControllerAction.Trigger2] = down;
                    break;
                case HostInput.Left:
                    ia[playerNo, ControllerAction.Left] = down;
                    if (down)
                    {
                        ia[playerNo, ControllerAction.Right] = false;
                    }
                    break;
                case HostInput.Up:
                    ia[playerNo, ControllerAction.Up] = down;
                    if (down)
                    {
                        ia[playerNo, ControllerAction.Down] = false;
                    }
                    break;
                case HostInput.Right:
                    ia[playerNo, ControllerAction.Right] = down;
                    if (down)
                    {
                        ia[playerNo, ControllerAction.Left] = false;
                    }
                    break;
                case HostInput.Down:
                    ia[playerNo, ControllerAction.Down] = down;
                    if (down)
                    {
                        ia[playerNo, ControllerAction.Up] = false;
                    }
                    break;
                case HostInput.NumPad7:
                    ia[playerNo, ControllerAction.Keypad7] = down;
                    break;
                case HostInput.NumPad8:
                    ia[playerNo, ControllerAction.Keypad8] = down;
                    break;
                case HostInput.NumPad9:
                    ia[playerNo, ControllerAction.Keypad9] = down;
                    break;
                case HostInput.NumPad4:
                    ia[playerNo, ControllerAction.Keypad4] = down;
                    break;
                case HostInput.NumPad5:
                    ia[playerNo, ControllerAction.Keypad5] = down;
                    break;
                case HostInput.NumPad6:
                    ia[playerNo, ControllerAction.Keypad6] = down;
                    break;
                case HostInput.NumPad1:
                    ia[playerNo, ControllerAction.Keypad1] = down;
                    break;
                case HostInput.NumPad2:
                    ia[playerNo, ControllerAction.Keypad2] = down;
                    break;
                case HostInput.NumPad3:
                    ia[playerNo, ControllerAction.Keypad3] = down;
                    break;
                case HostInput.NumPadMult:
                    ia[playerNo, ControllerAction.KeypadA] = down;
                    break;
                case HostInput.NumPad0:
                    ia[playerNo, ControllerAction.Keypad0] = down;
                    break;
                case HostInput.NumPadDiv:
                    ia[playerNo, ControllerAction.KeypadP] = down;
                    break;
                case HostInput.Reset:
                    ia[ConsoleSwitch.GameReset] = down;
                    break;
                case HostInput.Select:
                    ia[ConsoleSwitch.GameSelect] = down;
                    break;
                case HostInput.Color:
                    if (down)
                    {
                        ia[ConsoleSwitch.GameBW] = !ia[ConsoleSwitch.GameBW];
                        PostedMsg = ia[ConsoleSwitch.GameBW] ? "B/W" : "Color";
                    }
                    break;
                case HostInput.LeftDifficulty:
                    if (down)
                    {
                        ia[ConsoleSwitch.LDifficultyA] = !ia[ConsoleSwitch.LDifficultyA];
                        PostedMsg = "Left Difficulty: " + (ia[ConsoleSwitch.LDifficultyA] ? "A (Pro)" : "B (Novice)");
                    }
                    break;
                case HostInput.RightDifficulty:
                    if (down)
                    {
                        ia[ConsoleSwitch.RDifficultyA] = !ia[ConsoleSwitch.RDifficultyA];
                        PostedMsg = "Right Difficulty: " + (ia[ConsoleSwitch.RDifficultyA] ? "A (Pro)" : "B (Novice)");
                    }
                    break;
                case HostInput.SetKeyboardToPlayer1:
                    if (down)
                    {
                        SetKeyboardToPlayerNo(0);
                    }
                    break;
                case HostInput.SetKeyboardToPlayer2:
                    if (down)
                    {
                        SetKeyboardToPlayerNo(1);
                    }
                    break;
                case HostInput.SetKeyboardToPlayer3:
                    if (down)
                    {
                        SetKeyboardToPlayerNo(2);
                    }
                    break;
                case HostInput.SetKeyboardToPlayer4:
                    if (down)
                    {
                        SetKeyboardToPlayerNo(3);
                    }
                    break;
                case HostInput.PanLeft:
                    if (down)
                    {
                        LeftOffset++;
                    }
                    break;
                case HostInput.PanRight:
                    if (down)
                    {
                        LeftOffset--;
                    }
                    break;
                case HostInput.PanDown:
                    if (down)
                    {
                        ClipStart--;
                    }
                    break;
                case HostInput.PanUp:
                    if (down)
                    {
                        ClipStart++;
                    }
                    break;
                case HostInput.SaveMachine:
                    if (down)
                    {
                        SaveMachineState();
                    }
                    break;
                case HostInput.TakeScreenshot:
                    if (down)
                    {
                        TakeScreenshot();
                    }
                    break;
                case HostInput.Mute:
                    if (down)
                    {
                        Muted = !Muted;
                        PostedMsg = Muted ? "Mute" : "Mute Off";
                    }
                    break;
                case HostInput.Pause:
                    if (down && !Paused)
                    {
                        Paused = true;
                        PostedMsg = "Paused";
                    }
                    break;
                case HostInput.End:
                    if (down)
                    {
                        Ended = true;
                    }
                    break;
            }
        }

        public void RaiseLightGunInput(int screenWidth, int x, int y)
        {
            // constant latencies are for 2600, 7800 still needs to be determined
            var scanline = y + 4;
            var hpos = x + 23;
            M.InputAdapter.SetLightgunPos(CurrentKeyboardPlayerNo, scanline, hpos);
        }

        public void RaisePaddleInput(int valMax, int val)
        {
            RaisePaddleInput(CurrentKeyboardPlayerNo, valMax, val);
        }

        public void RaisePaddleInput(int playerNo, int valMax, int val)
        {
            var ohms = InputAdapter.PaddleOhmMax - (InputAdapter.PaddleOhmMax - InputAdapter.PaddleOhmMin) / valMax * val;
            M.InputAdapter.SetOhms(playerNo, ohms);
        }

        public int EnqueueAudio(byte[] buf)
        {
            if (!_AudioOpened)
            {
                var SoundSampleRate = M.SoundSampleRate * EffectiveFPS / M.FrameHZ;
                WinmmNativeMethods.Open(SoundSampleRate, M.Scanlines << 1, 30);
                _AudioOpened = true;
            }
            return WinmmNativeMethods.Enqueue(buf);
        }

        public void CloseAudio()
        {
            WinmmNativeMethods.Close();
            _AudioOpened = false;
        }

        public static Dictionary<Key, HostInput> CreateDefaultKeyBindings()
        {
            return new Dictionary<Key, HostInput>
            {
                { Key.Escape,       HostInput.End },
                { Key.Z,            HostInput.Fire },
                { Key.X,            HostInput.Fire2 },
                { Key.Up,           HostInput.Up },
                { Key.Left,         HostInput.Left },
                { Key.Right,        HostInput.Right },
                { Key.Down,         HostInput.Down },
                { Key.NumPad7,      HostInput.NumPad7 },
                { Key.NumPad8,      HostInput.NumPad8 },
                { Key.NumPad9,      HostInput.NumPad9 },
                { Key.NumPad4,      HostInput.NumPad4 },
                { Key.NumPad5,      HostInput.NumPad5 },
                { Key.NumPad6,      HostInput.NumPad6 },
                { Key.NumPad1,      HostInput.NumPad1 },
                { Key.NumPad2,      HostInput.NumPad2 },
                { Key.NumPad3,      HostInput.NumPad3 },
                { Key.Multiply,     HostInput.NumPadMult },
                { Key.NumPad0,      HostInput.NumPad0 },
                { Key.Divide,       HostInput.NumPadDiv },
                { Key.D1,           HostInput.LeftDifficulty },
                { Key.D2,           HostInput.RightDifficulty },
                { Key.F1,           HostInput.SetKeyboardToPlayer1 },
                { Key.F2,           HostInput.SetKeyboardToPlayer2 },
                { Key.F3,           HostInput.SetKeyboardToPlayer3 },
                { Key.F4,           HostInput.SetKeyboardToPlayer4 },
                { Key.F5,           HostInput.PanLeft },
                { Key.F6,           HostInput.PanRight },
                { Key.F7,           HostInput.PanUp },
                { Key.F8,           HostInput.PanDown },
                { Key.F11,          HostInput.SaveMachine },
                { Key.F12,          HostInput.TakeScreenshot },
                { Key.C,            HostInput.Color },
                { Key.F,            HostInput.ShowFrameStats },
                { Key.M,            HostInput.Mute },
                { Key.P,            HostInput.Pause },
                { Key.R,            HostInput.Reset },
                { Key.S,            HostInput.Select },
                { Key.Q,            HostInput.LeftPaddleSwap },
                { Key.W,            HostInput.GameControllerSwap },
                { Key.E,            HostInput.RightPaddleSwap },
            };
        }

        public static Dictionary<Key, HostInput> UpdateKeyBindingsFromGlobalSettings(Dictionary<Key, HostInput> keyBindings)
        {
            foreach (var binding in GlobalSettings.Instance.KeyBindings.Split(';'))
            {
                var keyHostInput = binding.Split(',');

                if (!keyHostInput.Length.Equals(2) || keyHostInput[0] == null || keyHostInput[1] == null) continue;
                Key key;
                try { key = (Key)Enum.Parse(typeof (Key), keyHostInput[0]); }
                catch (ArgumentException) { continue; }
                HostInput hostInput;
                try { hostInput = (HostInput)Enum.Parse(typeof (HostInput), keyHostInput[1]); }
                catch (ArgumentException) { continue;  }

                var priorKey = key;
                foreach (var keyVal in keyBindings)
                {
                    if (!keyVal.Value.Equals(hostInput)) continue;
                    priorKey = keyVal.Key;
                    break;
                }
                if (priorKey.Equals(key)) continue;

                keyBindings.Remove(priorKey);
                keyBindings.Add(key, hostInput);
            }
            return keyBindings;
        }

        #endregion

        #region Virtual Members

        public virtual void Run(MachineBase m)
        {
            if (m == null) throw new ArgumentNullException("m");

            M = m;
            M.AssignToHost(this);
            Muted = false;
            Paused = false;
            Ended = false;
            _AudioOpened = false;
            CurrentKeyboardPlayerNo = 0;
            ClipStart = M.FirstScanline;
            LeftOffset = 0;
            _PostedMsgExpireFrameCount = 0;
        }

        #endregion

        #region Helpers

        private void SetKeyboardToPlayerNo(int playerNo)
        {
            foreach (ControllerAction ca in Enum.GetValues(typeof(ControllerAction)))
            {
                M.InputAdapter[playerNo, ca] = false;
            }
            CurrentKeyboardPlayerNo = playerNo;
            PostedMsg = String.Format("Keyboard to Player {0}", CurrentKeyboardPlayerNo + 1);
        }

        private void SaveMachineState()
        {
            var fileName = string.Format("emu7800 machinestate {0:yyyy}.{0:MM}-{0:dd}.{0:HH}{0:mm}{0:ss}.emu", DateTime.Now);
            var fullName = Path.Combine(GlobalSettings.Instance.OutputDirectory, fileName);
            try
            {
                M.Serialize(fullName);
            }
            catch (Exception ex)
            {
                if (Utility.IsCriticalException(ex)) throw;
                Trace.Write("machine state save error: ");
                Trace.WriteLine(ex);
                PostedMsg = "Error saving machine state";
                return;
            }

            Trace.WriteLine("Machine state saved: " + fullName);
            PostedMsg = "Machine state saved";
        }

        private void TakeScreenshot()
        {
            var palette = M.GetPalette();
            var fb = new int[320 * M.Scanlines];
            if (M.VisiblePitch.Equals(160))
            {
                for (int i = 0, di = 0; i < M.VideoFrameBuffer.Length; i++, di += 2)
                {
                    fb[di] = fb[di + 1] = palette[M.VideoFrameBuffer[i]];
                }
            }
            else
            {
                for (var i = 0; i < M.VideoFrameBuffer.Length; i++)
                {
                    fb[i] = palette[M.VideoFrameBuffer[i]];
                }
            }

            var h = GCHandle.Alloc(fb, GCHandleType.Pinned);
            var fileName = string.Format("emu7800 screenshot {0:yyyy} {0:MM}-{0:dd} {0:HH}{0:mm}{0:ss}.bmp", DateTime.Now);
            var fullName = Path.Combine(GlobalSettings.Instance.OutputDirectory, fileName);
            try
            {
                using (var bm = new Bitmap(320, M.Scanlines, 4 * 320, PixelFormat.Format32bppRgb, h.AddrOfPinnedObject()))
                {
                    bm.Save(fullName);
                }
            }
            catch (Exception ex)
            {
                if (Utility.IsCriticalException(ex)) throw;
                Trace.WriteLine("Error while taking screenshot: " + ex);
                PostedMsg = "Screenshot failed";
                return;
            }
            finally
            {
                h.Free();
            }

            Trace.WriteLine("Screenshot taken: " + fullName);
            PostedMsg = "Screenshot taken";
        }

        #endregion
    }
}
