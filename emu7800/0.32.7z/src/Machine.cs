/*
 * Machine.cs
 * 
 * Abstraction of an emulated machine.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */

using System;
using System.Drawing;
using System.IO;

namespace EMU7800 {

public enum MachineType {
	Null,
	A2600NTSC,
	A2600PAL
};

public abstract class Machine {
	public IHost H;

	public readonly InputAdapter InputAdapter;
	public virtual M6502 CPU {
		get {
			return null;
		}
	}

	// Current frame number
	private long frameNumber;
	public  long FrameNumber {
		get {
			return frameNumber;
		}
	}

	// Number of scanlines on the display
	protected int scanlines;
	public    int Scanlines {
		get {
			return scanlines;
		}
	}

	// Frame rate
	protected int frameHZ;
	public    int FrameHZ {
		get {
			if (frameHZ < 1)
				frameHZ = 1;
			return frameHZ;
		}
		set {
			frameHZ = value;
			if (frameHZ < 1)
				frameHZ = 1;
		}
	}

	// ...in units of samples/sec
	protected int soundSampleRate;
	public    int SoundSampleRate {
		get {
			return soundSampleRate;
		}
	}

	// Size of the output window
	public abstract Size ViewPortSize { set; }

	// Location of the upper left corner of the clipping rectangle
	public abstract Point ClipLocation { get; set; }

	// Draw the entire next frame, not just updates
	public abstract bool DrawEntireFrame { get; set; }

	// Draw a "paused" frame, that is, draw entire frame but dimmed
	public abstract void DrawPauseFrame();

	public static Machine New(GameSettings gs, Cart c, InputAdapter ia) {
		if (gs == null || c == null || ia == null) {
			return null;
		}
		
		Machine m;

		switch (gs.MachineType) {
		case MachineType.A2600NTSC:
			m = new Machine2600NTSC(c, ia);
			break;
		case MachineType.A2600PAL:
			m = new Machine2600PAL(c, ia);
			break;
		default:
			m = new NullMachine(ia);
			break;
		}
		m.InputAdapter.Controllers[0] = gs.LController;
		m.InputAdapter.Controllers[1] = gs.RController;

		return m;
	}

	public void Reset() {
		frameNumber = 0;
		InputAdapter.Reset();
		DoReset();
	}

	public void Run() {
		InputAdapter.CheckPoint(frameNumber);
		DoRun();
		frameNumber++;
	}

	public abstract void StopCPU();
	public abstract bool ExecuteTokenList(TokenList tokenList);

	protected abstract void DoReset();
	protected abstract void DoRun();

	public Machine(InputAdapter ia) {
		InputAdapter = ia;
	}
}

public class NullMachine : Machine {
	public override string ToString() {
		return "NullMachine";
	}

	public override Size ViewPortSize { set {} }
	public override Point ClipLocation { get { return new Point(); } set {} }
	public override bool DrawEntireFrame { get { return false; } set {} }
	public override void DrawPauseFrame() {}

	public override void StopCPU() {}
	public override bool ExecuteTokenList(TokenList tl) {
		return false;
	}
	protected override void DoReset() {}
	protected override void DoRun()	{}

	public NullMachine(InputAdapter ia) : base(ia) {
		FrameHZ = 60;
	}
}
}
