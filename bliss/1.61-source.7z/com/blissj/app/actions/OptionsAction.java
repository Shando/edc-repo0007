package com.blissj.app.actions;

import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.blissj.app.*;

public class OptionsAction extends AbstractAction
{

    public OptionsAction(BlissMainFrame frame) {
        this.frame = frame;
        putValue(NAME, Bliss.RESOURCES.getString(
                "ActionOptions"));
    }

    public void actionPerformed(ActionEvent ae) {
        frame.displayOptions();
    }

    private BlissMainFrame      frame;

}
