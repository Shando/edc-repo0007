// ******************************************************
// 			  buffer.h  
//            by Windy
// *******************************************************
#ifdef WIN32
#include <windows.h>
#else
#define DWORD int
#endif



int init_soundbuffer(int size);
int read_soundbuffer(short *buffer,unsigned int size);
void write_soundbuffer(short *buffer,unsigned int size);
void Trash_soundbuffer(void);


void init_keybuffer(void);
void write_keybuffer(DWORD wParam , DWORD lParam , char chr);
int read_keybuffer(DWORD *wParam , DWORD *lParam , char *chr);
