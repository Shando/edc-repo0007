/*
 * Globals.cs
 * 
 * Global attributes applicable to the entire system.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */

using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.IO.IsolatedStorage;
using System.Reflection;
using System.Windows.Forms;

namespace EMU7800 {

public class Globals {
	public const string Title = "EMU7800";	public const string Version = "0.33";
	public const string Copyright = "Copyright (c) 2003 Mike Murphy";
	
	private static double opacity;
	public  static double Opacity {
		get {
			return opacity;
		}
		set {
			opacity = value;
			Globals.Save();
		}
	}

	private static Size controlPanelFormClientSize;
	public  static Size ControlPanelFormClientSize {
		get {
			return controlPanelFormClientSize;
		}
		set {
			controlPanelFormClientSize = value;
			Globals.Save();
		}
	}

	private static string rootDir;
	public  static string RootDir {
		get {
			return rootDir;
		}
		set {
			string ndir = value.Replace(@"\", "/");
			if (Directory.Exists(ndir)) {
				rootDir = ndir;
			}
		}
	}

	private static string romDirectory;
	public  static string ROMDirectory {
		get {
			return romDirectory;
		}
		set {
			string ndir = value.Replace(@"\", "/");
			if (Directory.Exists(ndir)) {
				romDirectory = ndir;
				Globals.Save();
			}
		}
	}

	private static string outputDirectory;
	public  static string OutputDirectory {
		get {
			return outputDirectory;
		}
		set {
			string ndir = value.Replace(@"\", "/");
			if (Directory.Exists(ndir)) {
				outputDirectory = ndir;
				Globals.Save();
			}
		}
	}

	// These properties must not be saved
	public static bool DXExists = false;
	public static bool FullScreenMode = false;

	public static void Load() {
		Log.Msg("[Globals]\n");

		try {

		IsolatedStorageFileStream f
			= new IsolatedStorageFileStream("Globals.txt",
				FileMode.OpenOrCreate);
		StreamReader reader
			= new StreamReader(f);

		string line;
		string[] kval;
		do {
			line = reader.ReadLine();
			if (line == null) {
				break;
			}
			kval = line.Split('=');
			string key = kval[0];
			string val = kval[1];

			switch (key) {
			case "ROMDirectory":
				romDirectory = val.Replace(@"\", "/");
				Log.Msg("ROMDirectory={0}\n", ROMDirectory);
				break;
			case "OutputDirectory":
				outputDirectory = val.Replace(@"\", "/");
				Log.Msg("OutputDirectory={0}\n", OutputDirectory);
				break;
			case "Opacity":
				try {
					opacity = Double.Parse(val);
				} catch {
					Log.Msg("Error reading {0} key\n", key);
				}
				Log.Msg("Opacity={0}%\n", opacity*100);
				break;
			case "ControlPanelFormClientSize":
				try {
					int w = Int32.Parse(val.Split(' ')[0]);
					int h = Int32.Parse(val.Split(' ')[1]);
					controlPanelFormClientSize = new Size(w, h);
				} catch {
					Log.Msg("Error reading {0} key\n", key);
				}
				Log.Msg("ControlPanelFormClientSize=({0}, {1})\n",
					ControlPanelFormClientSize.Width,
					ControlPanelFormClientSize.Height);
				break;
			}
		} while (line != null);

		f.Close();

		} catch (Exception e) {
			Log.Msg("Error reading Globals.txt: {0}\n", e.Message);
		}

		Log.Msg("[/Globals]\n");
	}

	public static void Save() {
		try {

		IsolatedStorageFileStream f
			= new IsolatedStorageFileStream("Globals.txt",
				FileMode.Create);
		StreamWriter w = new StreamWriter(f);
		w.WriteLine("Title={0}", Title);
		w.WriteLine("Version={0}", Version);
		w.WriteLine("Copyright={0}", Copyright);
		w.WriteLine("ROMDirectory={0}", ROMDirectory);
		w.WriteLine("OutputDirectory={0}", OutputDirectory);
		w.WriteLine("Opacity={0:f}", Opacity);
		w.WriteLine("ControlPanelFormClientSize={0} {1}", controlPanelFormClientSize.Width,
			controlPanelFormClientSize.Height);
		w.Flush();
		w.Close();
		f.Close();

		} catch (Exception e) {
			Log.Msg("Error saving Globals.txt: {0}\n", e.Message);
		}
	}

	public static void Main(string[] args) {
		Log.Msg("{0} v{1}\n", Title, Version);
#if DEBUG
		Log.Msg("DEBUG build\n");
#endif
		Log.Msg("{0}\n", Copyright);

		rootDir = Directory.GetCurrentDirectory().Replace(@"\", "/");

		// Setup some defaults
		romDirectory = rootDir + "/roms";
		if (!Directory.Exists(romDirectory)) {
			romDirectory = rootDir;
		}
		outputDirectory = rootDir + "/outdir";
		if (!Directory.Exists(outputDirectory)) {
			outputDirectory = rootDir;
		}
		opacity = 1.0;
		controlPanelFormClientSize = new Size(200, 200);

		try {
			Assembly a;
			a = Assembly.LoadWithPartialName("Microsoft.DirectX");
			Log.Msg("{0}\n", a.FullName);
			a = Assembly.LoadWithPartialName("Microsoft.DirectX.DirectSound");
			Log.Msg("{0}\n", a.FullName);
			a = Assembly.LoadWithPartialName("Microsoft.DirectX.DirectDraw");
			Log.Msg("{0}\n", a.FullName);
			Log.Msg("Managed DirectX available\n");
			DXExists = true;
		} catch {
			Log.Msg("Managed DirectX NOT available\n");
		}

		Globals.Load();

		// Ensure GameSettings static constructor is invoked
		Hashtable htbl = GameSettings.ROMProperties;

		IHost h;

		foreach (string arg in args) {
			if (arg.ToUpper() == "/FULLSCREEN" && DXExists) {
				FullScreenMode = true;
			}
		}

		if (DXExists) {
			if (FullScreenMode) {
				h = new DXHost();
			} else {
				h = new GDIDXHost();
			}
		} else {
			h = new GDIHost();
		}
                Application.Exit();
	}
}
}