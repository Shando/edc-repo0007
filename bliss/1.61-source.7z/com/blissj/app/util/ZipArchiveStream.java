package com.blissj.app.util;

import java.io.*;
import java.util.*;
import java.util.zip.*;

public class ZipArchiveStream extends ArchiveStream
{

    public ZipArchiveStream(InputStream is) throws IOException {
        zis = new ZipInputStream(is);
    }

    public ArchiveEntry getNextEntry() throws IOException {
        nextEntry = zis.getNextEntry();
        return (nextEntry == null ? null
                : new ZipArchiveEntry(nextEntry.getName(), nextEntry.getCrc()));
    }

    public int available() throws IOException {
        return zis.available();
    }

    public int read() throws IOException {
        return zis.read();
    }

    public void close() throws IOException {
        zis.close();
    }

    private ZipInputStream zis;
    private ZipEntry       nextEntry;
    private boolean        nextEntryRead;

    private static class ZipArchiveEntry implements ArchiveEntry
    {
        private ZipArchiveEntry(String name, long crc) {
            this.name = name;
            this.crc = crc;
        }

        public String getName() {
            return name;
        }

        public long getCrc() {
            return crc;
        }

        private String name;
        private long crc;
    }

}
