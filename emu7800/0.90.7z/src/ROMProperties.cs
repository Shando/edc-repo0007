/*
 * ROMProperties.cs
 * 
 * Represents the ROMProperties.csv file contents
 * 
 * Copyright 2004-2008 (c) Mike Murphy
 * 
 */
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using EMU7800.Machine;

namespace EMU7800
{
    public class ROMProperties
    {
        #region Object State

        // these enum identifiers are used for matching column names in the .csv file
        private enum Column
        {
            MD5,
            Title,
            Manufacturer,
            Year,
            ModelNo,
            Rarity,
            CartType,
            MachineType,
            LController,
            RController,
            HelpUri
        };

        private const string RomPropertiesFileName = "ROMProperties.csv";
        private readonly Dictionary<string, GameSettings> PropertyTable = new Dictionary<string, GameSettings>();
        private readonly Dictionary<Column, int> ColumnPos = new Dictionary<Column, int>();

        #endregion

        #region Public Members

        public GameSettings GetGameSettings(string md5)
        {
            if (md5 == null) throw new ArgumentNullException("md5");
            if (PropertyTable.Count.Equals(0)) Load();

            if (!PropertyTable.ContainsKey(md5))
            {
                PropertyTable[md5] = new GameSettings(md5);
            }
            return PropertyTable[md5];
        }

        public GameSettings GetGameSettingsFromFile(FileInfo fi)
        {
            if (fi == null) throw new ArgumentNullException("fi");
            if (PropertyTable.Count.Equals(0)) Load();

            GameSettings gs = null;

            var ext = Path.GetExtension(fi.FullName);
            if (@".exe|.dll|.csv|.emu".IndexOf(ext, StringComparison.OrdinalIgnoreCase) < 0)
            {
                var md5 = Utility.ComputeMD5Digest(fi);
                if (PropertyTable.ContainsKey(md5))
                {
                    gs = PropertyTable[md5];
                    gs.FileInfo = fi;
                }
                else
                {
                    if (md5.Equals("c8a73288ab97226c52602204ab894286", StringComparison.OrdinalIgnoreCase))
                    {
                        Trace.Write("Found 7800 Highscore Cart:");
                    }
                    else if (md5.Equals("0763f1ffb006ddbe32e52d497ee848ae", StringComparison.OrdinalIgnoreCase))
                    {
                        Trace.Write("Found 7800 NTSC BIOS:");
                    }
                    else if (md5.Equals("b32526ea179dc9ab9b2e5f8a2662b298", StringComparison.OrdinalIgnoreCase))
                    {
                        Trace.Write("Found incorrect but widely used 7800 NTSC BIOS:");
                    }
                    else if (md5.Equals("397bb566584be7b9764e7a68974c4263", StringComparison.OrdinalIgnoreCase))
                    {
                        Trace.Write("Found 7800 PAL BIOS:");
                    }
                    else
                    {
                        Trace.Write("Unrecognized file:");
                    }
                    Trace.WriteLine(" " + fi.FullName + " MD5=" + md5);
                }
            }
 
            return gs;
        }

        public void Load()
        {
            var fn = Path.Combine(GlobalSettings.Instance.BaseDirectory, RomPropertiesFileName);
            Trace.WriteLine("Loading " + fn + "...");

            PropertyTable.Clear();
            try
            {
                using (var r = new StreamReader(fn))
                {
                    InitializeColumnPos(r.ReadLine());
                    while (true)
                    {
                        var line = r.ReadLine();
                        if (line == null) break;
                        var gs = CreateGameSettingsFromLine(line);
                        PropertyTable[gs.MD5] = gs;
                    }
                }
            }
            catch (IOException ex)
            {
                Trace.WriteLine(ex);
            }

            Trace.WriteLine(PropertyTable.Count + " " + RomPropertiesFileName + " entries loaded");
        }

        public void Dump()
        {
            Debug.Assert(PropertyTable != null);

            var fn = Path.Combine(GlobalSettings.Instance.OutputDirectory, RomPropertiesFileName + ".txt");
            var count = 0;
            try
            {
                using (var w = new StreamWriter(fn))
                {
                    w.WriteLine("Title,Year,Manufacturer,ModelNo,CartType,MachineType,Rarity,LController,RController,MD5");
                    foreach (var gs in PropertyTable.Values)
                    {
                        w.WriteLine("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9}",
                            gs.Title,
                            gs.Year,
                            gs.Manufacturer,
                            gs.ModelNo,
                            gs.CartType.ToString().Equals("Default", StringComparison.OrdinalIgnoreCase) ? string.Empty : gs.CartType.ToString(),
                            gs.MachineType,
                            gs.Rarity,
                            gs.LController,
                            gs.RController,
                            gs.MD5);
                        count++;
                    }
                    w.Flush();
                }
                Trace.WriteLine(string.Format("Dumped {0} {1}.txt entries", RomPropertiesFileName, count));
            }
            catch (IOException ex)
            {
                Trace.WriteLine(ex);
            }
        }

        #endregion

        #region Constructors

        public ROMProperties()
        {
            ColumnPos.Add(Column.MD5, -1);
            ColumnPos.Add(Column.Title, -1);
            ColumnPos.Add(Column.Manufacturer, -1);
            ColumnPos.Add(Column.Year, -1);
            ColumnPos.Add(Column.ModelNo, -1);
            ColumnPos.Add(Column.Rarity, -1);
            ColumnPos.Add(Column.CartType, -1);
            ColumnPos.Add(Column.MachineType, -1);
            ColumnPos.Add(Column.LController, -1);
            ColumnPos.Add(Column.RController, -1);
            ColumnPos.Add(Column.HelpUri, -1);
        }

        #endregion

        #region Helpers

        private void InitializeColumnPos(string line)
        {
            var colno = 0;
            foreach (var colnm in line.Split(','))
            {
                Column col;
                try
                {
                    col = (Column)Enum.Parse(typeof(Column), colnm);
                }
                catch (ArgumentException)
                {
                    continue;
                }
                ColumnPos[col] = colno;
                colno++;
            }

            foreach (var pos in ColumnPos.Values)
            {
                if (pos < 0)
                {
                    throw new InvalidOperationException("bad ROMProperties.csv file: not all columns present");
                }
            }
        }

        private GameSettings CreateGameSettingsFromLine(string line)
        {
            var row = line.Split(',');
            var md5 = row[ColumnPos[Column.MD5]];
            var gs = new GameSettings(md5)
            {
                 Title = row[ColumnPos[Column.Title]],
                 Manufacturer = row[ColumnPos[Column.Manufacturer]],
                 Year = row[ColumnPos[Column.Year]],
                 ModelNo = row[ColumnPos[Column.ModelNo]],
                 Rarity = row[ColumnPos[Column.Rarity]],
                 CartType = EnumCartType(row[ColumnPos[Column.CartType]], md5),
                 MachineType = EnumMachineType(row[ColumnPos[Column.MachineType]], md5)
            };

            Controller dflt;
            switch (gs.MachineType)
            {
                default:
                //case MachineType.A2600NTSC:
                //case MachineType.A2600PAL:
                    dflt = Controller.Joystick;
                    break;
                case MachineType.A7800NTSC:
                case MachineType.A7800PAL:
                    dflt = Controller.ProLineJoystick;
                    break;
            }
            gs.LController = EnumController(row[ColumnPos[Column.LController]], dflt, md5);
            gs.RController = EnumController(row[ColumnPos[Column.RController]], dflt, md5);

            if (ColumnPos[Column.HelpUri] < row.Length)
            {
                var helpUri = row[ColumnPos[Column.HelpUri]].Trim();
                if (!helpUri.Length.Equals(0))
                {
                    gs.HelpUri = helpUri;
                }
            }

            gs.FileInfo = null;

            return gs;
        }

        private static CartType EnumCartType(string cartType, string md5)
        {
            if (cartType.Length.Equals(0)) return CartType.Default;

            CartType ct;
            try
            {
                ct = (CartType)Enum.Parse(typeof(CartType), cartType);
            }
            catch (ArgumentException)
            {
                ct = CartType.Default;
                Trace.WriteLine("bad CartType=" + cartType + " for md5=" + md5 + " in " + RomPropertiesFileName);
            }
            return ct;
        }

        private static MachineType EnumMachineType(string machineType, string md5)
        {
            if (machineType.Length.Equals(0)) return MachineType.A2600NTSC;

            MachineType mt;
            try
            {
                mt = (MachineType)Enum.Parse(typeof(MachineType), machineType);
            }
            catch (ArgumentException)
            {
                mt = MachineType.A2600NTSC;
                Trace.WriteLine("bad MachineType=" + machineType + " for md5=" + md5 + " in " + RomPropertiesFileName);
            }
            return mt;
        }

        private static Controller EnumController(string controller, Controller dflt, string md5)
        {
            if (controller.Length.Equals(0)) return dflt;

            Controller c;
            try
            {
                c = (Controller)Enum.Parse(typeof(Controller), controller);
            }
            catch (ArgumentException)
            {
                c = dflt;
                Trace.WriteLine("bad Controller=" + controller + " for md5=" + md5 + " in " + RomPropertiesFileName);
            }
            return c;
        }

        #endregion
    }
}