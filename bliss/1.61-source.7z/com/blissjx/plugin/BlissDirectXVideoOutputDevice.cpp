
#include <jni.h>
#include "DirectXVideoOutputDevice.h"

extern "C"
{

jfieldID nativeVideoHandleFieldID = NULL;
jfieldID stopFieldID = NULL;

JNIEXPORT jlong JNICALL Java_com_blissjx_plugin_DirectXVideoOutputDevice_nativeDirectXVideoOutputDevice(JNIEnv *env, jobject thisObject)
{
    if (nativeVideoHandleFieldID == NULL) {
        jclass clazz = env->GetObjectClass(thisObject);
        nativeVideoHandleFieldID = env->GetFieldID(clazz,
                "nativeHandle", "J");
        stopFieldID = env->GetFieldID(clazz, "stop", "Z");
    }
    return (jlong)(new DirectXVideoOutputDevice());
}

JNIEXPORT void JNICALL Java_com_blissjx_plugin_DirectXVideoOutputDevice_init(JNIEnv *env, jobject thisObject, jstring windowTitle)
{
    env->SetBooleanField(thisObject, stopFieldID, FALSE);
    DirectXVideoOutputDevice* nativeDevice = (DirectXVideoOutputDevice*)env->
            GetLongField(thisObject, nativeVideoHandleFieldID);
    const char *str = env->GetStringUTFChars(windowTitle, 0);
    INT32 result = nativeDevice->init(str);
    env->ReleaseStringUTFChars(windowTitle, str);
    if (result != 0) {
        jclass clazz = env->FindClass("com/bliss/core/EmulationException");
        env->ThrowNew(clazz, nativeDevice->getErrorDescription(result));
    }
}

JNIEXPORT void JNICALL Java_com_blissjx_plugin_DirectXVideoOutputDevice_setFullScreen(JNIEnv *env, jobject thisObject, jboolean b)
{
    DirectXVideoOutputDevice* nativeDevice = (DirectXVideoOutputDevice*)env->
            GetLongField(thisObject, nativeVideoHandleFieldID);
    nativeDevice->setFullScreenMode(b);
}

JNIEXPORT jboolean JNICALL Java_com_blissjx_plugin_DirectXVideoOutputDevice_isFullScreen(JNIEnv *env, jobject thisObject)
{
    DirectXVideoOutputDevice* nativeDevice = (DirectXVideoOutputDevice*)env->
            GetLongField(thisObject, nativeVideoHandleFieldID);
    return nativeDevice->isFullScreenMode();
}

JNIEXPORT void JNICALL Java_com_blissjx_plugin_DirectXVideoOutputDevice_setStretchMode(JNIEnv *env, jobject thisObject, jint mode)
{
    DirectXVideoOutputDevice* nativeDevice = (DirectXVideoOutputDevice*)env->
            GetLongField(thisObject, nativeVideoHandleFieldID);
    nativeDevice->setStretchMode((STRETCHMODE)mode);
}

JNIEXPORT jint JNICALL Java_com_blissjx_plugin_DirectXVideoOutputDevice_getStretchMode(JNIEnv *env, jobject thisObject)
{
    DirectXVideoOutputDevice* nativeDevice = (DirectXVideoOutputDevice*)env->
            GetLongField(thisObject, nativeVideoHandleFieldID);
    return nativeDevice->getStretchMode();
}

JNIEXPORT void JNICALL Java_com_blissjx_plugin_DirectXVideoOutputDevice_displayImage(JNIEnv *env, jobject thisObject, jbyteArray imageData, jboolean hasChanged)
{
    DirectXVideoOutputDevice* nativeDevice = (DirectXVideoOutputDevice*)env->
            GetLongField(thisObject, nativeVideoHandleFieldID);
    jboolean isCopy;
    jbyte* nativeImageData = env->GetByteArrayElements(imageData, &isCopy);
    nativeDevice->displayImage((unsigned char*)nativeImageData, hasChanged);
    if (isCopy)
        env->ReleaseByteArrayElements(imageData, nativeImageData, JNI_ABORT);

    if (nativeDevice->stop)
        env->SetBooleanField(thisObject, stopFieldID, TRUE);
}

JNIEXPORT void JNICALL Java_com_blissjx_plugin_DirectXVideoOutputDevice_release(JNIEnv *env, jobject thisObject)
{
    DirectXVideoOutputDevice* nativeDevice = (DirectXVideoOutputDevice*)env->
            GetLongField(thisObject, nativeVideoHandleFieldID);
    nativeDevice->release();
}

}

