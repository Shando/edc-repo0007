
#ifndef DIRECTXAUDIOOUTPUTDEVICE_H
#define DIRECTXAUDIOOUTPUTDEVICE_H

#include <dsound.h>

//potential error messages initializing DirectX
#define ERR_UNABLE_TO_CREATE_AUDIO                   1
#define ERR_UNABLE_TO_CREATE_PRIMARY_BUFFER          2
#define ERR_UNABLE_TO_CREATE_SECONDARY_BUFFER        3
#define ERR_UNABLE_TO_PLAY_PRIMARY_BUFFER            4
#define ERR_UNABLE_TO_PLAY_SECONDARY_BUFFER          5
#define ERR_UNABLE_TO_SETCOOPLEVEL                   6

class DirectXAudioOutputDevice
{

    public:
        DirectXAudioOutputDevice();
		~DirectXAudioOutputDevice();
        INT32 init();
        const CHAR* getErrorDescription(INT32 errorCode);
        INT32 getSampleRate();
        void playSample(INT32 sample);
        void release();


    private:
        IDirectSound8*        dsound;
        IDirectSoundBuffer*   primarySoundBuffer;
        IDirectSoundBuffer*   secondarySoundBuffer;

};

#endif
