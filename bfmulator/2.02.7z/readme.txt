BFMulator is a emulator for bellfruit MPU's 
-------------------------------------------

Key shortcuts:

CTRL + 1 insert coin 1 
CTRL + 2 insert coin 2
CTRL + 3 insert coin 3
CTRL + 4 insert coin 4
CTRL + 5 insert coin 5
CTRL + 6 insert coin 6

ESCape   Toggle menubar

F1       Test button1 (Green button on scorpion   MPU)
F2       Test button2 (Red   button on scorpion-1 MPU)

HOME / END  scroll reels

PageUp / PageDown + MouseWheel  scroll layout up/down

CTRL + F7 - F12 toggle reel optics (for testunit roms)


Some settings explained:

MPU/Cartidge(s) ===============================================================

Accurate timing:  if not checked the emulator uses a multitasking friendly
                  sleep function to throttle the CPU speed.

                  if checked the emulator uses the multitasking friendly
 		  sleep function only for a part of the delay, 
                  the rest is done in a loop.


CPU Latency:	  The emulator emulates CPU instructions in batches.
		  This slider controls the number of instruction in a batch.

		  LeftMost  = small batches ( fast PC needed more accurate timings )
		  RightMost = large batches ( less accurate timings )

		  Best leave this at 4 !!


Thread Priority:  Low,    better multitasking (uses less CPU power)
		  Normal, use more CPU power

Sound =========================================================================

Emulate PSG:	  if checked the PSG sound chip on scorpion-1 and 
                  the Ym2413 chip on scorpion-2 are emulated

Enable uPD7759	  if checked the sampled sound is emulated

Enable machine sounds:  if checked buttons clicks, coin, slide, mech.meter sounds are
                        used.

Nec can play Multiple : the Nec uPD7759 only has 1 channel.
                        If this box is checked it has more (unlimited) channels
			(probaly no longer working)

Enable Microphone input:	if checked the microphon is used for games wich use
				the adaptive sound card.
				if unchecked the sound input is allways maximum.

Mic Amp factor:		Amplyfication value for the microphone (1-255) 

			