package com.bliss.core.devices;

public interface ClockDevice extends Device
{

    public abstract long getTickFrequency();

    public abstract long getTick();

}
