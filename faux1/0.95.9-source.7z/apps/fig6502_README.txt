fig6502 - fig-FORTH 1.1 for the 6502

Through the courtesy of FORTH INTEREST GROUP P.O. BOX  2154 OAKLAND, CALIFORNIA 94621

Assembled for the Replica1 / Faux1 (32KB) mode by J.M.Reneau renejm@users.sourceforge.net 2012-02-11

Usage:

To load:

Open fig6502.woz with text editor and paste ASCII hex file into the WOZON.

-or-

Load ASCII (faux1 ony):
<control><L>  
Enter file name to load: apps/fig6502.woz
Enter (A)scii or (B)inary: a
Filename 'apps/fig6502.woz' loaded.\
Enter 300R to start.

-or-

Load ASCII (faux1 ony):
<control><L>  
Enter file name to load: apps/fig6502.bin
Enter (A)scii or (B)inary: b
Enter Starting Address in Hex: 300
Filename 'apps/fig6502.bin' loaded.\
Enter 300R to start.

- or -

./faux1 -n -l apps/fig6502.woz -c "300R"

2012-02-21
