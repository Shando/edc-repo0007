package com.blissj.app;

import java.util.*;
import javax.swing.*;
import javax.swing.table.*;
import com.bliss.core.*;
import com.bliss.core.cartridge.*;

public class CartridgeTableModel extends AbstractTableModel
{

    public final static int VIEW_ALL       = 0;
    public final static int VIEW_AVAILABLE = 1;

    public CartridgeTableModel() {
        this.cartFiles = new CartridgeFile[0];
        init();
    }

    private void init() {
        //load the images
        ClassLoader cl = getClass().getClassLoader();
        redStop = new ImageIcon(cl.getResource(
                "com/blissj/app/images/redstop.gif"));
        greenCheck = new ImageIcon(cl.getResource(
                "com/blissj/app/images/greencheck.gif"));

        cartTypes = CartridgeTypeFactory.getCartridgeTypeList();
        cartTypeFileMap = new int[cartTypes.length];

        resort();
        remapTypesToFiles();
    }

    public void setView(int view) {
        if (view == this.view)
            return;

        this.view = view;
        fireTableDataChanged();
    }

    public int getView() {
        return view;
    }

    public void setSorting(int column) {
        if (column == this.sortingColumn)
            return;

        this.sortingColumn = column;
        resort();
        remapTypesToFiles();
        fireTableDataChanged();
    }

    public int getSorting() {
        return sortingColumn;
    }

    public void setCartridgeFileList(CartridgeFile[] cartFiles) {
        this.cartFiles = cartFiles;
        remapTypesToFiles();
        fireTableDataChanged();
    }

    public boolean isCartridgeFileAvailable(int row) {
        if (view == VIEW_ALL)
            return (cartTypeFileMap[row] != -1);
        else
            return true;
    }

    public CartridgeFile getCartridgeFile(int row) {
        if (view == VIEW_ALL)
            return (cartTypeFileMap[row] == -1
                ? null : cartFiles[cartTypeFileMap[row]]);
        else
            return cartFiles[row];
    }

    public CartridgeType getCartridgeType(int row) {
        if (view == VIEW_ALL)
            return cartTypes[row];
        else
            return cartFiles[row].getType();
    }

    public int getColumnCount() {
        return 4;
    }

    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "";
            case 1:
                return Bliss.RESOURCES.getString("CartridgeColumnHeader");
            case 2:
                return Bliss.RESOURCES.getString("ProducerColumnHeader");
            case 3:
                return Bliss.RESOURCES.getString("YearColumnHeader");
            case 4:
            default:
                return Bliss.RESOURCES.getString("FileColumnHeader");
        }
    }

    public int getRowCount() {
        return (view == VIEW_ALL ? cartTypes.length : cartFiles.length);
    }

    public Object getValueAt(int row, int column) {
        CartridgeType type = (view == VIEW_ALL ? cartTypes[row] :
                cartFiles[row].getType());
        switch (column) {
            case 0:
                return ((view == VIEW_ALL && cartTypeFileMap[row] == -1)
                        ? redStop : greenCheck);
            case 1:
                return type.getName();
            case 2:
                return type.getProducer();
            case 3:
                return type.getYear();
            case 4:
            default:
                if (view == VIEW_ALL) {
                    CartridgeFile cartFile = (cartTypeFileMap[row] == -1 ? null
                            : cartFiles[cartTypeFileMap[row]]);
                    String filename;
                    if (cartFile != null)
                        filename = cartFile.getFile().getName();
                    else
                        filename = "";
                    return filename;
                }
                else
                    return cartFiles[row].getFile().getName();
        }
    }

    private void resort() {
        Arrays.sort(cartTypes, new Comparator() {
                public int compare(Object o1, Object o2) {
                    return ((CartridgeType)o1).getName().compareTo(
                            ((CartridgeType)o2).getName());
                }
            });
    }

    private void remapTypesToFiles() {
        //remap the datas to the files
        for (int i = 0; i < cartTypes.length; i++) {
            cartTypeFileMap[i] = -1;
            for (int j = 0; j < cartFiles.length; j++) {
                if (cartFiles[j].getType() == cartTypes[i]) {
                    cartTypeFileMap[i] = j;
                    break;
                }
            }
        }
    }

    private CartridgeType[] cartTypes;
    private int[]           cartTypeFileMap;
    private CartridgeFile[] cartFiles;
    private ImageIcon       redStop;
    private ImageIcon       greenCheck;
    private int             view;
    private int             sortingColumn;

}

