package com.blissj.app;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.bliss.core.*;
import com.bliss.core.devices.InputDevice;
import com.bliss.core.devices.InputSignal;

public class BlissPollInputDialog extends JDialog
{

    public BlissPollInputDialog(Frame parent, InputDevice inputDevice) {
        super(parent);
        this.inputDevice = inputDevice;
        initUI();
        initListeners();
    }

    private void initUI() {
        setModal(true);
        setTitle(Bliss.RESOURCES.getString("PollInputDialogTitle"));
        JPanel contentPane = new JPanel();
        setContentPane(contentPane);
        contentPane.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        contentPane.setLayout(new GridBagLayout());

        selectInputLabel = new JLabel(Bliss.RESOURCES.getString(
                "SelectInputForControl"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(0, 0, 8, 0);
        contentPane.add(selectInputLabel, gbc);

        controlToConfigureLabel = new JLabel();
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.insets = new Insets(0, 0, 12, 0);
        contentPane.add(controlToConfigureLabel, gbc);

        cancelButton = new JButton(Bliss.RESOURCES.getString("CancelButton"));
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        contentPane.add(cancelButton, gbc);
    }

    private void initListeners() {
        addComponentListener(new ComponentAdapter() {
                public void componentShown(ComponentEvent ce) {
                    inputDevice.initConfigMode();
                    timer.start();
                }
            });
        addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent we) {
                    if (timer.isRunning()) {
                        timer.stop();
                        inputDevice.releaseConfigMode();
                    }
                }
            });
        cancelButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    if (timer.isRunning()) {
                        timer.stop();
                        inputDevice.releaseConfigMode();
                    }
                    dispose();
                }
            });
    }

    public InputSignal pollForInputSignal(String description) {
        controlToConfigureLabel.setText(description);
        pack();
        BlissUtilities.centerWindowOverParent(this);
        setVisible(true);
        InputSignal returnValue = inputSignal;
        inputSignal = null;
        return returnValue;
    }

    //instance data
    private InputDevice inputDevice;
    private InputSignal inputSignal;
    private Timer       timer = new Timer(100, new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                InputSignal signal = inputDevice.pollForInputSignal();
                if (signal != null) {
                    timer.stop();
                    inputSignal = signal;
                    dispose();
                }
            }
        });

    //app components
    private JLabel  selectInputLabel;
    private JLabel  controlToConfigureLabel;
    private JButton cancelButton;

}
