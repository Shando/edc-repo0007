 /* 
  * UAE - The Un*x Amiga Emulator
  * 
  * WinUAE sound macros are here...
  * 
  * Copyright 1997 Bernd Schmidt
  * Copyright 1997 - 1999 Mathias Ortmann
  * Copyright 1999 - 2001 Brian King
  */

/*#define SOUND_HAS_PRIORITY*/

#define AHI_SUPPORT

extern char *sndptr, *sndptrmax;

#define SOUND_VALUE 0x40

extern int buffer_granularity;

extern void flush_sound_buffer( void );

extern long calcsound;

static __inline__ void check_sound_buffers (void)
{
    if( sndptr >= sndptrmax )
    {
        flush_sound_buffer();
	calcsound = 0;
    }
    else
    {
	calcsound = 1;
    }
}

#define PUT_SOUND_BYTE(b) do { *sndptr++ = b; } while(0)

#define PUT_SOUND_WORD(b) do { *(short *)sndptr = b; sndptr += 2;  } while(0)

#define PUT_SOUND_BYTE_RIGHT(b) PUT_SOUND_BYTE(b)
#define PUT_SOUND_BYTE_LEFT(b) PUT_SOUND_BYTE(b)
#define PUT_SOUND_WORD_RIGHT(b) PUT_SOUND_WORD(b)
#define PUT_SOUND_WORD_LEFT(b) PUT_SOUND_WORD(b)

#define SOUND16_BASE_VAL 0
#define SOUND8_BASE_VAL 128

#define DEFAULT_SOUND_MINB 1500
#define DEFAULT_SOUND_MAXB 1500
#define DEFAULT_SOUND_BITS 16
#define DEFAULT_SOUND_FREQ 22050

#define HAVE_STEREO_SUPPORT

void pause_sound(int);
void resume_sound(void);
