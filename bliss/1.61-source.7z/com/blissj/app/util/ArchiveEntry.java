package com.blissj.app.util;

public interface ArchiveEntry
{

    public String getName();

    public long getCrc();

}
