package com.bliss.core;

import java.io.*;
import java.util.*;
import com.bliss.core.devices.*;

/**
 * The AY-3-8910 chip in the Intellivision, also know as the Programmable
 * Sound Generator (PSG).
 *
 * @author Kyle Davis
 */
public class AY38914 extends Processor implements Peripheral
{

    public AY38914(AudioMixer.AudioOutputLine aol, int location,
            IODevice io0, IODevice io1)
    {
        this.aol = aol;
        registers = new Registers();
        registerAlias = new MemoryAlias(registers, location);
        this.ioDevice0 = io0;
        this.ioDevice1 = io1;
    }

    public int getMemoryCount() {
        return 1;
    }

    public Memory getMemory(int i) {
        return registerAlias;
    }

    public int getProcessorCount() {
        return 1;
    }

    public Processor getProcessor(int i) {
        return this;
    }

    public int getClockSpeed() {
        return Intellivision.NTSC_CLOCK_SPEED;
    }

    public void reset() {
        //reset the registers first
        registers.reset();
        registerAlias.reset();

        //reset the state variables
        noisePeriod = 0;
        noisePeriodValue = 0x20;
        noiseCounter = noisePeriodValue;
        random = 1;
        noise = true;
        noiseIdle = true;
        channel0.reset();
        channel1.reset();
        channel2.reset();
        envelopeIdle = true;
        envelopePeriod = 0;
        envelopePeriodValue = 0x10000;
        envelopeCounter = envelopePeriodValue;
        envelopeVolume = 0;
        envelopeHold = false;
        envelopeAltr = false;
        envelopeAtak = false;
        envelopeCont = false;

        //reset the IO devices
        ioDevice0.reset();
        ioDevice1.reset();
        outputEnabled0 = false;
        outputEnabled1 = false;
    }

    /**
     * Tick the AY38914.  This method has been profiled over and over again
     * in an attempt to tweak it for optimal performance.  Please be careful
     * with any modifications that may adversely affect performance.
     *
     * @return the number of ticks used by the AY38914, always returns 4.
     */
    public int tick() {
        //iterate the envelope generator
        envelopeCounter -= clockDivisor;
        if (envelopeCounter <= 0) {
            do {
                envelopeCounter += envelopePeriodValue;
                if (!envelopeIdle) {

                    envelopeVolume += (envelopeAtak ? 1 : -1);
                    if (envelopeVolume > 15 || envelopeVolume < 0) {
                        if (!envelopeCont) {
                            envelopeVolume = 0;
                            envelopeIdle = true;
                        }
                        else if (envelopeHold) {
                            envelopeVolume = (envelopeAtak == envelopeAltr
                                    ? 0 : 15);
                            envelopeIdle = true;
                        }
                        else {
                            envelopeAtak = (envelopeAtak != envelopeAltr);
                            envelopeVolume = (envelopeAtak ? 0 : 15);
                        }
                    }

                    //the envelope volume has changed so the channel outputs
                    //need to be updated if they are using the envelope
                    channel0.isDirty = channel0.envelope;
                    channel1.isDirty = channel1.envelope;
                    channel2.isDirty = channel2.envelope;
                }
            } while (envelopeCounter <= 0);
        }

        //iterate the noise generator
        noiseCounter -= clockDivisor;
        if (noiseCounter <= 0) {
            boolean oldNoise = noise;
            do {
                noiseCounter += noisePeriodValue;
                if (!noiseIdle) {
                    random = (random >> 1) ^ (noise ? 0x14000 : 0);
                    noise = ((random & 1) != 0);
                }
            } while (noiseCounter <= 0);

            //if the noise bit changed, then our channel outputs need
            //to be updated if they are using the noise generator
            if (oldNoise != noise) {
                channel0.isDirty = channel0.isDirty ||
                        !channel0.noiseDisabled;
                channel1.isDirty = channel1.isDirty ||
                        !channel1.noiseDisabled;
                channel2.isDirty = channel2.isDirty ||
                        !channel2.noiseDisabled;
            }
        }

        //iterate the tone generator for channel 0
        channel0.toneCounter -= clockDivisor;
        if (channel0.toneCounter <= 0) {
            do {
                channel0.toneCounter += channel0.periodValue;
                channel0.tone = !channel0.tone;
            } while (channel0.toneCounter <= 0);

            if (!channel0.toneDisabled)
                channel0.isDirty = true;
        }

        //iterate the tone generator for channel 1
        channel1.toneCounter -= clockDivisor;
        if (channel1.toneCounter <= 0) {
            do {
                channel1.toneCounter += channel1.periodValue;
                channel1.tone = !channel1.tone;
            } while (channel1.toneCounter <= 0); 

            if (!channel1.toneDisabled)
                channel1.isDirty = true;
        }

        //iterate the tone generator for channel 2
        channel2.toneCounter -= clockDivisor;
        if (channel2.toneCounter <= 0) {
            do {
                channel2.toneCounter += channel2.periodValue;
                channel2.tone = !channel2.tone;
            } while (channel2.toneCounter <= 0);

            if (!channel2.toneDisabled)
                channel2.isDirty = true;
        }

        if (channel0.isDirty) {
            channel0.cachedSample = amplitudes16Bit[
                    (((channel0.toneDisabled | channel0.tone) &
                    (channel0.noiseDisabled | noise))
                        ? (channel0.envelope ? envelopeVolume
                            : channel0.volume) : 0)];
            channel0.isDirty = false;
            cachedTotalOutputIsDirty = true;
        }

        if (channel1.isDirty) {
            channel1.cachedSample = amplitudes16Bit[
                    (((channel1.toneDisabled | channel1.tone) &
                    (channel1.noiseDisabled | noise))
                        ? (channel1.envelope ? envelopeVolume
                            : channel1.volume) : 0)];
            channel1.isDirty = false;
            cachedTotalOutputIsDirty = true;
        }

        if (channel2.isDirty) {
            channel2.cachedSample = amplitudes16Bit[
                    (((channel2.toneDisabled | channel2.tone) &
                    (channel2.noiseDisabled | noise))
                        ? (channel2.envelope ? envelopeVolume
                            : channel2.volume) : 0)];
            channel2.isDirty = false;
            cachedTotalOutputIsDirty = true;
        }

        //mix all three channel samples together to generate the overall
        //output sample for the entire AY38914
        if (cachedTotalOutputIsDirty) {
            cachedTotalOutput = (channel0.cachedSample +
                    channel1.cachedSample + channel2.cachedSample);
        }

        aol.writeSample(cachedTotalOutput);

        //every tick here always uses some multiple of 16 NTSC cycles
        return (clockDivisor<<4);
    }

    public void save(SaveOutputStream os) throws IOException {
        registers.save(os);

        os.writeBoolean(envelopeIdle);
        os.writeInt(envelopeCounter);
        os.writeInt(envelopePeriod);
        os.writeInt(envelopePeriodValue);
        os.writeInt(envelopeVolume);

        os.writeBoolean(envelopeHold);
        os.writeBoolean(envelopeAltr);
        os.writeBoolean(envelopeAtak);
        os.writeBoolean(envelopeCont);

        os.writeBoolean(noiseIdle);
        os.writeInt(noiseCounter);
        os.writeInt(noisePeriod);
        os.writeInt(noisePeriodValue);

        channel0.save(os);
        channel1.save(os);
        channel2.save(os);

        os.writeBoolean(outputEnabled0);
        os.writeBoolean(outputEnabled1);
    }

    public void load(LoadInputStream is) throws IOException {
        registers.load(is);

        envelopeIdle = is.readBoolean();
        envelopeCounter = is.readInt(0x00001, 0x10000);
        envelopePeriod = is.readInt(0x0000, 0xFFFF);
        envelopePeriodValue = is.readInt(0x00001, 0x10000);
        envelopeVolume = is.readInt(0, 15);

        envelopeHold = is.readBoolean();
        envelopeAltr = is.readBoolean();
        envelopeAtak = is.readBoolean();
        envelopeCont = is.readBoolean();

        noiseIdle = is.readBoolean();
        noiseCounter = is.readInt(0x01, 0x20);
        noisePeriod = is.readInt(0x00, 0x3F);
        noisePeriodValue = is.readInt(0x01, 0x20);

        channel0.load(is);
        channel1.load(is);
        channel2.load(is);

        outputEnabled0 = is.readBoolean();
        outputEnabled1 = is.readBoolean();

        cachedTotalOutputIsDirty = true;
    }

    public void setClockDivisor(int clockDivisor) {
        this.clockDivisor = clockDivisor;
    }

    public int getClockDivisor() {
        return clockDivisor;
    }

    //divisor for slowing down the clock speed for the AY38914
    private int clockDivisor = DEFAULT_CLOCK_DIVISOR;

    //plug in device
    private PlugIn            plugIn;
    private AudioMixer.AudioOutputLine   aol;

    //registers and channels
    private Registers       registers;
    private MemoryAlias     registerAlias;
    private Channel         channel0 = new Channel();
    private Channel         channel1 = new Channel();
    private Channel         channel2 = new Channel();

    //cached total output sample
    private boolean cachedTotalOutputIsDirty = true;
    private int     cachedTotalOutput;

    //envelope data
    private boolean         envelopeIdle = true;
    private int             envelopePeriod;
    private int             envelopePeriodValue = 0x10000;
    private int             envelopeCounter = envelopePeriodValue;
    private int             envelopeVolume;
    private boolean         envelopeHold;
    private boolean         envelopeAltr;
    private boolean         envelopeAtak;
    private boolean         envelopeCont;

    //IO devices, such as hand controllers or the ECS keyboard
    private IODevice        ioDevice0;
    private IODevice        ioDevice1;
    private boolean         outputEnabled0;
    private boolean         outputEnabled1;

    //noise data
    private boolean         noiseIdle = false;
    private int             noisePeriod;
    private int             noisePeriodValue = 0x20;
    private int             noiseCounter = noisePeriodValue;

    //data for random number generator, used for white noise accuracy
    private int     random = 1;
    private boolean noise = true;

    //input polling interval
    private final static int TICK_LENGTH_POLLING = AY38900.TICK_LENGTH_FRAME/4;

    //default clock divisor
    private final static int DEFAULT_CLOCK_DIVISOR = 1;

    //output amplitudes for a single channel
    private final static int[] amplitudes16Bit = {
            0x003C, 0x0055, 0x0079, 0x00AB, 0x00F1, 0x0155, 0x01E3, 0x02AA, 
            0x03C5, 0x0555, 0x078B, 0x0AAB, 0x0F16, 0x1555, 0x1E2B, 0x2AAA
        };
/*
    private final static int[] amplitudes16Bit = {
            0x0078, 0x00AA, 0x00F2, 0x0156, 0x01E2, 0x02AA, 0x03C6, 0x0554, 
            0x078A, 0x0AAA, 0x0F16, 0x1556, 0x1E2C, 0x2AAA, 0x3C56, 0x5554
        };
*/

    private class Registers extends RAM
    {
        private Registers() {
            super(0x0010, 0, 8);
        }

        public void poke(int location, int value) {
            switch(location) {
                case 0x00:
                    value = value & 0x00FF;
                    channel0.period = (channel0.period & 0x0F00) | value;
                    channel0.periodValue = (channel0.period == 0
                            ? 0x1000 : channel0.period);
                    break;

                case 0x01:
                    value = value & 0x00FF;
                    channel1.period = (channel1.period & 0x0F00) | value;
                    channel1.periodValue = (channel1.period == 0
                            ? 0x1000 : channel1.period);
                    break;

                case 0x02:
                    value = value & 0x00FF;
                    channel2.period = (channel2.period & 0x0F00) | value;
                    channel2.periodValue = (channel2.period == 0
                            ? 0x1000 : channel2.period);
                    break;

                case 0x03:
                    value = value & 0x00FF;
                    envelopePeriod = (envelopePeriod & 0xFF00) | value;
                    envelopePeriodValue = (envelopePeriod == 0
                            ? 0x10000 : (envelopePeriod<<1));
                    break;

                case 0x04:
                    value = value & 0x000F;
                    channel0.period = (channel0.period & 0x00FF) | (value<<8);
                    channel0.periodValue = (channel0.period == 0
                            ? 0x1000 : channel0.period);
                    break;

                case 0x05:
                    value = value & 0x000F;
                    channel1.period = (channel1.period & 0x00FF) | (value<<8);
                    channel1.periodValue = (channel1.period == 0
                            ? 0x1000 : channel1.period);
                    break;

                case 0x06:
                    value = value & 0x000F;
                    channel2.period = (channel2.period & 0x00FF) | (value<<8);
                    channel2.periodValue = (channel2.period == 0
                            ? 0x1000 : channel2.period);
                    break;

                case 0x07:
                    value = value & 0x00FF;
                    envelopePeriod = (envelopePeriod & 0x00FF) | (value<<8);
                    envelopePeriodValue = (envelopePeriod == 0
                            ? 0x10000 : (envelopePeriod<<1));
                    break;

                case 0x08:
                    value = value & 0x00FF;
                    outputEnabled0 = ((value & 0x0040) != 0);
                    outputEnabled1 = ((value & 0x0080) != 0);
                    channel0.toneDisabled = ((value & 0x0001) != 0);
                    channel1.toneDisabled = ((value & 0x0002) != 0);
                    channel2.toneDisabled = ((value & 0x0004) != 0);
                    channel0.noiseDisabled = ((value & 0x0008) != 0);
                    channel1.noiseDisabled = ((value & 0x0010) != 0);
                    channel2.noiseDisabled = ((value & 0x0020) != 0);
                    channel0.isDirty = true;
                    channel1.isDirty = true;
                    channel2.isDirty = true;
                    noiseIdle = channel0.noiseDisabled &
                            channel1.noiseDisabled & channel2.noiseDisabled;
                    break;

                case 0x09:
                    value = value & 0x001F;
                    noisePeriod = value;
                    noisePeriodValue = (noisePeriod == 0
                            ? 0x20 : (noisePeriod<<1));
                    break;

                case 0x0A:
                    value = value & 0x000F;
                    envelopeHold = ((value & 0x0001) != 0);
                    envelopeAltr = ((value & 0x0002) != 0);
                    envelopeAtak = ((value & 0x0004) != 0);
                    envelopeCont = ((value & 0x0008) != 0);
                    envelopeVolume = (envelopeAtak ? 0 : 15);
                    envelopeCounter = envelopePeriodValue;
                    envelopeIdle = false;
                    break;

                case 0x0B:
                    value = value & 0x003F;
                    channel0.envelope = ((value & 0x0010) != 0);
                    channel0.volume = (value & 0x000F);
                    channel0.isDirty = true;
                    break;

                case 0x0C:
                    value = value & 0x003F;
                    channel1.envelope = ((value & 0x0010) != 0);
                    channel1.volume = (value & 0x000F);
                    channel1.isDirty = true;
                    break;

                case 0x0D:
                    value = value & 0x003F;
                    channel2.envelope = ((value & 0x0010) != 0);
                    channel2.volume = (value & 0x000F);
                    channel2.isDirty = true;
                    break;

                case 0x0E:
                    if (outputEnabled1)
                        ioDevice1.setOutputValue(value);
                    break;

                case 0x0F:
                    if (outputEnabled0)
                        ioDevice0.setOutputValue(value);
                    break;
            }
            super.poke(location, value);
        }

        public int peek(int location) {
            switch(location) {
                case 0x0E:
                    return (!outputEnabled1 ? ioDevice1.getInputValue() : 0);
                case 0x0F:
                    return (!outputEnabled0 ? ioDevice0.getInputValue() : 0);
                default:
                    return super.peek(location);
            }
        }
    }

    private class Channel
    {
        private void reset() {
            volume = 0;
            period = 0;
            periodValue = 0x1000;
            toneCounter = periodValue;
            tone = false;
            envelope = false;
            toneDisabled = false;
            noiseDisabled = false;
            isDirty = true;
        }

        private void save(SaveOutputStream sos) throws IOException {
            sos.writeInt(period);
            sos.writeInt(periodValue);
            sos.writeInt(volume);
            sos.writeInt(toneCounter);
            sos.writeBoolean(tone);
            sos.writeBoolean(envelope);
            sos.writeBoolean(toneDisabled);
            sos.writeBoolean(noiseDisabled);
        }

        private void load(LoadInputStream lis) throws IOException {
            period = lis.readInt(0x0000, 0x0FFF);
            periodValue = lis.readInt(0x0001, 0x1000);
            volume = lis.readInt(0, 15);
            toneCounter = lis.readInt(0x0001, 0x1000);
            tone = lis.readBoolean();
            envelope = lis.readBoolean();
            toneDisabled = lis.readBoolean();
            noiseDisabled = lis.readBoolean();
            isDirty = true;
        }

        int     period;
        int     periodValue;
        int     volume;
        int     toneCounter;
        boolean tone;
        boolean envelope = false;
        boolean toneDisabled;
        boolean noiseDisabled;
        boolean isDirty;
        int     cachedSample;
    }

}
