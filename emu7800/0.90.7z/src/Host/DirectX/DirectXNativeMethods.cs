﻿using System;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Security;
using System.Text;
using System.Threading;

namespace EMU7800.Host.DirectX
{
    [StructLayout(LayoutKind.Sequential)]
    public struct Emu7800DirectX_Statistics
    {
        public int FrameCount;
        public int SegmentCount;
        public int Hz;
        public int FrameWidth;
        public int FrameHeight;
        public IntPtr DeviceWindow;
    }

    public enum Emu7800DirectXState
    {
        None,
        Initialize,
        Run,
        Acquire,
        Finalize
    };

    public delegate void PrepareFrameCallback();

    public static class DirectXNativeMethods
    {
        #region Fields

        private static SynchronizationContext _SynchronizationContext;
        private static GCHandle _FrameBufferHandle, _PaletteHandle;
        private static PrepareFrameCallback _PrepareFrame;
        private static bool _UseWorkerThread;
        private static Thread _WorkerThread;
        private static Emu7800DirectXState _State;
        private static readonly Stopwatch _Stopwatch = new Stopwatch();
        private static long _FrameDuration;

        #endregion

        public static bool ShowSnow { get; set; }
        public static Emu7800DirectXState RequestedState { get; set; }
        public static Emu7800DirectXState State { get { return _State; } private set { _State = value; } }

        public static int DX { get; set; }
        public static int DY { get; set; }

        public static Emu7800DirectX_Statistics Statistics
        {
            get { return GetStatistics(); }
        }

        public static int HResult { get; private set; }
        public static string HResultErrorMessage
        {
            get { return HResult < 0 ? GetErrorMessage(HResult) : string.Empty; }
        }
        public static bool IsDeviceOk { get { return HResult.Equals(0); } }
        public static bool IsDeviceLost { get { return HResult.Equals(1); } }
        public static bool IsDeviceStopped { get { return HResult.Equals(2); } }
        public static bool IsDeviceErrored { get { return HResult < 0; } }

        /// <summary>
        /// Initializes and starts the DirectX presentation system.
        /// </summary>
        /// <param name="adapter"></param>
        /// <param name="icon"></param>
        /// <param name="fullScreen"></param>
        /// <param name="frameBuffer"></param>
        /// <param name="palette"></param>
        /// <param name="hz"></param>
        /// <param name="effectiveHz"></param>
        /// <param name="stride"></param>
        /// <param name="deviceWindowHeight"></param>
        /// <param name="useWorkerThread"></param>
        /// <param name="callback"></param>
        /// <param name="deviceWindowWidth"></param>
        /// <exception cref="ArgumentNullException"/>
        /// <exception cref="ArgumentOutOfRangeException"/>
        /// <exception cref="ApplicationException">inability to initialize, see exception text for details</exception>
        public static void StartPresentation(int adapter, Icon icon, bool fullScreen, byte[] frameBuffer, int[] palette, int hz, int effectiveHz, int stride, int deviceWindowWidth, int deviceWindowHeight, bool useWorkerThread, PrepareFrameCallback callback)
        {
            GuardForNull("frameBuffer", frameBuffer);
            GuardForNull("palette", palette);
            GuardForNull("callback", callback);

            GuardForOutOfRange("frameBuffer", "must be of size multiple of stride parameter", frameBuffer.Length % stride == 0);
            GuardForOutOfRange("frameBuffer", "must have at least 240 scanlines", frameBuffer.Length/stride >= 240);
            GuardForOutOfRange("palette", "must be of size 256", palette.Length == 256);
            GuardForOutOfRange("hz", "must be either 50 or 60", hz == 50 || hz == 60);

            GuardForUnableToInit("already presenting", State == Emu7800DirectXState.None);

            _FrameBufferHandle = GCHandle.Alloc(frameBuffer, GCHandleType.Pinned);
            _PaletteHandle = GCHandle.Alloc(palette, GCHandleType.Pinned);
            try
            {
                HResult = EMU7800DirectX_Initialize(adapter, icon.Handle, fullScreen, frameBuffer, frameBuffer.Length, palette, hz, stride, 320, 240, deviceWindowWidth, deviceWindowHeight, useWorkerThread);
            }
            catch (DllNotFoundException ex)
            {
                GuardForUnableToInit("Unable to initialize EMU7800DirectX: " + ex.Message, false);
            }
            finally
            {
                if (!IsDeviceOk)
                {
                    _FrameBufferHandle.Free();
                    _PaletteHandle.Free();
                }
            }

            GuardForUnableToInit("already initialized", IsDeviceOk);
            GuardForUnableToInit(HResultErrorMessage, !IsDeviceErrored);

            _SynchronizationContext = SynchronizationContext.Current;
            if (_SynchronizationContext == null) throw new ApplicationException("No current SynchronizationContext");

            RequestedState = Emu7800DirectXState.None;
            _PrepareFrame = callback;
            _UseWorkerThread = useWorkerThread;
            _FrameDuration = Stopwatch.Frequency / effectiveHz;

            State = Emu7800DirectXState.Initialize;
            _PrepareFrame();

            State = Emu7800DirectXState.Run;
            if (_UseWorkerThread)
            {
                _WorkerThread = new Thread(RunPresentation) {IsBackground = false};
                _WorkerThread.Start();
            }
            else
            {
                RunPresentation();
            }
        }

        private static void RunPresentation()
        {
            while (true)
            {
                _Stopwatch.Reset();
                _Stopwatch.Start();

                if (State == Emu7800DirectXState.Acquire)
                {
                    _SynchronizationContext.Send(AcquirePrepareFrame, null);
                }
                else
                {
                    _PrepareFrame();
                }

                switch (RequestedState)
                {
                    case Emu7800DirectXState.Acquire:
                    case Emu7800DirectXState.Run:
                    case Emu7800DirectXState.Finalize:
                        State = RequestedState;
                        RequestedState = Emu7800DirectXState.None;
                        break;
                    case Emu7800DirectXState.Initialize:
                        RequestedState = Emu7800DirectXState.None;
                        break;
                }

                if (State == Emu7800DirectXState.Finalize) break;

                if (!_UseWorkerThread) System.Windows.Forms.Application.DoEvents();

                HResult = EMU7800DirectX_PresentFrame(ShowSnow, DX, DY);

                if (IsDeviceLost || IsDeviceStopped || IsDeviceErrored)
                {
                    Trace.WriteLine("Emu7800DirectX: Stopped from HResult=" + HResult
                        + (IsDeviceLost ? " (device lost)" : (IsDeviceStopped ? " (stop requested)" : string.Empty)));
                    State = Emu7800DirectXState.Finalize;
                    break;
                }

                while (_Stopwatch.ElapsedTicks < _FrameDuration) { }
            }

            State = Emu7800DirectXState.Finalize;

            _SynchronizationContext.Send(LastPrepareFrame, null);

            State = Emu7800DirectXState.None;
        }

        private static void AcquirePrepareFrame(object state)
        {
            _PrepareFrame();
        }

        private static void LastPrepareFrame(object state)
        {
            _PrepareFrame();
            EMU7800DirectX_Shutdown();
            try
            {
                _FrameBufferHandle.Free();
                _PaletteHandle.Free();
            }
            catch (InvalidOperationException) { }
        }

        #region Helpers

        private static Emu7800DirectX_Statistics GetStatistics()
        {
            var stats = EMU7800DirectX_GetStatistics();
            return (Emu7800DirectX_Statistics)Marshal.PtrToStructure(stats, typeof(Emu7800DirectX_Statistics));
        }

        private static string GetErrorMessage(int hresult)
        {
            var err = GetErrorString(hresult);
            var errDesc = GetErrorDescription(hresult);
            var s = new StringBuilder();
            if (string.IsNullOrEmpty(err) && string.IsNullOrEmpty(errDesc))
            {
                s.AppendFormat("HR={0:X8}", hresult);
            }
            if (!string.IsNullOrEmpty(err))
            {
                s.AppendFormat("{0}: ", err);
            }
            s.Append(errDesc);
            return s.ToString();
        }

        private static string GetErrorString(int hresult)
        {
            return EMU7800DirectX_DXGetErrorString(hresult) ?? string.Empty;
        }

        private static string GetErrorDescription(int hresult)
        {
            return EMU7800DirectX_DXGetErrorDescription(hresult) ?? string.Empty;
        }

        private static void GuardForNull(string paramName, object param)
        {
            if (param == null) throw new ArgumentNullException(paramName);
        }

        private static void GuardForOutOfRange(string paramName, string message, bool ok)
        {
            if (!ok) throw new ArgumentOutOfRangeException(paramName, "Bad " + paramName + " param: " + message);
        }

        private static void GuardForUnableToInit(string reason, bool ok)
        {
            if (!ok) throw new ApplicationException("Unable to initialize EMU7800DirectX: " + reason);
        }

        #endregion

        #region DllImports

        [DllImport("EMU7800.DirectX.dll"), SuppressUnmanagedCodeSecurity]
        private static extern int EMU7800DirectX_Initialize(int adapter, IntPtr hIcon, bool fullScreen,
            byte[] frameBuffer, int frameBufferSize, int[] palette, int hz, int stride,
            int targetFrameWidth, int targetFrameHeight, int deviceWindowWidth, int deviceWindowHeight,
            bool usingWorkerThread);

        [DllImport("EMU7800.DirectX.dll"), SuppressUnmanagedCodeSecurity]
        private static extern int EMU7800DirectX_TryRestoringLostDevice();

        [DllImport("EMU7800.DirectX.dll"), SuppressUnmanagedCodeSecurity]
        private static extern int EMU7800DirectX_PresentFrame(bool showSnow, int dx, int dy);

        [DllImport("EMU7800.DirectX.dll"), SuppressUnmanagedCodeSecurity]
        private static extern void EMU7800DirectX_Shutdown();

        [DllImport("EMU7800.DirectX.dll"), SuppressUnmanagedCodeSecurity]
        [return: MarshalAs(UnmanagedType.LPWStr)]
        private static extern string EMU7800DirectX_DXGetErrorString(int hresult);

        [DllImport("EMU7800.DirectX.dll"), SuppressUnmanagedCodeSecurity]
        [return: MarshalAs(UnmanagedType.LPWStr)]
        private static extern string EMU7800DirectX_DXGetErrorDescription(int hresult);

        [DllImport("EMU7800.DirectX.dll"), SuppressUnmanagedCodeSecurity]
        private static extern IntPtr EMU7800DirectX_GetStatistics();

        #endregion
    }
}
