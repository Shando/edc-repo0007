

P A L E

Pete's Lynx Emulator


Ver: 1.0

Date: 15 June 2003


Loading
=======

You MUST, start the load by typing either LOAD"" or MLOAD"" and
type <return> before clicking the LOAD tape button. So far I haven't
looked at restoring the stack after loading so at the moment
the emulator must be in a known stable state before loading
so I can re-enter the ROM code.
Actually MUST is quite a strong word, in fact you can
usually get away with it for BINARY programs (which don't return anyway),
another method which has mixed success is to list the first few program
lines after loading, this seems to restore sanity to the interpreter.


Keyboard
========

I suggest changing your keyboard 'repeat rate' and 'start delay' rate to
the maximum and minimum respectively. This should speed
up the response in games. In future I'll look at handling this
automatically. I left the keyboard mapping as per the original(ish),
again in the future I'll probably put an option in to give a more
meaningful layout. 


Sound
=====

Two sound drivers, one patches into the ROM, records sound
from the port accesses and then outputs the sound when finished.
Second driver (for MC games and other non ROM sound) needs 
some more work but basically tries to stream this continually
without needing the ROM hooks. Doesn't work too bad on my machine
but a bit speed dependent.


Instructions for loading Level 9 Adventures
===========================================

1. Reset & Open up the 1st file in the set eg: advent
   as a standard basic/binary and run it

2. Load up the second and run this one

3. Change mode to 'level 9' and open up the first
   file in the set eg: 'advent.tap'

The loader will automatically load the data from
parts 3,4 and 5 of the fileset and run the interpreter.
(Note: this has only been tested on 'Dungeon', as I
don't have any others to test :(  )


Known issues
============

1. Inexact emulation of bank refreshing

2. Speed adjustment clunky

3. Sound support needs more work 

4. Keyboard not 100% there yet - no dual keypresses
   eg: arrow key diagonals :(

5. Tape handling needs improving - without the typing nonsense!

6. Saving not supported

7. Fullscreen not implemented

8. 'Background Z80 Noise' missing -
   as soon as someone sends me a wav file :)

9. 6845 registers not implemented - no shaking ground in 'Air Raid'


Unknown Issues
=============

Any bug reports, hints, suggestions, will be gratefully received.

Please, please, please...

If you use the tape reading program and get some
progs back then send me a copy of the TAP file.
This emulator was written without the
benefit of having a Lynx, with only Camsofts 'Power Blaster'
and the Level 9 'Dungeon Adventure', the DEMO
tape courtesy of Paul Robson's CamLynx and some 
homegrown stuff of my own off some very cruddy tapes (the
level 9 game seems to have picked up some wonderful
phrases in the read off the tape).

In order to test and improve this emulator I need MORE
software. Any help here would be much appreciated, go on
I've even included a tape reader and email is cheap :))

Legal
=====

I've included the ROMs and software for this computer
because I can't think of anywhere else you'd get them
and to be honest I hope the people that originally wrote this
stuff are okay with it, any feedback from them on this issue
is welcome, if anybody has a problem with the stuff
being here then of course I'll apologise and remove it.
I apologise in advance to the creator(s) of 'Power Blaster' 
that until I get the keyboard handling sorted their
game plays below the level of the original.

My special thanks to everyone concerned with bringing
us the Lynx, it was a strange micro but one which
enjoys a certain cult status in UK micros history.


BTW: If your name is Vince, you were living in mid Wales in
the 80's and you own(ed) a lynx 96 with disk drive... you
may very well have the only surviving copies of some
of my programs... Get in touch...


Cheers,

Pete
heraclion@btopenworld.com


