package com.blissj.plugin;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import java.text.*;
import javax.swing.*;
import com.bliss.core.devices.*;
import com.bliss.core.*;
import com.bliss.core.cartridge.*;

public class AppVideoOutputDevice implements VideoOutputDevice
{

    public Option[] getOptions() {
        return controllers;
    }

    public AppVideoOutputDevice() {
        frame = new AppVideoOutputFrame();
        frame.addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent we) {
                    stop = true;
                }
            });
    }

    public void setFrameIconImage(Image iconImage) {
        frame.setIconImage(iconImage);
    }

    public Image getFrameIconImage() {
        return frame.getIconImage();
    }

    public void setScale(int scale) {
        this.scale = scale;
    }

    public int getScale() {
        return scale;
    }

    public void init(String windowTitle, byte[] imageBank) {
        frame.setTitle(windowTitle);

        DataBuffer dataBuffer = new DataBufferByte(imageBank, imageBank.length);
        int[] bitMasks = { 0xFF };
        SampleModel sampleModel = new SinglePixelPackedSampleModel(
                DataBuffer.TYPE_BYTE, 320, 192, bitMasks);
        WritableRaster raster = Raster.createWritableRaster(
                sampleModel, dataBuffer, new Point(0, 0));
        bufferedImage = new BufferedImage(AY38900.COLOR_MODEL, raster, false,
                null);

        this.stop = false;
        frame.renderer.invalidate();
        frame.pack();
        Dimension d1 = frame.getToolkit().getScreenSize();
        Dimension d2 = frame.getSize();
        frame.setLocation((d1.width - d2.width)/2, (d1.height - d2.height)/2);
        frame.setVisible(true);
        g = (Graphics2D)frame.renderer.getGraphics();
        g.setRenderingHints(optimizedForSpeed);
        g.scale(scale, scale);

        try { Thread.sleep(1000); }
        catch (InterruptedException ignored) {}
    }

    public void displayImage(byte[] imageData, boolean hasChanged) {
        if (hasChanged)
            g.drawImage(bufferedImage, 0, 0, null);
    }

    public void release() {
        if (g != null) {
            g.dispose();
            g = null;
        }
        bufferedImage = null;
        frame.setVisible(false);
        frame.dispose();
    }

    private BufferedImage bufferedImage;
    private AppVideoOutputFrame frame;
    private Graphics2D g;
    private int scale = 2;
    boolean stop;

    private Option[] controllers = {
            new ChoiceOption() {
                public String getDescription() {
                    return AppPlugIn.RESOURCES.getString(
                            "ScalingDescription");
                }
                public Object[] getChoices() {
                    return choices;
                }
                public String getDescription(Object choice) {
                    Object[] args = { choice };
                    return MessageFormat.format(choiceFormat, args);
                }
                public void setValue(Object choice) {
                    scale = ((Integer)choice).intValue();
                }
                public Object getValue() {
                    return new Integer(scale);
                }
                private Integer[] choices = {
                        new Integer(1),
                        new Integer(2),
                        new Integer(3),
                        new Integer(4),
                        new Integer(5)
                    };
                private String choiceFormat = AppPlugIn.
                        RESOURCES.getString("ScalingFormat");
            }
        };

    private final static HashMap optimizedForSpeed;

    static {
        optimizedForSpeed = new HashMap();
        optimizedForSpeed.put(RenderingHints.KEY_ALPHA_INTERPOLATION,
                RenderingHints.VALUE_ALPHA_INTERPOLATION_SPEED);
        optimizedForSpeed.put(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_OFF);
        optimizedForSpeed.put(RenderingHints.KEY_COLOR_RENDERING,
                RenderingHints.VALUE_COLOR_RENDER_SPEED);
        optimizedForSpeed.put(RenderingHints.KEY_DITHERING,
                RenderingHints.VALUE_DITHER_DISABLE);
        optimizedForSpeed.put(RenderingHints.KEY_FRACTIONALMETRICS,
                RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
        optimizedForSpeed.put(RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR);
        optimizedForSpeed.put(RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_SPEED);
        optimizedForSpeed.put(RenderingHints.KEY_STROKE_CONTROL,
                RenderingHints.VALUE_STROKE_PURE);
        optimizedForSpeed.put(RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
    }

    class AppVideoOutputFrame extends Frame
    {
        AppVideoOutputFrame() {
            initUI();
        }

        public void update(Graphics g) { }
    
        public void paint(Graphics g) { }
    
        private void initUI() {
            setBackground(Color.black);
            setResizable(false);
            setLayout(new BorderLayout());
    
            renderer = new Canvas() {
                    public void update(Graphics g) { }
                    public void paint(Graphics g) {
                        if (bufferedImage != null &&
                                AppVideoOutputDevice.this.g != null)
                            AppVideoOutputDevice.this.g.drawImage(
                                    bufferedImage, 0, 0, null);
                    }
                    public Dimension getPreferredSize() {
                        return new Dimension(scale * 320, scale * 192);
                    }
                };
            add(renderer, BorderLayout.CENTER);
    
            pack();
        }

        Canvas renderer;

    }

}
