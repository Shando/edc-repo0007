Emulator for the sega genesis/megadrive by Stef

email:	stef_d@caramail.com
        stef0@multimania.com


Date : 14/01/2000  
Changes between v0.15b <- v0.14a:  
  
- Frame skip added.  
- V-sync added.
- STATUS register of the VDP corrected.
- Readings in VDP corrected.  
- Some others small things.
  
60% of roms works.  
The sound doesn't work yet :(
  
Keys to play are the following (AZERTY keyboard):  
  
		Player 1			Player 2

	Up		Z		Up		Up
	Down		S		Down		Down
	Left		Q		Left		Left
	right		D		Right		Right
	A		F		A		K
	B		G		B		L
	C		H		C		M
	X		R		X		I
	Y		T		X		O
	Z		Y		Z		P
	Start		E		Start		Enter
	Mode		A		Mode		Right Shift
  
You can access to the Debug Mode with the key SPACES
Use Esc key to exit.