/* faux1 terminal Apple 1 emulator
 * Copyright (C) 2012 James M. Reneau (renejm@users.sourceforge.net)
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

// VERSION should not have spaces or special characters in it as it is used by the shell script
// maketar.sh to create the tgz source file

// strings

#ifndef VERSION

#define VERSION "0.95.5.20120221"

#define KEYBOARD_RAWERROR "keyboard- raw mode error"
#define KEYBOARD_ORIGINALERROR "keyboard- original mode error"
#define KEYBOARD_READERROR "keyboard- read error"

#define MEMORY_MODE "In %iKB memory mode.\n"
#define MEMORY_FILEERROR "Could not open file %s.\n"
#define MEMORY_FILEGOOD "Filename '%s' loaded.\n"
#define MEMORY_FILENAMEPROMPT "Enter file name to load: "
#define MEMORY_FILETYPEPROMPT "Enter (A)scii or (B)inary: "
#define MEMORY_FILEADRESSPROMPT "Enter Starting Address in Hex: "
#define MEMORY_ADRESSSTARTERROR "Invalid starting address.\n"
#define MEMORY_ROMGOOD "ROM '%s' loaded at %04X.\n"
#define MEMORY_ROMLOADPROMPT "Load ROM file '%s' into RAM at %04X? y/n: "

#define SCREEN_HELLO "\nfaux1 - built on the napple1 and pom1 tradition\nVersion %s\n^l=Load ^r=Reset ^h=Hard Reset ^x=Exit ^e=Mode %2dK\n"

#endif
