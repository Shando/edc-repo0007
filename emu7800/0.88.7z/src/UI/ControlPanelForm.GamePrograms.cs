using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows.Forms;
using EMU7800.Machine;

namespace EMU7800.UI
{
    partial class ControlPanelForm
    {
        #region Fields

        TreeNode treenodeTitle, treenodeUnknown;
        bool DoubleClickReady;
        int RomFileCount;

        #endregion

        #region Event Handlers

        void comboboxRomDir_SelectedValueChanged(object sender, EventArgs e)
        {
            var newRomDir = comboboxRomDir.Text.Trim();
            if (Directory.Exists(newRomDir))
            {
                GlobalSettings.Instance.RomDirectory = newRomDir;
                LoadTreeView();
            }
        }

        void buttonBrowse_Click(object sender, EventArgs e)
        {
            var ofdROMSelect = new OpenFileDialog
            {
                Title = "Select ROM File",
                Filter = "ROMs (*.bin)|*.bin|A78 ROMs (*.a78)|*.a78",
                FilterIndex = 1
            };

            var romDir = comboboxRomDir.Text.Trim();
            ofdROMSelect.InitialDirectory = Directory.Exists(romDir) ? romDir : GlobalSettings.Instance.RomDirectory;

            if (ofdROMSelect.ShowDialog() != DialogResult.OK) return;
            Application.DoEvents();
            GameSelectByFileName(ofdROMSelect.FileName);
        }

        void treeviewRomList_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                e.Handled = true;
                SetSelection(treeviewRomList.SelectedNode);
                treeviewRomList_NodeMouseDoubleClick(sender, null);
            }
        }

        void treeviewRomList_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            SetSelection(e.Node);
        }

        void treeviewRomList_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            if (DoubleClickReady && CurrGameSettings.FileInfo != null)
            {
                buttonStart_Click(sender, e);
            }
            DoubleClickReady = false;
        }

        #endregion

        #region Helpers

        void GameSelectByFileName(string fn)
        {
            var fi = new FileInfo(fn);

            AddRomDirToComboBoxIfNecessary(fi.DirectoryName);

            // this will reload the TreeView via cmbROMDir_SelectedValueChanged
            comboboxRomDir.SelectedItem = fi.DirectoryName;

            var recog = SelectTitle(fi.FullName);
            if (!recog)
            {
                MessageBox.Show("Use Console Tab to specify custom attributes.", "ROM Not Recognized", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                var gs = ROMProperties.GetGameSettings(Utility.ComputeMD5Digest(fi));
                gs.FileInfo = fi;
                Trace.WriteLine("-------");
                Trace.WriteLine("Unrecognized ROM: prefilled GameSettings fields as follows:");
                Trace.WriteLine(gs);
                CurrGameSettings = gs;
                UpdateGameTitleLabel();
            }
        }

        void AddRomDirToComboBoxIfNecessary(string romDir)
        {
            romDir = romDir.Trim();
            if (!Directory.Exists(romDir)) return;
            foreach (string item in comboboxRomDir.Items)
            {
                if (item.Equals(romDir, StringComparison.OrdinalIgnoreCase)) return;
            }
            comboboxRomDir.Items.Add(romDir);
        }

        void LoadComboBoxRomDirs()
        {
            var romDirectories = GlobalSettings.Instance.GetUserValue("ROMDirectories");
            foreach (var romDir in romDirectories.Split(';'))
            {
                AddRomDirToComboBoxIfNecessary(romDir);
            }
        }

        void SaveComboBoxRomDirs()
        {
            var sb = new StringBuilder();
            if (comboboxRomDir.SelectedItem != null)
            {
                // this will cause the subsequent foreach to add a dup, but it will be filtered on the next load.
                // this keeps the currently selected romdir at the top of the list.
                sb.Append(comboboxRomDir.SelectedItem);
            }
            foreach (string item in comboboxRomDir.Items)
            {
                if (!sb.Length.Equals(0)) sb.Append(';');
                sb.Append(item);
            }
            GlobalSettings.Instance.SetUserValue("ROMDirectories", sb.ToString());
        }

        void SetSelection(TreeNode n)
        {
            DoubleClickReady = false;
            if (n == null || n.Tag == null) return;

            DoubleClickReady = true;

            var gs = n.Tag as GameSettings;
            if (gs != CurrGameSettings)
            {
                CurrGameSettings = gs;
                Trace.WriteLine(CurrGameSettings.ToString());
            }

            UpdateGameTitleLabel();
            StartButtonEnabled = true;
            ResumeButtonEnabled = false;
        }

        void LoadTreeView()
        {
            Cursor = Cursors.WaitCursor;

            RomFileCount = 0;
            labelRomCount.Text = "Examining ROM Directory...";

            treeviewRomList.BeginUpdate();
            treeviewRomList.Nodes.Clear();

            treenodeTitle = new TreeNode("Title", 0, 1);
            treeviewRomList.Nodes.Add(treenodeTitle);

            var manuIndex = AddTreeSubRoot(treeviewRomList, "Manufacturer", new[] {
              "Absolute",
              "Activision",
              "Apollo",
              "Atari",
              "Avalon Hill",
              "Bitcorp",
              "Bomb",
              "CBS Electronics",
              "CCE",
              "Coleco",
              "CommaVid",
              "Data Age",
              "Epyx",
              "Exus",
              "Froggo",
              "HomeVision",
              "Hozer Video Games",
              "Imagic",
              "ITT Family Games",
              "Konami",
              "Mattel",
              "Milton Bradley",
              "Mystique",
              "Mythicon",
              "Panda",
              "Parker Bros",
              "Playaround",
              "Sears",
              "Sega",
              "Spectravideo",
              "Starsoft",
              "Suntek",
              "Telegames",
              "Telesys",
              "Tigervision",
              "US Games",
              "Video Gems",
              "Xonox",
              "Zellers",
              "Zimag",
              "20th Century Fox"});

            var al = new List<string>();
            for (var i = 1977; i <= DateTime.Today.Year; i++)
            {
                al.Add(i.ToString());
            }
            var yearIndex = AddTreeSubRoot(treeviewRomList, "Year", al);

            var rareIndex = AddTreeSubRoot(treeviewRomList, "Rarity", new[] {
                "Common", "Uncommon", "Rare", "Extremely Rare",
                "Unbelievably Rare", "Prototype", "Unreleased Prototype"});

            var machIndex = AddTreeSubRoot(treeviewRomList, "Machine Type", new[] {
                GetMachineTypeString(MachineType.A2600NTSC, true),
                GetMachineTypeString(MachineType.A2600PAL, true),
                GetMachineTypeString(MachineType.A7800NTSC, true),
                GetMachineTypeString(MachineType.A7800PAL, true)});

            var contIndex = AddTreeSubRoot(treeviewRomList, "LController", new[] {
                 "Joystick", "ProLineJoystick", "Paddles", "Driving", "Keypad", "Lightgun", "BoosterGrip"});
#if DEBUG
            var cartList = Enum.GetNames(typeof(CartType));
            var cartIndex = AddTreeSubRoot(treeviewRomList, "Cartridge Type", cartList);
#endif
            treenodeUnknown = new TreeNode("Unknown", 0, 1);
            treeviewRomList.Nodes.Add(treenodeUnknown);

            Application.DoEvents();

            if (!Directory.Exists(GlobalSettings.Instance.RomDirectory))
            {
                GlobalSettings.Instance.RomDirectory = Directory.GetCurrentDirectory();
            }
            var romFiles = new DirectoryInfo(GlobalSettings.Instance.RomDirectory).GetFiles();

            progressbarRomCount.Minimum = 0;
            progressbarRomCount.Value = 0;
            progressbarRomCount.Maximum = romFiles.Length;
            labelRomCount.Visible = false;
            progressbarRomCount.Visible = true;

            foreach (var fi in romFiles)
            {
                var gs = ROMProperties.GetGameSettingsFromFile(fi);
                if (gs == null)
                {
                    continue;
                }

                RomFileCount++;
                progressbarRomCount.Value = RomFileCount;

                var tn = new TreeNode(BuildTitle(gs.Title, gs.Manufacturer, GetMachineTypeString(gs.MachineType, false), gs.Year), 2, 2)
                {
                    Tag = gs
                };
                treenodeTitle.Nodes.Add(tn);

                AddTreeNode(manuIndex, gs, gs.Manufacturer, gs.Title, GetMachineTypeString(gs.MachineType, false), gs.Year);
                AddTreeNode(yearIndex, gs, gs.Year, gs.Title, gs.Manufacturer, GetMachineTypeString(gs.MachineType, false));
                AddTreeNode(rareIndex, gs, gs.Rarity, gs.Title, gs.Manufacturer, GetMachineTypeString(gs.MachineType, false), gs.Year);
                AddTreeNode(machIndex, gs, GetMachineTypeString(gs.MachineType, true), gs.Title, gs.Manufacturer, GetMachineTypeString(gs.MachineType, false), gs.Year);
                AddTreeNode(contIndex, gs, gs.LController.ToString(), gs.Title, gs.Manufacturer, GetMachineTypeString(gs.MachineType, false), gs.Year);
#if DEBUG
                AddTreeNode(cartIndex, gs, gs.CartType.ToString(), gs.Title, gs.Manufacturer, GetMachineTypeString(gs.MachineType, false), gs.Year);
#endif
                Application.DoEvents();
            }

            for (var i = 0; i < treeviewRomList.Nodes.Count; )
            {
                var c = treeviewRomList.Nodes[i];
                if (PruneTree(c))
                {
                    c.Remove();
                }
                else
                {
                    i++;
                }
            }

            treeviewRomList.Sorted = true;
            treeviewRomList.EndUpdate();
            treeviewRomList.Update();
            progressbarRomCount.Visible = false;

            labelRomCount.Text = String.Format("{0} ROM file{1} recognized", RomFileCount, (RomFileCount != 1 ? "s" : ""));
            labelRomCount.Visible = true;

            Cursor = Cursors.Arrow;
        }

        // Remove TreeNodes that have no dependencies
        static bool PruneTree(TreeNode p)
        {
            var score = 0;
            if (p.Nodes.Count > 0)
            {
                for (var i = 0; i < p.Nodes.Count; )
                {
                    var c = p.Nodes[i];
                    if (PruneTree(c))
                    {
                        c.Remove();
                    }
                    else
                    {
                        score++;
                        i++;
                    }
                }
            }
            return (score == 0 && p.Tag == null);
        }

        bool SelectTitle(string fullName)
        {
            var fi = new FileInfo(fullName);
            var md5 = Utility.ComputeMD5Digest(fi);
            if (md5 == null)
            {
                return false;
            }
            foreach (TreeNode tn in treenodeTitle.Nodes)
            {
                if (tn.Tag != null && md5 == ((GameSettings)tn.Tag).MD5)
                {
                    treeviewRomList.SelectedNode = tn;
                    return true;
                }
            }
            foreach (TreeNode tn in treenodeUnknown.Nodes)
            {
                if (tn.Tag != null && md5 == ((GameSettings)tn.Tag).MD5)
                {
                    treeviewRomList.SelectedNode = tn;
                    return true;
                }
            }
            return false;
        }

        static Dictionary<string, TreeNode> AddTreeSubRoot(TreeView root, string label, IEnumerable<string> subList)
        {
            var tnparent = new TreeNode(label, 0, 1);
            root.Nodes.Add(tnparent);
            var index = new Dictionary<string, TreeNode>();
            TreeNode tn;
            foreach (var s in subList)
            {
                tn = new TreeNode(s, 0, 1);
                tnparent.Nodes.Add(tn);
                index.Add(s, tn);
            }
            tn = new TreeNode("Other", 0, 1);
            tnparent.Nodes.Add(tn);
            index.Add("Other", tn);
            return index;
        }

        static void AddTreeNode(IDictionary<string, TreeNode> index, GameSettings gs, string key, params string[] titlebits)
        {
            var tn = new TreeNode(BuildTitle(titlebits), 2, 2) { Tag = gs };
            if (key == null || !index.ContainsKey(key))
            {
                key = "Other";
            }
            index[key].Nodes.Add(tn);
        }

        static string BuildTitle(params string[] titlebits)
        {
            var title = new StringBuilder();

            for (var i = 0; i < titlebits.Length; i++)
            {
                if (string.IsNullOrEmpty(titlebits[i])) continue;
                if (i > 0)
                {
                    title.Append(", ");
                }
                title.Append(titlebits[i]);
            }
            return title.ToString();
        }

        static string GetMachineTypeString(MachineType machineType, bool verbose)
        {
            var mts = string.Empty;

            switch (machineType)
            {
                case MachineType.A2600NTSC:
                    mts = verbose ? "VCS (2600) NTSC (N.American)" : "VCS";
                    break;
                case MachineType.A2600PAL:
                    mts = verbose ? "VCS (2600) PAL (European)" : "VCS PAL";
                    break;
                case MachineType.A7800NTSC:
                    mts = verbose ? "ProSystem (7800) NTSC (N.American)" : "ProSystem";
                    break;
                case MachineType.A7800PAL:
                    mts = verbose ? "ProSystem (7800) PAL (European)" : "ProSystem PAL";
                    break;
            }

            return mts;
        }

        #endregion
    }
}