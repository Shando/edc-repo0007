﻿/*
 * HostDirectX
 * 
 * A DirectX 9 based host.
 * 
 * Copyright (c) 2008 Mike Murphy
 * 
 */

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Diagnostics;
using System.Threading;

using EMU7800.Machine;

namespace EMU7800.Host.DirectX
{
    public class HostDirectX : HostBase, IDisposable
    {
        #region Fields

        private FontRenderer _FontRenderer;
        private int _ShowSnowCounter, _InitShowSnowCounter;
        private byte _FontColor;

        private Dictionary<Key, HostInput> _KeyBindings;
        private DirectInput _DirectInput;
        private bool _JoysticksSwapped, _LeftPaddlesSwapped, _RightPaddlesSwapped;
        private int _MouseX, _MouseY;
        private bool _ShowMouseCursor;   // For lightgun emulation

        private readonly bool _FullScreen;
        private bool _UseWorkerThread, _NoPauseOnLostFocus;

        private const int FRAME_SAMPLES = 120;
        private readonly Stopwatch _Stopwatch = new Stopwatch();
        private long _LastEndOfCycleTick;
        private readonly int[] _RunMachineTicks = new int[FRAME_SAMPLES];
        private readonly int[] _FrameDurationTicks = new int[FRAME_SAMPLES];
        private int _UsedAudioBuffers;

        #endregion

        #region Constructors

        public HostDirectX()
        {
            ReadConfiguration();
        }

        public HostDirectX(bool fullScreen) : this()
        {
            _FullScreen = fullScreen;
        }

        #endregion

        public override void Run(MachineBase m)
        {
            base.Run(m);
            M = m;

            _FontRenderer = new FontRenderer(M.VideoFrameBuffer, M.VisiblePitch);

            // ensures a current synchronization context is established
            if (_UseWorkerThread) System.Windows.Forms.Application.DoEvents();

            DirectXNativeMethods.StartPresentation(0, HostDirectXResources.EMUIcon, _FullScreen, M.VideoFrameBuffer, M.GetPalette(), M.FrameHZ, EffectiveFPS, M.VisiblePitch, 640, 480, _UseWorkerThread, PrepareFrame);

            if (_UseWorkerThread)
            {
                while (DirectXNativeMethods.State != Emu7800DirectXState.None)
                {
                    System.Windows.Forms.Application.DoEvents();
                    Thread.Sleep(100);
                }
            }
        }

        void PrepareFrame()
        {
            if (DirectXNativeMethods.State == Emu7800DirectXState.Run)
            {
                var startOfCycleTick = _Stopwatch.ElapsedTicks;

                if (!_DirectInput.Poll(false))
                {
                    Trace.WriteLine("HostDirectX: Lost input device(s)");
                    if (!_FullScreen && !_NoPauseOnLostFocus) RaiseInput(HostInput.Pause, true);
                    DirectXNativeMethods.RequestedState = _FullScreen ? Emu7800DirectXState.Finalize : Emu7800DirectXState.Acquire;
                }

                if (Ended || M.MachineHalt)
                {
                    DirectXNativeMethods.RequestedState = Emu7800DirectXState.Finalize;
                    return;
                }

                DirectXNativeMethods.DX = LeftOffset;
                DirectXNativeMethods.DY = ClipStart;

                if (_ShowSnowCounter > 0)
                {
                    DirectXNativeMethods.ShowSnow = --_ShowSnowCounter > 0;
                    var r = new Random();
                    for (var i = 0; i < M.SoundFrameBuffer.Length; i++)
                    {
                        M.SoundFrameBuffer[i] = (byte)r.Next(0x2);
                    }
                }
                else if (Paused)
                {
                    for (var i = 0; i < M.SoundFrameBuffer.Length; i++) M.SoundFrameBuffer[i] = 0;
                }
                else
                {
                    M.RunFrame();
                }

                if (!Muted) _UsedAudioBuffers = EnqueueAudio(M.SoundFrameBuffer);

                if (PostedMsg.Length > 0) _FontRenderer.DrawText(PostedMsg, LeftOffset + 2, ClipStart + 4, _FontColor++, 0); else _FontColor = 10;

                if (_ShowMouseCursor && _FullScreen) M.VideoFrameBuffer[_MouseY * M.VisiblePitch + _MouseX] = 10;

                var endOfCycleTick = _Stopwatch.ElapsedTicks;

                var statIndex = (int)M.FrameNumber % FRAME_SAMPLES;
                _RunMachineTicks[statIndex] = (int)(endOfCycleTick - startOfCycleTick);
                _FrameDurationTicks[statIndex] = (int)(endOfCycleTick - _LastEndOfCycleTick);

                _LastEndOfCycleTick = endOfCycleTick;

                return;
            }

            if (DirectXNativeMethods.State == Emu7800DirectXState.Acquire)
            {
                if (_DirectInput.Poll(true))
                {
                    Trace.WriteLine("HostDirectX: Reacquired input device(s)");
                    DirectXNativeMethods.RequestedState = Emu7800DirectXState.Run;
                    return;
                }
            }

            if (DirectXNativeMethods.State == Emu7800DirectXState.Initialize)
            {
                _ShowMouseCursor = M.InputAdapter.GetController(0) == Controller.Lightgun;

                // center mouse dot
                _MouseX = M.VisiblePitch >> 1;
                _MouseY = M.Scanlines >> 1;

                try
                {
                    _DirectInput = new DirectInput(DirectXNativeMethods.Statistics.DeviceWindow, _FullScreen);
                }
                catch (Exception ex)
                {
                    if (Utility.IsCriticalException(ex)) throw;
                    DirectXNativeMethods.RequestedState = Emu7800DirectXState.Finalize;
                    Trace.WriteLine(ex);
                    return;
                }

                _KeyBindings = UpdateKeyBindingsFromGlobalSettings(CreateDefaultKeyBindings());

                SetDirectInputHandlerForKeyboard();
                SetDirectInputHandlersForDevice(0);
                SetDirectInputHandlersForDevice(1);

                var statistics = DirectXNativeMethods.Statistics;
                var message = string.Format("HostDirectX: Frame=({0},{1}), Hz={2}", statistics.FrameWidth, statistics.FrameHeight, statistics.Hz);
                Trace.WriteLine(message);

                _Stopwatch.Start();
                _LastEndOfCycleTick = _Stopwatch.ElapsedTicks;

                _ShowSnowCounter = _InitShowSnowCounter;

                for (var i = 0; i < M.SoundFrameBuffer.Length; i++) M.SoundFrameBuffer[i] = 0;
                while (EnqueueAudio(M.SoundFrameBuffer) < 4) { }

                return;
            }

            if (DirectXNativeMethods.State == Emu7800DirectXState.Finalize)
            {
                if (_DirectInput != null)
                {
                    _DirectInput.Dispose();
                    _DirectInput = null;
                }
                CloseAudio();
                return;
            }
        }

        #region Input Handling

        void SetDirectInputHandlerForKeyboard()
        {
            _DirectInput.KeyboardChanged = OnKeyboardChanged;
        }

        void SetDirectInputHandlersForDevice(int deviceno)
        {
            switch (M.InputAdapter.GetController(deviceno))
            {
                case Controller.Joystick:
                case Controller.ProLineJoystick:
                case Controller.BoosterGrip:
                case Controller.Driving:
                    _DirectInput.JoystickChanged = OnJoystickChanged;
                    break;
                case Controller.Lightgun:
                    _DirectInput.MouseChanged = OnMouseChanged;
                    break;
                case Controller.Paddles:
                    if (_DirectInput.IsStelladaptor(deviceno))
                    {
                        _DirectInput.StelladaptorPaddleChanged = OnStelladaptorPaddleChanged;
                    }
                    else
                    {
                        _DirectInput.MousePaddleChanged = OnMousePaddleChanged;
                    }
                    break;
            }
        }

        void OnJoystickChanged(int deviceno, bool left, bool right, bool up, bool down, bool fire, bool fire2)
        {
            deviceno ^= (_JoysticksSwapped ? 1 : 0);
            RaiseInput(deviceno, HostInput.Left, left);
            RaiseInput(deviceno, HostInput.Right, right);
            RaiseInput(deviceno, HostInput.Up, up);
            RaiseInput(deviceno, HostInput.Down, down);
            RaiseInput(deviceno, HostInput.Fire, fire);
            RaiseInput(deviceno, HostInput.Fire2, fire2);
        }

        void OnMouseChanged(int dx, int dy, bool fire)
        {
            _MouseX += dx >> 2;
            _MouseY += dy >> 2;
            if (_MouseX < 0)
            {
                _MouseX = 0;
            }
            else if (_MouseX >= M.VisiblePitch)
            {
                _MouseX = M.VisiblePitch - 1;
            }
            if (_MouseY < 0)
            {
                _MouseY = 0;
            }
            else if (_MouseY >= M.Scanlines)
            {
                _MouseY = M.Scanlines - 1;
            }
            RaiseLightGunInput(M.VisiblePitch, _MouseX, _MouseY);
            RaiseInput(HostInput.Fire, fire);
        }

        void OnStelladaptorPaddleChanged(int paddleno, int val, bool fire)
        {
            paddleno ^= (_JoysticksSwapped ? 2 : 0);
            if (paddleno <= 1)
            {
                paddleno ^= (_LeftPaddlesSwapped ? 1 : 0);
            }
            else
            {
                paddleno ^= (_RightPaddlesSwapped ? 1 : 0);
            }
            RaisePaddleInput(paddleno, DirectInput.StelladaptorPaddleRange, val);
            RaiseInput(paddleno, HostInput.Fire, fire);
        }

        void OnMousePaddleChanged(int val, bool fire)
        {
            RaisePaddleInput(_DirectInput.MousePaddleRange, val);
            RaiseInput(HostInput.Fire, fire);
        }

        void OnKeyboardChanged(Key key, bool down)
        {
            HostInput hostInput;
            if (!_KeyBindings.TryGetValue(key, out hostInput)) return;

            switch (hostInput)
            {
                case HostInput.ShowFrameStats:
                    if (!down || !PostedMsg.Length.Equals(0)) break;
                    var rmTicks = 0.0;
                    var fdTicks = 0.0;
                    for (var i = 0; i < FRAME_SAMPLES; i++)
                    {
                        rmTicks += _RunMachineTicks[i];
                        fdTicks += _FrameDurationTicks[i];
                    }
                    rmTicks = rmTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
                    fdTicks = fdTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
                    PostedMsg = string.Format("{0:0.0} {1:0.0} {2:0.0} {3:0}", rmTicks, fdTicks - rmTicks, fdTicks, _UsedAudioBuffers);
                    break;
                case HostInput.LeftPaddleSwap:
                    if (!down) break;
                    _LeftPaddlesSwapped = !_LeftPaddlesSwapped;
                    PostedMsg = string.Format("Left Paddles {0}wapped", _LeftPaddlesSwapped ? "S" : "Uns");
                    break;
                case HostInput.GameControllerSwap:
                    if (!down) break;
                    _JoysticksSwapped = !_JoysticksSwapped;
                    PostedMsg = string.Format("Game Controllers {0}wapped", _JoysticksSwapped ? "S" : "Uns");
                    break;
                case HostInput.RightPaddleSwap:
                    if (!down) break;
                    _RightPaddlesSwapped = !_RightPaddlesSwapped;
                    PostedMsg = string.Format("Right Paddles {0}wapped", _RightPaddlesSwapped ? "S" : "Uns");
                    break;
                default:
                    RaiseInput(hostInput, down);
                    break;
            }
        }

        void ReadConfiguration()
        {
            NameValueCollection settings = null;
            try
            {
                settings = ConfigurationManager.GetSection("EMU7800/Settings") as NameValueCollection;
            }
            catch (ConfigurationErrorsException ex)
            {
                Trace.WriteLine(ex);
            }

            _UseWorkerThread = IsSettingTrue(settings, @"EMU7800.Host.DirectX.HostDirectX.UseSeparateWorkerThread", false);
            _NoPauseOnLostFocus = IsSettingTrue(settings, @"EMU7800.Host.DirectX.HostDirectX.NoPauseOnLostFocus", false);
            _InitShowSnowCounter = GetSettingInt(settings, @"EMU7800.Host.DirectX.HostDirectX.InitShowSnowCounter", 30);
        }

        static bool IsSettingTrue(NameValueCollection settings, string settingName, bool defaultValue)
        {
            return (settings != null) ? settings[settingName].Equals(bool.TrueString, StringComparison.OrdinalIgnoreCase) : defaultValue;
        }

        static int GetSettingInt(NameValueCollection settings, string settingName, int defaultValue)
        {
            var intVal = defaultValue;
            if (settings != null) int.TryParse(settings[settingName], out intVal);
            return intVal;
        }

        #endregion

        #region IDispose Members

        public void Dispose()
        {
            if (_DirectInput != null) _DirectInput.Dispose();
        }

        #endregion
    }
}