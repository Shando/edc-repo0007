

P A L E

Pete's Lynx Emulator


Ver: 3.2

Date: 29 June 2005

*** NEW ***

1. Lynx 128 Mode Working well, many thx to Russell for his input
2. More Status Displays - Memory map, CRTC, Sound etc.
3. Disk Image Converter
4. Partial 6845 Emulation
5. Settings saved to registry
6. Display presets 1x 2x etc.


Loading
=======

To load just normal basic or machine code programs use the LOAD
and MLOAD buttons, they actually type the LOAD"" at the prompt
so you don't have to type it in - cool.

If you need to load in a program (or binary file) directly
(for example as part of a multiple load program such as the demo
programs which already type the LOAD"" for you - use the small
buttons marked 'S' to the left of the main LOAD MLOAD buttons.


Keyboard
========

I left the keyboard mapping as per the original(ish),
in the future I'll probably put an option in to give a more
meaningful layout. Still to be done.


Sound
=====

Sound is probably the weakest part of the emu so far. I've messed
about with it a lot but due to the way the tope level stuff works
its a bit problematic. Next version should be a lot better.


AutoSpeed
=========

A first attempt at getting the thing to adjust
the emulation speed automatically even with all the
nonsense that windows throws at the timers :(

This needs more investigation, I'm not happy with
the core emulation engine really, not Marcel de Kogel's
code but the way I've wrapped it.

In particular you'll probably notice that the autospeed doesn't
do quite such a good job if you resize the main window
between the two extremes.
 

Instructions for loading Level 9 Adventures
===========================================


To load the level9 adventure:

Reset the Emulator (48k)
Click on LOAD BASIC
Choose 'ADVENT'
(It should load the first Welcome Screen)
Click on the 'S' MLOAD BINARY  (the little button)
Choose 'ADVENT2'
(this loads the adventure loader - you wont notice anything happening)
Click on LOAD LEVEL9
Choose 'ADVENT'
(it will automatically load the advent3, 4 & 5 files)

it should start running now, with the 'fix6845' it emulates the way
the screen shows the adventure code while its 'thinking' and
clears when its waiting for input.



Known issues
============

1. Inexact emulation of bank refreshing

2. Speed adjustment clunky

3. Sound support needs more work - still

4. Saving only works from the actual lynx SAVE"FILENAME" command
   saving BINARY data is not supported yet.

5. Fullscreen needs tweaking

6. 'Background Z80 Noise' missing -
   as soon as someone sends me a wav file :)
*UPDATE* I found a recording of genuine Lynx sounds
on one of my old tapes. This hopefully will get mixed in 
as a low level background a la 'Vector Dreams'.
7. 6845 registers not implemented (fully) (still) - no shaking ground in 'Air Raid'
*UPDATE* that ground is now shaking.  aaaarrrrgghhhhh!!!!!!!


Unknown Issues
=============

Any bug reports, hints, suggestions, will be gratefully received.

<plead>
If you use the tape reading program and get some
progs back then send me a copy of the TAP file.
This emulator was written without the
benefit of having a Lynx, with only Camsofts 'Power Blaster'
and the Level 9 'Dungeon Adventure', the DEMO
tape courtesy of Paul Robson's CamLynx and some 
homegrown stuff of my own off some very cruddy tapes (the
level 9 game seems to have picked up some wonderful
phrases in the read off the tape).

In order to test and improve this emulator I need MORE
software. Any help here would be much appreciated, go on
I've even included a tape reader and email is cheap :))
</plead>

*UPDATE*

Received with many thanks PENGO and ASSEMBLER
from Martyn Smith :)

C'mon you other guys, get me some software! An hour or so
spent by Recording some of your old tapes into Windows
will give me days of 'amusement' trying to get the programs to work.

Without any software I can't test the 6845 emulation :(

You can email me the raw recording if you want and I'll convert them
here.



Legal
=====

I've included the ROMs and software for this computer
because I can't think of anywhere else you'd get them
and to be honest I hope the people that originally wrote this
stuff are okay with it, any feedback from them is
welcome, if anybody has a problem with the stuff
being here then of course I'll apologise and remove it.

My special thanks to everyone concerned with bringing
us the Lynx, it's a strange micro but one which
enjoys a certain cult status in UK micro history.

And listing programs in it looks like 'tHe mAtRiX'  :)

BTW: If your name is Vince, you were living in mid Wales in
the 80's and you own(ed) a lynx 96 with disk drive... you
may very well have the only surviving copies of some
of my programs... Get in touch...

*UPDATE* 
I got in touch with Vince in the end, he's now living stateside
and has a very large motorbike. He's still into graphics though :)


Cheers,

Pete

heraclion@btopenworld.com


