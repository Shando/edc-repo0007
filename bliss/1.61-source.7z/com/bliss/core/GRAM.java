package com.bliss.core;

import java.io.IOException;

public class GRAM extends Memory
{
    public GRAM(int size, int location, int bitWidth) {
        image = new int[size];
        this.location = location;
        dirtyBytes = new boolean[size];
        this.bitWidth = bitWidth;
        this.trimmer = ((int)Math.pow(2, (double)bitWidth)) - 1;
    }

    public void save(SaveOutputStream os) throws IOException {
        for (int i = 0; i < image.length; i++)
            os.writeInt(image[i]);
    }

    public void load(LoadInputStream is) throws IOException {
        for (int i = 0; i < image.length; i++) {
            image[i] = is.readInt(0, trimmer);
            dirtyBytes[i] = true;
        }

        dirtyRAM = true;
    }

    public void reset() {
        dirtyRAM = true;
        for (int i = 0; i < image.length; i++) {
            image[i] = 0;
            dirtyBytes[i] = true;
        }
    }

    public int getLocation() {
        return location;
    }

    public int peek(int location) {
        return image[location-this.location];
    }

    public void poke(int location, int value) {
        value = (value & trimmer);
        if (image[location-this.location] != value) {
            image[location-this.location] = value;
            dirtyBytes[location-this.location] = true;
            dirtyRAM = true;
        }
    }

    public void markClean() {
        if (!dirtyRAM)
            return;

        for (int i = 0; i < dirtyBytes.length; i++)
            dirtyBytes[i] = false;
        dirtyRAM = false;
    }

    public boolean isDirty() {
        return dirtyRAM;
    }

    public boolean isDirty(int location) {
        return dirtyBytes[location-this.location];
    }

    public int getSize() {
        return image.length;
    }

    protected int[]     image;
    protected int       location;
    protected boolean[] dirtyBytes;
    protected boolean   dirtyRAM;
    protected int       bitWidth;
    protected int       trimmer;

}
