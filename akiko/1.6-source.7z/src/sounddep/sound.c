/*
 * UAE - The Un*x Amiga Emulator
 *
 * Win32 WaveOut and DirectSound interfaces
 *
 * Copyright 1997 Mathias Ortmann
 * Copyright 1997-2001 Brian King
 * Copyright 2000-2001 Bernd Roesch
 */
#include <windows.h>
#include <stdlib.h>
#include <stdarg.h>
#ifdef _MSC_VER
#include <mmsystem.h>
#else
#include "winstuff.h"
#endif
#include <stdio.h>

#include "sysconfig.h"
#include "sysdeps.h"

#include "config.h"
#include "options.h"
#include "threaddep/penguin.h"
#include "uae.h"
#include "gensound.h"
#include "sounddep/sound.h"
#include "events.h"
#include "memory.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "xwin.h"
#include "osdep/win32.h"
#include "gui.h"

static void RemoveAllNodes( void );
static LPWAVEHDR which_sound_buffer = NULL;

long calcsound = 0;

char *sndptr, *sndptrmax;

static WAVEFORMATEX wavfmt;

static HWAVEOUT hWaveOut = NULL;

static BOOL sound_stopped = FALSE;

static DWORD soundbufsize;

static int last_sound_setting;

static int sound_flushes  = 0;

// Synchronizing with wave output:
static int PendingWaveOutputs = 0;

#define PENDING_WAVE_OUTPUTS_WINDOW 2

static BOOL bPendingWaveOutputs = FALSE;
static HANDLE hPendingHandled   = INVALID_HANDLE_VALUE;

void close_sound (void)
{
    if( hWaveOut )
    {
	waveOutReset( hWaveOut );
	Sleep(1000); // Let all the WOM_DONE packets hit the callback
	RemoveAllNodes(); // Now we can actually remove all the completed packets
	waveOutClose( hWaveOut );
	hWaveOut = NULL;
	write_log( "WAVEOUT: closed\n" );
	bPendingWaveOutputs = FALSE;
	PendingWaveOutputs = 0;
    }
    cleanup_sound();
}

typedef struct _WAVEHDRNODE
{
    struct _WAVEHDRNODE *next;
    LPWAVEHDR lpWaveHdr;
} WAVEHDRNODE, *LPWAVEHDRNODE;

static LPWAVEHDRNODE lpWaveHdrList = NULL;
static LPWAVEHDRNODE lpWaveHdrTail = NULL;

static CRITICAL_SECTION csNodeList;

static void InsertNode( LPWAVEHDRNODE node )
{
    EnterCriticalSection( &csNodeList );
    if( !lpWaveHdrList )
    {
	lpWaveHdrList = node;
	lpWaveHdrTail = node;
    }
    else
    {
	lpWaveHdrTail->next = node;
	lpWaveHdrTail = node;
    }
    LeaveCriticalSection( &csNodeList );
}

static void RemoveAllNodes( void )
{
    LPWAVEHDRNODE lpNode = NULL;

    EnterCriticalSection( &csNodeList );
    lpNode = lpWaveHdrList;
    while( lpNode )
    {
	LPWAVEHDRNODE lpNext = NULL;
	waveOutUnprepareHeader( hWaveOut, lpNode->lpWaveHdr, sizeof( WAVEHDR ) );
	LocalFree( lpNode->lpWaveHdr->lpData );
	LocalFree( lpNode->lpWaveHdr );
	lpNext = lpNode->next;
	LocalFree( lpNode );
	lpNode = lpNext;
    }
    lpWaveHdrList = NULL;
    LeaveCriticalSection( &csNodeList );
}

void CALLBACK waveOutProc( HWAVEOUT hwo, UINT uMsg, DWORD dwInstance, DWORD dwParam1, DWORD dwParam2 )
{
    LPWAVEHDRNODE lpWaveHdrNode = NULL;
    switch( uMsg )
    {
	case WOM_DONE:
	    lpWaveHdrNode = (LPWAVEHDRNODE)LocalAlloc( LPTR, sizeof( WAVEHDRNODE ) );
	    if( lpWaveHdrNode )
	    {
		lpWaveHdrNode->lpWaveHdr = (LPWAVEHDR)dwParam1;
		InsertNode( lpWaveHdrNode );
		PendingWaveOutputs--;

		if( PendingWaveOutputs > currprefs.win32_sound_lag + PENDING_WAVE_OUTPUTS_WINDOW)
		{
		    bPendingWaveOutputs = TRUE;
		}
		else if( ( PendingWaveOutputs <= currprefs.win32_sound_lag ) && bPendingWaveOutputs )
		{
		    SetEvent( hPendingHandled );
		    bPendingWaveOutputs = FALSE;
		}

        }
	break;
	case WOM_OPEN:

	break;
	case WOM_CLOSE:

	break;
    }
}

static int FindAvailableWaveHdr( void )
{
    BOOL found = FALSE;
    MMRESULT result;
    LPWAVEHDR wavehdr = NULL;
    
    // If we've got some wave-headers in our list, lets just grab one of those
    EnterCriticalSection( &csNodeList );
    if( lpWaveHdrList )
    {
	LPWAVEHDRNODE lpWaveHdrNext = lpWaveHdrList->next;
	wavehdr = lpWaveHdrList->lpWaveHdr;
	LocalFree( lpWaveHdrList );
	lpWaveHdrList = lpWaveHdrNext;

	if( !lpWaveHdrList )
	{
	    lpWaveHdrTail = NULL;
	}

	waveOutUnprepareHeader( hWaveOut, wavehdr, sizeof( WAVEHDR ) );
    }
    else
    {
	// no wave-headers available, so we have to allocate one
	wavehdr = (LPWAVEHDR)LocalAlloc( LPTR, sizeof( WAVEHDR ) );
	wavehdr->lpData = LocalAlloc( LPTR, soundbufsize );
        wavehdr->dwBufferLength = soundbufsize;
    }
    LeaveCriticalSection( &csNodeList );

    wavehdr->dwFlags = 0;
    if( ( result = waveOutPrepareHeader( hWaveOut, wavehdr, sizeof( WAVEHDR ) ) ) != MMSYSERR_NOERROR )
    {
	write_log( "WAVEOUT: Failed to prepare waveOut header with error-code %d, hWaveOut = %p\n", result, hWaveOut );
    }

    // Our callback will enqueue the header when its done, and when we dequeue it, we'll free it
    return (int)wavehdr;
}

static void waveout_play( void )
{
    if( !sound_stopped )
    {
        PendingWaveOutputs++;
	if( waveOutWrite( hWaveOut, which_sound_buffer, sizeof( WAVEHDR ) ) != MMSYSERR_NOERROR )
	{
	    waveOutUnprepareHeader( hWaveOut, which_sound_buffer, sizeof( WAVEHDR ) );
	    LocalFree( which_sound_buffer->lpData );
	    LocalFree( which_sound_buffer );
	    write_log( "WAVEOUT: Failed to write to sound card\n" );
	}
        which_sound_buffer = (LPWAVEHDR)FindAvailableWaveHdr();
    }
    if( which_sound_buffer )
	sndptr = (char *)(which_sound_buffer->lpData);
    RemoveAllNodes();
    sndptrmax = sndptr + soundbufsize;
}

/* Use this to pause or stop Win32 sound output */
void pause_sound( int full_stop )
{
    if( currprefs.produce_sound > 1 )
    {
        if( full_stop )
        {
            last_sound_setting = currprefs.produce_sound;
            if( last_sound_setting > 1 )
                changed_prefs.produce_sound = 1;
            else
                changed_prefs.produce_sound = 0;
        }
	sound_stopped = TRUE;
    }
}

/* Use this to resume Win32 sound output */
void resume_sound( void )
{
    if( ( ( currprefs.produce_sound > 1 ) || ( last_sound_setting > 1 ) ) && sound_stopped && ( sound_flushes != 0 ) )
    {
        if( hWaveOut == NULL )
        {
            sound_flushes = 0; /* Because flush_sound_buffer() will increment this to 1 */
            if( last_sound_setting > 1 )
                changed_prefs.produce_sound = last_sound_setting;
        }
	sound_stopped = FALSE;
    }
}

void flush_sound_buffer( void )
{
    if( !sound_stopped )
    {
	sound_flushes++;
    }
    waveout_play();
}

static int init_sound_win32 (void)
{
    MMRESULT mmres;

    if( hWaveOut )
        return 0;

    if( currprefs.produce_sound < 1 ) 
    {
        write_log( "Sound output disabled.\n" );
        return 1;
    }

    wavfmt.cbSize = 0;
    wavfmt.wFormatTag = WAVE_FORMAT_PCM;
    wavfmt.nChannels = 1 + currprefs.stereo;
    wavfmt.nSamplesPerSec = currprefs.sound_freq + currprefs.win32_sound_speed_tweak; //?????JGI
    wavfmt.wBitsPerSample = currprefs.sound_bits;
    wavfmt.nBlockAlign = ( currprefs.sound_bits * wavfmt.nChannels ) / 8;
    wavfmt.nAvgBytesPerSec = wavfmt.nBlockAlign * currprefs.sound_freq;

    soundbufsize = ( SOUND_VALUE << currprefs.win32_sound_tweak ) * currprefs.sound_freq / 11025 * wavfmt.nBlockAlign;

    if( ( mmres = waveOutOpen( &hWaveOut, WAVE_MAPPER, &wavfmt, (DWORD)waveOutProc, 0, CALLBACK_FUNCTION ) ) )
    {
	TCHAR error[ MAX_PATH ];
#ifndef _WIN32_WCE
	char szMessage[ MAX_PATH ];
	WIN32GUI_LoadUIString( IDS_WAVEOUTOPENFAILURE, szMessage, MAX_PATH );
#endif
	waveOutGetErrorText( mmres, error, MAX_PATH - 1 );
	write_log( "WAVEOUT: %s.\n", error );
#ifdef _WIN32_WCE
	gui_message( error );
#else
	gui_message( szMessage );
#endif
	return 0;
    }
    if( hWaveOut == NULL )
	return 0;
    InitializeCriticalSection( &csNodeList );
    which_sound_buffer = (LPWAVEHDR)FindAvailableWaveHdr();
    sndptr = which_sound_buffer->lpData;
    sndptrmax = sndptr + soundbufsize;
    return currprefs.sound_freq;
}

static int rate;
static DWORD dwTimeSetEventHz = 0;
static DWORD sync_timer = 0;
static HANDLE hSyncEvent = NULL;
static UINT wTimerRes;

int init_sound (void)
{
    TIMECAPS tc;

    if( hSyncEvent = CreateEvent( NULL, FALSE, FALSE, NULL ) )
    {
        if( timeGetDevCaps( &tc, sizeof(TIMECAPS)) == TIMERR_NOERROR )
        {
            wTimerRes = min(max(tc.wPeriodMin, 1), tc.wPeriodMax);
            timeBeginPeriod(wTimerRes);
            dwTimeSetEventHz = vblank_hz;
            sync_timer = timeSetEvent( 1000 / vblank_hz + ( vblank_hz == 60 ? 1 : 0 ), 1, hSyncEvent, 0, TIME_PERIODIC | TIME_CALLBACK_EVENT_SET );
        }
    }

    if (currprefs.sound_bits == 16) {
	init_sound_table16 ();
	sample_handler = currprefs.stereo ? sample16s_handler : sample16_handler;
    } else {
	init_sound_table8 ();
	sample_handler = currprefs.stereo ? sample8s_handler : sample8_handler;
    }

    if ((rate = init_sound_win32 ()) < 2)
	return rate;

    scaled_sample_evtime = (unsigned long) maxhpos * maxvpos * vblank_hz * CYCLE_UNIT / rate;
    scaled_sample_evtime_ok = 1;
    write_log( "WaveOut driver found and configured for %d bits at %d Hz %s\n",
        currprefs.sound_bits, rate, currprefs.stereo ? "stereo" : "" );

    hPendingHandled = CreateEvent( NULL, FALSE, FALSE, NULL );

    return 1;
}

void update_sound (void)
{
    if( rate >= 11050 )
    {
        scaled_sample_evtime = (unsigned long) maxhpos * maxvpos * vblank_hz * CYCLE_UNIT / rate;
    }
    vsyncmintime = vsynctime;
    if( sync_timer && ( vblank_hz != dwTimeSetEventHz ) )
    {
	dwTimeSetEventHz = vblank_hz;
	timeKillEvent( sync_timer );

	sync_timer = timeSetEvent( 1000 / vblank_hz + ( vblank_hz == 60 ? 1 : 0 ), 1, hSyncEvent, 0, TIME_PERIODIC | TIME_CALLBACK_EVENT_SET );
    }
}     


int setup_sound (void)
{

    sound_available = 1;


    return 1;
}

static void cleanup_sound( void )
{
    if( sound_available )
    {
	if( sync_timer )
	{
	    timeKillEvent( sync_timer );
	    timeEndPeriod( wTimerRes );
	    sync_timer = 0;
	}
	if( hSyncEvent )
	{
	    CloseHandle( hSyncEvent );
	    hSyncEvent = NULL;
	}
	if( hPendingHandled )
	{
	    CloseHandle( hPendingHandled );
	    hPendingHandled = NULL;
	}
	if( sndptr ) // This pointer is only valid after we've actually initialized our critsec
	{
	    DeleteCriticalSection( &csNodeList );
	    sndptr = NULL;
	}
    }
}

void synchronize_timing( void )
{
    // We use rdtsc/QueryPerformanceCounter in "fastest possible" mode (m68k_speed == -1), 
    // so only use our hSyncEvent to do synchronization when not in this mode.
    if( sync_timer && ( currprefs.m68k_speed >= 0 ) )
    {
	// Synchronize to about 16 or 20ms
	WaitForSingleObject( hSyncEvent, INFINITE );
    }

    // If we're using sound to synchronize, wait for our waveOut packets to complete...
    if( currprefs.produce_sound >= 2 &&
	bPendingWaveOutputs &&
	currprefs.win32_sound_sync )
    {
	WaitForSingleObject( hPendingHandled, INFINITE );
    }
}
