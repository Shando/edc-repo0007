/*
 * HostSdl
 * 
 * An Sdl-based host
 * 
 * Copyright (c) 2004-2006 Mike Murphy
 * 
 */
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace EMU7800
{
	public class HostSdl : Host
	{
		const int WIDTH = 320, HEIGHT = 240;
		const bool FULLSCREEN = true;

		byte[] _FrameBuffer;
		byte[] _AudioBuffer;
		FontRenderer _FontRenderer;

		bool SdlJoysticksSwapped;

		int MouseX, MouseY;
		bool ShowMouseCursor;	// For lightgun emulation

		Dictionary<SdlKey, HostInput> _KeyBindings;

		Stopwatch _Stopwatch;
		const int FRAME_SAMPLES = 120;
		long _startOfCycleTick, _endOfCycleTick;
		long _frameBudgetTicks, _sleepableTicks;
		long _ticksPerMillisec = Stopwatch.Frequency / 1000;
		int[] _RunMachineTicks = new int[FRAME_SAMPLES];
		int[] _WaitTicks = new int[FRAME_SAMPLES];

		public static readonly HostSdl Instance = new HostSdl();
		private HostSdl()
		{
		}

		public override void Run(Machine m)
		{
			InitializeKeyBindings();
			InitializeInputSystem(m);

			try
			{
				Trace.Write("Simple DirectMedia Layer ");
				Trace.Write(SdlNativeMethods.Version);
				Trace.WriteLine(" detected");

				_FrameBuffer = new byte[M.VisiblePitch * M.Scanlines];
				_FontRenderer = new FontRenderer(_FrameBuffer, M.VisiblePitch, M.Palette, 0);

				SdlNativeMethods.Open(WIDTH, HEIGHT, FULLSCREEN, EMU7800App.Title);

				Run();
			}
			finally
			{
				SdlNativeMethods.Close();
				CloseAudio();

				Trace.WriteLine("SDL host shutdown");
			}
		}

		void Run()
		{
			SdlJoysticksSwapped = false;

			SdlNativeMethods.Keyboard += new SdlNativeMethods.KeyboardEventHandler(OnKeyboard);
			SdlNativeMethods.JoyButton += new SdlNativeMethods.JoyButtonEventHandler(OnJoyButton);
			SdlNativeMethods.JoyAxis += new SdlNativeMethods.JoyAxisEventHandler(OnJoyAxis);
			SdlNativeMethods.MouseButton += new SdlNativeMethods.MouseButtonEventHandler(OnMouseButton);
			SdlNativeMethods.MouseMotion += new SdlNativeMethods.MouseMotionEventHandler(OnMouseMotion);

			foreach (SdlJoystickDevice dev in SdlNativeMethods.Joysticks)
			{
				if (dev.Name != null && dev.Name.Contains("Stelladaptor"))
				{
					Trace.WriteLine("Stelladaptor detected: disabling mouse input");
					DeactivateMouseInput = true;
				}
			}

			ShowMouseCursor = M.InputAdapter.Controllers[0] == Controller.Lightgun;

			_Stopwatch = new Stopwatch();
			_frameBudgetTicks = Stopwatch.Frequency / M.FrameHZ;
			_sleepableTicks = _frameBudgetTicks - EMU7800App.Instance.Settings.CpuSpin * _ticksPerMillisec;
			_Stopwatch.Start();
			_endOfCycleTick = _Stopwatch.ElapsedTicks;

			while (!Ended && !M.MachineHalt)
			{
				_startOfCycleTick = _endOfCycleTick;

				SdlNativeMethods.PollAndDelegate();

				if (Paused)
				{
					for (int i = 0; i < _AudioBuffer.Length; i++)
					{
						_AudioBuffer[i] = 0;
					}
				}
				else
				{
					M.Run();
				}

				long endOfRunMachineTick = _Stopwatch.ElapsedTicks;

				int sleepTicks = (int)((_sleepableTicks - (endOfRunMachineTick - _startOfCycleTick)) / _ticksPerMillisec);
				if (sleepTicks > 0)
				{
					Thread.Sleep(sleepTicks);
				}

				PullFrame();

				while (EnqueueAudio(_AudioBuffer) == 1)
				{
				}

				_endOfCycleTick = _Stopwatch.ElapsedTicks;

				int statIndex = (int)M.FrameNumber % FRAME_SAMPLES;
				_RunMachineTicks[statIndex] = (int)(endOfRunMachineTick - _startOfCycleTick);
				_WaitTicks[statIndex] = (int)(_endOfCycleTick - endOfRunMachineTick);
			}
		}

		unsafe void PullFrame()
		{
			if (M.H.PostedMsg.Length > 0)
			{
				_FontRenderer.DrawText(M.H.PostedMsg, 2, M.H.ClipStart + 4, 10, 0);
			}

			SdlNativeMethods.Lock();
			uint* tptr = (uint*)SdlNativeMethods.Pixels.ToPointer();
			int si = ClipStart * M.VisiblePitch + LeftOffset;
			if (tptr != null)
			{
				uint* xptr = tptr;

				for (int i = 0; i < HEIGHT; i++)
				{
					while (si < 0)
					{
						si += _FrameBuffer.Length;
					}
					uint* yptr = xptr;
					for (int j = 0; j < M.VisiblePitch; j++)
					{
						while (si >= _FrameBuffer.Length)
						{
							si -= _FrameBuffer.Length;
						}
						uint pixel = (uint)M.Palette[_FrameBuffer[si++]];
						*yptr++ = pixel;
						if (M.VisiblePitch == (WIDTH >> 1))
						{
							*yptr++ = pixel;
						}
					}
					xptr += (SdlNativeMethods.Pitch >> 2);
				}

				if (ShowMouseCursor)
				{
					tptr[MouseY * WIDTH + MouseX] = 0xffffff;
				}
			}
			SdlNativeMethods.Unlock();
			//SdlNativeMethods.UpdateRect(0, 0, WIDTH, HEIGHT);
			SdlNativeMethods.Flip();
		}

		void OnJoyButton(int deviceno, int button, bool down)
		{
			InputAdapter ia = M.InputAdapter;
			int playerno = deviceno ^ (SdlJoysticksSwapped ? 1 : 0);

			if (Paused)
			{
			}
			else if (ia.Controllers[playerno] == Controller.Paddles)
			{
				if (DeactivateMouseInput && button <= 1)
				{
					// Map Stelladaptor joystick button events to paddle triggers when necessary
					button ^= (SdlNativeMethods.Joysticks[deviceno].PaddlesSwapped ? 1 : 0);
					playerno = (playerno << 1) | button;
					ia[playerno, ControllerAction.Trigger] = down;
				}
			}
			else if (button == EMU7800App.Instance.Settings.JoyBTrigger)
			{
				ia[playerno, ControllerAction.Trigger] = down;
			}
			else if (button == EMU7800App.Instance.Settings.JoyBBooster)
			{
				ia[playerno, ControllerAction.Trigger2] = down;
			}
		}

		void OnJoyAxis(int deviceno, int axis, int val)
		{
			InputAdapter ia = M.InputAdapter;
			int playerno = deviceno ^ (SdlJoysticksSwapped ? 1 : 0);

			if (Paused)
			{
			}
			else if (ia.Controllers[playerno] == Controller.Paddles)
			{
				if (DeactivateMouseInput && axis <= 1)
				{
					// Map Stelladaptor joystick axis events to paddle knobs when necessary
					axis ^= (SdlNativeMethods.Joysticks[deviceno].PaddlesSwapped ? 1 : 0);
					playerno = 2 * playerno + axis;
					RaisePaddleInput(playerno, 0xfeff, 0x8000 + val);
				}
			}
			else if (axis == 0)
			{
				RaiseInput(HostInput.Left, val < -8192);
				RaiseInput(HostInput.Right, val > 8192);
			}
			else if (axis == 1)
			{
				RaiseInput(HostInput.Up, val < -8192);
				RaiseInput(HostInput.Down, val > 8192);
			}
		}

		private void InitializeKeyBindings()
		{
			_KeyBindings = new Dictionary<SdlKey, HostInput>();
			_KeyBindings.Add(SdlKey.K_ESCAPE, HostInput.End);
			_KeyBindings.Add(SdlKey.K_LCTRL, HostInput.Fire);
			_KeyBindings.Add(SdlKey.K_RCTRL, HostInput.Fire);
			_KeyBindings.Add(SdlKey.K_LALT, HostInput.Fire2);
			_KeyBindings.Add(SdlKey.K_RALT, HostInput.Fire2);
			_KeyBindings.Add(SdlKey.K_LEFT, HostInput.Left);
			_KeyBindings.Add(SdlKey.K_UP, HostInput.Up);
			_KeyBindings.Add(SdlKey.K_RIGHT, HostInput.Right);
			_KeyBindings.Add(SdlKey.K_DOWN, HostInput.Down);
			_KeyBindings.Add(SdlKey.K_KP7, HostInput.NumPad7);
			_KeyBindings.Add(SdlKey.K_KP8, HostInput.NumPad8);
			_KeyBindings.Add(SdlKey.K_KP9, HostInput.NumPad9);
			_KeyBindings.Add(SdlKey.K_KP4, HostInput.NumPad4);
			_KeyBindings.Add(SdlKey.K_KP5, HostInput.NumPad5);
			_KeyBindings.Add(SdlKey.K_KP6, HostInput.NumPad6);
			_KeyBindings.Add(SdlKey.K_KP1, HostInput.NumPad1);
			_KeyBindings.Add(SdlKey.K_KP2, HostInput.NumPad2);
			_KeyBindings.Add(SdlKey.K_KP3, HostInput.NumPad3);
			_KeyBindings.Add(SdlKey.K_KP_MULTIPLY, HostInput.NumPadMult);
			_KeyBindings.Add(SdlKey.K_KP0, HostInput.NumPad0);
			_KeyBindings.Add(SdlKey.K_KP_DIVIDE, HostInput.NumPadDiv);
			_KeyBindings.Add(SdlKey.K_1, HostInput.LeftDifficulty);
			_KeyBindings.Add(SdlKey.K_2, HostInput.RightDifficulty);
			_KeyBindings.Add(SdlKey.K_F1, HostInput.SetKeyboardToPlayer1);
			_KeyBindings.Add(SdlKey.K_F2, HostInput.SetKeyboardToPlayer2);
			_KeyBindings.Add(SdlKey.K_F3, HostInput.SetKeyboardToPlayer3);
			_KeyBindings.Add(SdlKey.K_F4, HostInput.SetKeyboardToPlayer4);
			_KeyBindings.Add(SdlKey.K_F5, HostInput.PanLeft);
			_KeyBindings.Add(SdlKey.K_F6, HostInput.PanRight);
			_KeyBindings.Add(SdlKey.K_F7, HostInput.PanUp);
			_KeyBindings.Add(SdlKey.K_F8, HostInput.PanDown);
			_KeyBindings.Add(SdlKey.K_F11, HostInput.SaveMachine);
			_KeyBindings.Add(SdlKey.K_F12, HostInput.Unknown);
			_KeyBindings.Add(SdlKey.K_c, HostInput.Color);
			_KeyBindings.Add(SdlKey.K_f, HostInput.Unknown);
			_KeyBindings.Add(SdlKey.K_m, HostInput.Mute);
			_KeyBindings.Add(SdlKey.K_p, HostInput.Pause);
			_KeyBindings.Add(SdlKey.K_r, HostInput.Reset);
			_KeyBindings.Add(SdlKey.K_s, HostInput.Select);
			_KeyBindings.Add(SdlKey.K_q, HostInput.Unknown);
			_KeyBindings.Add(SdlKey.K_w, HostInput.Unknown);
			_KeyBindings.Add(SdlKey.K_e, HostInput.Unknown);
		}

		void OnKeyboard(int deviceno, bool down, int scancode, SdlKey key, SdlMod mod)
		{
			if (_KeyBindings.ContainsKey(key))
			{
				switch (key)
				{
					case SdlKey.K_f:
						if (down)
						{
							double rmTicks = 0.0, wTicks = 0.0;
							for (int i = 0; i < FRAME_SAMPLES; i++)
							{
								rmTicks += _RunMachineTicks[i];
								wTicks += _WaitTicks[i];
							}
							rmTicks = rmTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
							wTicks = wTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
							double fps = 1000.0 / (rmTicks + wTicks);
							M.H.PostedMsg = string.Format("{0}/{1} FPS {2:0.0}+{3:0.0}={4:0.0}/{5:0.0} ms", Math.Round(fps, 0), M.H.EffectiveFPS, rmTicks, wTicks, rmTicks + wTicks, 1000.0 / M.H.EffectiveFPS);
						}
						break;
					case SdlKey.K_q:
						if (down)
						{
							SwapPaddles(0);
						}
						break;
					case SdlKey.K_w:
						if (down)
						{
							SdlJoysticksSwapped = !SdlJoysticksSwapped;
							PostedMsg = String.Format("P1/P2 Game Controllrs {0}wapped", SdlJoysticksSwapped ? "S" : "Uns");
						}
						break;
					case SdlKey.K_e:
						if (down)
						{
							SwapPaddles(1);
						}
						break;
					case SdlKey.K_F12:
						if (down)
						{
							try
							{
								string fn = String.Format("screenshot {0:yyyy} {0:MM}-{0:dd} {0:HH}{0:mm}{0:ss}.bmp", DateTime.Now);
								string rmsg = SdlNativeMethods.SaveBMP(Path.Combine(EMU7800App.Instance.Settings.OutputDirectory, fn));
								Trace.Write("Screenshot taken: ");
								Trace.WriteLine(fn);
								M.H.PostedMsg = "Screenshot taken";
							}
							catch (Exception ex)
							{
								Trace.Write("Error while taking screenshot: ");
								Trace.WriteLine(ex.Message);
								M.H.PostedMsg = "Screenshot failed";
							}
						}
						break;
					default:
						M.H.RaiseInput(_KeyBindings[key], down);
						break;
				}
			}
			else
			{
				M.H.RaiseInput(HostInput.Unknown, down);
			}
		}

		void OnMouseButton(int deviceno, bool down, SdlMouseButton button, int x, int y)
		{
			if (Paused || DeactivateMouseInput)
			{
			}
			else
			{
				RaiseInput(HostInput.Fire, down);
			}
		}

		void OnMouseMotion(bool down, int x, int y, int xrel, int yrel)
		{
			// Record last known mouse position for drawing things
			// like possible mouse cursors
			MouseX = x;
			MouseY = y;

			if (!DeactivateMouseInput)
			{
				RaiseLightGunInput(WIDTH, x, y);
				RaisePaddleInput(WIDTH, MouseX);
			}
		}
 
		void SwapPaddles(int deviceno)
		{
			if (SdlNativeMethods.Joysticks[deviceno].Opened)
			{
				SdlNativeMethods.Joysticks[deviceno].PaddlesSwapped = !SdlNativeMethods.Joysticks[deviceno].PaddlesSwapped;
				PostedMsg = String.Format("P{0} Stelladptr Paddles {1}wapped",
					deviceno + 1, SdlNativeMethods.Joysticks[deviceno].PaddlesSwapped ? "A" : "Uns");
			}
		}

		public override void UpdateDisplay(byte[] buf, int scanline, int xstart, int len)
		{
			if (M.H.PostedMsg.Length > 0 && scanline <= M.H.ClipStart + 12)
			{
				// do not overwrite the rendered text of the posted message
			}
			else
			{
				int i = scanline*M.VisiblePitch + xstart;
				int x = xstart;
				while (len-- > 0)
				{
					if (i >= _FrameBuffer.Length)
					{
						i -= _FrameBuffer.Length;
					}
					_FrameBuffer[i++] = buf[x++];
				}
			}
		}

		public override void UpdateSound(byte[] buf)
		{
			if (Muted)
			{
				for (int i = 0; i < buf.Length; i++)
				{
					buf[i] = 0;
				}
			}
			_AudioBuffer = buf;
		}
	}
}