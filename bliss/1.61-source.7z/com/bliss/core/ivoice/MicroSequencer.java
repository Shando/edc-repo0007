package com.bliss.core.ivoice;

import java.io.*;
import com.bliss.core.*;
import com.bliss.core.devices.*;

/**
 * The microsequencer included in the Intellivoice.  Note that the entire
 * Intellivoice was a bitwise little-endian machine so you will notice the
 * effects of that throughout this code.
 *
 * @author Kyle Davis
 */
class MicroSequencer extends Processor
{

    MicroSequencer(LPC12 lpc12) {
        this.lpc12 = lpc12;
        lpc12.microSequencer = this;
        registers = new Registers();
        ivoiceROMImage = new int[0x800];
        ivoiceROM = new ROM(ivoiceROMImage, 0x1000);
    }

    public int getClockSpeed() {
        return 1600000;
    }

    public void reset() {
        currentBits = 0;
        bitsLeft = 0;
        isIdle = true;

        pc = 0;
        page = 1;
        stack = 0;
        mode = 0;
        repeatPrefix = 0;
        command = 0;
        lrqHigh = true;
        fifoHead = 0;
        fifoSize = 0;
        speaking = false;
    }

    public void save(SaveOutputStream sos) throws IOException {
        sos.writeInt(bitsLeft);
        sos.writeInt(currentBits);
        sos.writeInt(pc);
        sos.writeInt(mode);
        sos.writeInt(repeatPrefix);
        sos.writeInt(page);
        sos.writeInt(command);

        sos.writeBoolean(lrqHigh);
        sos.writeBoolean(speaking);
        sos.writeInt(fifoHead);
        sos.writeInt(fifoSize);
        for (int i = 0; i < fifoBytes.length; i++)
            sos.writeInt(fifoBytes[i]);
    }

    public void load(LoadInputStream lis) throws IOException {
        bitsLeft = lis.readInt(0, 31);
        currentBits = lis.readInt(0, Integer.MAX_VALUE);
        pc = lis.readInt(0, 0xFFFF);
        mode = lis.readInt(0, 3);
        repeatPrefix = lis.readInt(0, 3);
        page = lis.readInt(0, 0xF);
        command = lis.readInt(0, 0xFF);

        lrqHigh = lis.readBoolean();
        speaking = lis.readBoolean();
        fifoHead = lis.readInt(0, 63);
        fifoSize = lis.readInt(0, 64);
        for (int i = 0; i < fifoBytes.length; i++)
            fifoBytes[i] = lis.readInt(0, 0x3FF);
    }

    public int tick() {
//System.out.println("microsequencer running");

        if (!speaking) {
            speaking = true;
            pc = 0x1000 | (command << 1);
            bitsLeft = 0;
            command = 0;
            lrqHigh = true;
        }

        while (!isIdle) {
            int repeatBefore = repeatPrefix;
            decode();
            if (repeatBefore != 0)
                repeatPrefix = 0;
        }

        return 1;
    }

    private byte readDelta(int numBits) {
        int value = readBits(numBits);
        if ((value & (1 << (numBits - 1))) != 0)
            value |= -1 << numBits;
        return (byte)value;
    }

    private int readBits(int numBits) {
        return readBits(numBits, false);
    }

    private int readBits(int numBits, boolean reverseOrder) {
        while (bitsLeft < numBits) {
            if (pc < 0x1800) {
//System.out.println("peeking from ROM: " + Integer.toString(pc, 16));
                currentBits |= (ivoiceROM.peek(pc) << bitsLeft);
                bitsLeft += 8;
                pc = (pc+1) & 0xFFFF;
            }
            else if (pc == 0x1800 && fifoSize > 0) {
//System.out.println("reading from FIFO: " + Integer.toString(fifoHead, 16));
                currentBits |= (fifoBytes[fifoHead] << bitsLeft);
                fifoHead = (fifoHead+1) & 0x3F;
                fifoSize--;
                bitsLeft += 10;
            }
            else {
//System.out.println("ERROR! Read outside of bounds: " + Integer.toString(pc, 16));
                currentBits |= (0x03FF << bitsLeft);
                bitsLeft += 10;
                pc = (pc+1) & 0xFFFF;
            }

//System.out.println("current bits: " + Integer.toString(currentBits, 16));
        }

        int output = currentBits & bitMasks[numBits-1];
        if (reverseOrder)
            output = flipEndian(output, numBits);
        currentBits = currentBits >> numBits;
        bitsLeft -= numBits;
        return output;
    }

    private final void RTS() {
//System.out.println("RTS");
        if (stack == 0) {
            if (!lrqHigh) {
                pc = 0x1000 | (command << 1);
                bitsLeft = 0;
                command = 0;
                lrqHigh = true;
            }
            else {
                speaking = false;
                isIdle = true;
            }
        }
        else {
            pc = stack;
            stack = 0;
            bitsLeft = 0;
        }
    }

    private final void SETPAGE(int immed4) {
//System.out.println("SETPAGE: " + immed4);
        this.page = flipEndian(immed4, 4);
    }

    private final void LOADALL(int immed4) {
//System.out.println("LOADALL");
        lpc12.repeat = (repeatPrefix << 4) | immed4;
        if (lpc12.repeat == 0)
            return;

        lpc12.amplitude = readBits(8);
        lpc12.period = readBits(8);
        //lpc12.periodCounter = (lpc12.period == 0 ? 0x100 : lpc12.period);
        lpc12.b[0] = (byte)readBits(8);
        lpc12.f[0] = (byte)readBits(8);
        lpc12.b[1] = (byte)readBits(8);
        lpc12.f[1] = (byte)readBits(8);
        lpc12.b[2] = (byte)readBits(8);
        lpc12.f[2] = (byte)readBits(8);
        lpc12.b[3] = (byte)readBits(8);
        lpc12.f[3] = (byte)readBits(8);
        lpc12.b[4] = (byte)readBits(8);
        lpc12.f[4] = (byte)readBits(8);
        lpc12.b[5] = (byte)readBits(8);
        lpc12.f[5] = (byte)readBits(8);
        if ((mode & 0x01) == 0) {
            lpc12.amplitudeInterpolation = 0;
            lpc12.periodInterpolation = 0;
        }
        else {
            lpc12.amplitudeInterpolation = (byte)readBits(8);
            lpc12.periodInterpolation = (byte)readBits(8);
        }

        lpc12.isIdle = false;
        isIdle = true;
    }

    private final void LOAD_2(int immed4) {
//System.out.println("LOAD_2");
        lpc12.repeat = (repeatPrefix << 4) | immed4;
        if (lpc12.repeat == 0)
            return;

        lpc12.amplitude = (readBits(6) << 2) | (lpc12.amplitude & 0x03);
        lpc12.period = readBits(8);
        //lpc12.periodCounter = (lpc12.period == 0 ? 0x100 : lpc12.period);
        switch (mode) {
            case 0x0:
                lpc12.b[0] = (byte)((readBits(3) << 4) | (lpc12.b[0] & 0x0F));
                lpc12.f[0] = (byte)((readBits(5) << 3) | (lpc12.f[0] & 0x07));
                lpc12.b[1] = (byte)((readBits(3) << 4) | (lpc12.b[1] & 0x0F));
                lpc12.f[1] = (byte)((readBits(5) << 3) | (lpc12.f[1] & 0x07));
                lpc12.b[2] = (byte)((readBits(3) << 4) | (lpc12.b[2] & 0x0F));
                lpc12.f[2] = (byte)((readBits(5) << 3) | (lpc12.f[2] & 0x07));
                lpc12.b[3] = (byte)((readBits(4) << 3) | (lpc12.b[3] & 0x07));
                lpc12.f[3] = (byte)((readBits(6) << 2) | (lpc12.f[3] & 0x03));
                lpc12.b[4] = (byte)((readBits(7) << 1) | (lpc12.b[4] & 0x01));
                lpc12.f[4] = (byte)((readBits(6) << 2) | (lpc12.f[4] & 0x03));
                lpc12.b[5] = 0;
                lpc12.f[5] = 0;
                break;
            case 0x1:
                lpc12.b[0] = (byte)((readBits(3) << 4) | (lpc12.b[0] & 0x0F));
                lpc12.f[0] = (byte)((readBits(5) << 3) | (lpc12.f[0] & 0x07));
                lpc12.b[1] = (byte)((readBits(3) << 4) | (lpc12.b[1] & 0x0F));
                lpc12.f[1] = (byte)((readBits(5) << 3) | (lpc12.f[1] & 0x07));
                lpc12.b[2] = (byte)((readBits(3) << 4) | (lpc12.b[2] & 0x0F));
                lpc12.f[2] = (byte)((readBits(5) << 3) | (lpc12.f[2] & 0x07));
                lpc12.b[3] = (byte)((readBits(4) << 3) | (lpc12.b[3] & 0x07));
                lpc12.f[3] = (byte)((readBits(6) << 2) | (lpc12.f[3] & 0x03));
                lpc12.b[4] = (byte)((readBits(7) << 1) | (lpc12.b[4] & 0x01));
                lpc12.f[4] = (byte)((readBits(6) << 2) | (lpc12.f[4] & 0x03));
                lpc12.b[5] = (byte)readBits(8);
                lpc12.f[5] = (byte)readBits(8);
                break;
            case 0x2:
                lpc12.b[0] = (byte)((readBits(6) << 1) | (lpc12.b[0] & 0x01));
                lpc12.f[0] = (byte)((readBits(6) << 2) | (lpc12.f[0] & 0x03));
                lpc12.b[1] = (byte)((readBits(6) << 1) | (lpc12.b[1] & 0x01));
                lpc12.f[1] = (byte)((readBits(6) << 2) | (lpc12.f[1] & 0x03));
                lpc12.b[2] = (byte)((readBits(6) << 1) | (lpc12.b[2] & 0x01));
                lpc12.f[2] = (byte)((readBits(6) << 2) | (lpc12.f[2] & 0x03));
                lpc12.b[3] = (byte)((readBits(6) << 1) | (lpc12.b[3] & 0x01));
                lpc12.f[3] = (byte)((readBits(7) << 1) | (lpc12.f[3] & 0x01));
                lpc12.b[4] = (byte)readBits(8);
                lpc12.f[4] = (byte)readBits(8);
                lpc12.b[5] = 0;
                lpc12.f[5] = 0;
                break;
            case 0x3:
                lpc12.b[0] = (byte)((readBits(6) << 1) | (lpc12.b[0] & 0x01));
                lpc12.f[0] = (byte)((readBits(6) << 2) | (lpc12.f[0] & 0x03));
                lpc12.b[1] = (byte)((readBits(6) << 1) | (lpc12.b[1] & 0x01));
                lpc12.f[1] = (byte)((readBits(6) << 2) | (lpc12.f[1] & 0x03));
                lpc12.b[2] = (byte)((readBits(6) << 1) | (lpc12.b[2] & 0x01));
                lpc12.f[2] = (byte)((readBits(6) << 2) | (lpc12.f[2] & 0x03));
                lpc12.b[3] = (byte)((readBits(6) << 1) | (lpc12.b[3] & 0x01));
                lpc12.f[3] = (byte)((readBits(7) << 1) | (lpc12.f[3] & 0x01));
                lpc12.b[4] = (byte)readBits(8);
                lpc12.f[4] = (byte)readBits(8);
                lpc12.b[5] = (byte)readBits(8);
                lpc12.f[5] = (byte)readBits(8);
                break;
        }

        lpc12.amplitudeInterpolation = (byte)
                ((lpc12.amplitudeInterpolation & 0xE0) | (readBits(5)));
        lpc12.periodInterpolation = (byte)
                ((lpc12.periodInterpolation & 0xE0) | (readBits(5)));

        lpc12.isIdle = false;
        isIdle = true;
    }

    private final void SETMSB_3(int immed4) {
//System.out.println("SETMSB_3");
        lpc12.repeat = (repeatPrefix << 4) | immed4;
        if (lpc12.repeat == 0)
            return;

        lpc12.amplitude = (readBits(6) << 2) | (lpc12.amplitude & 0x03);
        if (mode == 0x00 || mode == 0x02) {
            lpc12.b[5] = 0;
            lpc12.f[5] = 0;
        }

        switch (mode) {
            case 0x0:
            case 0x1:
                lpc12.f[0] = (byte)((readBits(5) << 3) | (lpc12.f[0] & 0x07));
                lpc12.f[1] = (byte)((readBits(5) << 3) | (lpc12.f[1] & 0x07));
                lpc12.f[2] = (byte)((readBits(5) << 3) | (lpc12.f[2] & 0x07));
                break;
            case 0x2:
            case 0x3:
                lpc12.f[0] = (byte)((readBits(6) << 2) | (lpc12.f[0] & 0x03));
                lpc12.f[1] = (byte)((readBits(6) << 2) | (lpc12.f[1] & 0x03));
                lpc12.f[2] = (byte)((readBits(6) << 2) | (lpc12.f[2] & 0x03));
                break;
        }

        lpc12.amplitudeInterpolation = (byte)
                ((lpc12.amplitudeInterpolation & 0xE0) | (readBits(5)));
        lpc12.periodInterpolation = (byte)
                ((lpc12.periodInterpolation & 0xE0) | (readBits(5)));

        lpc12.isIdle = false;
        isIdle = true;
    }

    private final void LOAD_4(int immed4) {
//System.out.println("LOAD_4");
        lpc12.repeat = (repeatPrefix << 4) | immed4;
        if (lpc12.repeat == 0)
            return;

        lpc12.amplitude = (readBits(6) << 2) | (lpc12.amplitude & 0x03);
        lpc12.period = readBits(8);
        //lpc12.periodCounter = (lpc12.period == 0 ? 0x100 : lpc12.period);
        lpc12.b[0] = 0;
        lpc12.f[0] = 0;
        lpc12.b[1] = 0;
        lpc12.f[1] = 0;
        lpc12.b[2] = 0;
        lpc12.f[2] = 0;
        switch (mode) {
            case 0x0:
                lpc12.b[3] = (byte)((readBits(4) << 3) | (lpc12.b[3] & 0x07));
                lpc12.f[3] = (byte)((readBits(6) << 2) | (lpc12.f[3] & 0x03));
                lpc12.b[4] = (byte)((readBits(7) << 1) | (lpc12.b[4] & 0x01));
                lpc12.f[4] = (byte)((readBits(6) << 2) | (lpc12.f[4] & 0x03));
                lpc12.b[5] = 0;
                lpc12.f[5] = 0;
                break;
            case 0x1:
                lpc12.b[3] = (byte)((readBits(4) << 3) | (lpc12.b[3] & 0x07));
                lpc12.f[3] = (byte)((readBits(6) << 2) | (lpc12.f[3] & 0x03));
                lpc12.b[4] = (byte)((readBits(7) << 1) | (lpc12.b[4] & 0x01));
                lpc12.f[4] = (byte)((readBits(6) << 2) | (lpc12.f[4] & 0x03));
                lpc12.b[5] = (byte)readBits(8);
                lpc12.f[5] = (byte)readBits(8);
                break;
            case 0x2:
                lpc12.b[3] = (byte)((readBits(6) << 1) | (lpc12.b[3] & 0x01));
                lpc12.f[3] = (byte)((readBits(7) << 1) | (lpc12.f[3] & 0x01));
                lpc12.b[4] = (byte)readBits(8);
                lpc12.f[4] = (byte)readBits(8);
                lpc12.b[5] = 0;
                lpc12.f[5] = 0;
                break;
            case 0x3:
                lpc12.b[3] = (byte)((readBits(6) << 1) | (lpc12.b[3] & 0x01));
                lpc12.f[3] = (byte)((readBits(7) << 1) | (lpc12.f[3] & 0x01));
                lpc12.b[4] = (byte)readBits(8);
                lpc12.f[4] = (byte)readBits(8);
                lpc12.b[5] = (byte)readBits(8);
                lpc12.f[5] = (byte)readBits(8);
                break;
        }

        lpc12.amplitudeInterpolation = 0;
        lpc12.periodInterpolation = 0;

        lpc12.isIdle = false;
        isIdle = true;
    }

    private final void SETMSB_5(int immed4) {
//System.out.println("SETMSB_5");
        lpc12.repeat = (repeatPrefix << 4) | immed4;
        if (lpc12.repeat == 0)
            return;

        lpc12.amplitude = (readBits(6) << 2) | (lpc12.amplitude & 0x03);
        lpc12.period = readBits(8);
        //lpc12.periodCounter = (lpc12.period == 0 ? 0x100 : lpc12.period);
        if (mode == 0x00 || mode == 0x02) {
            lpc12.b[5] = 0;
            lpc12.f[5] = 0;
        }

        switch (mode) {
            case 0x0:
            case 0x1:
                lpc12.f[0] = (byte)((readBits(5) << 3) | (lpc12.f[0] & 0x07));
                lpc12.f[1] = (byte)((readBits(5) << 3) | (lpc12.f[1] & 0x07));
                lpc12.f[2] = (byte)((readBits(5) << 3) | (lpc12.f[2] & 0x07));
                break;
            case 0x2:
            case 0x3:
                lpc12.f[0] = (byte)((readBits(6) << 2) | (lpc12.f[0] & 0x03));
                lpc12.f[1] = (byte)((readBits(6) << 2) | (lpc12.f[1] & 0x03));
                lpc12.f[2] = (byte)((readBits(6) << 2) | (lpc12.f[2] & 0x03));
                break;
        }

        lpc12.isIdle = false;
        isIdle = true;
    }

    private final void SETMSB_6(int immed4) {
//System.out.println("SETMSB_6");
        lpc12.repeat = (repeatPrefix << 4) | immed4;
        if (lpc12.repeat == 0)
            return;

        lpc12.amplitude = (readBits(6) << 2) | (lpc12.amplitude & 0x03);
        if (mode == 0x00 || mode == 0x02) {
            lpc12.b[5] = 0;
            lpc12.f[5] = 0;
        }

        switch (mode) {
            case 0x0:
                lpc12.f[3] = (byte)((readBits(6) << 2) | (lpc12.f[3] & 0x03));
                lpc12.f[4] = (byte)((readBits(6) << 2) | (lpc12.f[4] & 0x03));
                lpc12.b[5] = 0;
                lpc12.f[5] = 0;
                break;
            case 0x1:
                lpc12.f[3] = (byte)((readBits(6) << 2) | (lpc12.f[3] & 0x03));
                lpc12.f[4] = (byte)((readBits(6) << 2) | (lpc12.f[4] & 0x03));
                lpc12.f[5] = (byte)readBits(8);
                break;
            case 0x2:
                lpc12.f[3] = (byte)((readBits(7) << 1) | (lpc12.f[3] & 0x01));
                lpc12.f[4] = (byte)readBits(8);
                lpc12.b[5] = 0;
                lpc12.f[5] = 0;
                break;
            case 0x3:
                lpc12.f[3] = (byte)((readBits(7) << 1) | (lpc12.f[3] & 0x01));
                lpc12.f[4] = (byte)readBits(8);
                lpc12.f[5] = (byte)readBits(8);
                break;
        }

        lpc12.isIdle = false;
        isIdle = true;
    }

    private final void JMP(int immed4) {
        pc = (page << 12) | (flipEndian(immed4, 4) << 8) | readBits(8, true);
        bitsLeft = 0;
//System.out.println("JMP: " + Integer.toString(pc, 16));
    }

    private final void SETMODE(int immed4) {
//System.out.println("SETMODE");
        immed4 = flipEndian(immed4, 4);
        mode = immed4 & 0x3;
        repeatPrefix = (immed4 & 0xC) >> 2;
//System.out.println("repeatPrefix: " + repeatPrefix);
    }

    private final void DELTA_9(int immed4) {
//System.out.println("DELTA_9 mode=" + mode);
        lpc12.repeat = (repeatPrefix << 4) | immed4;
        if (lpc12.repeat == 0)
            return;

        lpc12.amplitude = ((lpc12.amplitude | 0x10000) + (readDelta(4) << 2))
                & 0xFFFF;
        lpc12.period = ((lpc12.period | 0x10000) + readDelta(5)) & 0xFFFF;
        //lpc12.periodCounter = (lpc12.period == 0 ? 0x100 : lpc12.period);
//System.out.println("new period: " + lpc12.period);
        switch (mode) {
            case 0x0:
                lpc12.b[0] += readDelta(3) << 4;
                lpc12.f[0] += readDelta(3) << 3;
                lpc12.b[1] += readDelta(3) << 4;
                lpc12.f[1] += readDelta(3) << 3;
                lpc12.b[2] += readDelta(3) << 4;
                lpc12.f[2] += readDelta(3) << 3;
                lpc12.b[3] += readDelta(3) << 3;
                lpc12.f[3] += readDelta(4) << 2;
                lpc12.b[4] += readDelta(4) << 1;
                lpc12.f[4] += readDelta(4) << 2;
                break;
            case 0x1:
                lpc12.b[0] += readDelta(3) << 4;
                lpc12.f[0] += readDelta(3) << 3;
                lpc12.b[1] += readDelta(3) << 4;
                lpc12.f[1] += readDelta(3) << 3;
                lpc12.b[2] += readDelta(3) << 4;
                lpc12.f[2] += readDelta(3) << 3;
                lpc12.b[3] += readDelta(3) << 3;
                lpc12.f[3] += readDelta(4) << 2;
                lpc12.b[4] += readDelta(4) << 1;
                lpc12.f[4] += readDelta(4) << 2;
                lpc12.b[5] += readDelta(5);
                lpc12.f[5] += readDelta(5);
                break;
            case 0x2:
                lpc12.b[0] += readDelta(4) << 1;
                lpc12.f[0] += readDelta(4) << 2;
                lpc12.b[1] += readDelta(4) << 1;
                lpc12.f[1] += readDelta(4) << 2;
                lpc12.b[2] += readDelta(4) << 1;
                lpc12.f[2] += readDelta(4) << 2;
                lpc12.b[3] += readDelta(4) << 1;
                lpc12.f[3] += readDelta(5) << 1;
                lpc12.b[4] += readDelta(5);
                lpc12.f[4] += readDelta(5);
                break;
            case 0x3:
                lpc12.b[0] += readDelta(4) << 1;
                lpc12.f[0] += readDelta(4) << 2;
                lpc12.b[1] += readDelta(4) << 1;
                lpc12.f[1] += readDelta(4) << 2;
                lpc12.b[2] += readDelta(4) << 1;
                lpc12.f[2] += readDelta(4) << 2;
                lpc12.b[3] += readDelta(4) << 1;
                lpc12.f[3] += readDelta(5) << 1;
                lpc12.b[4] += readDelta(5);
                lpc12.f[4] += readDelta(5);
                lpc12.b[5] += readDelta(5);
                lpc12.f[5] += readDelta(5);
                break;
        }

        lpc12.isIdle = false;
        isIdle = true;
    }

    private final void SETMSB_A(int immed4) {
//System.out.println("SETMSB_A");
        lpc12.repeat = (repeatPrefix << 4) | immed4;
        if (lpc12.repeat == 0)
            return;

        lpc12.amplitude = (readBits(6) << 2) | (lpc12.amplitude & 0x03);
        switch (mode) {
            case 0x0:
            case 0x1:
                lpc12.f[0] = (byte)((readBits(5) << 3) | (lpc12.f[0] & 0x07));
                lpc12.f[1] = (byte)((readBits(5) << 3) | (lpc12.f[1] & 0x07));
                lpc12.f[2] = (byte)((readBits(5) << 3) | (lpc12.f[2] & 0x07));
                break;
            case 0x2:
            case 0x3:
                lpc12.f[0] = (byte)((readBits(6) << 2) | (lpc12.f[0] & 0x03));
                lpc12.f[1] = (byte)((readBits(6) << 2) | (lpc12.f[1] & 0x03));
                lpc12.f[2] = (byte)((readBits(6) << 2) | (lpc12.f[2] & 0x03));
                break;
        }

        lpc12.isIdle = false;
        isIdle = true;
    }

    private final void JSR(int immed4) {
        int newpc = (page << 12) | (flipEndian(immed4, 4) << 8) | readBits(8, true);
        stack = pc;
        pc = newpc;
        bitsLeft = 0;
//System.out.println("JSR: " + Integer.toString(pc, 16));
    }

    private final void LOAD_C(int immed4) {
//System.out.println(Integer.toString(pc, 16).toUpperCase() + ": LOAD_C mode=" + mode);
        lpc12.repeat = (repeatPrefix << 4) | immed4;
        if (lpc12.repeat == 0)
            return;

        lpc12.amplitude = (readBits(6) << 2) | (lpc12.amplitude & 0x03);
        lpc12.period = readBits(8);
        //lpc12.periodCounter = (lpc12.period == 0 ? 0x100 : lpc12.period);
//System.out.println("period: " + lpc12.period);
        switch (mode) {
            case 0x0:
                lpc12.b[0] = (byte)((readBits(3) << 4) | (lpc12.b[0] & 0x0F));
                lpc12.f[0] = (byte)((readBits(5) << 3) | (lpc12.f[0] & 0x07));
                lpc12.b[1] = (byte)((readBits(3) << 4) | (lpc12.b[1] & 0x0F));
                lpc12.f[1] = (byte)((readBits(5) << 3) | (lpc12.f[1] & 0x07));
                lpc12.b[2] = (byte)((readBits(3) << 4) | (lpc12.b[2] & 0x0F));
                lpc12.f[2] = (byte)((readBits(5) << 3) | (lpc12.f[2] & 0x07));
                lpc12.b[3] = (byte)((readBits(4) << 3) | (lpc12.b[3] & 0x07));
                lpc12.f[3] = (byte)((readBits(6) << 2) | (lpc12.f[3] & 0x03));
                lpc12.b[4] = (byte)((readBits(7) << 1) | (lpc12.b[4] & 0x01));
                lpc12.f[4] = (byte)((readBits(6) << 2) | (lpc12.f[4] & 0x03));
                lpc12.b[5] = 0;
                lpc12.f[5] = 0;
                break;
            case 0x1:
                lpc12.b[0] = (byte)((readBits(3) << 4) | (lpc12.b[0] & 0x0F));
                lpc12.f[0] = (byte)((readBits(5) << 3) | (lpc12.f[0] & 0x07));
                lpc12.b[1] = (byte)((readBits(3) << 4) | (lpc12.b[1] & 0x0F));
                lpc12.f[1] = (byte)((readBits(5) << 3) | (lpc12.f[1] & 0x07));
                lpc12.b[2] = (byte)((readBits(3) << 4) | (lpc12.b[2] & 0x0F));
                lpc12.f[2] = (byte)((readBits(5) << 3) | (lpc12.f[2] & 0x07));
                lpc12.b[3] = (byte)((readBits(4) << 3) | (lpc12.b[3] & 0x07));
                lpc12.f[3] = (byte)((readBits(6) << 2) | (lpc12.f[3] & 0x03));
                lpc12.b[4] = (byte)((readBits(7) << 1) | (lpc12.b[4] & 0x01));
                lpc12.f[4] = (byte)((readBits(6) << 2) | (lpc12.f[4] & 0x03));
                lpc12.b[5] = (byte)readBits(8);
                lpc12.f[5] = (byte)readBits(8);
                break;
            case 0x2:
                lpc12.b[0] = (byte)((readBits(6) << 1) | (lpc12.b[0] & 0x01));
                lpc12.f[0] = (byte)((readBits(6) << 2) | (lpc12.f[0] & 0x03));
                lpc12.b[1] = (byte)((readBits(6) << 1) | (lpc12.b[1] & 0x01));
                lpc12.f[1] = (byte)((readBits(6) << 2) | (lpc12.f[1] & 0x03));
                lpc12.b[2] = (byte)((readBits(6) << 1) | (lpc12.b[2] & 0x01));
                lpc12.f[2] = (byte)((readBits(6) << 2) | (lpc12.f[2] & 0x03));
                lpc12.b[3] = (byte)((readBits(6) << 1) | (lpc12.b[3] & 0x01));
                lpc12.f[3] = (byte)((readBits(7) << 1) | (lpc12.f[3] & 0x01));
                lpc12.b[4] = (byte)readBits(8);
                lpc12.f[4] = (byte)readBits(8);
                lpc12.b[5] = 0;
                lpc12.f[5] = 0;
                break;
            case 0x3:
                lpc12.b[0] = (byte)((readBits(6) << 1) | (lpc12.b[0] & 0x01));
                lpc12.f[0] = (byte)((readBits(6) << 2) | (lpc12.f[0] & 0x03));
                lpc12.b[1] = (byte)((readBits(6) << 1) | (lpc12.b[1] & 0x01));
                lpc12.f[1] = (byte)((readBits(6) << 2) | (lpc12.f[1] & 0x03));
                lpc12.b[2] = (byte)((readBits(6) << 1) | (lpc12.b[2] & 0x01));
                lpc12.f[2] = (byte)((readBits(6) << 2) | (lpc12.f[2] & 0x03));
                lpc12.b[3] = (byte)((readBits(6) << 1) | (lpc12.b[3] & 0x01));
                lpc12.f[3] = (byte)((readBits(7) << 1) | (lpc12.f[3] & 0x01));
                lpc12.b[4] = (byte)readBits(8);
                lpc12.f[4] = (byte)readBits(8);
                lpc12.b[5] = (byte)readBits(8);
                lpc12.f[5] = (byte)readBits(8);
                break;
        }

        lpc12.amplitudeInterpolation = 0;
        lpc12.periodInterpolation = 0;

        lpc12.isIdle = false;
        isIdle = true;
    }

    private final void DELTA_D(int immed4) {
//System.out.println("DELTA_D");
        lpc12.repeat = (repeatPrefix << 4) | immed4;
        if (lpc12.repeat == 0)
            return;

        lpc12.amplitude = ((lpc12.amplitude | 0x10000) + (readDelta(4) << 2))
                & 0xFFFF;
        lpc12.period = ((lpc12.period | 0x10000) + readDelta(5)) & 0xFFFF;
        //lpc12.periodCounter = (lpc12.period == 0 ? 0x100 : lpc12.period);
        switch (mode) {
            case 0x0:
                lpc12.b[3] += readDelta(3) << 3;
                lpc12.f[3] += readDelta(4) << 2;
                lpc12.b[4] += readDelta(4) << 1;
                lpc12.f[4] += readDelta(4) << 2;
                break;
            case 0x1:
                lpc12.b[3] += readDelta(3) << 3;
                lpc12.f[3] += readDelta(4) << 2;
                lpc12.b[4] += readDelta(4) << 1;
                lpc12.f[4] += readDelta(4) << 2;
                lpc12.b[5] += readDelta(5);
                lpc12.f[5] += readDelta(5);
                break;
            case 0x2:
                lpc12.b[3] += readDelta(4) << 1;
                lpc12.f[3] += readDelta(5) << 1;
                lpc12.b[4] += readDelta(5);
                lpc12.f[4] += readDelta(5);
                break;
            case 0x3:
                lpc12.b[3] += readDelta(4) << 1;
                lpc12.f[3] += readDelta(5) << 1;
                lpc12.b[4] += readDelta(5);
                lpc12.f[4] += readDelta(5);
                lpc12.b[5] += readDelta(5);
                lpc12.f[5] += readDelta(5);
                break;
        }

        lpc12.isIdle = false;
        isIdle = true;
    }

    private final void LOAD_E(int immed4) {
//System.out.println("LOAD_E");
        lpc12.repeat = (repeatPrefix << 4) | immed4;
        if (lpc12.repeat == 0)
            return;

        lpc12.amplitude = (readBits(6) << 2) | (lpc12.amplitude & 0x03);
        lpc12.period = readBits(8);
        //lpc12.periodCounter = (lpc12.period == 0 ? 0x100 : lpc12.period);
        
        lpc12.isIdle = false;
        isIdle = true;
    }

    private final void PAUSE(int immed4) {
//System.out.println("PAUSE");
        lpc12.repeat = (repeatPrefix << 4) | immed4;
        if (lpc12.repeat == 0)
            return;

        //clear everything
        lpc12.amplitude = 0;
        lpc12.period = 0;
        for (int j = 0; j < 6; j++) {
            lpc12.b[j] = 0;
            lpc12.f[j] = 0;
        }
        lpc12.amplitudeInterpolation = 0;
        lpc12.periodInterpolation = 0;

        lpc12.isIdle = false;
        isIdle = true;
    }

    private void decode() {
        int immed4 = readBits(4);
        int nextInstruction = readBits(4, true);
        switch (nextInstruction) {
            case 0x0:
                if (immed4 == 0)
                    RTS();
                else
                    SETPAGE(immed4);
                break;
            case 0x8:
                SETMODE(immed4);
                break;
            case 0x4:
                LOAD_4(immed4);
                break;
            case 0xC:
                LOAD_C(immed4);
                break;
            case 0x2:
                LOAD_2(immed4);
                break;
            case 0xA:
                SETMSB_A(immed4);
                break;
            case 0x6:
                SETMSB_6(immed4);
                break;
            case 0xE:
                LOAD_E(immed4);
                break;
            case 0x1:
                LOADALL(immed4);
                break;
            case 0x9:
                DELTA_9(immed4);
                break;
            case 0x5:
                SETMSB_5(immed4);
                break;
            case 0xD:
                DELTA_D(immed4);
                break;
            case 0x3:
                SETMSB_3(immed4);
                break;
            case 0xB:
                JSR(immed4);
                break;
            case 0x7:
                JMP(immed4);
                break;
            case 0xF:
                PAUSE(immed4);
                break;
        }
    }

    private final static int flipEndian(int value, int bits) {
//System.out.println("flip input: " + Integer.toString(value));
        int output = 0;
        int bitMask = 1;
        for (int i = 0; i < bits; i++) {
            int offset = (bits-1)-(i<<1);
            if (offset > 0)
                output |= (value & bitMask) << offset;
            else
                output |= (value & bitMask) >> -offset;
            bitMask = bitMask << 1;
        }
//System.out.println("flip output: " + Integer.toString(output));
        return output;
    }

    //counters for reading the byte-stream as a bit-stream
    private int bitsLeft;
    private int currentBits;

    //registers
    private int pc;
    private int stack;
    private int mode;
    private int repeatPrefix;
    private int page;
    private int command;

    private LPC12 lpc12;
    int[] ivoiceROMImage;
    private ROM   ivoiceROM;
    Registers     registers;
    private boolean lrqHigh;
    private boolean speaking;
    private int[] fifoBytes = new int[64];
    private int   fifoHead;
    private int   fifoSize;


    private final static int[] bitMasks = {
            0x0001, 0x0003, 0x0007, 0x000F, 0x001F, 0x003F, 0x007F, 0x00FF,
            0x01FF, 0x03FF, 0x07FF, 0x0FFF, 0x1FFF, 0x3FFF, 0x7FFF, 0xFFFF };

    private final static int FIFO_LOCATION = 0x1800;
    private final static int FIFO_SIZE     = 64;
    private final static int FIFO_END      = FIFO_LOCATION + FIFO_SIZE;

    private class Registers extends Memory
    {
        public int getSize() {
            return 2;
        }

        public int getLocation() {
            return 0x0080;
        }

        public void reset() {
        }

        public void save(SaveOutputStream sos) {}

        public void load(LoadInputStream lis) {}

        public void poke(int location, int value) {
            switch(location) {
                case 0x0080:
//System.out.println("poking to 0x0080: " + Integer.toString(value, 16));
                    if (lrqHigh) {
                        command = value & 0xFF;
                        lrqHigh = false;
                        if (!speaking)
                            isIdle = false;
                    }
                    break;
                case 0x0081:
                    if ((value & 0x0400) != 0)
                        reset();
                    else if (fifoSize < fifoBytes.length) {
                        fifoBytes[(fifoHead+fifoSize) & 0x3F] = value;
                        fifoSize++;
                    }
                    break;
            }
        }

        public int peek(int location) {
            switch(location) {
                case 0x0080:
                    return (lrqHigh ? 0x8000 : 0);
                case 0x0081:
                default:
                    return (fifoSize == fifoBytes.length ? 0x8000 : 0);
            }
        }
    }

}
