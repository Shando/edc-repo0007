/*
 * TokenList.cs
 *
 * Supporting class for executable command lines.
 *
 * Copyright (c) 2003 Mike Murphy
 *
 */
using System;
using System.Collections;
using System.Globalization;
using System.Text;

namespace EMU7800 {

public struct Token {
	public string Symbol;
	public int Number;
	public bool IsNumber;
	public bool EOL;
}

public class TokenList {
	private Queue TokenQ;

	public Token GetNextToken() {
		Token tok = new Token();

		if (TokenQ.Count > 0) {
			tok = (Token)TokenQ.Dequeue();
		} else {
			tok.EOL = true;
		}
		return tok;
	}

	public Token LookAhead {
		get {
			Token tok = new Token();
			if (TokenQ.Count > 0) {
				tok = (Token)TokenQ.Peek();
			} else {
				tok.EOL = true;
			}
			return tok;
		}
	}

	public bool Empty {
		get {
			return TokenQ.Count == 0;
		}
	}

	public TokenList(String commandLine) {
		string[] toks = commandLine.ToLower().Split();

		TokenQ = new Queue();

		foreach (string tok in toks) {
			if (tok.Length == 0) {
				continue;
			}

			Token token = new Token();
			
			token.Symbol = tok;
			token.IsNumber = false;

			if (tok.Substring(0, 1) == "$") {
				try {					token.Number = Int32.Parse(						tok.Substring(1),						NumberStyles.HexNumber);					token.IsNumber = true;				} catch {}			} else if (tok.Length >= 2 && tok.Substring(0, 2) == "0x") {				try {					token.Number = Int32.Parse(						tok.Substring(2),						NumberStyles.HexNumber);					token.IsNumber = true;				} catch {}			} else {
				try {					token.Number = Int32.Parse(						tok,						NumberStyles.Number);					token.IsNumber = true;				} catch {}
			}
			TokenQ.Enqueue(token);
		}
	}
}

}
