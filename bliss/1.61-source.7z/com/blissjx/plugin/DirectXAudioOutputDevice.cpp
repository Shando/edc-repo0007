
#include <iostream>
#include "DirectXAudioOutputDevice.h"
#include "DirectXVideoOutputDevice.h"

using namespace std;

extern DirectXVideoOutputDevice* currentDevice;


const CHAR* audioErrorMessages[6] = {
    "Failed to create DirectSound object",
    "Failed to create the primary audio buffer",
	"Failed to create the secondary audio buffer",
    "Unable to play the primary audio buffer",
    "Unable to play the secondary audio buffer",
	"Unable to set the cooperative level"
};


const CHAR* DirectXAudioOutputDevice::getErrorDescription(INT32 errorCode)
{
    return audioErrorMessages[errorCode-1];
}


DirectXAudioOutputDevice::DirectXAudioOutputDevice()
{
    dsound = NULL;
    primarySoundBuffer = NULL;
    secondarySoundBuffer = NULL;
}

DirectXAudioOutputDevice::~DirectXAudioOutputDevice()
{
	release();

	if(secondarySoundBuffer) {
		secondarySoundBuffer->Release();
		secondarySoundBuffer = NULL;
	}
	if(primarySoundBuffer) {
		primarySoundBuffer->Release();
		primarySoundBuffer = NULL;
	}
	if(dsound) {
		dsound->Release();
		dsound = NULL;
	}
}

INT32 DirectXAudioOutputDevice::init() {
    if (FAILED(DirectSoundCreate8(&DSDEVID_DefaultPlayback, &dsound, NULL))) {
        return ERR_UNABLE_TO_CREATE_AUDIO;
    }

    if (FAILED(dsound->SetCooperativeLevel(currentDevice->m_hWnd,
            DSSCL_NORMAL)))
    {
        return ERR_UNABLE_TO_SETCOOPLEVEL;
    }

    DSBUFFERDESC bufferDesc;
    bufferDesc.dwSize = sizeof(DSBUFFERDESC);
    bufferDesc.dwFlags = DSBCAPS_PRIMARYBUFFER;
    bufferDesc.dwBufferBytes = 0;
    bufferDesc.dwReserved = 0;
    bufferDesc.lpwfxFormat = NULL;
    bufferDesc.guid3DAlgorithm = GUID_NULL;
    if (FAILED(dsound->CreateSoundBuffer(&bufferDesc, &primarySoundBuffer,
            NULL)))
    {
        return ERR_UNABLE_TO_CREATE_PRIMARY_BUFFER;
    }

    WAVEFORMATEX wfx;
    wfx.wFormatTag = WAVE_FORMAT_PCM;
    wfx.nChannels = 1;
    wfx.nSamplesPerSec = 22050;
    wfx.wBitsPerSample = 16;
    wfx.nBlockAlign = (wfx.nChannels * wfx.wBitsPerSample)/8;
    wfx.nAvgBytesPerSec = wfx.nSamplesPerSec * wfx.nBlockAlign;
    wfx.cbSize = 0;

    bufferDesc.dwFlags = DSBCAPS_GLOBALFOCUS;
    bufferDesc.dwBufferBytes = 8820;
    bufferDesc.dwReserved = 0;
    bufferDesc.lpwfxFormat = &wfx;
    bufferDesc.guid3DAlgorithm = GUID_NULL;
    if (FAILED(dsound->CreateSoundBuffer(&bufferDesc, &secondarySoundBuffer,
            NULL)))
    {
        return ERR_UNABLE_TO_CREATE_SECONDARY_BUFFER;
    }


	// Clear out buffers to prevent noise at startup
	//
	LPVOID  pvAudioPtr1, pvAudioPtr2 = NULL;
	DWORD dwAudioBytes1, dwAudioBytes2 = 0;
	HRESULT rCode;

	rCode = secondarySoundBuffer->Lock(
		0,						// DWORD dwOffset, 
		8820,						// DWORD dwBytes, 
		&pvAudioPtr1, 
		&dwAudioBytes1, 
		&pvAudioPtr2, 
		&dwAudioBytes2, 
		DSBLOCK_ENTIREBUFFER 
		);

	memset(pvAudioPtr1, 0, dwAudioBytes1);

	rCode = secondarySoundBuffer->Unlock(
		pvAudioPtr1, 
		dwAudioBytes1, 
		pvAudioPtr2, 
		dwAudioBytes2 
		);

    if (FAILED(primarySoundBuffer->Play(0, 0, DSBPLAY_LOOPING))) {
        return ERR_UNABLE_TO_PLAY_PRIMARY_BUFFER;
    }

    if (FAILED(secondarySoundBuffer->Play(0, 0, DSBPLAY_LOOPING))) {
        return ERR_UNABLE_TO_PLAY_SECONDARY_BUFFER;
    }

    return 0;
}

INT32 DirectXAudioOutputDevice::getSampleRate() {
    return 22050;
}

UINT8 samples[4410];
UINT32 sampleCount = 0;
UINT32 writePosition = 0;

void DirectXAudioOutputDevice::playSample(INT32 sample) {
    //THIS IS TEMPORARY...
    sample >>= 1;

    samples[sampleCount] = (UINT8)(sample & 0x00FF);
    samples[sampleCount+1] = (UINT8)(((sample & 0x80000000) >> 24) |
            ((sample & 0xFF00) >> 8));
    sampleCount += 2;

    if (sampleCount < 4410)
        return;

    sampleCount = 0;

    DWORD playCursor;
    DWORD writeCursor;
    do {
        if (FAILED(secondarySoundBuffer->GetCurrentPosition(&playCursor,
                &writeCursor)))
        { 
            return;
        }
    }
    while ((playCursor >= writePosition && playCursor <= writePosition+4410) ||
            (writeCursor >= writePosition && writeCursor <= writePosition+4410));

    VOID* ptr1;
    VOID* ptr2;
    DWORD size1;
    DWORD size2;
    if (FAILED(secondarySoundBuffer->Lock(writePosition, 4410,
            &ptr1, &size1, &ptr2, &size2, 0)))
    {
        if (FAILED(secondarySoundBuffer->Restore()))
            return;

        if (FAILED(secondarySoundBuffer->Lock(writePosition, 4410,
                &ptr1, &size1, &ptr2, &size2, 0)))
        {
            return;
        }
    }
    memcpy(ptr1, samples, size1);
    if (4410-size1 > 0)
        memcpy(ptr2, samples+size1, 4410-size1);

    secondarySoundBuffer->Unlock(ptr1, size1, ptr2, 4410-size1);

    if (writePosition == 0)
        writePosition = 4410;
    else
        writePosition = 0;
}

void DirectXAudioOutputDevice::release()
{
    if (secondarySoundBuffer != NULL) {
        secondarySoundBuffer->Stop();
        secondarySoundBuffer->Release();
        secondarySoundBuffer = NULL;
    }
    if (primarySoundBuffer != NULL) {
        primarySoundBuffer->Stop();
        primarySoundBuffer->Release();
        primarySoundBuffer = NULL;
    }
    if (dsound != NULL) {
        dsound->Release();
        dsound = NULL;
    }
}

