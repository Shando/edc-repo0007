/*
 * DXHost
 *
 * An [almost] all DirectX-based host.  
 *
 * Copyright (c) 2003 Mike Murphy
 *
 *
 */

using System;
using System.Drawing;
using System.Windows.Forms;

using Microsoft.DirectX;
using Microsoft.DirectX.DirectDraw;

namespace EMU7800 {

public class DXHost : GDIDXHost {
	protected Microsoft.DirectX.DirectDraw.Device DisplayDevice;
        protected Microsoft.DirectX.DirectDraw.Surface FrontSurface;
        protected Microsoft.DirectX.DirectDraw.Surface BackSurface;
        protected Microsoft.DirectX.DirectDraw.Clipper Clipper;
	protected bool DisplayNeedRestore;

	protected override void InitDisplay() {
		Log.Msg("Initializing DirectX DirectDraw...");

		FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;

		DisplayNeedRestore = false;

		DisplayDevice = new Microsoft.DirectX.DirectDraw.Device();
		DisplayDevice.SetCooperativeLevel(this,	Microsoft.DirectX
			.DirectDraw.CooperativeLevelFlags.FullscreenExclusive);
		DisplayDevice.SetDisplayMode(640, 480, 32, 0, false);

		SurfaceDescription desc = new SurfaceDescription();
		desc.SurfaceCaps.Flip = true;
		desc.SurfaceCaps.Complex = true;
		desc.SurfaceCaps.PrimarySurface = true;
		desc.BackBufferCount = 1;
            
		DeviceIdentifier di = DisplayDevice.GetDeviceInformation(GetDeviceFlags.Default);
	    	               
		FrontSurface = new Surface(desc, DisplayDevice);
		SurfaceCaps caps = new SurfaceCaps();
		caps.BackBuffer = true;
		BackSurface = FrontSurface.GetAttachedSurface(caps); 
		BackSurface.ColorFill(Color.Black);
        
		Clipper = new Clipper(DisplayDevice);
		Clipper.Window = this;
		FrontSurface.Clipper = Clipper;

		Log.Msg("done\n{0}\n", di);

		KeyDown += new KeyEventHandler(OnKeyDown);
		KeyUp   += new KeyEventHandler(OnKeyUp);
		KeyPreview = true;
	}

	protected override bool SurfacesOK() {
		if (!DisplayDevice.TestCooperativeLevel()) {
			DisplayNeedRestore = true;
			return false;
		}
		if (DisplayNeedRestore) {
			DisplayDevice.RestoreAllSurfaces();
			DisplayNeedRestore = false;
			RefreshDisplay();
		}
		return true;
	}

	protected override void ShowTextMsg() {
		BackSurface.ForeColor = Color.White;
		BackSurface.DrawText(0, 0, TextMsg, false);
	}

	protected override void ClearTextMsg() {
		BackSurface.ColorFill(new Rectangle(0, 0, 200, 20), Color.Black);
	}

	protected override void FlipFrame() {
		FrontSurface.Draw(BackSurface, DrawFlags.Wait);
	}

	protected override void RefreshDisplay() {
		BackSurface.ColorFill(Color.Black);
		FlipFrame();
		M.DrawEntireFrame = true;
	}

	public override void UpdateRect(DisplRect r) {
		// Perform some clipping on the left and right sides of the display
		// (Not sure why the Clipper doesn't do this)
		if (r.X > 639 || r.Right < 0) {
			return;
		}
		if (r.X < 0) {
			r.Width += r.X;
			r.X = 0;
		}
		if (r.Right > 639) {
			r.Width -= r.Right - 639;
		}
		if (r.Width <= 0) {
			return;
		}

		BackSurface.ColorFill(r.Rectangle, Color.FromArgb(r.Argb));
	}
}
}
