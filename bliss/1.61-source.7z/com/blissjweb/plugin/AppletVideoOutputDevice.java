package com.blissjweb.plugin;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.*;
import java.text.*;
import com.bliss.core.devices.*;
import com.bliss.core.*;
import com.bliss.core.cartridge.*;

public class AppletVideoOutputDevice implements VideoOutputDevice
{

    public Option[] getOptions() {
        return Option.EMPTY_CONTROLLER_ARRAY;
    }

    public AppletVideoOutputDevice(Component c) {
        this.component = c;
    }

    public void init(byte[] imageBank) {
        Dimension d = component.getSize();
        width = d.width;
        height = d.height;
        background = component.getBackground();
        g = component.getGraphics();
        
        source = new MemoryImageSource(320, 192, AY38900.COLOR_MODEL,
                imageBank, 0, 320);
        source.setAnimated(true);
        image = component.createImage(source);
    }

    public void displayImage(byte[] imageData, boolean imageChanged) {
        if (imageChanged) {
            source.newPixels(0, 0, 320, 192);
            g.drawImage(image, 0, 0, width, height, background, null);
        }
    }

    public void release() {
        g.dispose();
        g = null;
    }

    private Component component;
    private int width;
    private int height;
    private Color background;
    private MemoryImageSource source;
    private Image image;
    private Graphics g;

}
