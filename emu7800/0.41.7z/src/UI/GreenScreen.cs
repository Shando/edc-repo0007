/*
 * GreenScreen.cs
 * 
 * A TabPage that provides a command line interface.
 * 
 * Copyright (c) 2003, 2004 Mike Murphy
 * 
 */

using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace EMU7800 {

public class GreenScreenPage : TabPage {
	private ControlPanelForm ControlPanelForm;

	private Label label1, label2;
	private TextBox outBox;
	private TextBox inpBox;

	public GreenScreenPage(ControlPanelForm f) {
		ControlPanelForm = f;
	
		Text = "Console";

		label2 = new Label();
		label2.Text = "Command-line Input";

		inpBox = new TextBox();
		inpBox.Text ="";
		inpBox.BackColor = System.Drawing.SystemColors.ControlText;
		inpBox.ForeColor = Color.Lime;
		inpBox.Font = new Font("Courier New", 10F,
			FontStyle.Regular, GraphicsUnit.Point, ((System.Byte)(0))); 
		inpBox.Multiline = false;
		inpBox.AcceptsReturn = true;
		inpBox.AcceptsTab = true;
		inpBox.KeyPress += new KeyPressEventHandler(OnKeyPress);
		inpBox.TextChanged += new EventHandler(OnTextChanged);
		inpBox.TabStop = true;
		inpBox.TabIndex = 0;

		label1 = new Label();
		label1.Text = "Output Message Log";
		
		outBox = new TextBox();
		outBox.Text = "";
		outBox.Multiline = true;
		outBox.ScrollBars = ScrollBars.Both;
		outBox.ReadOnly = true;
		outBox.AcceptsTab = false;
		outBox.WordWrap = false;
		outBox.BackColor = System.Drawing.SystemColors.ControlText;
		outBox.ForeColor = Color.Lime;
		outBox.Font = inpBox.Font;
		outBox.TabStop = false;
				
		Controls.AddRange(new Control[] {label1, outBox, label2, inpBox});

		Layout += new LayoutEventHandler(OnLayout);
		VisibleChanged += new EventHandler(OnVisibleChanged);
		Log.LogUpdated += new LogUpdatedHandler(OnLogUpdated);
	}

	private void OnVisibleChanged(Object sender, EventArgs e) {
		if (Log.LoggerStarted == false) {
			Log.LoggerStarted = true;
		}
		if (outBox.Visible) {
			outBox.AppendText(Log.GetMsgs());
		}		
		inpBox.Text = null;
		inpBox.Focus();
	}

	private void OnLogUpdated() {
		if (outBox.Visible) {
			outBox.AppendText(Log.GetMsgs());
		}
	}

	private void OnLayout(Object sender, LayoutEventArgs e) {
		int w = Size.Width - 30;

		label1.Location = new Point(15, 10);
		label1.Size = new Size(w, label1.PreferredHeight);

		outBox.Location = new Point(15,
			label1.Location.Y + label1.Size.Height + 2);
		outBox.Size = new Size(w, Size.Height - 90);

		label2.Location = new Point(15,
			outBox.Location.Y + outBox.Size.Height + 5);
		label2.Size = new Size(w, label2.PreferredHeight);

		inpBox.Location = new Point(15,
			label2.Location.Y + label2.Size.Height + 2);
		inpBox.Size = new Size(w, 35);
	}
	
	private void OnKeyPress(Object sender, KeyPressEventArgs e) {
		if (e.KeyChar == (char)13) {
         		e.Handled = true;
			IssueInpBoxCommand();
   		}
	}

	private void OnTextChanged(Object sender, EventArgs e) {
	}

	private void IssueInpBoxCommand() {
		string commandline = inpBox.Text;
		inpBox.Text = "";
		Log.Msg(">{0}\n", commandline);
		ExecuteCommandLine(new CommandLine(commandline));
		inpBox.Focus();
	}

	private void ExecuteCommandLine(CommandLine cl) {		bool recog = false;		RecordPlaybackInputAdapter ria;		GameSettings gs;		if (ControlPanelForm.M != null) {			if (ControlPanelForm.M.ExecuteCommandLine(cl)) {				recog = true;			}		}		switch (cl.Verb) {
		case "clear":
			outBox.Clear();
			Log.Msg("log cleared\n");
			break;
		case "gs":
			Log.Msg(ControlPanelForm.CurrGameSettings.ToString() + "\n");
			break;
		case "outdir":
			Log.Msg("outdir:\n{0}\n", Globals.OutputDirectory);
			break;
		case "ls":
			Log.Msg("Files in outdir:\n");
                        FileInfo[] files;
			try {
				files = new DirectoryInfo(Globals.OutputDirectory).GetFiles();
			} catch (DirectoryNotFoundException) {
				Log.Msg("Directory {0} does not exist\n", Globals.OutputDirectory);
				break;
			}
			foreach (FileInfo fi in files) {
				Log.Msg("{0} {1}k\n", fi.Name.PadRight(25, ' '),
					fi.Length/1024);
			}
			break;
		case "rec":
			if (!cl.CheckParms("s")) {
				Log.Msg("need filename\n");
				break;
			}
			if (ControlPanelForm.CurrGameSettings == null) {
				Log.Msg("no game selected\n");
				break;
			}
			ria = new RecordPlaybackInputAdapter(
				cl.Parms[0].StrValue,
				ControlPanelForm.CurrGameSettings.SaveKey);
			ControlPanelForm.IA = ria;
			ControlPanelForm.RunMachine();
			ria.StopRecording();
			break;
		case "pb":
			if (!cl.CheckParms("s")) {
				Log.Msg("need filename\n");
				break;
			}
			ria = new RecordPlaybackInputAdapter(cl.Parms[0].StrValue);
			if (ria.PlaybackSaveKey == null) {
				Log.Msg("error starting playback\n");
				break;
			}
			gs = GameSettings.New(ria.PlaybackSaveKey);
			if (gs == null || !gs.ROMFound) {
				Log.Msg("rom not found in current rom directory\n");
				break;
			}
			ControlPanelForm.IA = ria;
			ControlPanelForm.CurrGameSettings = gs;
			ControlPanelForm.RunMachine();
			ria.StopPlayback();
			break;
		case "stop":
			InputAdapter ia = ControlPanelForm.IA;
			try {
				((RecordPlaybackInputAdapter)ia).StopRecording();
				((RecordPlaybackInputAdapter)ia).StopPlayback();
				Log.Msg("stopped\n");
			} catch {
				Log.Msg("no recording or playback in effect\n");
			}
			break;
		case "run":
			if (cl.Parms.Length < 4 || cl.Parms.Length > 5) {
				Log.Msg("usage: run [romname in outdir] [cartype] [lc] [rc] [ntsc/pal]\n");
				break;
			}
			gs = new GameSettings("nokey");
			gs.ROMFileName = cl.Parms[0].StrValue;
			gs.ROMFullName = Globals.OutputDirectory + "/" + gs.ROMFileName;
			try {
				gs.CartType = (CartType)Enum.Parse(typeof(CartType), cl.Parms[1].StrValue.ToUpper());
			} catch {
				Log.Msg("bad cartype, available types:\n");
				foreach (CartType ct in Enum.GetValues(typeof(CartType))) {
					Log.Msg("{0} ", ct);
				}
				Log.Msg("\n");
				break;
			}
			try {
				gs.LController = (Controller)Enum.Parse(typeof(Controller), cl.Parms[2].StrValue);
				gs.RController = (Controller)Enum.Parse(typeof(Controller), cl.Parms[3].StrValue);
			} catch {
				Log.Msg("bad controller type, available types:\n");
				foreach (Controller ct in Enum.GetValues(typeof(Controller))) {
					Log.Msg("{0} ", ct);
				}
				Log.Msg("\n");
				break;
			}
			gs.MachineType = MachineType.A2600NTSC;
			if (cl.Parms.Length > 4 && cl.Parms[4].StrValue.ToUpper() == "PAL") {
				gs.MachineType = MachineType.A2600PAL;
			}
			ControlPanelForm.CurrGameSettings = gs;
			ControlPanelForm.RunMachine();
			break;
		case "opacity":
			if (cl.CheckParms("i")) {
				int op = cl.Parms[0].IntValue;
				if (op > 100) {
					op = 100;
				} else if (op < 25) {
					op = 25;
				}
				ControlPanelForm.Opacity = (double)op/100.0;
				Globals.Opacity = ControlPanelForm.Opacity;
				Globals.Save();
				Log.Msg("Opacity set to {0}%\n", op);
			} else {
				Log.Msg("bad opacity parm\n");			
			}
			break;
		case "joybuttons":
			if (cl.Parms.Length == 0) {
				Log.Msg("joybuttons: trigger:{0} booster:{1} select:{2} reset:{3} swap:{4}\n",
					Globals.JoyBTrigger,
					Globals.JoyBBooster,
					Globals.JoyBSelect,
					Globals.JoyBReset,
					Globals.JoyBSwap);
			} else if (cl.CheckParms("iiiii")) {
				Globals.JoyBTrigger = cl.Parms[0].IntValue;
				Globals.JoyBBooster = cl.Parms[1].IntValue;
				Globals.JoyBSelect = cl.Parms[2].IntValue;
				Globals.JoyBReset = cl.Parms[3].IntValue;
				Globals.JoyBSwap = cl.Parms[4].IntValue;
				Globals.Save();
				Log.Msg("joystick button bindings saved\n");
			} else {
				Log.Msg("bad parms\n");
				Log.Msg("usage: joybuttons [trigger#] [booster#] [select#] [reset#] [swap#]\n");
			}
			break;
		case "fps":
			if (cl.CheckParms("i")) {
				int fpsdelta = cl.Parms[0].IntValue;
				if (fpsdelta > 40)
					fpsdelta = 40;
				if (fpsdelta < -40)
					fpsdelta = -40;
				ControlPanelForm.FPSDelta = fpsdelta;
			} else if (cl.Parms.Length > 0) {
				Log.Msg("bad FPS parm\n");
			}
			Log.Msg("FPS delta set to {0}\n", ControlPanelForm.FPSDelta);
			break;
		case "sb":
			if (cl.CheckParms("i")) {
				int nsb = cl.Parms[0].IntValue;
				if (nsb < 2)
					nsb = 2;
				ControlPanelForm.NumSoundBuffers = nsb;
			} else if (cl.Parms.Length > 0) {
				Log.Msg("bad parm\n");
			}
			Log.Msg("number of sound buffers: {0}\n",
				ControlPanelForm.NumSoundBuffers);
			break;
		case "help":
		case "h":
		case "?":
			Log.Msg("** General Commands **\n"
				+ " ?: this help menu\n"
				+ " clear: clear log messages (64k limit)\n"
				+ " gs: show game settings\n"
				+ " outdir [newdir]: show/update output directory\n"
				+ " ls: show files in outdir\n"
				+ " rec [filen]: start recording input\n"
				+ " pb [filen]: playback recording\n"
				+ " stop: stop playback or recording\n"
				+ " run: run [romnm] [cartype] [lc] [rc] [ntsc/pal]\n"
				+ " fps [ratedelta]: adj. frames per second\n"
				+ " sb [num]: number of sound buffers\n"
				+ " opacity [50-100]\n"
				+ " joybuttons [trigger#] [booster#] [select#] [reset#] [swap#]\n");
			break;
		default:
			if (!recog) {
				Log.Msg("Unrecognized command\n");
			}
			break;
		}
	}
}
}