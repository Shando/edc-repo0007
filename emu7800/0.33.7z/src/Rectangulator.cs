/*
 * Rectangulator
 *
 * Caches display updates and issues net changes as a performance
 * optimization.
 *
 * Copyright (c) 2003 Mike Murphy
 *
 *
 */

using System;
using System.Drawing;

namespace EMU7800 {

public struct DisplRect {
	public byte Colu;
	public int Argb;
	public int X, Y, Width, Height;

	private byte DimmedColu {
		get {
			byte co = (byte)(Colu & 0xf0);
			byte lu = (byte)(Colu & 0x0f);
			if (lu >= 2)
				lu -= 2;
			return (byte)(co | lu);
		}
	}

	public void SetArgb(int[] palette, bool PauseDim) {
		unchecked {
			Argb = (int)0xff000000 | palette[PauseDim ? DimmedColu : Colu];
		}
	}

	public int Top {
		get {
			return Y;
		}
	}

	public int Left {
		get {
			return X;
		}
	}

	public int Right {
		get {
			return X + Width;
		}
	}

	public int Bottom {
		get {
			return Y + Height;
		}
	}

	public Rectangle Rectangle {
		get {
			return new Rectangle(X, Y, Width, Height);
		}
		set {
			X = value.X;
			Y = value.Y;
			Width = value.Width;
			Height = value.Height;
		}
	}
}

public class Rectangulator {
	public Machine M;

	public  bool DrawEntireFrame = false;

	private Size viewPortSize;
	public  Size ViewPortSize {
		get {
			return viewPortSize;
		}
		set {
			viewPortSize = value;
			UpdatePixelSize();
			UpdateOffset();
			DrawEntireFrame = true;
		}
	}

	public Point ClipLocation {
		get {
			return ClippingRect.Location;
		}
		set {
			ClippingRect.Location = value;
			DrawEntireFrame = true;
		}
	}

	private Size FrameBufferSize;
	private Rectangle ClippingRect;
	private Size PixelAspectRatio, PixelSize;
	private int[] Palette;
	private byte[] FrameBuffer;
	private Size Offset;
	private bool PauseDim;

	private DisplRect[] aRects;
	private DisplRect[] cRects;
	private int aIdx, aCount;
	private int cIdx, cCount;

	public void SetPalette(int[] palette) {
		if (palette.Length == 256) {
			Palette = palette;
		}
	}

	public void DrawPauseFrame() {
		DrawEntireFrame = true;
		PauseDim = true;
		StartFrame();
		int w = FrameBufferSize.Width;
		int h = FrameBufferSize.Height;
		byte[] buff = new byte[w];
		for (int i=0; i < h; i++) {
			for (int j=0; j < w; j++) {
				buff[j] = FrameBuffer[i*w + j];
			}
			InputScanline(buff, i, 0, w);
		}
		EndFrame();
		PauseDim = false;
		DrawEntireFrame = true;
	}

	public void StartFrame() {
		// Empty both rectangle lists
		//
		aIdx = 0;
		aCount = 0;
		cIdx = 0;
		cCount = 0;
	}

	public void EndFrame() {
		// Flush any remaining rectangles on the active list
		//
		while (aIdx < aCount) {
			DoRectUpdated(aRects[aIdx]);
			aIdx++;
		}
		DrawEntireFrame = false;
	}
	
	public void InputScanline(byte[] scanlineBuffer,
			int scanline, int hposStart, int updateClocks) {

		if (scanline < ClippingRect.Y || scanline >= FrameBufferSize.Height
				|| scanline >= ClippingRect.Bottom) {
			return;
		}

		int sli = hposStart;
		int fbi = scanline*FrameBufferSize.Width + hposStart;

		byte colu;

		// Build the current rectangle list, horizontally merging when
		// possible
		//
		while (updateClocks-- > 0 && sli < FrameBufferSize.Width) {
			colu = scanlineBuffer[sli];
			if (colu != FrameBuffer[fbi] || DrawEntireFrame) {
				if (cCount > 0 && colu == cRects[cCount - 1].Colu
					&& cRects[cCount - 1].Right == sli) {
					cRects[cCount - 1].Width++;
				} else {
					cRects[cCount].Colu = colu;
					cRects[cCount].Rectangle
						= new Rectangle(sli, scanline, 1, 1);
					cCount++;
				}
				FrameBuffer[fbi] = colu;
			}
			sli++; fbi++;
		}

		// Exit early if we are not at the end of the scanline
		//
		if (sli < scanlineBuffer.Length) {
			return;
		}

		// Look for opportunities to vertically merge with
		// rectangles on the active list, otherwise flush the
		// unmergable active rectangles
		//
		while (cIdx < cCount && aIdx < aCount) {
			if (cRects[cIdx].X > aRects[aIdx].X) {
				DoRectUpdated(aRects[aIdx]);
				aIdx++;
			} else if (cRects[cIdx].X == aRects[aIdx].X
					&& cRects[cIdx].Width == aRects[aIdx].Width
					&& cRects[cIdx].Colu == aRects[aIdx].Colu) {
				cRects[cIdx] = aRects[aIdx];
				cRects[cIdx].Height++;
				aIdx++;
			}
			cIdx++;
		}

		// Flush any remaining active rectangles that have no hope for
		// subsequent merging
		//		
		while (aIdx < aCount) {
			DoRectUpdated(aRects[aIdx]);
			aIdx++;
		}		
		
		// For the next scanline, make the current rectangle list the
		// new active list, and then empty the current list
		//
		DisplRect[] swapTmp = aRects;

		aRects = cRects;
		aIdx = 0;
		aCount = cCount;

		cRects = swapTmp;
		cIdx = 0;
		cCount = 0;
	}

	public Rectangulator(Machine m, int hpixels, int scanlines, Size pAspectRatio) {
		M = m;
		FrameBufferSize = new Size(hpixels, scanlines);
		FrameBuffer = new byte[hpixels*scanlines];
		aRects = new DisplRect[hpixels];
		cRects = new DisplRect[hpixels];
		PixelAspectRatio = pAspectRatio;

		ClippingRect = new Rectangle(0, 0, 160, 240);
		ViewPortSize = new Size(320, 240);
		Palette = TIATables.NTSCPalette;

		PauseDim = false;
	}

	private void DoRectUpdated(DisplRect r) {
		r.SetArgb(Palette, PauseDim);

		r.X -= ClippingRect.X;
		r.Y -= ClippingRect.Y;

		r.X *= PixelSize.Width;
		r.Y *= PixelSize.Height;
		r.Width *= PixelSize.Width;
		r.Height *= PixelSize.Height;

		r.X += Offset.Width;
		r.Y += Offset.Height;
		
		if (M.H != null) {
			M.H.UpdateRect(r);
		}
	}

	private void UpdatePixelSize() {
		int i=0;

		while (true) {
			i++;
			if (viewPortSize.Width
				< ClippingRect.Size.Width * PixelAspectRatio.Width * i) {
				break;
			}
			if (viewPortSize.Height
				< ClippingRect.Size.Height * PixelAspectRatio.Height * i) {
				break;
			}
		}

		PixelSize = PixelAspectRatio;
		if (i > 1) {
			i--;
			PixelSize.Width *= i;
			PixelSize.Height *= i;
		}
	}

	private void UpdateOffset() {
		Offset = new Size(
			(viewPortSize.Width
				- ClippingRect.Size.Width*PixelSize.Width)/2,
			(viewPortSize.Height
				- ClippingRect.Size.Height*PixelSize.Height)/2);
	}
}
}