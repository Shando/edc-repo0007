package com.blissj.app;

import java.awt.*;
import javax.swing.*;

public class BlissAboutDialog extends JDialog
{

    public BlissAboutDialog(JFrame parent) {
        super(parent);
        initUI();
    }

    private void initUI() {
        setTitle(Bliss.RESOURCES.getString("BlissAboutDialogTitle"));
        setResizable(false);
        setBackground(new Color(119, 147, 191));
        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());

        logo = getToolkit().getImage(getClass().getClassLoader().getResource(
                "com/blissj/app/images/blisssplash.gif"));
        MediaTracker mt = new MediaTracker(this);
        mt.addImage(logo, 0);
        try {
            mt.waitForID(0);
        }
        catch (InterruptedException ignored) { }

        JLabel logoLabel = new JLabel(new ImageIcon(logo));
        contentPane.add(logoLabel, BorderLayout.CENTER);

        pack();
    }

    private Image logo;

}
