package com.blissj.app.actions;

import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.blissj.app.*;

public class PlayCartridgeAction extends AbstractAction
{

    public PlayCartridgeAction(BlissMainFrame frame, JTable cartridgeTable) {
        this.frame = frame;
        this.cartTable = cartridgeTable;
        this.cartTableModel = (CartridgeTableModel)cartTable.getModel();
        setEnabled(false);
        putValue(NAME, Bliss.RESOURCES.getString("ActionPlayCartridge"));
        cartTable.getSelectionModel().addListSelectionListener(
            new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent lse) {
                    if (lse.getValueIsAdjusting())
                        return;
                    int selection = cartTable.getSelectionModel().
                            getAnchorSelectionIndex();
                    setEnabled(!cartTable.getSelectionModel().
                            isSelectionEmpty() &&
                            cartTableModel.isCartridgeFileAvailable(selection));
                }
            });
    }

    public void actionPerformed(ActionEvent ae) {
        frame.playCartridge();
    }

    private BlissMainFrame      frame;
    private JTable              cartTable;
    private CartridgeTableModel cartTableModel;

}
