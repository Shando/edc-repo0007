/*
 * Log.cs
 * 
 * Logger for the entire application.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */ 
using System;
using System.Diagnostics;
using System.Text;

namespace EMU7800 {

public delegate void LogBroadcastHandler(string msgs);

public class Log {
	public static bool Flushing = false;
	public static event LogBroadcastHandler LogBroadcast;

	private static StringBuilder MessageSpool = new StringBuilder();	public static void Msg(String fmt, params object[] objs) {		Debug.Write(String.Format(fmt, objs));		MessageSpool.AppendFormat(fmt, objs);		FlushMsgs();	}	public static void FlushMsgs() {		if (Flushing && LogBroadcast != null) {			string msgs = "";			if (MessageSpool.Length > 0) {				msgs = MessageSpool.ToString();				MessageSpool.Length = 0;				LogBroadcast(msgs.Replace("\n", Environment.NewLine));			}		}	}}
}
