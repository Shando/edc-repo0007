#include <errno.h>
#include <stdio.h>

void main(int argc, char **argv)
{
 int travel;

 for (travel=1; travel<argc; travel++)
 {
  FILE *file;

  printf ("\n-- %s --\n",argv[travel]);
  file=fopen(argv[travel],"rt");
  if (!file)
   printf (">> Cannot open: %s",strerror(errno));
  else
  {
   int x;

   while (1)
   {
    x=fgetc(file);
    if (x<0) break;
    fputc(x,stdout);
   }

   fclose(file);
  }
 }
}
