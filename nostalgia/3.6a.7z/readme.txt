Nostalgia, an Intellivision Emulator

Version 3.6

by Joe Fisher
joefish75@hotmail.com


To see what's new with Nostalgia, scroll down to the bottom to see the change log.


Hello, and thanks for trying my emulator! It's my first stab at an emulator of any sort.  
I chose the Inty because when I think of childhood video game fun, the one thing that 
pops into my head is playing Tron and the Deadly Discs with my dad, competing for the 
highest score, taking out the Recognizer, striving for 1,000,000 points so I could see 
the orange guys with the sticks they showed in the instruction manual.  *sigh*  

	I have to send out an *ENORMOUS* thank you to Joe Zbiciak, Inty genius and creator 
of "jzIntv", and Kyle Davis, all around nice guy and creator of "Bliss".  These two emulators 
were a big part of my inspiration, and the guys themselves were critical to the development 
of Nostalgia.  Kyle was extremely helpful in lending advice and sample code, and Joe used 
his superhuman powers of perception to detect bugs in my code before I could even type it.

	I couldn't have done it without you guys (or it would've taken me 6 years), so I just
wanted to let you know you're appreciated :)

	Thank you to Steve Orth and all who have made suggestions to improve Nostalgia.	

	And while I'm thanking people, thank you to my wonderful wife Lizzie,
who tolerated me staying up until 2am more than a few nights working on this 
(and I'm sure there'll be more), and for coming up with the name and great title 
screen for "Nostalgia".

--------------------------------------

*--- Running the program

	Put the Exec and Grom files in the same directory you installed Nostalgia into,
run Nostalgia, and select "Load Cartridge" from the main menu.
	You can point Nostalgia to your existing ROM directory by using the Game Options,
or dump all of your ROMS in the existing "roms" directory.

*--- Command line options

	You may specify the screen resolution, whether or not to use ECS and the game to 
run on the command line.  If you specify a game on the command line, Nostalgia will skip
the menu system and immediately run the game.

Valid Options:
-WxH or /WxH	: Run in WxH resolution eg. -320x240, /640x480, etc.
-ECS or /ECS	: Use the ECS if available
-NOECS or /NOECS: Do not use the ECS even if available

  The game file you specify MUST be the LAST thing on the command line.  It may be inside
double quotes, "", but does not need to be, even if it has spaces in it.

These are all valid command lines:

Nostalgia -800x600
Nostalgia -320x200 -ecs c:\my games\inty\world series baseball.bin
Nostalgia /NOecs /1024x768 "C:\emus\roms\snafu.rom"
Nostalgia c:\program files\games\my roms\atlantis.bin
Nostalgia "c:\program files\games\my roms\atlantis.bin"
Nostalgia c:\progra~1\games\my~1\atlantis.bin

These are NOT VALID:

Nostalgia c:\games\snafu.bin -640x480
Nostalgia "c:\my games\atlantis.bin" -noecs

*--- Running the program in Network mode

	Select "Network Play" form the main menu, and you will enter into the network game
setup.  You will get a list of network service providers.  The only one I have tested
currently is TCP/IP.  Once the game is setup, you will be able to chat and discuss what 
game you would like to play.

	The host player will be the one who creates the game.  He will have
control over which game is played.  If you will be the client player, ie the one who joins
he game, make sure your game settings are all setup in single player mode first, as you
won't be able to change them during the game.

	The host, or creating, player will be the Left controller, and the client player will
be the Right controller.

*--- Controls

 -Joysticks:
	Nostalgia will take the first two joysticks available in the system and make them the 
Left and Right hand controllers in that order.  The stick emulates the disc on the Inty's 
hand controller, and buttons 1, 2, and 3 are the Top, Left and Right buttons respectively.


 -Keyboard:

	Default key mapping is as below, and it can be changed:

		Left: 			Right:
		(Numeric
		Keypad)

-Inty Keypad

123		789		    	123
456		456		    	QWE
789		123		    	ASD
C0E		.0<enter>		ZXC

-Inty Buttons

Top:		Home			Leftshift
Left:		Delete			Leftcontrol
Right:		PageDown		Leftalt

-Inty Disc

Up:		    Uparrow			I
Left:		Leftarrow		J
Right:		Rightarrow		L
Down:		Downarrow		K

-Miscellaneous

<F4>	Toggle Sound On/Off
<F5>	Save game state
<F6>	Toggle Frame Rate / Frame Skip info
<F7>	Restore game state
<F8>	Begin / end AVI movie recording.
<F9>	Pause game
<F10>	Begin / end WAV sound recording.
<F11>	Reset
<F12>	Save screenshot
<ESC>	Quit current game

<ESC>   Go back a menu/cancel changes
<ENTER> Accept changes
<F12>	Leave Nostalgia

*--- Box and Overlay images

	Nostalgia comes with 10 box and overlay images thanks to Steve Orth of the 
IntvFunhouse (http://intvfunhouse.com).  You can add your own by putting your image in the 
images folder (you can change the location of this folder in the options) and making it the 
same name as the game.  Check in the games.cfg if you're not sure of the name to use for 
the game in question.  An overlay image has the same name with "_overlay" at the end.  The 
files can be in BMP, GIF or JPG format.  Some examples:

Tron Deadly Discs.jpg
Tron Deadly Discs_overlay.jpg
Lock 'n' Chase.gif
Lock 'n' Chase_overlay.bmp


Have fun, and please let me know what you think.

             Joe

--------------------------------------
Updates since version 3.5:
  Optimized the display and input routines to more than double the frame rate!
    This will allow Nostalgia to run more smoothly on more PCs.
    Thanks to Joe Zbiciak for his contributions.
  Games that use the ECS now turn it on automatically when played.
  Added a frame rate counter.  Press <F6> to enable / disable.
  Nostalgia now supports any display mode your video card does!
    Look in the Game Options screen to try them out.
  Configuration now stored in the Regsitry.
  The command line now allows you to set the resolution in -WxH format.
    (eg. -640x480)  The format will be verified against the list of available
	modes, and error.log will tell you if it was invalid.
  Nostalgia now comes with Joe Zbiciak's MiniExec and MiniGrom so you can play
    games "right out of the box."
  There are now many homebrew games packaged with Nostalgia.  Thanks to Arnauld
    Chevallier, Joe Zbiciak and Ryan Kinnen for providing them.
    See README.HTML to find out more about them.
  Added a Windows Installer.
  Added throttling for play with no sound.
  Added option and hotkey <F4> to turn sound on/off.
  Added notification of MiniExec support.  Games can be marked supported in
    "Add to Database" button on the Load Cartridge screen.
  Made the display more accurate to a real Intellivision.  Thanks to Steve
    Orth, Arnauld Chevallier, and Joe Zbiciak.
  Fixed usability issues with the menuing system like:
    Notification of delays when loading the cartridge list.
    Pageup/Pagedown support in the scrollbars for choosing Rom/Image folders.
    Display of Rom/Image files while browsing for Rom/Image folders.
  Fixed a bug that caused a crash when opening up large numbers of roms.
  Fixed a bug in Nostalgia's database preventing Super Soccer from running.
  Fixed a bug that caused the sound to disappear after loading many games.
  Fixed 2 bugs that caused crashes under certain conditions.

Debugger-specific updates:
  Improvements to the speed of the debugger.
  The debugger now remembers the last game you chose so you don't have to
    reselect the game to re-run it every time.
  Games are now properly loaded from the command line in the debugger.
  The trace window now follows along when stepping rather than reloading
    every time.
  Added optional throttling when sound is off.
  Added a help dialog to the debugger, <F1>.
  Debugger now keeps track of the last folder you opened a rom from.
  Fixed a debugger bug preventing <F10> from working as expected.
  Fixed a debugger bug causing a crash on exit.
  Fixed a bug preventing the debugger from finding the EXEC and GROM files.

--------------------------------------
Updates since version 3.3:
  Added the ability to run with nonstandard EXEC and GROM files, such as the
    miniexec and minigrom provided with Joe Zbiciak's SDK-1600. Just name the
    files "exec.bin" and "grom.bin" and drop them in the folder with Nostalgia.
	Added the ability to use either joystick to move the mouse cursor.  Thanks
    to Steve Hoogerhyde for suggesting this one.
  Greatly enhanced keyboard navigation in the menus.  <ESC> now goes back a
    menu or selects "Cancel".  <ENTER> selects "Save".
  Fixed a bug in the colorstack display routine.  Thanks to Joe Zbiciak for
    discovering this and mysteriously knowing exactly where the problem was.
  Fixed a bug Chuck Whitby was kind enough to find for me.  What a guy!
  Fixed a bug that was preventing Chess in Triple Action from working.

--------------------------------------
Updates since version 3.2:
  AVI format movies can now be recorded while playing a game!  By pressing <F8>, 
    all screen activity and sound is recorded to an AVI file at a maximum of
    15 frames per second.
  Screen captures are now saved in Windows Bitmap format.
  Screenshots and other captures now reside in their own directory.
    \nostalgia\captures\
  Captures are now named based on the game you're playing.  For example, a sound
    caputre while playing Atlantis might look like:
      Atlantis00001.wav
  Multiple captures are now possible, up to 99999 separate captures of a type per
    game.  For example, if you took 3 screenshots while playing Snafu, they would
    be saved as:
      Snafu00001.bmp
      Snafu00002.bmp
      Snafu00003.bmp
  Old capture files will never be overwritten by Nostalgia.  A new filename is
    chosen each time.
  Command line options have been redone for flexibility. See "Command Line Options"
    below for more information.

--------------------------------------
Updates since version 3.1:
  Added Sound Capture capability!  Now, by pressing <F10>, whatever sounds and 
    music are playing in the game get recorded to a wave file.  Capture those cool
    Snafu snake noises, or use some Astrosmash sounds on your desktop! 
  A big "Thank You" to Jorg Schafer for this feature. 
  Ein grosses "danken Ihnen" zu Jorg Schafer f�r diese Eigenschaft. 
  Added 2 command line options:
    A rom may now be specified on the command line in quotes 
      (nostalgia "c:\roms\digdug.bin") to allow the use of frontends for Nostalgia. 
      Thanks to Remi Juneau for this one.
    The screen resolution may be specified on the command line.
      320, 640, 800, 1024.


--------------------------------------
Updates since version 3.0:
  Fixed a bug in the Networking that was preventing Network play.
  Fixed type ahead to work with numeric game names (4-Tris, etc)
  Added "Home" and "End" capability to Load Cartridge screen.
  Changed the way video memory is used to fix a problem that was causing Nostalgia
    to stop working unexpectedly on some video cards.
  Generally reworked code for more efficiency, especially the core chip code.

--------------------------------------
Updates since version 2.5:
  Added ECS support!  Keyboard and music keyboard are supported.
  Added a real Windows help file.
  Made more improvemnts to the menuing system.
  Added "Type Ahead" to the Load Cartridge screen.  You may now press the first
   letter of the game you want to play to jump to it in the list.
  Made improvements to the way joysticks are handled to allow multiple joysticks
   with the same name to function properly.
  Fixed a big, ugly bug in the joystick routine that was causing a dump from
    the game under certain circumstances.  Thanks to Michael Mellor for catching
    this one.
  Changed the quick save and restore to properly save and restore ECS and 
   ROM format games.

Debugger-specific updates:
  Added the ability to look at the main memory map, the cartridge map or ECS ROM.
  Added selections for ECS support and Intellivoice support (Intellivoice not
   actually supported, yet)

--------------------------------------
Updates since version 2.2: 
  Added the ability to open games that aren't in Nostalgia's database.  Any game that
   is in ROM format or has a config (.cfg) file with it can be opened.
  Complete support for Intellicart ROM format.
  Complete support for Intellicart ROM bankswitching.
  Removed a lot of annoyances in Nostalgia.  Having to press a key at the splash
   screen, the initial dialog box, and other nitpicky things.
--------------------------------------
Updates since version 2.0: 
  Added the "Add File to Database" button.  This allows a new game to be added to
  Nostalgia's database.
  Added preliminary support for Intellicart ROM file format.
  Overhauled the sound system.
  Added support for the Classic Game Controller interface (more on this later).
--------------------------------------
Updates since version 1.0: 
  Added support for playing Nostalgia over the Internet!
  Needs *much* more testing.  There still may be sync problems, and the client player
   can't do much other than play the game.
--------------------------------------
