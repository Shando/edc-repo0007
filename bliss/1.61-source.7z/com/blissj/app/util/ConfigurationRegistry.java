package com.blissj.app.util;

import java.io.*;
import java.text.*;
import java.util.*;

public class ConfigurationRegistry
{

    public ConfigurationRegistry(File registryFile) {
        this.registryFile = registryFile;
    }
    
    public String[] getKeys(String[] key, String[] defaultListOfKeys) {
        KeyEntry keyEntry = getKey(key, false);
        if (keyEntry == null)
            return new String[0];
        
        ArrayList subKeys = keyEntry.getKeys();
        String[] subKeyNames = new String[subKeys.size()];
        int keyCount = 0;
        for (Iterator i = subKeys.iterator(); i.hasNext(); keyCount++)
            subKeyNames[keyCount] = ((KeyEntry)i.next()).getName();
        return subKeyNames;
    }

    public String getDataAsString(String[] key, String valueName,
            String defaultData)
    {
        KeyEntry keyEntry = getKey(key, false);
        if (keyEntry == null)
            return defaultData;
        
        ValueEntry value = keyEntry.getValue(valueName);
        if (value == null)
            return defaultData;
        
        return value.getDataAsString();
    }

    public int getDataAsInt(String[] key, String valueName, int defaultData) {
        KeyEntry keyEntry = getKey(key, false);
        if (keyEntry == null)
            return defaultData;

        ValueEntry value = keyEntry.getValue(valueName);
        if (value == null)
            return defaultData;
        
        return value.getDataAsInt();
    }

    public void setKey(String[] key) {
        KeyEntry nextKeyEntry = registry;
        for (int i = 0; i < key.length-1; i++) {
            KeyEntry previousKeyEntry = nextKeyEntry;
            nextKeyEntry = (KeyEntry)nextKeyEntry.getKey(key[i]);
            if (nextKeyEntry == null) {
               nextKeyEntry = new KeyEntry(key[i]);
               previousKeyEntry.putKey(nextKeyEntry);
            }
        }
        nextKeyEntry.putKey(new KeyEntry(key[key.length-1]));
    }

    public void setData(String[] key, String valueName, int data) {
        KeyEntry lastKeyEntry = getKey(key, true);
        ValueEntry value = lastKeyEntry.getValue(valueName);
        if (value == null) {
            value = new ValueEntry(valueName, new Integer(data));
            lastKeyEntry.putValue(value);
        }
        else
            value.setData(new Integer(data));
    }

    public void setData(String[] key, String valueName, String data) {
        if (data == null) {
            removeValue(key, valueName);
            return;
        }

        KeyEntry lastKeyEntry = getKey(key, true);
        ValueEntry value = lastKeyEntry.getValue(valueName);
        if (value == null) {
            value = new ValueEntry(valueName, data);
            lastKeyEntry.putValue(value);
        }
        else
            value.setData(data);
    }

    public void removeKey(String[] key) {
        KeyEntry nextKeyEntry = registry;
        for (int i = 0; i < key.length-1; i++) {
            nextKeyEntry = nextKeyEntry.getKey(key[i]);
            if (nextKeyEntry == null)
                return;
        }
        nextKeyEntry.removeKey(key[key.length-1]);
    }

    public void removeValue(String[] key, String valueName) {
        KeyEntry lastKeyEntry = getKey(key, false);
        if (lastKeyEntry != null)
            lastKeyEntry.removeValue(valueName);
    }

    protected KeyEntry getKey(String[] key, boolean createIfNeeded) {
        KeyEntry nextKeyEntry = registry;
        for (int i = 0; i < key.length; i++) {
            KeyEntry previousKeyEntry = nextKeyEntry;
            nextKeyEntry = (KeyEntry)nextKeyEntry.getKey(key[i]);
            if (nextKeyEntry == null) {
                if (createIfNeeded) {
                    nextKeyEntry = new KeyEntry(key[i]);
                    previousKeyEntry.putKey(nextKeyEntry);
                }
                else
                    //key does not exist
                    return null;
            }
        }
        return nextKeyEntry;
    }

    
    public static String[] concatenateKeys(String[] key1, String[] key2) {
        String[] newKey = new String[key1.length + key2.length];
        concatenateKeys(key1, key2, newKey);
        return newKey;
    }

    public static String[] concatenateKeys(String[] key1, String[] key2,
            String[] outputKey)
    {
        System.arraycopy(key1, 0, outputKey, 0, key1.length);
        System.arraycopy(key2, 0, outputKey, key1.length, key2.length);
        return outputKey;
    }

    public static String[] concatenateKeys(String[] key1, String key2) {
        String[] newKey = new String[key1.length + 1];
        System.arraycopy(key1, 0, newKey, 0, key1.length);
        newKey[newKey.length-1] = key2;
        return newKey;
    }

    public void saveRegistry() throws IOException {
        DataOutputStream dos = new DataOutputStream(new BufferedOutputStream(
                new FileOutputStream(registryFile), 4096));
        dos.writeInt(1);
        saveKey(registry, dos);
        dos.close();
    }

    public void saveKey(KeyEntry key, DataOutputStream dos)
            throws IOException
    {
        String name = key.getName();
        dos.writeInt(name.length());
        dos.writeChars(name);
        ArrayList subKeys = key.getKeys();
        dos.writeInt(subKeys.size());
        for (Iterator i = subKeys.iterator(); i.hasNext();)
            saveKey((KeyEntry)i.next(), dos);
        ArrayList subValues = key.getValues();
        dos.writeInt(subValues.size());
        for (Iterator i = subValues.iterator(); i.hasNext();)
            saveValue((ValueEntry)i.next(), dos);
    }

    public void saveValue(ValueEntry value, DataOutputStream dos)
            throws IOException
    {
        String name = value.getName();
        dos.writeInt(name.length());
        dos.writeChars(name);
        int dataType = value.getDataType();
        dos.writeInt(dataType);
        if (dataType == ValueEntry.INT_TYPE)
            dos.writeInt(value.getDataAsInt());
        else {
            String data = value.getDataAsString();
            dos.writeInt(data.length());
            dos.writeChars(data);
        }
    }

    public void loadRegistry() throws IOException {
        DataInputStream dis = new DataInputStream(new BufferedInputStream(
                new FileInputStream(registryFile), 4096));
        int size = dis.readInt();
        for (int i = 0; i < size; i++)
            loadKey(null, dis);
        dis.close();
    }

    private void loadKey(KeyEntry parentKey, DataInputStream dis)
            throws IOException
    {
        int keyNameSize = dis.readInt();
        char[] c = new char[keyNameSize];
        for (int i = 0; i < keyNameSize; i++)
            c[i] = dis.readChar();
        KeyEntry newKey = new KeyEntry(new String(c));
        int subKeys = dis.readInt();
        for (int i = 0; i < subKeys; i++)
            loadKey(newKey, dis);
        int subValues = dis.readInt();
        for (int i = 0; i < subValues; i++)
            loadValue(newKey, dis);
        if (parentKey == null)
            registry = newKey;
        else
            parentKey.putKey(newKey);
    }

    private void loadValue(KeyEntry key, DataInputStream dis)
            throws IOException
    {
        int nameSize = dis.readInt();
        char[] c = new char[nameSize];
        for (int i = 0; i < nameSize; i++)
            c[i] = dis.readChar();
        int type = dis.readInt();
        ValueEntry ve;
        if (type == ValueEntry.INT_TYPE)
            ve = new ValueEntry(new String(c), new Integer(dis.readInt()));
        else {
            String name = new String(c);
            nameSize = dis.readInt();
            c = new char[nameSize];
            for (int i = 0; i < nameSize; i++)
                c[i] = dis.readChar();
            ve = new ValueEntry(name, new String(c));
        }
        key.putValue(ve);
    }

    private KeyEntry registry = new KeyEntry("root");
    private File registryFile;

    private class KeyEntry implements Comparable
    {
        private KeyEntry(String keyName) {
            this.keyName = keyName;
        }

        private String getName() {
            return keyName;
        }

        private KeyEntry getKey(String keyName) {
            return (KeyEntry)keys.get(keyName);
        }

        private ArrayList getKeys() {
            return keysNO;
        }

        private void putKey(KeyEntry subKey) {
            keys.put(subKey.keyName, subKey);
            keysNO.add(subKey);
        }

        private void removeKey(String keyName) {
            Object subKey = keys.get(keyName);
            if (subKey != null) {
                keys.remove(keyName);
                keysNO.remove(subKey);
            }
        }

        private ValueEntry getValue(String valueName) {
            return (ValueEntry)vals.get(valueName);
        }

        private ArrayList getValues() {
            return valsNO;
        }

        private void putValue(ValueEntry value) {
            vals.put(value.getName(), value);
            valsNO.add(value);
        }

        private void removeValue(String valueName) {
            Object value = keys.get(valueName);
            if (value != null) {
                vals.remove(valueName);
                valsNO.remove(value);
            }
        }

        public int compareTo(Object o) {
            return keyName.compareTo(((KeyEntry)o).keyName);
        }

        private final String    keyName;
        private final TreeMap   keys   = new TreeMap();
        private final ArrayList keysNO = new ArrayList();
        private final TreeMap   vals   = new TreeMap();
        private final ArrayList valsNO = new ArrayList();
    }

    private class ValueEntry
    {

        private final static int INT_TYPE    = 0;
        private final static int STRING_TYPE = 1;

        private ValueEntry(String valueName, Object data) {
            this.valueName = valueName;
            this.data = data;
        }

        private String getName() {
            return valueName;
        }

        private String getDataAsString() {
            return (String)data;
        }

        private int getDataAsInt() {
            return ((Integer)data).intValue();
        }

        private int getDataType() {
            return (data instanceof Integer) ? INT_TYPE : STRING_TYPE;
        }

        private void setData(Object data) {
            if (!data.getClass().equals(this.data.getClass())) {
                //incompatible existing type
                Object[] params = { this.data.getClass().getName(),
                        valueName, data.getClass().getName() };
                throw new IllegalArgumentException(
                        "The new registry value of class " +
                        data.getClass().getName() +
                        " is incompatible with the existing value of class " +
                        this.data.getClass().getName());
            }

            this.data = data;
        }

        private final String valueName;
        private Object data;
    }
}
