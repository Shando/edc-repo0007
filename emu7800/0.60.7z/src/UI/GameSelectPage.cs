/*
 * GameSelectPage.cs
 * 
 * A TabPage that facilitates game ROM selection.
 * 
 * Copyright (c) 2003, 2004 Mike Murphy
 * 
 */
using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Text;
using System.Reflection;
using System.Windows.Forms;

namespace EMU7800 {

public class GameSelectPage : TabPage {
	private ControlPanelForm ControlPanelForm;

	private Label lblGameTitle, lblROMDir, lblROMCount;
	private ComboBox cmbROMDir;
	private Button btnBrowse;
	private OpenFileDialog ofdROMSelect;

	private bool InitialTreeViewLoaded = false;
	private TreeView tvROMList;
	private TreeNode tnTitle, tnUnknown;
	private bool DoubleClickReady;
	private int ROMFileCount;
	private ImageList ImageList;

	public void SetGameTitleLabel(string label) {
		lblGameTitle.Text = label;
	}

	public GameSelectPage(ControlPanelForm f) {
		ControlPanelForm = f;

		Text = "Game Programs";

		ImageList = new ImageList();
		foreach (string fn in new string[] {"CLSDFOLD.BMP", "OPENFOLD.BMP", "ROM.BMP"}) {
			ImageList.Images.Add(new Bitmap(Assembly.GetExecutingAssembly().GetManifestResourceStream("EMU7800.Images." + fn)));
		}

		lblROMDir = new Label();
		lblROMDir.Location = new Point(5, 5);
		lblROMDir.Size = new Size(Width, lblROMDir.PreferredHeight);
		lblROMDir.Text = "Current ROM Directory";

		cmbROMDir = new ComboBox();
		cmbROMDir.Text = EMU7800App.Instance.Settings.ROMDirectory;
		cmbROMDir.Location = new Point(5, 20);
		cmbROMDir.Items.Add(cmbROMDir.Text);
		cmbROMDir.SelectedValueChanged += new EventHandler(OnComboBoxChanged);

		btnBrowse = new Button();
		btnBrowse.Text = "Browse";
		btnBrowse.Location = new Point(5, 45);
		btnBrowse.Size = new Size(70, 25);
		btnBrowse.Click += new EventHandler(OnBrowseClick);

		lblGameTitle = new Label();
		lblGameTitle.Location = new Point(5, 80);
		lblGameTitle.Text = EMU7800App.Copyright;
		lblGameTitle.BorderStyle = BorderStyle.FixedSingle;
		lblGameTitle.TextAlign = ContentAlignment.MiddleCenter;

		tvROMList = new TreeView();
		tvROMList.Location = new Point(5, 120);
		tvROMList.HideSelection = false;
		tvROMList.ImageList = ImageList;
		tvROMList.AfterSelect += new TreeViewEventHandler(OnClickTreeView);
		tvROMList.DoubleClick += new EventHandler(OnDoubleClickTreeView);

		lblROMCount = new Label();
		lblROMCount.Size = new Size(Width, lblROMCount.PreferredHeight);
		lblROMCount.Text = "";

		Layout += new LayoutEventHandler(OnLayout);
		MouseEnter += new EventHandler(OnMouseEnter);
		tvROMList.MouseEnter += new EventHandler(OnMouseEnter);

		Controls.AddRange(new Control[] {
			lblGameTitle, lblROMDir, lblROMCount,
			cmbROMDir, btnBrowse, tvROMList});
	}

	private void OnMouseEnter(object sender, EventArgs e) {
		if (!InitialTreeViewLoaded) {
			InitialTreeViewLoaded = true;
			DoLoadTreeView();
		}
	}

	private void OnComboBoxChanged(object sender, EventArgs e) {
		if (cmbROMDir.Text != EMU7800App.Instance.Settings.ROMDirectory) {
			EMU7800App.Instance.Settings.ROMDirectory = cmbROMDir.Text;
			DoLoadTreeView();
		}
	}

	private void OnBrowseClick(object sender, EventArgs e) {
		ofdROMSelect = new OpenFileDialog();
		ofdROMSelect.Title = "Select ROM File";
		ofdROMSelect.Filter = "ROMs (*.bin)|*.bin|A78 ROMs (*.a78)|*.a78" ;
		ofdROMSelect.FilterIndex = 1;

		ofdROMSelect.InitialDirectory
			= Directory.Exists(cmbROMDir.Text)
			? cmbROMDir.Text : EMU7800App.Instance.Settings.RootDir;

		if (ofdROMSelect.ShowDialog() == DialogResult.OK) {
			GameSelectByFileName(ofdROMSelect.FileName);
		}
	}

	private bool GameSelectByFileName(string fn) {
		FileInfo fi = new FileInfo(fn);

		cmbROMDir.Text = fi.DirectoryName;

		if (!cmbROMDir.Items.Contains(fi.DirectoryName)) {
			cmbROMDir.Items.Add(fi.DirectoryName);
		}

		EMU7800App.Instance.Settings.ROMDirectory = fi.DirectoryName;
		DoLoadTreeView();

		bool recog = SelectTitle(fi.FullName);
		if (!recog) {
			MessageBox.Show("Use Console Tab to specify custom attributes.",
				"ROM Not Recognized",
				MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			GameSettings gs = EMU7800App.Instance.ROMProperties.GetGameSettings(MD5.ComputeMD5Digest(fi));
			gs.FileInfo = fi;
			Log.Msg("-------\n");
			Log.Msg("Unrecognized ROM: prefilled GameSettings fields as follows:\n{0}", gs.ToString());
			ControlPanelForm.CurrGameSettings = gs;
		}

		return recog;
	}
	
	private void OnClickTreeView(object sender, TreeViewEventArgs e) {
		DoubleClickReady = false;

		if (e.Node == null || e.Node.Tag == null) {
			ControlPanelForm.CurrGameSettings = null;
			return;
		}

		DoubleClickReady = true;
		
		ControlPanelForm.CurrGameSettings = ((GameSettings)e.Node.Tag);

		ControlPanelForm.StartButtonEnabled = true;
		ControlPanelForm.ResumeButtonEnabled = false;
	}

	private void OnDoubleClickTreeView(object sender, EventArgs e) {
		if (DoubleClickReady && ControlPanelForm.CurrGameSettings.FileInfo != null) {
			ControlPanelForm.OnClickStart(sender, e);
		}
		DoubleClickReady = false;
	}

	private void OnLayout(object sender, LayoutEventArgs e) {
		int w = Width - 10;

		cmbROMDir.Size = new Size(w, cmbROMDir.Size.Height);
		lblGameTitle.Size = new Size(w, 30);
		tvROMList.Size = new Size(w, Size.Height - tvROMList.Location.Y - 20);
		lblROMCount.Location = new Point(5, Size.Height - 15);
	}

	private void DoLoadTreeView() {
		Cursor prevCursor = ControlPanelForm.Cursor;
		ControlPanelForm.Cursor = Cursors.WaitCursor;

		lblROMCount.Text = "Examining ROM directory...";

		ROMFileCount = 0;

		LoadTreeView();

		StringBuilder sb = new StringBuilder();
		sb.Append(ROMFileCount);
		sb.Append(" ROM file");
		if (ROMFileCount != 1) {
			sb.Append("s");
		}
		sb.Append(" recognized");
		lblROMCount.Text = sb.ToString();

		ControlPanelForm.Cursor = prevCursor;
	}

	private void LoadTreeView() {
		tvROMList.BeginUpdate();
		tvROMList.Nodes.Clear();

		tnTitle = new TreeNode("Title", 0, 1);
		tvROMList.Nodes.Add(tnTitle);

		Hashtable manuIndex = AddTreeSubRoot(tvROMList, "Manufacturer", new string[] {
			"Absolute",
			"Activision",
			"Atari",
			"CBS Electronics",
			"Coleco",
			"Epyx",
			"Froggo",
			"Imagic",
			"Konami",
			"Mattel",
			"Milton Bradley",
			"Mystique",
			"Parker Bros",
			"Sega",
			"Starsoft",
			"Telesys",
			"Tigervision",
			"20th Century Fox",
		});

		ArrayList al = new ArrayList();
		for (int i=1977; i <= System.DateTime.Today.Year; i++) {
			al.Add(i.ToString());
		}
		Hashtable yearIndex = AddTreeSubRoot(tvROMList, "Year", (string[])al.ToArray(typeof(System.String)));

		Hashtable rareIndex = AddTreeSubRoot(tvROMList, "Rarity", new string[] {
			"Common", "Uncommon", "Rare", "Extremely Rare",
			"Unbelievably Rare", "Prototype", "Unreleased Prototype",
		});

		Hashtable machIndex = AddTreeSubRoot(tvROMList, "Machine Type", new string[] {
			"A2600NTSC", "A2600PAL",
			"A7800NTSC", "A7800PAL",
		});

		Hashtable contIndex = AddTreeSubRoot(tvROMList, "LController", new string[] {
			"Joystick", "ProLineJoystick", "Paddles", "Driving", "Keypad", "Lightgun", "BoosterGrip"
		});
#if DEBUG
		string[] cartList = Enum.GetNames(typeof(CartType));
		Hashtable cartIndex = AddTreeSubRoot(tvROMList, "Cartridge Type", cartList);
#endif
		tnUnknown = new TreeNode("Unknown", 0, 1);
		tvROMList.Nodes.Add(tnUnknown);

		StringBuilder md5 = new StringBuilder();
		FileInfo[] romFiles;	
		if (!Directory.Exists(EMU7800App.Instance.Settings.ROMDirectory)) {
			EMU7800App.Instance.Settings.ROMDirectory = Directory.GetCurrentDirectory();
		}
		romFiles = new DirectoryInfo(EMU7800App.Instance.Settings.ROMDirectory).GetFiles();
	
		foreach (FileInfo fi in romFiles) {
			GameSettings gs = EMU7800App.Instance.ROMProperties.GetGameSettingsFromFile(fi);
			if (gs == null) {
				continue;
			}

			ROMFileCount++;

			TreeNode tn = new TreeNode(BuildTitle(gs.Title, gs.Manufacturer, gs.Year), 2, 2);
			tn.Tag = gs;
			tnTitle.Nodes.Add(tn);

			AddTreeNode(manuIndex, gs, gs.Manufacturer,
				gs.Title, gs.Year);
			AddTreeNode(yearIndex, gs, gs.Year,
				gs.Title, gs.Manufacturer);
			AddTreeNode(rareIndex, gs, gs.Rarity,
				gs.Title, gs.Manufacturer, gs.Year);
			AddTreeNode(machIndex, gs, gs.MachineType.ToString(),
				gs.Title, gs.Manufacturer, gs.Year);
			AddTreeNode(contIndex, gs, gs.LController.ToString(),
				gs.Title, gs.Manufacturer, gs.Year);
#if DEBUG
			AddTreeNode(cartIndex, gs, gs.CartType.ToString(),
				gs.Title, gs.Manufacturer, gs.Year);
#endif
			Application.DoEvents();
		}

		for (int i=0; i < tvROMList.Nodes.Count; ) {
			TreeNode c = tvROMList.Nodes[i];
			if (PruneTree(c)) {
				c.Remove();
			} else {
				i++;
			}
		}

		tvROMList.Sorted = true;
		tvROMList.EndUpdate();
		tvROMList.Update();
	}

	// Remove TreeNodes that have no dependencies
	private bool PruneTree(TreeNode p) {
		int score = 0;
		if (p.Nodes.Count > 0) {
			for (int i=0; i < p.Nodes.Count; ) {
				TreeNode c = p.Nodes[i];
				if (PruneTree(c)) {
					c.Remove();
				} else {
					score++;
					i++;
				}
			}
		}
		return (score == 0 && p.Tag == null);
	}

	private bool SelectTitle(string fullName) {
		FileInfo fi = new FileInfo(fullName);
		string md5sum = MD5.ComputeMD5Digest(fi);
		if (md5sum == null) {
			return false;
		}
		foreach (TreeNode tn in tnTitle.Nodes) {
			if (tn.Tag == null) {
				continue;
			}
			if (md5sum == ((GameSettings)tn.Tag).MD5Sum) {
				tvROMList.SelectedNode = tn;
				return true;
			}
		}
		foreach (TreeNode tn in tnUnknown.Nodes) {
			if (tn.Tag == null) {
				continue;
			}
			if (md5sum == ((GameSettings)tn.Tag).MD5Sum) {
				tvROMList.SelectedNode = tn;
				return true;
			}
		}
		return false;
	}

	private Hashtable AddTreeSubRoot(TreeView root, string label, string[] subList) {
		TreeNode tnparent = new TreeNode(label, 0, 1);
		root.Nodes.Add(tnparent);
		Hashtable index = new Hashtable();
		TreeNode tn;
		foreach (string s in subList) {
			tn = new TreeNode(s, 0, 1);
			tnparent.Nodes.Add(tn);
			index.Add(s, tn);
		}
		tn = new TreeNode("Other", 0, 1);
		tnparent.Nodes.Add(tn);
		index.Add("Other", tn);
		return index;
	}

	private void AddTreeNode(Hashtable index, GameSettings gs, string key,
			params string[] titlebits) {
		TreeNode tn = new TreeNode(BuildTitle(titlebits), 2, 2);
		tn.Tag = gs;
		if (key == null || !index.ContainsKey(key)) {
			key = "Other";
		}
		((TreeNode)index[key]).Nodes.Add(tn);
	}

	private string BuildTitle(params string[] titlebits) {
		StringBuilder title = new StringBuilder();

		for (int i=0; i < titlebits.Length; i++) {
			if (titlebits[i] == null) {
				titlebits[i] = "";
			}
			if (titlebits[i].Length > 0) {
				if (i > 0) {
					title.Append(", ");
				}
				title.Append(titlebits[i]);
			}
		}
		return title.ToString();
	}
}
}