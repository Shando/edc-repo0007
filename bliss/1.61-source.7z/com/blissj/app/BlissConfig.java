package com.blissj.app;

import java.awt.event.*;
import java.io.*;
import java.util.*;
import com.blissj.app.util.*;

public class BlissConfig
{

    public final static long CRC_EXECUTIVE_ROM = 0xCBCE86F7L;
    public final static long CRC_GROM          = 0x683A4158L;
    public final static long CRC_ECS_ROM       = 0xEA790A06L;
    public final static long CRC_IVOICE_ROM    = 0x0DE7579DL;
    public final static int SIZE_EXECUTIVE_ROM = 8192;
    public final static int SIZE_GROM          = 2048;
    public final static int SIZE_ECS_ROM       = 24576;
    public final static int SIZE_IVOICE_ROM    = 2048;

    //keys
    public final static String[] KEY = { "bliss", "config" };
    public final static String[] KEY_UI = {
            "bliss", "config", "ui" };
    public final static String[] KEY_GENERAL = {
            "bliss", "config", "general" };
    public final static String[] KEY_INPUT_LEFT_CONTROLLER = {
            "bliss", "config", "input", "player1" };
    public final static String[] KEY_INPUT_RIGHT_CONTROLLER = {
            "bliss", "config", "input", "player2" };
    public final static String[] KEY_INPUT_ECS_KEYBOARD = {
            "bliss", "config", "input", "keyboard" };

    //config values
    public final static String   VALUE_CARTRIDGE_DIRECTORY = "cartdir";

    //defaults
    public final static String   DEFAULT_CARTRIDGE_DIRECTORY = "roms";

}
