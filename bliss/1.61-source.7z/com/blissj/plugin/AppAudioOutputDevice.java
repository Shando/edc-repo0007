package com.blissj.plugin;

import java.text.*;
import javax.sound.sampled.*;
import com.bliss.core.devices.*;
import com.bliss.core.*;

public class AppAudioOutputDevice implements AudioOutputDevice
{

    public final static int SAMPLE_RATE_11025 = 11025;
    public final static int SAMPLE_RATE_22050 = 22050;
    public final static int SAMPLE_RATE_44100 = 44100;

    public Option[] getOptions() {
        return controllers;
    }

    public void init() {
        acquireChannel();
    }

    public int available() {
        return sourceDataLine.available();
    }

    public void playSamples(int[] samples, int numSamples) {
        if (sourceDataLine == null)
            return;

        for (int i = 0; i < numSamples; i++)
            playSample(samples[i]);
    }

    public void playSample(int sample) {
        if (sourceDataLine == null)
            return;

        frame[0] = (byte)(sample & 0x00FF);
        frame[1] = (byte)((sample & 0xFF00) >> 8);
        System.arraycopy(frame, 0, frame, 2, 2);
        if (sampleRate < SAMPLE_RATE_44100) {
            System.arraycopy(frame, 0, frame, 4, 4);
            if (sampleRate < SAMPLE_RATE_22050)
                System.arraycopy(frame, 0, frame, 8, 8);
        }
        sourceDataLine.write(frame, 0, frame.length);
    }

    public void setBufferLength(int millis) {
        if (bufferSizeInMillis == millis)
            return;
 
        bufferSizeInMillis = millis;
        if (sourceDataLine != null) {
            releaseChannel();
            acquireChannel();
        }
    }

    public int getBufferLength() {
        return bufferSizeInMillis;
    }

    public void setSampleRate(int rate) {
        this.sampleRate = rate;
        frame = new byte[(sampleRate == SAMPLE_RATE_11025 ? 16
                : (sampleRate == SAMPLE_RATE_22050 ? 8 : 4))];
    }

    public int getSampleRate() {
        return sampleRate;
    }

    public void release() {
        releaseChannel();
    }

    private void acquireChannel() {
        if (sourceDataLine != null)
            sourceDataLine.close();

        AudioFormat desiredFormat = new AudioFormat(
                AudioFormat.Encoding.PCM_SIGNED, 44100, 16, 2, 4, 44100, false);
        int bufferSizeInBytes = (int)(bufferSizeInMillis*(float)44100*
                (float)8)/1000;
        DataLine.Info desiredLine = new DataLine.Info(SourceDataLine.class,
                desiredFormat, bufferSizeInBytes);
        Line.Info[] infos = AudioSystem.getSourceLineInfo(desiredLine);
        try {
            sourceDataLine = (SourceDataLine)AudioSystem.getLine(infos[0]);
            sourceDataLine.open(desiredFormat, bufferSizeInBytes);
            sourceDataLine.start();
        }
        catch (LineUnavailableException lue) {
            //oh, well.  "NO SOUND FOR YOU!"
            sourceDataLine = null;
        }
    }

    private void releaseChannel() {
        if (sourceDataLine == null)
            return;

        sourceDataLine.close();
        sourceDataLine = null;
    }

    private SourceDataLine sourceDataLine;
    private int sampleRate = SAMPLE_RATE_11025;
    private byte[] frame = new byte[16];
    private int bufferSizeInMillis = 40;


    private Option[] controllers = {
            new ChoiceOption() {
                public String getCategory() {
                    return AppPlugIn.RESOURCES.getString("AppPlugInName");
                }
                public String getDescription() {
                    return AppPlugIn.RESOURCES.getString(
                            "SampleRateDescription");
                }
                public Object[] getChoices() {
                    return choices;
                }
                public String getDescription(Object choice) {
                    return ((Integer)choice).toString();
                }
                public void setValue(Object choice) {
                    setSampleRate(((Integer)choice).intValue());
                }
                public Object getValue() {
                    return new Integer(sampleRate);
                }
                private Integer[] choices = {
                        new Integer(SAMPLE_RATE_11025),
                        new Integer(SAMPLE_RATE_22050),
                        new Integer(SAMPLE_RATE_44100) };
            },
            new ChoiceOption() {
                public String getCategory() {
                    return AppPlugIn.RESOURCES.getString("AppPlugInName");
                }
                public String getDescription() {
                    return AppPlugIn.RESOURCES.getString(
                            "BufferLengthDescription");
                }
                public Object[] getChoices() {
                    return choices;
                }
                public String getDescription(Object choice) {
                    Object[] args = { choice };
                    return MessageFormat.format(choiceFormat, args);
                }
                public void setValue(Object choice) {
                    bufferSizeInMillis = ((Integer)choice).intValue();
                }
                public Object getValue() {
                    return new Integer(bufferSizeInMillis);
                }
                private Integer[] choices = {
                        new Integer(20),
                        new Integer(30),
                        new Integer(40),
                        new Integer(60),
                        new Integer(80),
                        new Integer(100),
                        new Integer(150),
                        new Integer(200) };
                private String choiceFormat = AppPlugIn.RESOURCES.getString(
                        "BufferLengthFormat");
            }
        };

}
