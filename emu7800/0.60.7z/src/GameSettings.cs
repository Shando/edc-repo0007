/*
 * GameSettings.cs
 * 
 * Represents attribute data associated with ROMs
 * 
 * Copyright 2003, 2004 (c) Mike Murphy
 * 
 */
using System;
using System.IO;
using System.Text;

namespace EMU7800 {

public class GameSettings {
	public string MD5Sum;
	public string Title, Manufacturer, Year, ModelNo, Rarity;
	public CartType CartType;
	public MachineType MachineType;
	public Controller LController, RController;

	public FileInfo FileInfo;

	public int Offset {
		get {
			return (FileInfo.Extension.ToLower() == ".a78") ? 128 : 0;
		}
	}	

	public override string ToString() {
		StringBuilder s = new StringBuilder("GameSettings:\n");

		s.AppendFormat(" MD5Sum: {0}\n", MD5Sum);
		s.AppendFormat(" Title: {0}\n", Title);
		s.AppendFormat(" Manufacturer: {0}\n", Manufacturer);
		s.AppendFormat(" Year: {0}\n", Year);
		s.AppendFormat(" ModelNo: {0}\n", ModelNo);
		s.AppendFormat(" Rarity: {0}\n", Rarity);
		s.AppendFormat(" CartType: {0}\n", CartType);
		s.AppendFormat(" MachineType: {0}\n", MachineType);
		s.AppendFormat(" LController: {0}\n", LController);
		s.AppendFormat(" RController: {0}\n", RController);

		s.AppendFormat(" FileName: {0}\n", FileInfo != null ? FileInfo.FullName : "<null>");
		if (FileInfo != null) {
			s.AppendFormat(" Size: {0}\n", FileInfo.Length);
		}

		return s.ToString();
	}

	public GameSettings(string md5Sum) {
		MD5Sum = md5Sum;
	}
}
}