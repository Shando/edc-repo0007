
#include "Win32PlugIn.h"

INT32 Win32PlugIn::init()
{
    INT32 result;
//    if (result = videoOutputDevice.init(inty->getCartridge()->getName())) {
    if (result = videoOutputDevice.init("BLISS")) {
		MessageBox(NULL,
			videoOutputDevice.getErrorDescription(result),
			"Video Initialization Error", MB_OK | MB_ICONERROR);
        return result;
    }
    if (result = audioOutputDevice.init()) {
        videoOutputDevice.release();
		MessageBox(NULL,
			audioOutputDevice.getErrorDescription(result),
			"Audio Initialization Error", MB_OK | MB_ICONERROR);
        return result;
    }
    if (result = inputDevice.init()) {
        videoOutputDevice.release();
        audioOutputDevice.release();
		MessageBox(NULL,
			inputDevice.getErrorDescription(result),
			"Input Initialization Error", MB_OK | MB_ICONERROR);
        return result;
    }
    return 0;
}

void Win32PlugIn::release()
{
    inputDevice.release();
    audioOutputDevice.release();
    videoOutputDevice.release();
}

BOOL Win32PlugIn::stopRequested()
{
	bool stop = (inputDevice.stop || videoOutputDevice.stop);

	inputDevice.stop = false;			// Prepare for next
	videoOutputDevice.stop = false;

    return (stop);
}

DirectXVideoOutputDevice* Win32PlugIn::getVideoOutputDevice() {
    return &videoOutputDevice;
}

DirectXAudioOutputDevice* Win32PlugIn::getAudioOutputDevice() {
    return &audioOutputDevice;
}

DirectInputDevice* Win32PlugIn::getInputDevice() {
    return &inputDevice;
}

Win32ClockDevice* Win32PlugIn::getClockDevice() {
    return &clockDevice;
}

