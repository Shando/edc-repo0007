numberguess - a simple demonstration program - guess my number

Usage:
This progrm expects the APPLE1 Integer BASIC loaded in ROM at 0xE000.

Load ASCII Binary (faux1 and replica1):
Open numberguess.woz with text editor and paste ASCII hex file into the WOZON.
Enter E2B3R into WOZMON to warm start BASIC.
> RUN

-or-

Load ASCII BASIC (faux1 and replica1):
Enter E000R to cold start BASIC.
Open numberguess.bas with text editor and paste ASCII text file into the BASIC.
> RUN

-or-

From the command line
./faux1 -a 300 -l apps/nuerguess.woz -c "e2b3r" -c "run"

2012-02-22
