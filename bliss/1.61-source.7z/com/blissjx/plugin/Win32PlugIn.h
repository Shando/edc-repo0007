
#ifndef WIN32PLUGIN_H
#define WIN32PLUGIN_H

#include <windows.h>
#include "DirectXVideoOutputDevice.h"
#include "DirectXAudioOutputDevice.h"
#include "DirectInputDevice.h"
#include "Win32ClockDevice.h"

class Win32PlugIn
{
    public:
		Win32PlugIn::~Win32PlugIn() {
			release();
		}

        INT32 init();
        void release();
        BOOL stopRequested();
        DirectXVideoOutputDevice* Win32PlugIn::getVideoOutputDevice();
        DirectXAudioOutputDevice* Win32PlugIn::getAudioOutputDevice();
        DirectInputDevice* Win32PlugIn::getInputDevice();
        Win32ClockDevice* Win32PlugIn::getClockDevice();

    private:
        DirectXVideoOutputDevice videoOutputDevice;
        DirectXAudioOutputDevice audioOutputDevice;
        DirectInputDevice        inputDevice;
        Win32ClockDevice         clockDevice;

};

#endif

