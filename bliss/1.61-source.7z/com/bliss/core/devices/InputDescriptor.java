package com.bliss.core.devices;

public interface InputDescriptor
{

    public String getDescription();

}
