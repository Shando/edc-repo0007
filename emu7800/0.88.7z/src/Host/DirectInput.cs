/*
 * DirectInput
 *
 * Utility class for acquiring input using DirectInput
 *
 * Copyright (c) 2007 Mike Murphy
 *
 */
using System;
using System.Diagnostics;
using Microsoft.DirectX.DirectInput;

namespace EMU7800.Host
{
    internal class DirectInput : IDisposable
    {
        private const int JOYSTICK_RANGE = 1000;
        private const int JOYSTICK_DEADZONE = 100;

        private volatile Device[] _Joysticks = new Device[2];
        private volatile Device _Mouse;

        private struct LastJoystickInput
        {
            public bool Left, Right, Up, Down, Fire, Fire2;
        };

        private struct LastPaddleInput
        {
            public int Val;
            public bool Fire;
        };

        private readonly LastJoystickInput[] _LastJoystickInput = new LastJoystickInput[2];
        private readonly LastPaddleInput[] _LastStelladaptorPaddleInput = new LastPaddleInput[2];
        private LastPaddleInput _LastMousePaddleInput;

        private readonly bool[] _IsStelladaptor = new bool[2];

        public delegate void JoystickChangedHandler(int joystickno, bool left, bool right, bool up, bool down, bool fire, bool fire2);
        public delegate void StelladaptorPaddleChangedHandler(int paddleno, int val, bool fire);
        public delegate void MousePaddleChangedHandler(int val, bool fire);
        public delegate void MouseChangedHandler(int x, int y, bool fire);

        public JoystickChangedHandler JoystickChanged;
        public StelladaptorPaddleChangedHandler StelladaptorPaddleChanged;
        public MousePaddleChangedHandler MousePaddleChanged;
        public MouseChangedHandler MouseChanged;

        public int MousePaddleRange { get; private set; }

        public static int StelladaptorPaddleRange
        {
            [DebuggerStepThrough]
            get { return JOYSTICK_RANGE << 1; }
        }

        public bool IsStelladaptor(int deviceno)
        {
            return _IsStelladaptor[deviceno & 1];
        }

        public void Poll()
        {
            if (_Joysticks[0] != null)
            {
                PollDevice(_Joysticks[0]);
                if (_IsStelladaptor[0])
                {
                    RaiseStelladaptorPaddleChanged(0);
                    RaiseStelladaptorPaddleChanged(1);
                }
                RaiseJoystickChanged(0);
            }
            if (_Joysticks[1] != null)
            {
                PollDevice(_Joysticks[1]);
                if (_IsStelladaptor[1])
                {
                    RaiseStelladaptorPaddleChanged(2);
                    RaiseStelladaptorPaddleChanged(3);
                }
                RaiseJoystickChanged(1);
            }
            if (_Mouse != null)
            {
                _Mouse.Poll();
                RaiseMousePaddleChanged();
                RaiseMouseChanged();
            }
        }

        void RaiseJoystickChanged(int deviceno)
        {
            if (JoystickChanged != null)
            {
                deviceno &= 1;
                var dev = _Joysticks[deviceno];
                if (dev != null)
                {
                    var left = dev.CurrentJoystickState.X < -JOYSTICK_DEADZONE;
                    var right = dev.CurrentJoystickState.X > JOYSTICK_DEADZONE;
                    var up = dev.CurrentJoystickState.Y < -JOYSTICK_DEADZONE;
                    var down = dev.CurrentJoystickState.Y > JOYSTICK_DEADZONE;
                    var fire1 = dev.CurrentJoystickState.GetButtons()[0] != 0;
                    var fire2 = dev.CurrentJoystickState.GetButtons()[1] != 0;
                    if (left != _LastJoystickInput[deviceno].Left
                        || right != _LastJoystickInput[deviceno].Right
                        || up != _LastJoystickInput[deviceno].Up
                        || down != _LastJoystickInput[deviceno].Down
                        || fire1 != _LastJoystickInput[deviceno].Fire
                        || fire2 != _LastJoystickInput[deviceno].Fire2)
                    {
                        _LastJoystickInput[deviceno].Left = left;
                        _LastJoystickInput[deviceno].Right = right;
                        _LastJoystickInput[deviceno].Up = up;
                        _LastJoystickInput[deviceno].Down = down;
                        _LastJoystickInput[deviceno].Fire = fire1;
                        _LastJoystickInput[deviceno].Fire2 = fire2;
                        JoystickChanged(deviceno, left, right, up, down, fire1, fire2);
                    }
                }
            }
        }

        void RaiseStelladaptorPaddleChanged(int paddleno)
        {
            if (StelladaptorPaddleChanged == null) return;

            paddleno &= 3;
            var dev = _Joysticks[paddleno >> 1];
            if (dev == null) return;

            var js = dev.CurrentJoystickState;
            var val = ((paddleno & 1) == 0) ? js.X : js.Y;
            val += JOYSTICK_RANGE;
            var fire = js.GetButtons()[paddleno & 1] != 0;
            if (val == _LastStelladaptorPaddleInput[paddleno].Val && fire == _LastStelladaptorPaddleInput[paddleno].Fire) return;

            _LastStelladaptorPaddleInput[paddleno].Val = val;
            _LastStelladaptorPaddleInput[paddleno].Fire = fire;
            StelladaptorPaddleChanged(paddleno, val, fire);
        }

        void RaiseMousePaddleChanged()
        {
            if (MousePaddleChanged == null) return;

            var ms = _Mouse.CurrentMouseState;
            var val = ms.X;
            var fire = ms.GetMouseButtons()[0] != 0;
            if (val == 0 && fire == _LastMousePaddleInput.Fire) return;

            _LastMousePaddleInput.Val += val;
            _LastMousePaddleInput.Fire = fire;
            if (_LastMousePaddleInput.Val < 0)
            {
                _LastMousePaddleInput.Val = 0;
            }
            else if (_LastMousePaddleInput.Val > MousePaddleRange)
            {
                _LastMousePaddleInput.Val = MousePaddleRange;
            }
            MousePaddleChanged(_LastMousePaddleInput.Val, _LastMousePaddleInput.Fire);
        }

        void RaiseMouseChanged()
        {
            if (MouseChanged == null) return;

            var ms = _Mouse.CurrentMouseState;
            MouseChanged(ms.X, ms.Y, ms.GetMouseButtons()[0] != 0);
        }

        public void Dispose()
        {
            if (_Joysticks[0] != null) _Joysticks[0].Unacquire();
            if (_Joysticks[1] != null) _Joysticks[1].Unacquire();
            if (_Mouse == null) return;
            _Mouse.Unacquire();
            _Mouse.Dispose();
            _Mouse = null;
        }

        public DirectInput(IntPtr handle)
        {
            MousePaddleRange = JOYSTICK_RANGE;
            var deviceno = 0;
            foreach (DeviceInstance i in Manager.GetDevices(DeviceClass.GameControl, EnumDevicesFlags.AttachedOnly))
            {
                if (deviceno >= 2) break;
                if (_Joysticks[deviceno] != null) continue;
                _Joysticks[deviceno] = new Device(i.InstanceGuid);
                PrepareDevice(_Joysticks[deviceno], handle);
                _IsStelladaptor[deviceno] = i.ProductName.Equals("Stelladaptor 2600-to-USB Interface");
                Trace.Write("DirectInput: P");
                Trace.Write(deviceno + 1);
                Trace.Write(" game controller detected: ");
                Trace.WriteLine(i.ProductName);
                _Joysticks[deviceno].Acquire();
                deviceno++;
            }

            foreach (DeviceInstance i in Manager.GetDevices(DeviceClass.Pointer, EnumDevicesFlags.AttachedOnly))
            {
                _Mouse = new Device(i.InstanceGuid);
                _Mouse.SetDataFormat(DeviceDataFormat.Mouse);
                _Mouse.SetCooperativeLevel(handle, CooperativeLevelFlags.NonExclusive | CooperativeLevelFlags.Background);
                _Mouse.Acquire();
            }
        }

        static void PrepareDevice(Device dev, IntPtr handle)
        {
            dev.SetDataFormat(DeviceDataFormat.Joystick);
            dev.SetCooperativeLevel(handle, CooperativeLevelFlags.NonExclusive | CooperativeLevelFlags.Background);
            foreach (DeviceObjectInstance d in dev.Objects)
            {
                if ((d.ObjectId & (int)DeviceObjectTypeFlags.Axis) != 0)
                {
                    dev.Properties.SetRange(ParameterHow.ById, d.ObjectId, new InputRange(-JOYSTICK_RANGE, JOYSTICK_RANGE));
                }
            }
        }

        static void PollDevice(Device dev)
        {
            try
            {
                dev.Poll();
            }
            catch (InputLostException)
            {
                dev.Acquire();
                dev.Poll();
            }
            catch (UnpluggedException)
            {
                if (dev != null)
                {
                    Trace.Write("DirectInput: ");
                    Trace.Write(dev.DeviceInformation.ProductName);
                    Trace.WriteLine(" unplugged");
                }
            }
        }
    }
}
