package com.blissj.plugin;

import java.awt.*;
import java.awt.event.*;
import javax.swing.KeyStroke;
import com.bliss.core.*;
import com.bliss.core.devices.*;

public class AppInputDevice implements InputDevice
{

    AppInputDevice() {
        signalsPlayerOne = new AppInputSignal[DEFAULTS_PLAYER_ONE.length];
        System.arraycopy(DEFAULTS_PLAYER_ONE, 0, signalsPlayerOne, 0,
                DEFAULTS_PLAYER_ONE.length);
        signalsPlayerTwo = new AppInputSignal[DEFAULTS_PLAYER_TWO.length];
        System.arraycopy(DEFAULTS_PLAYER_TWO, 0, signalsPlayerTwo, 0,
                DEFAULTS_PLAYER_TWO.length);
        signalsKeyboard = new AppInputSignal[DEFAULTS_KEYBOARD.length];
        System.arraycopy(DEFAULTS_KEYBOARD, 0, signalsKeyboard, 0,
                DEFAULTS_KEYBOARD.length);
        signalsEmulator = new AppInputSignal[DEFAULTS_EMULATOR.length];
        System.arraycopy(DEFAULTS_EMULATOR, 0, signalsEmulator, 0,
                DEFAULTS_EMULATOR.length);
    }

    public Option[] getOptions() {
        return Option.EMPTY_CONTROLLER_ARRAY;
    }

    public void poll() {
        //check to see if the user pressed escape
        if (keyMap[KeyEvent.VK_ESCAPE])
            stop = true;
    }

    public InputSignal getInputSignal(String configString) {
        try {
            return new AppInputSignal(Integer.parseInt(configString));
        }
        catch (NumberFormatException nfe) {
            return null;
        }
    }

    public InputSignal getInputSignal(int controlID) {
        if (controlID >= PLAYER_ONE_ID_START &&
                controlID <= PLAYER_ONE_ID_END)
        {
            return signalsPlayerOne[controlID - PLAYER_ONE_ID_START];
        }
        else if (controlID >= PLAYER_TWO_ID_START &&
                controlID <= PLAYER_TWO_ID_END)
        {
            return signalsPlayerTwo[controlID - PLAYER_TWO_ID_START];
        }
        else if (controlID >= KEYBOARD_ID_START &&
                controlID <= KEYBOARD_ID_END)
        {
            return signalsKeyboard[controlID - KEYBOARD_ID_START];
        }
        else if (controlID >= EMULATOR_ID_START &&
                controlID <= EMULATOR_ID_END)
        {
            return signalsEmulator[controlID - EMULATOR_ID_START];
        }
        return null;
    }

    public void setInputSignal(int controlID, InputSignal signal) {
        AppInputSignal inputSignal = (AppInputSignal)signal;
        if (controlID >= PLAYER_ONE_ID_START &&
                controlID <= PLAYER_ONE_ID_END)
        {
            signalsPlayerOne[controlID - PLAYER_ONE_ID_START] = inputSignal;
        }
        else if (controlID >= PLAYER_TWO_ID_START &&
                controlID <= PLAYER_TWO_ID_END)
        {
            signalsPlayerTwo[controlID - PLAYER_TWO_ID_START] = inputSignal;
        }
        else if (controlID >= KEYBOARD_ID_START &&
                controlID <= KEYBOARD_ID_END)
        {
            signalsKeyboard[controlID - KEYBOARD_ID_START] = inputSignal;
        }
        else if (controlID >= EMULATOR_ID_START &&
                controlID <= EMULATOR_ID_END)
        {
            signalsEmulator[controlID - EMULATOR_ID_START] = inputSignal;
        }
    }

    public InputSignal getDefaultSignal(int controlID) {
        if (controlID >= PLAYER_ONE_ID_START &&
                controlID <= PLAYER_ONE_ID_END)
        {
            return DEFAULTS_PLAYER_ONE[controlID - PLAYER_ONE_ID_START];
        }
        else if (controlID >= PLAYER_TWO_ID_START &&
                controlID <= PLAYER_TWO_ID_END)
        {
            return DEFAULTS_PLAYER_TWO[controlID - PLAYER_TWO_ID_START];
        }
        else if (controlID >= KEYBOARD_ID_START &&
                controlID <= KEYBOARD_ID_END)
        {
            return DEFAULTS_KEYBOARD[controlID - KEYBOARD_ID_START];
        }
        else if (controlID >= EMULATOR_ID_START &&
                controlID <= EMULATOR_ID_END)
        {
            return DEFAULTS_EMULATOR[controlID - EMULATOR_ID_START];
        }
        return null;
    }

    public InputSignal pollForInputSignal() {
        for (int i = 0; i < keyMap.length; i++) {
            if (keyMap[i])
                return new AppInputSignal(i);
        }
        return null;
    }

    public float getControlValue(int controlID) {
        AppInputSignal signal = null;
        if (controlID <= PLAYER_ONE_ID_END) {
            signal = signalsPlayerOne[controlID - PLAYER_ONE_ID_START];
        }
        else if (controlID <= PLAYER_TWO_ID_END) {
            signal = signalsPlayerTwo[controlID - PLAYER_TWO_ID_START];
        }
        else if (controlID <= KEYBOARD_ID_END) {
            signal = signalsKeyboard[controlID - KEYBOARD_ID_START];
        }
        else if (controlID <= EMULATOR_ID_END) {
            signal = signalsEmulator[controlID - EMULATOR_ID_START];
        }
        if (signal == null)
            return 0.0f;

        int keyCode = signal.keyCode;
        return (keyMap[keyCode] ? SIGNAL_ON : SIGNAL_OFF);
    }

    public void initConfigMode() {
        Toolkit.getDefaultToolkit().addAWTEventListener(keyListener,
                AWTEvent.KEY_EVENT_MASK);
    }

    public void releaseConfigMode() {
        Toolkit.getDefaultToolkit().removeAWTEventListener(keyListener);
        for (int i = 0; i < keyMap.length; i++)
            keyMap[i] = false;
    }

    public void init() {
        stop = false;
        Toolkit.getDefaultToolkit().addAWTEventListener(keyListener,
                AWTEvent.KEY_EVENT_MASK);
    }

    public void release() {
        Toolkit.getDefaultToolkit().removeAWTEventListener(keyListener);
        for (int i = 0; i < keyMap.length; i++)
            keyMap[i] = false;
    }

    boolean stop;
    private boolean[]        keyMap        = new boolean[0xFFFF];
    private AppInputSignal[] signalsPlayerOne;
    private AppInputSignal[] signalsPlayerTwo;
    private AppInputSignal[] signalsKeyboard;
    private AppInputSignal[] signalsEmulator;

    private final static AppInputSignal[] DEFAULTS_EMULATOR = {
            new AppInputSignal(KeyEvent.VK_F1),
            new AppInputSignal(KeyEvent.VK_F5),
            new AppInputSignal(KeyEvent.VK_F6),
            new AppInputSignal(KeyEvent.VK_F9),
            new AppInputSignal(KeyEvent.VK_F12)
        };

    private final static AppInputSignal[] DEFAULTS_PLAYER_ONE = {
            new AppInputSignal(KeyEvent.VK_UP),
            new AppInputSignal(KeyEvent.VK_PAGE_UP),
            new AppInputSignal(KeyEvent.VK_RIGHT),
            new AppInputSignal(KeyEvent.VK_PAGE_DOWN),
            new AppInputSignal(KeyEvent.VK_DOWN),
            new AppInputSignal(KeyEvent.VK_END),
            new AppInputSignal(KeyEvent.VK_LEFT),
            new AppInputSignal(KeyEvent.VK_HOME),
            new AppInputSignal(KeyEvent.VK_CONTROL),
            new AppInputSignal(KeyEvent.VK_Z),
            new AppInputSignal(KeyEvent.VK_X),
            null,
            null,
            null,
            new AppInputSignal(KeyEvent.VK_1),
            new AppInputSignal(KeyEvent.VK_2),
            new AppInputSignal(KeyEvent.VK_3),
            new AppInputSignal(KeyEvent.VK_4),
            new AppInputSignal(KeyEvent.VK_5),
            new AppInputSignal(KeyEvent.VK_6),
            new AppInputSignal(KeyEvent.VK_7),
            new AppInputSignal(KeyEvent.VK_8),
            new AppInputSignal(KeyEvent.VK_9),
            new AppInputSignal(KeyEvent.VK_0),
            new AppInputSignal(KeyEvent.VK_DELETE),
            new AppInputSignal(KeyEvent.VK_ENTER),
            null,
            null,
        };
    
    private final static AppInputSignal[] DEFAULTS_PLAYER_TWO = {
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null
        };

    private final static AppInputSignal[] DEFAULTS_KEYBOARD = {
            new AppInputSignal(KeyEvent.VK_A),
            new AppInputSignal(KeyEvent.VK_B),
            new AppInputSignal(KeyEvent.VK_C),
            new AppInputSignal(KeyEvent.VK_D),
            new AppInputSignal(KeyEvent.VK_E),
            new AppInputSignal(KeyEvent.VK_F),
            new AppInputSignal(KeyEvent.VK_G),
            new AppInputSignal(KeyEvent.VK_H),
            new AppInputSignal(KeyEvent.VK_I),
            new AppInputSignal(KeyEvent.VK_J),
            new AppInputSignal(KeyEvent.VK_K),
            new AppInputSignal(KeyEvent.VK_L),
            new AppInputSignal(KeyEvent.VK_M),
            new AppInputSignal(KeyEvent.VK_N),
            new AppInputSignal(KeyEvent.VK_O),
            new AppInputSignal(KeyEvent.VK_P),
            new AppInputSignal(KeyEvent.VK_Q),
            new AppInputSignal(KeyEvent.VK_R),
            new AppInputSignal(KeyEvent.VK_S),
            new AppInputSignal(KeyEvent.VK_T),
            new AppInputSignal(KeyEvent.VK_U),
            new AppInputSignal(KeyEvent.VK_V),
            new AppInputSignal(KeyEvent.VK_W),
            new AppInputSignal(KeyEvent.VK_X),
            new AppInputSignal(KeyEvent.VK_Y),
            new AppInputSignal(KeyEvent.VK_Z),
            new AppInputSignal(KeyEvent.VK_0),
            new AppInputSignal(KeyEvent.VK_1),
            new AppInputSignal(KeyEvent.VK_2),
            new AppInputSignal(KeyEvent.VK_3),
            new AppInputSignal(KeyEvent.VK_4),
            new AppInputSignal(KeyEvent.VK_5),
            new AppInputSignal(KeyEvent.VK_6),
            new AppInputSignal(KeyEvent.VK_7),
            new AppInputSignal(KeyEvent.VK_8),
            new AppInputSignal(KeyEvent.VK_9),
            new AppInputSignal(KeyEvent.VK_UP),
            new AppInputSignal(KeyEvent.VK_DOWN),
            new AppInputSignal(KeyEvent.VK_LEFT),
            new AppInputSignal(KeyEvent.VK_RIGHT),
            new AppInputSignal(KeyEvent.VK_COMMA),
            new AppInputSignal(KeyEvent.VK_PERIOD),
            new AppInputSignal(KeyEvent.VK_SPACE),
            new AppInputSignal(KeyEvent.VK_SEMICOLON),
            new AppInputSignal(KeyEvent.VK_COLON),
            new AppInputSignal(KeyEvent.VK_DEAD_GRAVE),
            new AppInputSignal(KeyEvent.VK_ENTER),
            new AppInputSignal(KeyEvent.VK_CONTROL),
            new AppInputSignal(KeyEvent.VK_SHIFT),
        };

    private AWTEventListener keyListener = new AWTEventListener() {
            public void eventDispatched(AWTEvent event) {
                KeyEvent ke = (KeyEvent)event;
                if (ke.getID() == KeyEvent.KEY_PRESSED)
                    keyMap[ke.getKeyCode()] = true;
                else if (ke.getID() == KeyEvent.KEY_RELEASED)
                    keyMap[ke.getKeyCode()] = false;
            }
        };

    private static class AppInputSignal implements InputSignal
    {
        public AppInputSignal(int keyCode) {
            this.keyCode = keyCode;
            this.description = "'" + KeyEvent.getKeyText(keyCode) + "'";
        }

        public String getDescription() {
            return description;
        }

        public String getConfigString() {
            return Integer.toString(keyCode);
        }

        private int keyCode;
        private String description;
    }

}
