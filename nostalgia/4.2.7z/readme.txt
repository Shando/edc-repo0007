Nostalgia, an Intellivision Emulator

by Joe Fisher
joe@shiny-technologies.com

------ Version 4.2 Updates --------------------------------
  Added a screen saver!  Press <CTRL + S> from any of the
    menus to activate it.
  Applied some optimizations to greatly increase the speed
    of the emulator engine.  This means Nostalgia will run
    at full speed on more computers.
  Added Kaillera network support!  Run from the command line
    with the -k switch, or run from inside Nostalgia.
  Fixed a GLARING bug in initial multiplayer implementation.
  Added the ability to customize other keys, like screenshot,
    sound enable, etc.  Edit controls.cfg to change them
    Valid values are found in controls.txt.
  Fixed the "Ice Trek" bug that prevented you from getting to
    the last screen.
  Fixed some odd bugs in joystick handling.
  Updated Ice Trek bug fix with Joe Z's new info.  Thanks, Joe!
  Fixed a series of bugs with the display of moving objects.
  Small updates to sound emulation for accuracy
  Fixed a bug in the way controls.cfg was saved.  Thanks to
    Rick for finding this one.

Debugger:
  Fixed a bug that prevented certain games from loading.
-----------------------------------------------------------

Scroll down to the bottom to see the rest of the change log.


  Hello, and thanks for trying my emulator! It's my first stab at an emulator of any sort.  
I chose the Inty because when I think of childhood video game fun, the one thing that 
pops into my head is playing Tron and the Deadly Discs with my dad, competing for the 
highest score, taking out the Recognizer, striving for 1,000,000 points so I could see 
the orange guys with the sticks they showed in the instruction manual.  *sigh*  

    I have to send out an *ENORMOUS* thank you to Joe Zbiciak, Inty genius and creator 
of "jzIntv", and Kyle Davis, all around nice guy and creator of "Bliss".  These two emulators 
were a big part of my inspiration, and the guys themselves were critical to the development 
of Nostalgia.  Kyle was extremely helpful in lending advice and sample code, and Joe used 
his superhuman powers of perception to detect bugs in my code before I could even type it.

    I couldn't have done it without you guys (or it would've taken me 6 years), so I just
wanted to let you know you're appreciated :)

    Thank you to Steve Orth and all who have made suggestions to improve Nostalgia.    

    And while I'm thanking people, thank you to my wonderful wife Lizzie,
who tolerated me staying up until 2am more than a few nights working on this 
(and I'm sure there'll be more), and for coming up with the name and great title 
screen for "Nostalgia".

--------------------------------------

*--- Running the program

    Put the Exec and Grom files in the same directory you installed Nostalgia into,
run Nostalgia, and select "Load Cartridge" from the main menu.
    You can point Nostalgia to your existing ROM directory by using the Game Options,
or dump all of your ROMS in the existing "roms" directory.

*--- Command line options

    You may specify the screen resolution, whether or not to use ECS and the game to 
run on the command line.  If you specify a game on the command line, Nostalgia will
skip the menu system and immediately run the game.

Valid Options:
-WxH or /WxH           : Run in WxH resolution eg. -320x240, /640x480, etc.
-ECS or /ECS           : Use the ECS
-NOECS or /NOECS       : Do not use the ECS even if available
-IVOICE or /IVOICE     : Use the Intellivoice
-NOIVOICE or /NOIVOICE : Do not use the Intellivoice, even if available
-p:pal.bmp or
/p:"some pal.bmp"      : Specify a new palette to use.  See palettes below.
-c:file.txt or
-c:"some file.txt"     : Specify a file for controller options.
-l or /l               : Skip the main menu screen and go directly to the
                           load cart screen.

  Anything without a / or - in front of it will be considered a path to a
cartridge.  This can be either relative or absolute.  If that path has spaces
in it, please enclose it in double or single quotes.

These are all valid command lines:

Nostalgia -800x600
Nostalgia -320x200 -ecs "c:\my games\inty\world series baseball.bin"
Nostalgia /NOecs 'C:\emus\roms\snafu.rom' /1024x768
Nostalgia 'c:\program files\games\my roms\atlantis.bin'
Nostalgia "c:\program files\games\my roms\atlantis.bin"
Nostalgia c:\progra~1\games\my~1\atlantis.bin
Nostalgia ..\..\myRoms\atlantis.bin


*--- Palettes

    Palettes are now customizable.  You can take a screenshot <F12> to get an 8 bit
palettized bitmap of your favorite game.  Then load up your photo editor, and tweak the
palette until it's what you want.  Now, use the -p: command line option to load it back
in.  It'll be saved for future use in the registry.
    Alternately, you can manually edit the palette in the GUI.  You can also export
an existing palette to a bmp file.

*--- Running the program in Network mode

    Select "Network Play" from the main menu, and you will be sent to the Kaillera setup
dialog.  Choose the server to connect to, then have one player create a game.  The other
players will then join that game.  You can also run Nostalgia with the /k command line
switch to go directly to the Kaillera dialog.

*--- Controls

-Joysticks:
    Nostalgia will take the first two joysticks available in the system and make them the 
Left and Right hand controllers in that order.  The stick emulates the disc on the Inty's 
hand controller, and buttons 1, 2, and 3 are the Top, Left and Right buttons respectively.


-Keyboard:

    Default key mapping is as below, and it can be changed:

        Left:                 Right:
        (Numeric
        Keypad)

-Inty Keypad

123        789                123
456        456                QWE
789        123                ASD
C0E        .0<enter>          ZXC

-Inty Buttons

Top:        Home              Leftshift
Left:       Delete            Leftcontrol
Right:      PageDown          Leftalt

-Inty Disc

Up:         Uparrow           I
Left:       Leftarrow         J
Right:      Rightarrow        L
Down:       Downarrow         K

-Miscellaneous

These keys can be changed by editing controls.cfg:

<F1>       Open chat window in Multiplayer
<F4>       Toggle Sound On/Off
<F5>       Save game state
<F6>       Toggle Frame Rate / Frame Skip display
<F7>       Restore game state
<F8>       Begin / end AVI movie recording.
<F9>       Pause game
<F10>      Begin / end WAV sound recording.
<F11>      Reset
<F12>      Save screenshot
<ESC>      Quit current game (cannot be changed)
<Numpad +> Increase frame skip rate - if game is choppy
<Numpad -> Decrease frame skip rate - for better video quality

 In the menu system only:
<ESC>      Go back a menu/cancel changes
<ENTER>    Accept changes
<F12>      Leave Nostalgia

*--- Box and Overlay images

    Nostalgia comes with 10 box and overlay images thanks to Steve Orth of the 
IntvFunhouse (http://intvfunhouse.com).  You can add your own by putting your image in the 
images folder (you can change the location of this folder in the options) and making it the 
same name as the game.  Check in the games.cfg if you're not sure of the name to use for 
the game in question.  An overlay image has the same name with "_overlay" at the end.  The 
files can be in BMP, GIF or JPG format.  Some examples:

Tron Deadly Discs.jpg
Tron Deadly Discs_overlay.jpg
Lock 'n' Chase.gif
Lock 'n' Chase_overlay.bmp


Have fun, and please let me know what you think.

             Joe

------ Version 4.1 Updates --------------------------------
  Game Manuals are now supported!  Manuals must be in text format, and have
    the same name as the box image file.  They go in the Manuals folder,
    which is customizable in the dbTool.  eg:
      Astrosmash - Meteor.jpg   Image
      Astrosmash - Meteor.txt   Manual
  Mousewheel is now supported in the cart loader and manual viewer screens.
  Keyboard now functions when CGC is connected.
  CGC is now enabled by default if it is connected.
  You can now use CGC or Joystick in the menu screens.
  dbTool will now save any changes to the current ROM when you press Save -
    you no longer have to press "Update Entry" if you're just editing the
    one file.
  HUGE bug in command line handling fixed.  Thanks to Jason for reporting.
  Fixed a bug in the Intellivoice / ECS switches in the database.
  
------ Version 4.0 Updates --------------------------------
  INTELLIVOICE!!!  Yes, the Intellivoice is now supported!  Drop
    in the ivoice.bin (or whatever yours in named) and listen to
    that sweet, sweet robitic voice.
  You can now have Nostalgia automatically update your video frame
    skip.  This will allow Nostalgia to adjust its frame rate to 
    match your hardware speed.  Enabled by default.
  ECS and Intellivoice are now controlled by switches in the game
    database.  You will not have to manually enable them.  They can
    still be manually forced on/off via command line switches.
  You can now select an option to go directly to the load cart
    screen, skipping the main menu entirely.  Thanks, David!
  New command line switches:
    -IVOICE -NOIVOICE : force the Intellivoice on or off.
    -l : Go directly to the cart loader screen.
  ".itv" added to the list of acceptable cartridge extensions.
  Tremendously improved error reporting inside the game.  You'll
    now have more information on why your favorite game won't load.

Debugger updates:
  Massive improvement to tracing interface.  You can now specify
    an arbitrary number of log and break points.  They will be
    saved in triggers.cfg, which is human-readable and editable.
  You can now view the logfile via a button on the main interface.
    You can also set a flag to have the logfile pop up after 
    each run.
  Tracing now handles Intellivoice instructions.  The jumps even
    tell you which subroutine in ROM you're jumping into.
  HUGE increase in speed in the trace dump operation.
  Added options to change how memory gets initialized on startup.
  
------ Version 3.9 Updates --------------------------------
  The game folder is no longer rescanned every time Nostalgia is run.
    It is only rescanned if the folder contents have changed.
  There is now a database management tool for maintaining and updating
    the database.
  The MiniExec and MiniGrom have been renamed so they don't overwrite any
    existing Exec and Grom files.
  Better handling of .cfg files.  Now supporting Write Only Memory.
  Keyboard Navigation in the menus.  Thanks, James!
  Added Hardware Stretch.  Now you can use a high rez video mode
    and stretch the image full screen for that fuzzy, retro
    bad TV feeling!  Does not work well on some video cards.
  Added the ability to edit the game palette.  Think my color choices
    need some tweaking?  Head into Game Options and edit until your
    little heart's content.  BIG thanks to David Trammell for this idea.
  Added visual feedback to button presses.
  You can now specify a combination of two keys to map to a single input.
    For example, you can map UPARROW and LEFTARROW to together send
    the NORTHWEST command to the Intellivision.  Thanks to Rick
    Reynolds for this one!
  Palettes can be exported to a bmp file.  They can be imported via the
    command line.  -p:mypal.bmp  The new palette will be saved to the
    registry.
  Screenshots are now saved in 8 bit palettized format.  Why?  This
    allows you to take a screenshot of your favorite game and load it
    into your favorite photo editor.  You can now mess with the palette
    and see exactly what your changes will do.  Now just load that palette
    into Nostalgia, and you're set to go!
  Screenshots are now saved with a new naming convention:
    cartname_mmddHHMMSS.bmp
    mmonth, dday, HHour, MMinute, SSecond.
  New hand controller file.  Made easier to use for those working with a 
    frontend or game cab.  Default file is controls.cfg.  See controls.txt
    for a listing of possible values.
  New command line switch -c:file.ext.  This allows you to specify a
    controller file to use.  Now you can have separate files for different
    games.
  You can now export your hand controller file.  It will generate a text
    file in the captures directory.
  Fixed a bug that prevented the ECS options screen from working.
  Made mouse movement a lot smoother in Menus.
  The keyboard is now enabled when using the CGC.
  Refinements to the input system to make it more reliable and
    maintainable.
  Changed ECS and IVoice options to be checkboxes instead of popping up
    a new window.
  More video changes to speed things up.
  Changes to sound routines to fix a slight bug.
  Changes to sound handling to drop sound frames if game is running too
    slowly.
  Fixed another bug with video capture.
  Fixed some problems with the menuing system and gfx display.
  Network play has been disabled pending updates.
  Fixed some problems in the input routines that caused crashes under
    certain circumstances.
  SPACEBAR now goes to the next game in the Load Cart screen.

Debugger updates:
  HUGE increaswe in speed in the trace and trace dump operations.
  Now sound stops playing when you pause.
  General updates to robustness.

--------------------------------------
Updates since version 3.6a:
  More video optimization.
  You can now ESCAPE out of Nostalgia from the main menu.
  Fixed massive problems with AVI capture.
  Made AVI captures smoother.

Debugger updates:
  Many changes to keyboard navigation for better ease of use.

--------------------------------------
Updates since version 3.5:
  Optimized the display and input routines to more than double the frame rate!
    This will allow Nostalgia to run more smoothly on more PCs.
    Thanks to Joe Zbiciak for his contributions.
  Games that use the ECS now turn it on automatically when played.
  Added a frame rate counter.  Press <F6> to enable / disable.
  Nostalgia now supports any display mode your video card does!
    Look in the Game Options screen to try them out.
  Configuration now stored in the Regsitry.
  The command line now allows you to set the resolution in -WxH format.
    (eg. -640x480)  The format will be verified against the list of available
    modes, and error.log will tell you if it was invalid.
  Nostalgia now comes with Joe Zbiciak's MiniExec and MiniGrom so you can play
    games "right out of the box."
  There are now many homebrew games packaged with Nostalgia.  Thanks to Arnauld
    Chevallier, Joe Zbiciak and Ryan Kinnen for providing them.
    See README.HTML to find out more about them.
  Added a Windows Installer.
  Added throttling for play with no sound.
  Added option and hotkey <F4> to turn sound on/off.
  Added notification of MiniExec support.  Games can be marked supported in
    "Add to Database" button on the Load Cartridge screen.
  Made the display more accurate to a real Intellivision.  Thanks to Steve
    Orth, Arnauld Chevallier, and Joe Zbiciak.
  Fixed usability issues with the menuing system like:
    Notification of delays when loading the cartridge list.
    Pageup/Pagedown support in the scrollbars for choosing Rom/Image folders.
    Display of Rom/Image files while browsing for Rom/Image folders.
  Fixed a bug that caused a crash when opening up large numbers of roms.
  Fixed a bug in Nostalgia's database preventing Super Soccer from running.
  Fixed a bug that caused the sound to disappear after loading many games.
  Fixed 2 bugs that caused crashes under certain conditions.
  Fixed a bug that kept Tron Solar Sailer from working.  Thanks Steve Orth
    and Joe Z.
  Fixed a bug that caused games like Mission X to seem to wrap around the
    screen.  Thanks to Marco Turconi for finding this one.
  Fixed gross inaccuracies in the sound and video emulation.  Thanks, Joe Z.

Debugger-specific updates:
  Improvements to the speed of the debugger.
  Debugger can now run in 16, 24 or 32 bit display modes, not just 16.
  The debugger now remembers the last game you chose so you don't have to
    reselect the game to re-run it every time.
  Games are now properly loaded from the command line in the debugger.
  The trace window now follows along when stepping rather than reloading
    every time.
  Added optional throttling when sound is off.
  Added a help dialog to the debugger, <F1>.
  Debugger now keeps track of the last folder you opened a rom from.
  Fixed a debugger bug preventing <F10> from working as expected.
  Fixed a debugger bug causing a crash on exit.
  Fixed a bug preventing the debugger from finding the EXEC and GROM files.

--------------------------------------
Updates since version 3.3:
  Added the ability to run with nonstandard EXEC and GROM files, such as the
    miniexec and minigrom provided with Joe Zbiciak's SDK-1600. Just name the
    files "exec.bin" and "grom.bin" and drop them in the folder with Nostalgia.
    Added the ability to use either joystick to move the mouse cursor.  Thanks
    to Steve Hoogerhyde for suggesting this one.
  Greatly enhanced keyboard navigation in the menus.  <ESC> now goes back a
    menu or selects "Cancel".  <ENTER> selects "Save".
  Fixed a bug in the colorstack display routine.  Thanks to Joe Zbiciak for
    discovering this and mysteriously knowing exactly where the problem was.
  Fixed a bug Chuck Whitby was kind enough to find for me.  What a guy!
  Fixed a bug that was preventing Chess in Triple Action from working.

--------------------------------------
Updates since version 3.2:
  AVI format movies can now be recorded while playing a game!  By pressing <F8>, 
    all screen activity and sound is recorded to an AVI file at a maximum of
    15 frames per second.
  Screen captures are now saved in Windows Bitmap format.
  Screenshots and other captures now reside in their own directory.
    \nostalgia\captures\
  Captures are now named based on the game you're playing.  For example, a sound
    caputre while playing Atlantis might look like:
      Atlantis00001.wav
  Multiple captures are now possible, up to 99999 separate captures of a type per
    game.  For example, if you took 3 screenshots while playing Snafu, they would
    be saved as:
      Snafu00001.bmp
      Snafu00002.bmp
      Snafu00003.bmp
  Old capture files will never be overwritten by Nostalgia.  A new filename is
    chosen each time.
  Command line options have been redone for flexibility. See "Command Line Options"
    below for more information.

--------------------------------------
Updates since version 3.1:
  Added Sound Capture capability!  Now, by pressing <F10>, whatever sounds and 
    music are playing in the game get recorded to a wave file.  Capture those cool
    Snafu snake noises, or use some Astrosmash sounds on your desktop! 
  A big "Thank You" to Jorg Schafer for this feature. 
  Ein grosses "danken Ihnen" zu Jorg Schafer f�r diese Eigenschaft. 
  Added 2 command line options:
    A rom may now be specified on the command line in quotes 
      (nostalgia "c:\roms\digdug.bin") to allow the use of frontends for Nostalgia. 
      Thanks to Remi Juneau for this one.
    The screen resolution may be specified on the command line.
      320, 640, 800, 1024.


--------------------------------------
Updates since version 3.0:
  Fixed a bug in the Networking that was preventing Network play.
  Fixed type ahead to work with numeric game names (4-Tris, etc)
  Added "Home" and "End" capability to Load Cartridge screen.
  Changed the way video memory is used to fix a problem that was causing Nostalgia
    to stop working unexpectedly on some video cards.
  Generally reworked code for more efficiency, especially the core chip code.

--------------------------------------
Updates since version 2.5:
  Added ECS support!  Keyboard and music keyboard are supported.
  Added a real Windows help file.
  Made more improvemnts to the menuing system.
  Added "Type Ahead" to the Load Cartridge screen.  You may now press the first
   letter of the game you want to play to jump to it in the list.
  Made improvements to the way joysticks are handled to allow multiple joysticks
   with the same name to function properly.
  Fixed a big, ugly bug in the joystick routine that was causing a dump from
    the game under certain circumstances.  Thanks to Michael Mellor for catching
    this one.
  Changed the quick save and restore to properly save and restore ECS and 
   ROM format games.

Debugger-specific updates:
  Added the ability to look at the main memory map, the cartridge map or ECS ROM.
  Added selections for ECS support and Intellivoice support (Intellivoice not
   actually supported, yet)

--------------------------------------
Updates since version 2.2: 
  Added the ability to open games that aren't in Nostalgia's database.  Any game that
   is in ROM format or has a config (.cfg) file with it can be opened.
  Complete support for Intellicart ROM format.
  Complete support for Intellicart ROM bankswitching.
  Removed a lot of annoyances in Nostalgia.  Having to press a key at the splash
   screen, the initial dialog box, and other nitpicky things.
--------------------------------------
Updates since version 2.0: 
  Added the "Add File to Database" button.  This allows a new game to be added to
  Nostalgia's database.
  Added preliminary support for Intellicart ROM file format.
  Overhauled the sound system.
  Added support for the Classic Game Controller interface (more on this later).
--------------------------------------
Updates since version 1.0: 
  Added support for playing Nostalgia over the Internet!
  Needs *much* more testing.  There still may be sync problems, and the client player
   can't do much other than play the game.
--------------------------------------
