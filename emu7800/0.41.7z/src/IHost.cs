/*
 * IHost.cs
 * 
 * An interface of an emulator host.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */

using System;

namespace EMU7800 {

public interface IHost {
	void Run();
	void UpdateDisplay(byte[] buf, int scanline, int start, int len);
	void UpdateSound(byte[] buf);
}
}
