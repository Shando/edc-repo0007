/*
 * Dapple ][ Emulator  Version 0.05
 * Copyright (C) 2002, 2003 Dapple ][ Development.  All rights reserved.
 *
 * Component:  Memory: routines for emulating 128Kb Apple ram
 * Revision:   (0.05) 2003.0129
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <stdio.h>
#include <string.h>
#include <dos.h>
#include "asmlib.h"
#include "dapple.h"

/* dapple.c */
extern unsigned int window;
extern unsigned int keyboard;
extern unsigned char appletype;
extern unsigned char inidebugflag;
extern unsigned char messageflag;
void applereset();

extern unsigned char HDDROM[256];
extern unsigned char *shiftstate;
extern unsigned char dqhdv;
extern unsigned char dqshift;

/* video.c */
extern unsigned char virtgraphic;
extern unsigned char virtmixed;
extern unsigned char virtpage2;
extern unsigned char virthgr;
extern unsigned char virt80col;
extern unsigned char virtaltchar;
extern unsigned char virtdhres;
extern unsigned char virtiou;
extern unsigned int virtcachemode;
extern unsigned char virtvideobyte;
void virtsetmode();
void virtwrite0400      (unsigned int address);
void virtwrite0400aux   (unsigned int address);
void virtwrite0800      (unsigned int address);
void virtwrite0800aux   (unsigned int address);
void virtwrite2000      (unsigned int address);
void virtwrite2000aux   (unsigned int address);
void virtwrite4000      (unsigned int address);
void virtwrite4000aux   (unsigned int address);

/* cpu65c02.c */
extern unsigned int rasterline;
extern unsigned int cycle;

/* disk.c */
unsigned char driveread(unsigned int addr);
void drivewrite(unsigned int addr, unsigned int value);

/* joystick.c */
unsigned int joya();
unsigned int joyb();

/* other */
unsigned char ReadRawDiskIO  (unsigned int addr);
unsigned char ReadMassStorIO (unsigned int addr);
void WriteParallel   (unsigned int addr, unsigned int value);
void WriteRawDiskIO  (unsigned int addr, unsigned int value);
void WriteMassStorIO (unsigned int addr, unsigned int value);


/* flags that handle memory access */
unsigned char memrompath[256];
unsigned char memram[0x28000];          /* main and aux memory + 32kb rom                       */
unsigned char memkey;                   /* apple key                                            */
unsigned int  memjoyx;                  /* apple joystick x                                     */
unsigned int  memjoyy;                  /* apple joystick y                                     */
unsigned char memjoybutton0;            /* apple open button                                    */
unsigned char memjoybutton1;            /* apple close button                                   */
unsigned int  memjoycycle;              /* timer counter                                        */
unsigned char memauxread;               /* read motherboard ram or aux ram                      */
unsigned char memauxwrite;              /* write motherboard ram or aux ram                     */
unsigned char memstore80;
unsigned char memintcxrom;              /* read from slot rom $c100-$cfff or internal rom       */
unsigned char memslotc3;                /* read from slot rom $c300-$c3ff or internal rom       */
unsigned char memlcaux;                 /* read $0-$1ff + $d000-$ffff from main or aux memory   */
unsigned char memlcramr;                /* read LC RAM or ROM?                                  */
unsigned char memlcramw;                /* write LC RAM or ROM?                                 */
unsigned char memlcbank2;               /* read from LC bank 1 or LC bank 2                     */
unsigned char memann3;                  /* annunciator #3                                       */
unsigned char memnolc;                  /* Is there a LC card installed?                        */
unsigned char memclearmode;             /* memory clear pattern                                 */

/* flags for sound */
unsigned char soundflag;


/*-------------------------------------*/


      void soundinit() {

        soundflag = 1;

      } /* soundinit */


/*-------------------------------------*/


      void soundclick() {
        register int al;

        if (soundflag) {
        /* Toggle the speaker */
          al = inportb(0x61);
          al ^= 0x02;
          al &= 0xfe;
          outportb(0x61,al);
        }
      } /* click */


/*-------------------------------------*/


      void soundmenu () {
        unsigned int screen;
        unsigned int keyboard;
        unsigned int window;
        unsigned char key;
        unsigned char update;

        screen = screenstore();
        if (!windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1, "Sound Options", &keyboard, &window)) {

          update = 1;
          do {
            if (update) {
              channelout(window, 12);           /* clear window */
              stringwrite(window, "\r[ESC] - Quit\r");

              stringwrite(window, "\r\r[S] - Speaker: ");
              if (soundflag) {
                stringwrite(window, "enabled");
              }
              else {
                stringwrite(window, "disabled");
              }

              imageupdate();
              update = 0;
            }
            do {
              key = (unsigned char)channelin(keyboard);
            }
            while ((key == 0) && (!exitprogram));
            switch (key) {
              case 's' :
              case 'S' :
                soundflag = !soundflag;
                update = 1;
                break;
            } /* switch (key) */
          }
          while ((key != 27) && (key != 32) && (key != 13) && (!exitprogram));
          channelclose(keyboard);
          channelclose(window);
        }
        screenrestore(screen);

      } /* soundmenu */


/*-------------------------------------*/


      void memoryreset() {

        memkey          = memkey & 0x7f;
        memauxread      = 0;
        memauxwrite     = 0;
        memintcxrom     = 0;            /* read from slot rom $c100-$cfff               */
        memslotc3       = 0x80;         /* read slot rom                                */
        memlcaux        = 0;            /* read $0-$1ff + $d000-$ffff from main memory  */
        memlcramr       = 0;            /* read ROM                                     */
        memlcramw       = 0;            /* write ROM?                                   */
        memlcbank2      = 0;            /* read from LC bank 1                          */
        memstore80      = 0;            /* 80 store off                                 */
        memann3         = 0x80;         /* annunciator #3 on                            */

        memjoycycle     = cycle;

      } /* MemoryReset */


/*-------------------------------------*/


      void memoryclear() {
        register unsigned int i;

        switch (memclearmode) {
          case 0 :
            break;
          case 1 :
            for (i=0; i<0x20000; i++) {
              memram[i] = 0;
//          memset(memram,0x00,0x20000);
            }
            break;
          case 2 :
            for (i=0; i<0x20000; i++) {
              memram[i] = 0xea;
//          memset(memram,0xea,0x20000));
            }
            break;
        } /* switch (memclearmode) */
        memkey = 0;

      } /* memoryclear */


/*-------------------------------------*/


      void memorysetclearmode(unsigned char value) {

        if (value < 3) {
          memclearmode = value;
        }

      } /* memorysetclearmode */


/*-------------------------------------*/


      unsigned char memorygetclearmode() {

        return memclearmode;

      } /* memorygetclearmode */


/*-------------------------------------*/


      void memoryinit() {

        memorysetclearmode(1);
        memoryclear();
        memnolc = 0;
        memjoyx         = 0x575;
        memjoyy         = 0x575;
        memjoybutton0   = 0;
        memjoybutton1   = 0;
        memoryreset();
        strcpy(memrompath, "apple2e.rom");

      } /* memoryinit */


/*-------------------------------------*/


      unsigned int memoryloadrom (unsigned int keyboard, unsigned int window, unsigned char *newrompath) {
        FILE *file;
        unsigned int filelength;
        register unsigned int i;

        if (!*newrompath) return 0;
        stringwrite(window, "Initializing Apple...\r");
        imageupdate();

        stringwrite(window, "Attempting to load Apple Rom '");
        stringwrite(window, newrompath);
        stringwrite(window, "'...\r");

        file=fopen(newrompath,"rb");
        if (!file) {
          stringwrite(window, "Sorry, I can't seem to open the rom file.\r");
          stringwrite(window, "Press any key to continue...\r");
          imageupdate();
          do { }
          while ( (unsigned char)channelin(keyboard) == 0);
          return 0;
        }

        strcpy(memrompath,newrompath);

        fseek(file,0,SEEK_END);
        filelength=ftell(file);
        fseek(file,0,SEEK_SET);
        stringwrite(window, "Reading rom file...\r");
        imageupdate();
        switch (filelength) {
          case 12288 :
            fread(&memram[0x21000],12288,1,file);       /* read rom */
            for (i=0; i<0x1000; i++) {
              memram[i+0x20000] = 0;                    /* clear INTCXROM */
              memram[i+0x24000] = 0;                    /* clear slot rom */
              memram[i+0x25000] = memram[i+0x21000];    /* copy rom */
              memram[i+0x26000] = memram[i+0x22000];
              memram[i+0x27000] = memram[i+0x23000];
            }
            appletype = '+';            /* machine is AppleII+ */
            break;
          case 16128 :
            fread(&memram[0x20100], 3840,1,file);       /* read INTCXROM */
            fread(&memram[0x21000],12288,1,file);       /* read rom */
            for (i=0; i<0x1000; i++) {
              memram[i+0x24000] = 0;                    /* clear slot rom */
              memram[i+0x25000] = memram[i+0x21000];    /* copy rom */
              memram[i+0x26000] = memram[i+0x22000];
              memram[i+0x27000] = memram[i+0x23000];
            }
            appletype = 'e';            /* machine is AppleIIe */
            break;
          case 16384 :
            fread(&memram[0x21000],12288,1,file);       /* read rom */
            fread(&memram[0x24000], 4096,1,file);       /* read slot rom */
            for (i=0; i<0x1000; i++) {
              memram[i+0x20000] = 0;                    /* clear INTCXROM */
              memram[i+0x25000] = memram[i+0x21000];    /* copy rom */
              memram[i+0x26000] = memram[i+0x22000];
              memram[i+0x27000] = memram[i+0x23000];
            }
            appletype = '+';            /* machine is AppleII+ */
            break;
          case 20480 :  /* ApplePC/AppleWin 12K */
            fseek(file,4096,SEEK_SET);
            fread(&memram[0x24000],4096,1,file);        /* read slot rom */
            fread(&memram[0x21000],12288,1,file);       /* read rom */
            for (i=0; i<0x1000; i++) {
              memram[i+0x20000] = 0;                    /* clear INTCXROM */
              memram[i+0x25000] = memram[i+0x21000];    /* copy rom */
              memram[i+0x26000] = memram[i+0x22000];
              memram[i+0x27000] = memram[i+0x23000];
            }
            appletype = '+';            /* machine is AppleII+ */
            break;
          case 32768 :  /* this gets false positive on //c BIOS */
            fread(&memram[0x20000],32768,1,file);       /* read INTCXROM + rom + slot rom + rom2 */
            appletype = 'e';            /* machine is AppleIIe */
            break;
          default :
            appletype = 0;
            fclose(file);
            stringwrite(window, "Unknown type of rom file.\r");
            stringwrite(window, "Press any key to continue...\r");
            imageupdate();
            do { }
            while ( (unsigned char)channelin(keyboard) == 0);
            return 0;
        } /* switch */
        fclose(file);
        if (appletype == '+') {
          stringwrite(window, "Machine is Apple ][+.\r");
        }
        else {
          stringwrite(window, "Machine is Apple //e.\r");
        }
        imageupdate();

/* load parallelport slot rom */
        file=fopen("parallel.rom","rb");
        if (!file) {
          stringwrite(window, "Parallel port : ROM not available.\r");
          imageupdate();
        }
        else {
          stringwrite(window, "Parallel port rom found.\r");
          imageupdate();
          fread(&memram[0x24100],256,1,file);
          fclose(file);
        }

/* load disk slot rom */
        file=fopen("disk.rom","rb");
        if (!file) {
          stringwrite(window, "disk ][ : ROM not available.\r");
          imageupdate();
        }
        else {
          stringwrite(window, "disk ][ slot rom found.\r");
          imageupdate();
          fread(&memram[0x24600],256,1,file);
          fclose(file);
        }

/* load mass storage slot rom */
        file=fopen("massstor.rom","rb");
        if (!file) {
          stringwrite(window, "Mass storage devices : ROM not available.\r");
          imageupdate();
        }
        else {
          stringwrite(window, "Mass storage device rom found.\r");
          imageupdate();
          fread(&memram[0x24500],256,1,file);
          fclose(file);
        }

/* init memory */
        stringwrite(window, "Resetting Apple...\r");
        imageupdate();

        memoryclear();
        applereset();

        return -1;
      } /* memoryloadrom */


/*-------------------------------------*/


/* automatic search for rom file */
      unsigned int memoryautoloadrom(unsigned int keyboard, unsigned int window) {
        FILE *rom;
        unsigned int i;

/* Try Apple//e first, then AppleII+ */

        rom = fopen(memrompath,"rb");
        i = (unsigned int)(rom);
        if (i) {
          fclose(rom);
          i = memoryloadrom(keyboard, window, memrompath);
        }
        if (!i) {
          strcpy(memrompath,"apple2e.rom");
          rom = fopen(memrompath,"rb");
          i = (unsigned int)(rom);
          if (i) {
            fclose(rom);
            i = memoryloadrom(keyboard, window, memrompath);
          }
          if (!i) {
            strcpy(memrompath,"apple2ee.rom");
            rom = fopen(memrompath,"rb");
            i = (unsigned int)(rom);
            if (i) {
              fclose(rom);
              i = memoryloadrom(keyboard, window, memrompath);
            }
            if (!i) {
              strcpy(memrompath,"apple2eo.rom");
              rom = fopen(memrompath,"rb");
              i = (unsigned int)(rom);
              if (i) {
                fclose(rom);
                i = memoryloadrom(keyboard, window, memrompath);
              }
              if (!i) {
                strcpy(memrompath,"apple2.rom");
                rom = fopen(memrompath,"rb");
                i = (unsigned int)(rom);
                if (i) {
                  fclose(rom);
                  i = memoryloadrom(keyboard, window, memrompath);
                }
                if (!i) {
                  strcpy(memrompath,"apple2o.rom");
                  rom = fopen(memrompath,"rb");
                  i = (unsigned int)(rom);
                  if (i) {
                    fclose(rom);
                    i = memoryloadrom(keyboard, window, memrompath);
                  }
                  if (!i) {
                    strcpy(memrompath,"apple2m.rom");
                    rom = fopen(memrompath,"rb");
                    i = (unsigned int)(rom);
                    if (i) {
                      fclose(rom);
                      i = memoryloadrom(keyboard, window, memrompath);
                    }
                    if (!i) {
                      strcpy(memrompath, "");
                      stringwrite(window, "No Apple ROMS found\r");
                      stringwrite(window, "Press a key to continue.\r");
                      imageupdate();
                      do {}
                      while ( (unsigned char)channelin(keyboard) == 0);
                      return 0;
                    }
                  }
                }
              }
            }
          }
        }
        return -1;
      } /* memoryautoloadrom */


/*-------------------------------------*/


      void memorystore(FILE *file) {

        fwrite(&soundflag,      sizeof(soundflag),      1,file);
        fwrite(&appletype,      sizeof(appletype),      1,file);
        fwrite(&memrompath,     sizeof(memrompath),     1,file);
        fwrite(&memram,         49152,                  1,file);
        if (!memnolc) {
          fwrite(&memram[49152],16384,                  1,file);
        }
        if (appletype == 'e') {
          fwrite(&memram[65536],49152,                  1,file);
          if (!memnolc) {
            fwrite(&memram[65536+49152],16384,          1,file);
          }
        }
        fwrite(&memram[0x20000],32768,                  1,file);
        fwrite(&memauxread,     sizeof(memauxread),     1,file);
        fwrite(&memauxwrite,    sizeof(memauxwrite),    1,file);
        fwrite(&memintcxrom,    sizeof(memintcxrom),    1,file);
        fwrite(&memslotc3,      sizeof(memslotc3),      1,file);
        fwrite(&memlcaux,       sizeof(memlcaux),       1,file);
        fwrite(&memlcramr,      sizeof(memlcramr),      1,file);
        fwrite(&memlcramw,      sizeof(memlcramw),      1,file);
        fwrite(&memlcbank2,     sizeof(memlcbank2),     1,file);
        fwrite(&memstore80,     sizeof(memstore80),     1,file);
        fwrite(&memann3,        sizeof(memann3),        1,file);

      } /* memorystore */


/*-------------------------------------*/


      void memoryrestore(FILE *file) {

        fread(&soundflag,       sizeof(soundflag),      1,file);
        fread(&appletype,       sizeof(appletype),      1,file);
        fread(&memrompath,      sizeof(memrompath),     1,file);
        fread(&memram,          49152,                  1,file);
        if (!memnolc) {
          fread(&memram[49152],16384,                   1,file);
        }
        if (appletype == 'e') {
          fread(&memram[65536],49152,                   1,file);
          if (!memnolc) {
            fread(&memram[65536+49152],16384,           1,file);
          }
        }
        fread(&memram[0x20000], 32768,                  1,file);
        fread(&memauxread,      sizeof(memauxread),     1,file);
        fread(&memauxwrite,     sizeof(memauxwrite),    1,file);
        fread(&memintcxrom,     sizeof(memintcxrom),    1,file);
        fread(&memslotc3,       sizeof(memslotc3),      1,file);
        fread(&memlcaux,        sizeof(memlcaux),       1,file);
        fread(&memlcramr,       sizeof(memlcramr),      1,file);
        fread(&memlcramw,       sizeof(memlcramw),      1,file);
        fread(&memlcbank2,      sizeof(memlcbank2),     1,file);
        fread(&memstore80,      sizeof(memstore80),     1,file);
        fread(&memann3,         sizeof(memann3),        1,file);

      } /* memoryrestore */


/*-------------------------------------*/


unsigned char memoryread(unsigned int addr) {

  if (addr < 0xc000) {
    if (addr < 0x2000) {
      if (addr < 0x400) {
        if (addr < 0x200) {
/* $0000 - $01ff */
          if (memlcaux)         { return memram[addr+65536]; }                  /* aux 64 */
          else                  { return memram[addr]; }                        /* main 64 */
        }
        else {
/* $0200 - $03ff */
          if (memauxread)       { return memram[addr+65536]; }                  /* aux 64 */
          else                  { return memram[addr]; }                        /* main 64 */
        }
      }
      else {
        if (addr < 0x800) {
/* $0400 - $07ff */
          if (memstore80) {
            if (virtpage2)      { return memram[addr+65536]; }                  /* aux 64 */
            else                { return memram[addr]; }                        /* main 64 */
          }
          else {
            if (memauxread)     { return memram[addr+65536]; }                  /* aux 64 */
            else                { return memram[addr]; }                        /* main 64 */
          }
        }
        else {
/* $0800 - $1fff */
          if (memauxread)       { return memram[addr+65536]; }                  /* aux 64 */
          else                  { return memram[addr]; }                        /* main 64 */
        }
      }
    } /* if (addr < 0x2000) */
    else {
      if (addr < 0x4000) {
/* $2000 - $3fff */
        if ((memstore80) && (virthgr)) {
          if (virtpage2)        { return memram[addr+65536]; }                  /* aux 64 */
          else                  { return memram[addr]; }                        /* main 64 */
        }
        else {
          if (memauxread)       { return memram[addr+65536]; }                  /* aux 64 */
          else                  { return memram[addr]; }                        /* main 64 */
        }
      }
      else {
/* $4000 - $bfff */
        if (memauxread)         { return memram[addr+65536]; }                  /* aux 64 */
        else                    { return memram[addr]; }                        /* main 64 */
      }
    }
  } /* if (addr < 0xc000) */
  else {
    if (addr >= 0xd000) {
      if ((!memlcramr) || (memnolc && (!(appletype=='e'))) ) {
        return memram[addr-0xd000+0x21000];     /* ROM is the same for whatever memlcaux is set to */
      }
      else {
        if (memlcaux) {
          if (addr < 0xe000) {
            if (!memlcbank2) {
              return memram[(addr-0x1000)+0x10000];
            }
          }
          return memram[addr+0x10000];
        }
        else {
          if (addr < 0xe000) {
            if (!memlcbank2) {
              return memram[addr-0x1000];
            }
          }
          return memram[addr];
        }
      } /* else if (memlcramr) */
    } /* if (addr => 0xd000 */
    else {

 /* test for softswitch area */
      if (addr <= 0xc0ff) {

        if (addr <= 0xc00f) { return memkey; }  /* keyboard */

        if (inidebugflag) return 0x0d;          /* avoid accessing softswitches from the debugger */

        if (addr <= 0xc01f) {
          if (appletype == 'e') {
            switch (addr) {
              case 0xc010 :     { memkey = memkey & 0x7f;
                                  return memkey;        /* not correct (undefined so far) */
                                }
              case 0xc011 :     return (memlcbank2  | (memkey&0x7f));
              case 0xc012 :     return (memlcramr   | (memkey&0x7f));
              case 0xc013 :     return (memauxread  | (memkey&0x7f));
              case 0xc014 :     return (memauxwrite | (memkey&0x7f));
              case 0xc015 :     return (memintcxrom | (memkey&0x7f));
              case 0xc016 :     return (memlcaux    | (memkey&0x7f));
              case 0xc017 :     return (memslotc3   | (memkey&0x7f));
              case 0xc018 :     return (memstore80  | (memkey&0x7f));
              case 0xc019 :     return (rasterline<192) ? ((memkey&0x7f)|0x80) : (memkey&0x7f);
              case 0xc01a :     return ((virtgraphic ^ 0x80) | (memkey&0x7f));
              case 0xc01b :     return (virtmixed   | (memkey&0x7f));
              case 0xc01c :     return (virtpage2   | (memkey&0x7f));
              case 0xc01d :     return (virthgr     | (memkey&0x7f));
              case 0xc01e :     return (virtaltchar | (memkey&0x7f));
              case 0xc01f :     return (virt80col   | (memkey&0x7f));
            } /* switch */
          }
          else {
            memkey = memkey & 0x7f;
            return memkey;      /* not correct (undefined so far) */
          }
        }


        if (addr <= 0xc02f)                             return memkey&0x7f;    /* Cassette output toggle */

        if (addr <= 0xc03f)     { soundclick();         return memkey&0x7f; } /* Speaker */

        if (addr <= 0xc04f)                             return memkey&0x7f;   /* Utility output strobe - nani yo? */

        if (addr <= 0xc06f) {
          switch (addr) {
            case 0xc050 : { if (!virtgraphic) {
                              virtgraphic = 0x80;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc051 : { if (virtgraphic) {
                              virtgraphic = 0;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc052 : { if (virtmixed) {
                              virtmixed = 0;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc053 : { if (!virtmixed) {
                              virtmixed = 0x80;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc054 : { if (virtpage2) {
                              virtpage2 = 0;
                              if (!memstore80) {
                                virtcachemode = (((virtcachemode & 0xfe) + 2) & 0xfe) | (virtcachemode & 0xff00);
                                virtsetmode();
                              }
                            }
                            return virtvideobyte;
                          }
            case 0xc055 : { if (!virtpage2) {
                              virtpage2 = 0x80;
                              if (!memstore80) {
                                virtsetmode();
                              }
                            }
                            return virtvideobyte;
                          }
            case 0xc056 : { if (virthgr) {
                              virthgr = 0;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc057 : { if (!virthgr) {
                              virthgr = 0x80;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }

            case 0xc058 : return virtvideobyte; /* Out0-off - nani yo? */
            case 0xc059 : return virtvideobyte; /* Out0-on - nani yo? */
            case 0xc05a : return virtvideobyte; /* Out1-off - nani yo? */
            case 0xc05b : return virtvideobyte; /* Out1-on - nani yo? */
            case 0xc05c : return virtvideobyte; /* Out2-off - nani yo? */
            case 0xc05d : return virtvideobyte; /* Out2-on - nani yo? */
/*
   C05E 49246 CLRAN3       OE G WR   If IOUDIS off: Annunciator 3 Off
              Y0EDGE         C  WR   If IOUDIS on: Interrupt on Y0 Rising
              DHIRESON      ECG WR   In 80-Column Mode: Double Width Graphics
*/
            case 0xc05e : {
                            if (!virtiou) {
                              memann3 = 0;              /* annunciator#3 off */
                            }
                            if (!virtdhres) {
                              virtdhres = 0x80;         /* double hires on   */
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
/*
    C05F 49247 SETAN3       OE G WR   If IOUDIS off: Annunciator 3 On
               Y0EDGE         C  WR   If IOUDIS on: Interrupt on Y0 Falling
               DHIRESOFF     ECG WR   In 80-Column Mode: Single Width Graphics
*/
            case 0xc05f : {
                            if (!virtiou) {
                              memann3 = 0x80;           /* annunciator#3 on */
                            }
                            if (virtdhres) {
                              virtdhres = 0;            /* double hires off */
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc060 : return 255; // was nothing here -uso.
            case 0xc068 : return 0x00; /* Cassette input */
/* C061 49249 RDBTN0        EC   R7  Switch Input 0 / Open Apple */
            case 0xc061 :
            case 0xc069 : return memjoybutton0;
/* C062 49250 BUTN1         E    R7  Switch Input 1 / Solid Apple */
            case 0xc062 :
            case 0xc06a : return memjoybutton1;
/* C063 49251 RD63          E    R7  Switch Input 2 / Shift Key
                             C   R7  Bit 7 = Mouse Button Not Pressed */
            case 0xc063 :
            case 0xc06b : return 0; // if (*shiftstate&3) return dqshift?128:0; else return 128;
/* C064 49252 PADDL0       OECG  R7  Analog Input 0 */
            case 0xc064 :
            case 0xc06c : if ((cycle - memjoycycle - memjoyx) > 0x7fffffff) {
                            return 0x80;
                          }
                          else {
                            return 0;
                          }
//                              {
//                                extern unsigned char ReadGameTimer(unsigned short Address);
//                                return ReadGameTimer(addr&0xFF);
//                              }
/* C065 49253 PADDL1       OECG  R7  Analog Input 1 */
            case 0xc065 :
            case 0xc06d : if ((cycle - memjoycycle - memjoyy) > 0x7fffffff) {
                            return 0x80;
                          }
                          else {
                            return 0;
                          }
//                              {
//                                extern unsigned char ReadGameTimer(unsigned short Address);
//                                return ReadGameTimer(addr&0xFF);
//                              }
/* C066 49254 PADDL2       OE G  R7  Analog Input 2
              RDMOUX1        C   R7  Mouse Horiz Position */
            case 0xc066 :
            case 0xc06e : return 0xa0; /* Pdl2 */
/* C067 49255 PADDL3       OE G  R7  Analog Input 3
              RDMOUY1        C   R7  Mouse Vert Position */
            case 0xc067 :
            case 0xc06f : return 0xa0; /* Pdl3 */
          } /* switch (addr) */
        } /* if (addr <= 0xc06f */

        if (addr <= 0xc07f) {
          switch (addr) {
/* C070 49364 PTRIG         E    R   Analog Input Reset
                          C  WR   Analog Input Reset + Reset VBLINT Flag */
            case 0xc070 :
              memjoycycle = cycle;      /* save cpu cycle */
//                            extern unsigned char ResetGameTimer(unsigned short Address);
//                            ResetGameTimer(addr);
              return virtvideobyte;

/* The following still has to be included : */
/* C073 49367 BANKSEL       ECG W    Memory Bank Select for > 128K */
/* C078 49372                C  W    Disable IOU Access */
/* C079 49373                C  W    Enable IOU Access */

/* C07E 49278 IOUDISON      EC  W    Disable IOU
              RDIOUDIS      EC   R7  Status of IOU Disabling */
            case 0xc07e : {
                            if (appletype=='e') { return ((virtiou)   | (virtvideobyte & 0x7f)); }
                            else { return virtvideobyte; }
                          }
/* C07F 49279 IOUDISOFF     EC  W    Enable IOU
              RDDHIRES      EC   R7  Status of Double HiRes */
            case 0xc07f : {
                            if (appletype=='e') { return ((virtdhres) | (virtvideobyte & 0x7f)); }
                            else { return virtvideobyte; }
                          }

          } /* switch */
          return virtvideobyte;
        }

/* Language Card Handling */
        if (addr <= 0xc08f) {
          switch (addr) {
            case 0xc080 :
            case 0xc084 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0;     /* Write Rom */
                            return (memkey&0x7f);
                          }
            case 0xc081 :
            case 0xc085 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0x80;  /* Write Bank */
                            return (memkey&0x7f);
                          }
            case 0xc082 :
            case 0xc086 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0;     /* Write Rom */
                            return (memkey&0x7f);
                          }
            case 0xc083 :
            case 0xc087 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0x80;  /* Write Bank */
                            return (memkey&0x7f);
                          }
            case 0xc088 :
            case 0xc08c : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0;     /* Write Rom */
                            return (memkey&0x7f);
                          }
            case 0xc089 :
            case 0xc08d : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0x80;  /* Write Bank */
                            return (memkey&0x7f);
                          }
            case 0xc08a :
            case 0xc08e : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0;     /* Write Rom */
                            return (memkey&0x7f);
                          }
            case 0xc08b :
            case 0xc08f : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0x80;  /* Write Bank */
                            return (memkey&0x7f);
                          }
          } /* switch */
        }

/* Slot #1 Softswitches: Parallel Port */
        if (addr >= 0xc090 && addr <= 0xc09f) {
/*        return ReadParallel (addr); */
          return 0xa0;
        }

/* Slot #5 Softswitches */
        if (addr >= 0xc0d0 && addr <= 0xc0df) {
          return ReadRawDiskIO (addr);
        }

/* Slot #6 Softswitches */
        if (addr >= 0xc0e0 && addr <= 0xc0ef) {
          return driveread(addr);
        }

/* Slot #7 Softswitches */
        if (addr >= 0xc0f0 && addr <= 0xc0ff && (!dqhdv)) {
          return dqhdv? 0xa0 : ReadMassStorIO (addr);
        }

/* The remaining addresses between 0xc000 and 0xc0ff are simply ignored. */
        return 0xa0;
      } /* if (addr <= 0xc0ff */
      else {
/* $c100 - $cfff */
        if (memintcxrom) return memram[(addr-0xc000)+0x20000];
        else {
          if (addr <= 0xc1ff) return memram[(addr-0xc000)+0x24000];             /* 1 */
          if (addr <= 0xc2ff) return memram[(addr-0xc000)+0x24000];             /* 2 */
          if (addr <= 0xc3ff) {                                                 /* 3 */
            if (appletype=='e') {
              if (memslotc3)    { return memram[(addr-0xc000)+0x24000]; }       /* slot */
              else              { return memram[(addr-0xc000)+0x20000]; }       /* copy of INTCXROM */
            }
            else                { return memram[(addr-0xc000)+0x24000]; }       /* slot */
          }
          if (addr <= 0xc4ff) return memram[(addr-0xc000)+0x24000];             /* 4 */
          if (addr <= 0xc5ff) return memram[(addr-0xc000)+0x24000];             /* 5 */
          if (addr <= 0xc6ff) return memram[(addr-0xc000)+0x24000];             /* 6 */
          if (addr <= 0xc7ff) return dqhdv ? 0xff : HDDROM[addr-0xc700];        /* 7 */
          if (addr >= 0xc800) return memram[(addr-0xc000)+0x20000];
          return 0xff;
        }
      } /* else if (addr <= 0xc0ff */
    } /* else if (addr >= 0xd000) */
  } /* else if (addr < 0xc000) */
} /* memoryread() */


/*-------------------------------------*/


void memorywrite(unsigned int addr, unsigned int val) {

  if (addr < 0xc000) {
    if (addr < 0x2000) {
      if (addr < 0x400) {
        if (addr < 0x200) {
/* $0000 - $01ff */
          if (memlcaux)         { memram[addr+65536] = val; return; }                   /* aux 64 */
          else                  { memram[addr]       = val; return; }                   /* main 64 */
        }
        else {
/* $0200 - $03ff */
          if (memauxwrite)      { memram[addr+65536] = val; return; }                   /* aux 64 */
          else                  { memram[addr]       = val; return; }                   /* main 64 */
        }
      }
      else {
        if (addr < 0x800) {
/* $0400 - $07ff */
          if (memstore80) {
            if (virtpage2) {
              if (memram[addr+65536] != val) {
                                memram[addr+65536] = val;                               /* aux 64 */
                                virtwrite0400aux(addr);
              }
              return;
            }
            else {
              if (memram[addr] != val) {
                                memram[addr] = val;                                     /* main 64 */
                                virtwrite0400(addr);
              }
              return;
            }
          } /* if (memstore80) */
          else {
            if (memauxwrite) {
              if (memram[addr+65536] != val) {
                                memram[addr+65536] = val;                               /* aux 64 */
                                virtwrite0400aux(addr);
              }
              return;
            }
            else {
              if (memram[addr] != val) {
                                memram[addr] = val;                                     /* main 64 */
                                virtwrite0400(addr);
              }
              return;
            }
          } /* else if (memstore80) */
        } /* if (addr < 0x800 */
        else {
          if (addr < 0xc00) {
/* $0800 - $0bff */
            if (memauxwrite) {
              if (memram[addr+65536] != val) {
                                memram[addr+65536] = val;                               /* aux 64 */
                                virtwrite0800aux(addr);
              }
              return;
            }
            else {
              if (memram[addr] != val) {
                                memram[addr] = val;                                     /* main 64 */
                                virtwrite0800(addr);
              }
              return;
            }
          }
          else {
/* $0c00 - $1fff */
            if (memauxwrite)    { memram[addr+65536] = val; return; }                   /* aux 64 */
            else                { memram[addr]       = val; return; }                   /* main 64 */
          }
        }
      }
    } /* if (addr < 0x2000) */
    else {
      if (addr < 0x4000) {
/* $2000 - $3fff */
        if ((memstore80) && (virthgr)) {
          if (virtpage2) {
            if (memram[addr+65536] != val) {
                                memram[addr+65536] = val;                               /* aux 64 */
                                virtwrite2000aux(addr);
            }
            return;
          }
          else {
            if (memram[addr] != val) {
                                memram[addr] = val;                                     /* main 64 */
                                virtwrite2000(addr);
            }
            return;
          }
        }
        else {
          if (memauxwrite) {
            if (memram[addr+65536] != val) {
                                memram[addr+65536] = val;                               /* aux 64 */
                                virtwrite2000aux(addr);
            }
            return;
          }
          else {
            if (memram[addr] != val) {
                                memram[addr] = val;                                     /* main 64 */
                                virtwrite2000(addr);
            }
            return;
          }
        }
      }
      else {
        if (addr < 0x6000) {
/* $4000 - $5fff */
          if (memauxwrite) {
            if (memram[addr+65536] != val) {
                                memram[addr+65536] = val;                               /* aux 64 */
                                virtwrite4000aux(addr);
            }
            return;
          }
          else {
            if (memram[addr] != val) {
                                memram[addr] = val;                                     /* main 64 */
                                virtwrite4000(addr);
            }
            return;
          }
        }
        else {
/* $6000 - $bfff */
          if (memauxwrite)      { memram[addr+65536] = val; return; }                   /* aux 64 */
          else                  { memram[addr]       = val; return; }                   /* main 64 */
        }
      }
    }
  } /* if (addr < 0xc000) */
  else {
    if (addr >= 0xd000) {
      if ((!memlcramw) || (memnolc && !(appletype=='e')) ) {
        return;         /* ROM is the same for whatever memlcaux is set to */
      }
      else {
        if (memlcaux) {
          if (addr < 0xe000) {
            if (!memlcbank2) {
              memram[(addr-0x1000)+0x10000] = val;
              return;
            }
          }
          memram[addr+0x10000] = val;
          return;
        }
        else {
          if (addr < 0xe000) {
            if (!memlcbank2) {
              memram[addr-0x1000] = val;
              return;
            }
          }
          memram[addr] = val;
          return;
        }
      } /* else if (memlcramw) */
    } /* if (addr => 0xd000 */
    else {

 /* test for softswitch area */
      if (addr <= 0xc0ff) {

      if (inidebugflag) return;

        if (addr <= 0xc00f) {
          if (appletype=='e') { /* only on Apple//e */
            switch (addr) {
              case 0xc000 : { if (memstore80) {
                                memstore80 = 0;
                                virtsetmode();
                              }
                              return;
                            }
              case 0xc001 : { if (!memstore80) {
                                memstore80 = 0x80;
                                virtsetmode();
                              }
                              return;
                            }
              case 0xc002 : { memauxread        = 0;    return; }
              case 0xc003 : { memauxread        = 0x80; return; }
              case 0xc004 : { memauxwrite       = 0;    return; }
              case 0xc005 : { memauxwrite       = 0x80; return; }
              case 0xc006 : { memintcxrom       = 0;    return; }        /* SLOTCXROM Off */
              case 0xc007 : { memintcxrom       = 0x80; return; }        /* SLOTCXROM On */
              case 0xc008 : { memlcaux          = 0;    return; }
              case 0xC009 : { memlcaux          = 0x80; return; }
              case 0xc00a : { memslotc3         = 0;    return; }        /* SLOTC3ROM Off */
              case 0xc00b : { memslotc3         = 0x80; return; }        /* SLOTC3ROM On */
              case 0xc00c : { if (virt80col) {
                                virt80col = 0;
//                              virtdhres = 0;
                                virtsetmode();
                              }
                              return;
                            }
              case 0xc00d : { if (!virt80col) {
                                virt80col = 0x80;
//                              if (!memann3) { virtdhres = 0x80; }
                                virtsetmode();
                              }
                              return;
                            }
              case 0xc00e : { if (virtaltchar) {                /* only update if there was a change */
                                virtaltchar = 0;
                                virtsetmode();
                              }
                              return;
                            }
              case 0xc00f : { if (!virtaltchar) {               /* only update if there was a change */
                                virtaltchar = 0x80;
                                virtsetmode();
                              }
                              return;
                            }
            } /* switch */
          } /* if (appletype=='e') */
          else return;
        } /* if (addr <= 0xc00f */

        if (addr <= 0xc01f) {
          memkey = memkey & 0x7f;
          return;
        }

        if (addr <= 0xc02f)                             return;   /* Cassette output toggle */

        if (addr <= 0xc03f)     { soundclick(); /*soundclick();*/ return; } /* Speaker */

        if (addr <= 0xc04f)                             return;   /* Utility output strobe - nani yo? */

        if (addr <= 0xc06f) {
          switch (addr) {
            case 0xc050 : { if (!virtgraphic) {
                              virtgraphic = 0x80;
                              virtsetmode();
                            }
                            return;
                          }
            case 0xc051 : { if (virtgraphic) {
                              virtgraphic = 0;
                              virtsetmode();
                            }
                            return;
                          }
            case 0xc052 : { if (virtmixed) {
                              virtmixed = 0;
                              virtsetmode();
                            }
                            return;
                          }
            case 0xc053 : { if (!virtmixed) {
                              virtmixed = 0x80;
                              virtsetmode();
                            }
                            return;
                          }
            case 0xc054 : { if (virtpage2) {
                              virtpage2 = 0;
                              if (!memstore80) {
                                virtcachemode = (((virtcachemode & 0xfe) + 2) & 0xfe) | (virtcachemode & 0xff00);
                                virtsetmode();
                              }
                            }
                            return;
                          }
            case 0xc055 : { if (!virtpage2) {
                              virtpage2 = 0x80;
                              if (!memstore80) {
                                virtsetmode();
                              }
                            }
                            return;
                          }
            case 0xc056 : { if (virthgr) {
                              virthgr = 0;
                              virtsetmode();
                            }
                            return;
                          }
            case 0xc057 : { if (!virthgr) {
                              virthgr = 0x80;
                              virtsetmode();
                            }
                            return;
                          }

            case 0xc058 : return; /* Out0-off - nani yo? */
            case 0xc059 : return; /* Out0-on - nani yo? */
            case 0xc05a : return; /* Out1-off - nani yo? */
            case 0xc05b : return; /* Out1-on - nani yo? */
            case 0xc05c : return; /* Out2-off - nani yo? */
            case 0xc05d : return; /* Out2-on - nani yo? */
/*
   C05E 49246 CLRAN3       OE G WR   If IOUDIS off: Annunciator 3 Off
              Y0EDGE         C  WR   If IOUDIS on: Interrupt on Y0 Rising
              DHIRESON      ECG WR   In 80-Column Mode: Double Width Graphics
*/
            case 0xc05e : {
                            if (!virtiou) {
                              memann3 = 0;              /* annunciator#3 off */
                            }
                            if (!virtdhres) {
                              virtdhres = 0x80; /* double hires on   */
                              virtsetmode();
                            }
                            return;
                          }
/*
    C05F 49247 SETAN3       OE G WR   If IOUDIS off: Annunciator 3 On
               Y0EDGE         C  WR   If IOUDIS on: Interrupt on Y0 Falling
               DHIRESOFF     ECG WR   In 80-Column Mode: Single Width Graphics
*/
            case 0xc05f : {
                            if (!virtiou) {
                              memann3 = 0x80;           /* annunciator#3 on */
                            }
                            if (virtdhres) {
                              virtdhres = 0;            /* double hires off */
                              virtsetmode();
                            }
                            return;
                          }
            case 0xc060 :
            case 0xc068 : return; /* Cassette input */
            case 0xc061 :
            case 0xc069 : return;
            case 0xc062 :
            case 0xc06a : return;
            case 0xc063 :
            case 0xc06b : return;
            case 0xc064 :
            case 0xc06c : return; /* Pdl0 */
            case 0xc065 :
            case 0xc06d : return; /* Pdl1 */
            case 0xc066 :
            case 0xc06e : return; /* Pdl2 */
            case 0xc067 :
            case 0xc06f : return; /* Pdl3 */
          } /* switch (addr) */
        } /* if (addr <= 0xc06f */

//        if (addr == 0xc070) {
//          memjoycycle = cycle;        /* save cpu cycle */
//          extern unsigned char ResetGameTimer(unsigned short Address);
//          ResetGameTimer(addr);
//          return;
//        }

        if (addr <= 0xc07f) {
          switch (addr) {
            case 0xc070 :
              memjoycycle = cycle;      /* save cpu cycle */
              return;
/* The following still has to be included :
C073 49367 BANKSEL       ECG W    Memory Bank Select for > 128K
C07E 49278 IOUDISON      EC  W    Disable IOU
           RDIOUDIS      EC   R7  Status of IOU Disabling
C07F 49279 IOUDISOFF     EC  W    Enable IOU
           RDDHIRES      EC   R7  Status of Double HiRes
*/
            case 0xc07e : { virtiou = 0;    return; }
            case 0xc07f : { virtiou = 0x80; return; }

          } /* switch */
          return;
        }

/* Language Card Handling */
        if (addr <= 0xc08f) {
          switch (addr) {
            case 0xc080 :
            case 0xc084 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0;     /* Write Rom */
                            return;
                          }
            case 0xc081 :
            case 0xc085 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0x80;  /* Write Bank */
                            return;
                          }
            case 0xc082 :
            case 0xc086 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0;     /* Write Rom */
                            return;
                          }
            case 0xc083 :
            case 0xc087 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0x80;  /* Write Bank */
                            return;
                          }
            case 0xc088 :
            case 0xc08c : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0;     /* Write Rom */
                            return;
                          }
            case 0xc089 :
            case 0xc08d : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0x80;  /* Write Bank */
                            return;
                          }
            case 0xc08a :
            case 0xc08e : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0;     /* Write Rom */
                            return;
                          }
            case 0xc08b :
            case 0xc08f : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0x80;  /* Write Bank */
                            return;
                          }
          } /* switch */
        }

/* Slot #1 Softswitches: Parallel Port */
        if (addr >= 0xc090 && addr <= 0xc09f) {
          WriteParallel (addr, val);    return;
        }

/* Slot #5 Softswitches */
        if (addr >= 0xc0d0 && addr <= 0xc0df) {
          WriteRawDiskIO (addr, val);   return;
        }

/* Slot #6 Softswitches */
        if (addr >= 0xc0e0 && addr <= 0xc0ef) {
          drivewrite (addr, val);      return;
        }

/* Slot #7 Softswitches */
        if (addr >= 0xc0f0 && addr <= 0xc0ff && (!dqhdv)) {
          WriteMassStorIO (addr, val);  return;
        }


/* The remaining addresses between 0xc000 and 0xc0ff are simply ignored. */
        return;
      } /* if (addr <= 0xc0ff */

      if (memintcxrom) { return; }

/* Slot #4: Z80 */
// if (Addr>=50432 && Addr<=50687)
#ifdef EMUZ80
        if (addr==0xc400) {
          if (cpuinuse==emuZ80) { /* from manual */
            cpuinuse=emu6502;
            return;
          }
          cpuinuse=emuZ80;
          return;
        }
#endif
        return;
    } /* else (if addr >= 0xd000 */
  } /* else (if (addr < 0xc000 */
} /* memorywrite */


/*-------------------------------------*/


      void memorymenu () {
        unsigned int screen;
        unsigned int keyboard;
        unsigned int window;
        unsigned char key;
        unsigned char update;

        screen = screenstore();
        if (!windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1, "Memory Options", &keyboard, &window)) {

          messageflag = 0;
          update = 1;
          do {
            if (update) {
              channelout(window, 12);           /* clear window */
              stringwrite(window, "\r[ESC] - Quit\r");

              stringwrite(window, "Current ROM file is: ");
              stringwrite(window, memrompath);
              channelout(window, 13);

              stringwrite(window, "\r[1] - Apple ][ - Monitor         ");
              channelout(window,  0!=strstr(memrompath,"apple2m.rom")  ? '*': ' ');
              stringwrite(window, "\r[2] - Apple ][ - Autostart       ");
              channelout(window,  0!=strstr(memrompath,"apple2o.rom")  ? '*': ' ');
              stringwrite(window, "\r[3] - Apple ][ Plus              ");
              channelout(window,  0!=strstr(memrompath,"apple.rom")    ? '*': ' ');
              stringwrite(window, "\r[4] - Apple //e - Apple ][ Title ");
              channelout(window,  0!=strstr(memrompath,"apple2eo.rom") ? '*': ' ');
              stringwrite(window, "\r[5] - Apple //e Enhanced         ");
              channelout(window,  0!=strstr(memrompath,"apple2ee.rom") ? '*': ' ');
              stringwrite(window, "\r[6] - Apple //e                  ");
              channelout(window,  0!=strstr(memrompath,"apple2e.rom")  ? '*': ' ');

              stringwrite(window, "\r\r[M] - Maximum ][/][+ RAM ");
              if (memnolc) { stringwrite(window, "48k"); }
              else          { stringwrite(window, "64k"); }

              stringwrite(window, "\r\r(RAM in //e mode is always 128K)\r");

              stringwrite(window, "\r[R] - Reset computer");
              stringwrite(window, "\r[C] - Clear memory and reset computer");
              stringwrite(window, "\r[P] - Clear pattern = ");
              if (memorygetclearmode() == 1) {
                stringwrite(window, "00 00 00...");
              }
              else {
                stringwrite(window, "EA EA EA...");
              }
              imageupdate();
              update = 0;
            }
            do {
              key = (unsigned char)channelin(keyboard);
            }
            while ((key == 0) && (!exitprogram));
            switch (key) {
              case '1' :
                channelout(window, 12);
                memoryloadrom(keyboard, window, "apple2m.rom");
                update = 1;
                break;
              case '2' :
                channelout(window, 12);
                memoryloadrom(keyboard, window, "apple2o.rom");
                update = 1;
                break;
              case '3' :
                channelout(window, 12);
                memoryloadrom(keyboard, window, "apple.rom");
                update = 1;
                break;
              case '4' :
                channelout(window, 12);
                memoryloadrom(keyboard, window, "apple2eo.rom");
                update = 1;
                break;
              case '5' :
                channelout(window, 12);
                memoryloadrom(keyboard, window, "apple2ee.rom");
                update = 1;
                break;
              case '6' :
                channelout(window, 12);
                memoryloadrom(keyboard, window, "apple2e.rom");
                update = 1;
                break;
              case 'c' :
              case 'C' :
                stringwrite(window, "\r\rClear memory and reset Apple...\rAre you sure? (y/n)");
                imageupdate();
                do {
                  key = (unsigned char)channelin(keyboard);
                }
                while ((key == 0) && (!exitprogram));
                if ((key == 'y') || (key == 'Y') || (exitprogram)) {
                  memoryclear();
                  applereset();
                }
                key = 0;
                update = 1;
                break;
              case 'm' :
              case 'M' :
                if (appletype == '+') {
                  memnolc = !memnolc;
                  update = 1;
                }
                break;
              case 'p' :
              case 'P' :
                if (memorygetclearmode() == 1) {
                  memorysetclearmode(2);
                }
                else {
                  memorysetclearmode(1);
                }
                update = 1;
                break;
              case 'r' :
              case 'R' :
                stringwrite(window, "\r\rReset Apple...\rAre you sure? (y/n)");
                imageupdate();
                do {
                  key = (unsigned char)channelin(keyboard);
                }
                while ((key == 0) && (!exitprogram));
                if ((key == 'y') || (key == 'Y') || (exitprogram)) {
                  applereset();
                }
                key = 0;
                update = 1;
                break;
            } /* switch (key) */
          }
          while ((key != 27) && (key != 32) && (key != 13) && (!exitprogram));
          channelclose(keyboard);
          channelclose(window);
          messageflag = 1;
        }
        screenrestore(screen);

      } /* drivemenu */
