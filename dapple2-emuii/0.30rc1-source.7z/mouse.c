/*
 * EMU][ Apple ][-class emulator
 * Copyright (C) 2002, 2003 by the EMU][ Project/Dapple ][ Team
 *
 * This component last revised 2003.0610 (0.30 Release Candidate 1)
 *
 * Component:  MOUSE: mouse emulation
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <stdio.h>
#include <string.h>
/* used by chdir */
#include <unistd.h>
#include "asmlib.h"
#include "dapple.h"

/* dapple.c */
extern unsigned char inirompath[260];
extern unsigned char inidebugflag;
extern unsigned char slotroms;
void cwdxchgslash(unsigned char *stringptr, unsigned int value);
void windowpresskey(unsigned int keyboard, unsigned int window);

/* video.c */
extern unsigned char virtvideobyte;

/* memory.c */
extern unsigned char memram[0x28000];

/* cpu65c02.c */
void cpusetstate(unsigned int value);

#define MODEON          1
#define MODEIRQMOVE     2
#define MODEIRQBUTTON   4
#define MODEIRQVBL      8
#define MODEIRQCXFALL   16
#define MODEIRQCXRAISE  32
#define MODEIRQCYFALL   64
#define MODEIRQCYRAISE  128

#define IRQBUTTON1PREV  1
#define IRQMOVE         2
#define IRQBUTTON       4
#define IRQVBL          8
#define IRQBUTTON1      16
#define IRQXYMOVE       32
#define IRQBUTTON0PREV  64
#define IRQBUTTON0      128
#define IRQCXFALL       16
#define IRQCXRAISE      32
#define IRQCYFALL       64
#define IRQCYRAISE      128

static unsigned char    mouserom[256];
static unsigned char    mousepresent;
static unsigned char    mouseactive;
static unsigned int     mouseslot;
static unsigned char    mousemode;
static unsigned char    mousestate;
static unsigned char    mouseirq;
static int              mousex;
static int              mousey;
static int              mousereadx;
static int              mouseready;
static int              mouseoldx;
static int              mouseoldy;
static int              mouseleft;
static int              mousetop;
static int              mouseright;
static int              mousedown;
unsigned int            mousebutton;
static unsigned int     mouseoldbutton;


/*--------------------------------------*/


      void mousereset() {

        mousemode       = 0;
        mousestate      = 0;
        mouseirq        = 0;
        mousex          = 0;
        mousey          = 0;
        mousereadx      = 0;
        mouseready      = 0;
        mouseoldx       = 0;
        mouseoldy       = 0;
        mouseleft       = 0;
        mousetop        = 0;
        mouseright      = 4095;
        mousedown       = 4095;
        mousebutton     = 0;
        mouseoldbutton  = 0;

      } /* mousereset */


/*--------------------------------------*/


      void mouseinit() {

        memset(mouserom, 0xff, sizeof(mouserom));
        mousepresent = 0;
        mouseactive = 1;
        mouseslot = 2;
        mousereset();

      } /* mouseinit */


/*-------------------------------------*/


      void mouseloadrom(unsigned int keyboard, unsigned int window) {
        FILE *file;
        unsigned char filepath[260];
        unsigned char oldcwd[260];


        cwdxchgslash(oldcwd, 256);                              /* read old directory path      */
        chdir(inirompath);                                      /* set rom directory            */

        strcpy(filepath, "slotmous.a65");                       /* search for source code       */
        file=fopen(filepath,"rb");
        if (!file) {
          strcpy(filepath, "slotmous.s");
          file=fopen(filepath,"rb");
          if (!file) {
            strcpy(filepath, "slotmous.asm");
            file=fopen(filepath,"rb");
          }
        }
        if (file) {
          fclose(file);                                         /* close file again */
          stringwritemessage(window,
"!\
EAssemble source code for mouse slot rom...\r;\
GAssembliere Source Code f�r das Mouse-Slotrom...\r;\
;");
          imageupdate();
          memset(mouserom, 0xff, sizeof(mouserom));
          assembler(mouserom, sizeof(mouserom), filepath);      /* assemble source code */
          mousepresent = 1;
        }
        else {
          strcpy(filepath, "mouse.rom");;                       /* search binary rom file       */
          file=fopen(filepath,"rb");
          if (file) {
            stringwritemessage(window,
"!\
EReading mouse slot rom from file...\r;\
GLese Mouse-Slotrom aus Datei...\r;\
;");
            imageupdate();
            fread(mouserom, sizeof(mouserom), 1, file);         /* read binary rom file */
            fclose(file);
            mousepresent = 1;
          }
          else {
            stringwritemessage(window,
"!\
ENo separate mouse slot rom found\r;\
GKein gesondertes Mouse-Slotrom vorhanden\r;\
;");
            mousepresent = 0;
            mouseactive = 0;
            imageupdate();
          }
        }
        chdir(oldcwd);                  /* restore original directory */
/*      windowpresskey(keyboard, window); */
/*      debugger(mouserom, sizeof(mouserom)); */

      } /* mouseloadrom */


/*--------------------------------------*/


      unsigned int mousestore(unsigned int winprotocol, FILE *file) {
        unsigned char header[32];

        memset(header, 0x00, sizeof(header));
        strcpy(header, "MOUSE STATE V0.28");
        fwrite(header,          sizeof(header), 1, file);

        fwrite(mouserom,        sizeof(mouserom),       1, file);
        fwrite(&mousepresent,   sizeof(mousepresent),   1, file);
        fwrite(&mouseactive,    sizeof(mouseactive),    1, file);
        fwrite(&mouseslot,      sizeof(mouseslot),      1, file);
        fwrite(&mousemode,      sizeof(mousemode),      1, file);
        fwrite(&mousestate,     sizeof(mousestate),     1, file);
        fwrite(&mouseirq,       sizeof(mouseirq),       1, file);
        fwrite(&mousex,         sizeof(mousex),         1, file);
        fwrite(&mousey,         sizeof(mousey),         1, file);
        fwrite(&mousereadx,     sizeof(mousereadx),     1, file);
        fwrite(&mouseready,     sizeof(mouseready),     1, file);
        fwrite(&mouseoldx,      sizeof(mouseoldx),      1, file);
        fwrite(&mouseoldy,      sizeof(mouseoldy),      1, file);
        fwrite(&mouseleft,      sizeof(mouseleft),      1, file);
        fwrite(&mousetop,       sizeof(mousetop),       1, file);
        fwrite(&mouseright,     sizeof(mouseright),     1, file);
        fwrite(&mousedown,      sizeof(mousedown),      1, file);
        fwrite(&mousebutton,    sizeof(mousebutton),    1, file);
        fwrite(&mouseoldbutton, sizeof(mouseoldbutton), 1, file);

        stringwrite(winprotocol, "Mouse stored.\r");
        return 0;

      } /* mousestore */


/*--------------------------------------*/


      unsigned int mouserestore(unsigned int winprotocol, FILE *file) {
        unsigned char header[32];

        fread(header,           sizeof(header),         1,file);
        if (strcmp(header, "MOUSE STATE V0.28")) {
          stringwrite(winprotocol, "Mouse emulation data not found.\r");
          return 1;
        }

        fread(mouserom,         sizeof(mouserom),       1, file);
        fread(&mousepresent,    sizeof(mousepresent),   1, file);
        fread(&mouseactive,     sizeof(mouseactive),    1, file);
        fread(&mouseslot,       sizeof(mouseslot),      1, file);
        fread(&mousemode,       sizeof(mousemode),      1, file);
        fread(&mousestate,      sizeof(mousestate),     1, file);
        fread(&mouseirq,        sizeof(mouseirq),       1, file);
        fread(&mousex,          sizeof(mousex),         1, file);
        fread(&mousey,          sizeof(mousey),         1, file);
        fread(&mousereadx,      sizeof(mousereadx),     1, file);
        fread(&mouseready,      sizeof(mouseready),     1, file);
        fread(&mouseoldx,       sizeof(mouseoldx),      1, file);
        fread(&mouseoldy,       sizeof(mouseoldy),      1, file);
        fread(&mouseleft,       sizeof(mouseleft),      1, file);
        fread(&mousetop,        sizeof(mousetop),       1, file);
        fread(&mouseright,      sizeof(mouseright),     1, file);
        fread(&mousedown,       sizeof(mousedown),      1, file);
        fread(&mousebutton,     sizeof(mousebutton),    1, file);
        fread(&mouseoldbutton,  sizeof(mouseoldbutton), 1, file);

        stringwrite(winprotocol, "Mouse restored.\r");

        return 0;

      } /* mouserestore */


/*--------------------------------------*/


      void mousevbl() {
        register unsigned int mouseval;

        if (mousemode & MODEON) {
          if ((mouseright - mouseleft) > 279) {
            mouseval = mousegetx() >> 2;
          }
          else {
            mouseval = mousegetx() >> 3;
          }
          if (mouseval < mouseleft) {
            mouseval = mouseleft;
          }
          else {
            if (mouseval > mouseright) {
              mouseval = mouseright;
            }
          }
          mousex = mouseval;

          if ((mousedown - mousetop) > 191) {
            mouseval = mousegety() >> 2;
          }
          else {
            mouseval = mousegety() >> 3;
          }
          if (mouseval < mousetop) {
            mouseval = mousetop;
          }
          else {
            if (mouseval > mousedown) {
              mouseval = mousedown;
            }
          }
          mousey = mouseval;

          mouseoldbutton = mousebutton;
          mousebutton = mousegetbutton();

/* check for falling/raising coor */

          if (mousex < mousereadx) {
            if ((mousemode & MODEIRQCXFALL) && (!(mouseirq & IRQCXFALL))) {
              cpusetstate(STATEIRQ);
            }
            mouseirq = mouseirq | IRQCXFALL;
          }
          if (mousex > mousereadx) {
            if ((mousemode & MODEIRQCXRAISE) && (!(mouseirq & IRQCXRAISE))) {
              cpusetstate(STATEIRQ);
            }
            mouseirq = mouseirq | IRQCXRAISE;
          }
          if (mousey < mouseready) {
            if ((mousemode & MODEIRQCYFALL) && (!(mouseirq & IRQCYFALL))) {
              cpusetstate(STATEIRQ);
            }
            mouseirq = mouseirq | IRQCYFALL;
          }
          if (mousey > mouseready) {
            if ((mousemode & MODEIRQCYRAISE) && (!(mouseirq & IRQCYRAISE))) {
              cpusetstate(STATEIRQ);
            }
            mouseirq = mouseirq | IRQCYRAISE;
          }

/* check for interrupts */

          if ((mousex != mousereadx) || (mousey != mouseready)) {
            if ((mousemode & MODEIRQMOVE) && (!(mouseirq & IRQMOVE))) {
              cpusetstate(STATEIRQ);
            }
            mouseirq = mouseirq | IRQMOVE;
            mousereadx = mousex;
            mouseready = mousey;
          }
          if (mousebutton && 0xff) {
            if ((mousemode & MODEIRQBUTTON) && (!(mouseirq & IRQBUTTON))) {
              cpusetstate(STATEIRQ);
            }
            mouseirq = mouseirq | IRQBUTTON;
          }
          if ((mousemode & MODEIRQVBL) && (!(mouseirq & IRQVBL))) {
            cpusetstate(STATEIRQ);
          }
          mouseirq = mouseirq | IRQVBL;

        } /* if (mousemode & MODEON) */

      } /* mousevbl */


/*--------------------------------------*/


      void mouseputcoor() {

        memram[0x478+mouseslot] = (unsigned char)mousex;
        memram[0x578+mouseslot] = (unsigned char)(mousex >> 8);
        memram[0x4f8+mouseslot] = (unsigned char)mousey;
        memram[0x5f8+mouseslot] = (unsigned char)(mousey >> 8);

      } /* mouseputcoor */


/*--------------------------------------*/


      unsigned char mouseread(unsigned int addr) {

        return 0xff;

      } /* mouseread */


/*--------------------------------------*/


      void mousewrite(unsigned int addr, unsigned value) {
        register unsigned int t1;
        register unsigned int t2;
        register unsigned int t3;

        if ((inidebugflag) || (!mouseactive)) {
          return;
        }

        switch (addr & 0xf) {
          case 0x02 :
            mousemode = value & (MODEON | MODEIRQMOVE | MODEIRQBUTTON | MODEIRQVBL);
            memram[0x7f8+mouseslot] = mousemode;
            return;
          case 0x03 :
            switch (value) {
              case 0x00 :       /* clampxmouse */
                t1 = memram[0x478] | (memram[0x578] << 8);
                t2 = memram[0x4f8] | (memram[0x5f8] << 8);
                if (t1 > t2) {
                  t3 = t1;
                  t1 = t2;
                  t2 = t3;
                }
                if (t1 > 1023) {
                  t1 = 1023;
                }
                if (t2 > 1023) {
                  t2 = 1023;
                }
                mouseleft  = t1;
                mouseright = t2;
                return;
              case 0x01 :       /* clampymouse */
                t1 = memram[0x478] | (memram[0x578] << 8);
                t2 = memram[0x4f8] | (memram[0x5f8] << 8);
                if (t1 > t2) {
                  t3 = t1;
                  t1 = t2;
                  t2 = t3;
                }
                if (t1 > 1023) {
                  t1 = 1023;
                }
                if (t2 > 1023) {
                  t2 = 1023;
                }
                mousetop  = t1;
                mousedown = t2;
                return;
              case 0x02 :       /* initmouse */
                mousereset();
                mouseputcoor();
                return;
              case 0x03 :       /* servemouse */
                memram[0x778+mouseslot] = mousestate | (mouseirq & (IRQMOVE | IRQBUTTON | IRQVBL));
                mouseirq = 0;           /* reset mouse's interrupt line */
                return;
              case 0x04 :       /* readmouse */
                mouseputcoor();
                mousestate = ((mousestate >> 4) & IRQBUTTON1PREV) | ((mousestate >> 1) & IRQBUTTON0PREV);
                if ((mousex != mouseoldx) || (mousey != mouseoldy)) {
                  mousestate = mousestate | IRQXYMOVE;
                  mouseoldx = mousex;
                  mouseoldy = mousey;
                }
                mousestate = mousestate | ((mousebutton & 0xff)         ? IRQBUTTON0 : 0x00);
                mousestate = mousestate | ((mousebutton & 0xff0000)     ? IRQBUTTON1 : 0x00);
                memram[0x778+mouseslot] = mousestate  | (mouseirq & (IRQMOVE | IRQBUTTON | IRQVBL));
                return;
             case 0x05 :        /* setmouse */
               return;
             case 0x06 :        /* posmouse */
                t1 = memram[0x478+mouseslot] | (memram[0x578+mouseslot] << 8);
                if (t1 < mouseleft) {
                  t1 = mouseleft;
                }
                else {
                  if (t1 > mouseright) {
                    t1 = mouseright;
                  }
                }
                mousex = t1;
                t1 = memram[0x4f8+mouseslot] | (memram[0x5f8+mouseslot] << 8);
                if (t1 < mousetop) {
                  t1 = mousetop;
                }
                else {
                  if (t1 > mousedown) {
                    t1 = mousedown;
                  }
                }
                mousey = t1;
                return;
              case 0x07 :       /* homemouse */
                mousex = mouseleft;
                mousey = mousetop;
                return;
              default :
                return;
            } /* switch (value) */
            return;
          default :
            return;
        } /* switch */
      } /* mousewrite */


/*--------------------------------------*/


      unsigned char mousereadiou(unsigned int addr) {
        return 0x00; /* not yet */

        switch (addr) {
          case 0xc058 :
            mousemode = mousemode & ~MODEIRQMOVE;
            break;
          case 0xc059 :
            mousemode = mousemode | MODEIRQMOVE;
            break;
          case 0xc05a :
            mousemode = mousemode & ~MODEIRQVBL;
            break;
          case 0xc05b :
            mousemode = mousemode | MODEIRQVBL;
            break;
          case 0xc05c :
            mousemode = (mousemode | MODEIRQCXFALL) & ~MODEIRQCXRAISE;
            break;
          case 0xc05d :
            mousemode = (mousemode | MODEIRQCXRAISE) & ~MODEIRQCXFALL;
            break;
          case 0xc05e :
            mousemode = (mousemode | MODEIRQCYFALL) & ~MODEIRQCYRAISE;
            break;
          case 0xc05f :
            mousemode = (mousemode | MODEIRQCYRAISE) & ~MODEIRQCYFALL;
            break;
        } /* switch (addr) */

        return virtvideobyte;

      } /* mousereadiou */


/*--------------------------------------*/


      void mousewriteiou(unsigned int addr) {
        return; /* not yet */

        switch (addr) {
          case 0xc058 :
            mousemode = mousemode & ~MODEIRQMOVE;
            break;
          case 0xc059 :
            mousemode = mousemode | MODEIRQMOVE;
            break;
          case 0xc05a :
            mousemode = mousemode & ~MODEIRQVBL;
            break;
          case 0xc05b :
            mousemode = mousemode | MODEIRQVBL;
            break;
          case 0xc05c :
            mousemode = (mousemode | MODEIRQCXFALL) & ~MODEIRQCXRAISE;
            break;
          case 0xc05d :
            mousemode = (mousemode | MODEIRQCXRAISE) & ~MODEIRQCXFALL;
            break;
          case 0xc05e :
            mousemode = (mousemode | MODEIRQCYFALL) & ~MODEIRQCYRAISE;
            break;
          case 0xc05f :
            mousemode = (mousemode | MODEIRQCYRAISE) & ~MODEIRQCYFALL;
            break;
        } /* switch (addr) */

        return;

      } /* mousewriteiou */


/*--------------------------------------*/


      unsigned char mouseromread(unsigned int addr) {

        if (mouseactive) {
          return mouserom[addr & 0xff]; /* read from the rom which was separately loaded */
        }
        else {
          return 0xff;
        }

      } /* mouseromread */


/*--------------------------------------*/


      void mouseromwrite(unsigned int addr, unsigned int value) {

        return;         /* Nothing happens here */

      } /* mouseromwrite */



