package com.bliss.core.devices;

import java.awt.image.*;
import com.bliss.core.*;

public interface Device
{

    public Option[] getOptions();

}
