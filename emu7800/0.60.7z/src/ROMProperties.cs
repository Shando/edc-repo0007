/*
 * ROMProperties.cs
 * 
 * Represents the ROMProperties.csv file contents
 * 
 * Copyright 2004 (c) Mike Murphy
 * 
 */
using System;
using System.Collections;
using System.IO;

namespace EMU7800 {

public class ROMProperties {
	private const string ROM_PROPERTIES_FN = "ROMProperties.csv";
	private Hashtable PropertyTable = null;

	public GameSettings GetGameSettings(string md5sum) {
		if (md5sum == null) {
			throw new Exception("null md5sum argument not allowed");
		}
		if (PropertyTable == null) {
			Load();
		}
		if (!PropertyTable.ContainsKey(md5sum)) {
			PropertyTable[md5sum] = new GameSettings(md5sum);
		}
		return (GameSettings)PropertyTable[md5sum];
	}

	public GameSettings GetGameSettingsFromFile(FileInfo fi) {
		string md5 = MD5.ComputeMD5Digest(fi);

		if (PropertyTable == null) {
			Load();
		}
		if (!PropertyTable.ContainsKey(md5)) {
			Log.Msg("Unrecognized file: \n{0}\nMD5={1}\n",
				fi.FullName, md5.ToString());
			return null;
		}

		GameSettings gs = (GameSettings)PropertyTable[md5];
		gs.FileInfo = fi;

		return gs;
	}

	public void Load() {
		string fn = Path.Combine(EMU7800App.Instance.Settings.RootDir, ROM_PROPERTIES_FN);

		Log.Msg("Loading {0}...\n", fn);

		PropertyTable = new Hashtable();
		StreamReader r;
		try {
			r = new StreamReader(fn);
		} catch (Exception e) {
			Log.Msg("{0}\n", e.Message);
			return;
		}

		string line = r.ReadLine();

		Hashtable Column = new Hashtable();
		int colno = 0;
		foreach (string colnm in line.Split(',')) {
			Column[colnm] = colno++;
		}

		string md5;

		while (true) {
			line = r.ReadLine();
			if (line == null) {
				break;
			}

			string[] row = line.Split(',');
			md5 = row[(int)Column["MD5"]];

			GameSettings gs = new GameSettings(md5);
			gs.Title = row[(int)Column["Title"]];
			gs.Manufacturer = row[(int)Column["Manufacturer"]];
			gs.Year = row[(int)Column["Year"]];
			gs.ModelNo = row[(int)Column["ModelNo"]];
			gs.Rarity = row[(int)Column["Rarity"]];

			gs.CartType = EnumCartType(row[(int)Column["CartType"]], ref md5);
			gs.MachineType = EnumMachineType(row[(int)Column["MachineType"]], ref md5);

			Controller dflt;
			switch (gs.MachineType) {
			default:
			case MachineType.A2600NTSC:
			case MachineType.A2600PAL:
				dflt = Controller.Joystick;
				break;
			case MachineType.A7800NTSC:
			case MachineType.A7800PAL:
				dflt = Controller.ProLineJoystick;
				break;
			}
			gs.LController = EnumController(row[(int)Column["LController"]], dflt, ref md5);
			gs.RController = EnumController(row[(int)Column["RController"]], dflt, ref md5);

			gs.FileInfo = null;

			PropertyTable[md5] = gs;
		}
		r.Close();
		Log.Msg("Loaded {0} {1} entries\n", PropertyTable.Count, ROM_PROPERTIES_FN);
	}

	public void Dump() {
		if (PropertyTable == null) {
			return;
		}

		string fn = Path.Combine(EMU7800App.Instance.Settings.OutputDirectory, ROM_PROPERTIES_FN + ".txt");
		StreamWriter w;

		try {
			w = new StreamWriter(fn);
		} catch (Exception e) {
			Log.Msg("{0}\n", e.Message);
			return;
		}

		w.WriteLine("Title,Year,Manufacturer,ModelNo,CartType,MachineType,Rarity,LController,RController,MD5");
		IDictionaryEnumerator iter = PropertyTable.GetEnumerator();
		int count = 0;
		for (iter.Reset(); iter.MoveNext(); count++) {
			GameSettings gs = (GameSettings)iter.Value;
			w.WriteLine("{0},{1},{2},{3},{4},{5},{6},{7},{8},{9}",
				gs.Title,
				gs.Year,
				gs.Manufacturer,
				gs.ModelNo,
				gs.CartType.ToString() == "Default" ? "" : gs.CartType.ToString(),
				gs.MachineType.ToString(),
				gs.Rarity,
				gs.LController.ToString(),
				gs.RController.ToString(),
				gs.MD5Sum);
		}
		w.Flush();
		w.Close();
		Log.Msg("Dumped {0} {1}.txt entries\n", ROM_PROPERTIES_FN, count);
	}

	public ROMProperties() {}

	private CartType EnumCartType(string cartType, ref string md5) {
		CartType ct;

		try {
			ct = (CartType)Enum.Parse(typeof(CartType), cartType.ToUpper());
		} catch (ArgumentException) {
			ct = CartType.Default;
			if (cartType.Length > 0) {
				Log.Msg("bad CartType ({0}) for md5={1} in {2}\n", 
					cartType, md5, ROM_PROPERTIES_FN);
			}
		}
		return ct;
	}

	private MachineType EnumMachineType(string machineType, ref string md5) {
		MachineType mt;

		try {
			mt = (MachineType)Enum.Parse(typeof(MachineType), machineType.ToUpper());
		} catch (ArgumentException) {
			mt = MachineType.A2600NTSC;
			if (machineType.Length > 0) {
				Log.Msg("bad MachineType ({0}) for md5={1} in {2}\n", 
					machineType, md5, ROM_PROPERTIES_FN);
			}
		}
		return mt;
	}
			
	private Controller EnumController(string controller, Controller dflt, ref string md5) {
		Controller c;

		try {
			c = (Controller)Enum.Parse(typeof(Controller), controller);
		} catch (ArgumentException) {
			c = dflt;
			if (controller.Length > 0) {
				Log.Msg("bad Controller ({0}) for md5={1} in {2}\n", 
					controller, md5, ROM_PROPERTIES_FN);
			}
		}
		return c;
	}
}
}