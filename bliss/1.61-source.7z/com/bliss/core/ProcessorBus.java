package com.bliss.core;

import java.io.IOException;
import com.bliss.core.devices.*;

public class ProcessorBus
{

    ProcessorBus(EmulationDirector director) {
        this.director = director;
    }

    public void reset() {
        clock = 1;
        tickDelta = 0;
        currentProcessor = 0;
        paused = false;
        for (int i = 0; i < processorCount; i++)
            processors[i].reset();

        long totalClockSpeed = (long)processors[0].getClockSpeed();
        for (int i = 1; i < processorCount; i++) {
            totalClockSpeed = lcm(totalClockSpeed,
                    ((long)processors[i].getClockSpeed()));
        }

        for (int i = 0; i < processorCount; i++) {
            processors[i].reset();
            processorTicks[i] = 0;
            processorTickFactors[i] = (totalClockSpeed /
                    ((long)processors[i].getClockSpeed()));
        }
    }

    public void save(SaveOutputStream sos) throws IOException {
        sos.writeLong(clock);
        sos.writeLong(tickDelta);
        sos.writeInt(currentProcessor);
        for (int i = 0; i < processorCount; i++)
            processors[i].save(sos);
    }

    public void load(LoadInputStream lis) throws IOException {
        clock = lis.readLong(0, Long.MAX_VALUE);
        tickDelta = lis.readLong(0, Long.MAX_VALUE);
        currentProcessor = lis.readInt(0, MAX_PROCESSORS);
        for (int i = 0; i < processorCount; i++)
            processors[i].load(lis);
    }

    public void addProcessor(Processor p) {
        processors[processorCount] = p;
        processorCount++;
    }

    public void removeProcessor(Processor p) {
        for (int i = 0; i < processorCount; i++) {
            if (processors[i] == p) {
                for (int j = i; j < (processorCount-1); j++)
                    processors[j] = processors[j+1];
                processorCount--;
            }
        }
    }

    public void run() {
        running = true;
        while (running) {
            //skip this processor if it has been idled
            if (!processorsIdle[currentProcessor]) {
                processorTicks[currentProcessor] -= tickDelta;

                //if the clock just caught up to the processor, and
                //if the processor is not about to go idle, then run it
                if (processorTicks[currentProcessor] == 0) {
                    if (processors[currentProcessor].isIdle)
                        processorsIdle[currentProcessor] = true;
                    else
                        processorTicks[currentProcessor] =
                                (((long)processors[currentProcessor].tick()) *
                                    processorTickFactors[currentProcessor]);
                }
            }
    
            //move to the next processor
            currentProcessor++;

            //if we've now run through all of the processors, go back to
            //the beginning, awaken any processors that have come out of
            //an idle state, and determine the next tick delta
            if (currentProcessor == processorCount) {
                currentProcessor = 0;
    
                //determine the next tick delta
                tickDelta = Long.MAX_VALUE;
                for (int i = 0; i < processorCount; i++) {
                    //wake up any processors that want to wake up
                    processorsIdle[i] = (processorsIdle[i] &&
                            processors[i].isIdle);

                    //if the processor is not idle by this point, use it
                    //to calculate the tick delta
                    if (!processorsIdle[i] && processorTicks[i] < tickDelta)
                        tickDelta = processorTicks[i];
                }

                //move the clock forward by the tick delta amount
                clock += tickDelta;
            }
    
            while (paused && running) {
                director.pollInput();
                director.displayImage(true);
            }
        }
    }

    public void stop() {
        this.running = false;
    }

    public void setPaused(boolean paused) {
        this.paused = paused;
    }

    public boolean isPaused() {
        return paused;
    }

    private static long lcm(long a, long b) {
        long gcd = gcd(a, b);
        return (a/gcd)*b;
    }

    /**
     * This is an implementation of Euclid's Algorithm for determining
     * the greatest common denominator of two numbers.
     */
    private static long gcd(long m, long n) {
        long r = m % n;
        while (r != 0) {
            m = n;
            n = r;
            r = m % n;
        }
        return n;
    }

    private EmulationDirector director;
    long clock;
    private long tickDelta;
    private int currentProcessor;
    private volatile boolean running;
    private boolean     paused;
    private PlugIn      plugIn;
    private Processor[] processors           = new Processor[MAX_PROCESSORS];
    private long[]      processorTickFactors = new long[MAX_PROCESSORS];
    private long[]      processorTicks       = new long[MAX_PROCESSORS];
    private boolean[]   processorsIdle       = new boolean[MAX_PROCESSORS];
    private int         processorCount       = 0;

    private final static int MAX_PROCESSORS = 15;

}
