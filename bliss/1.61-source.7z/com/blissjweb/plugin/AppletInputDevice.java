package com.blissjweb.plugin;

import java.awt.*;
import java.awt.event.*;
import com.bliss.core.*;
import com.bliss.core.devices.*;

public class AppletInputDevice implements InputDevice
{

    AppletInputDevice(Component c) {
        this.component = c;
        signalsPlayerOne = new AppletInputSignal[DEFAULTS_PLAYER_ONE.length];
        System.arraycopy(DEFAULTS_PLAYER_ONE, 0, signalsPlayerOne, 0,
                DEFAULTS_PLAYER_ONE.length);
        signalsPlayerTwo = new AppletInputSignal[DEFAULTS_PLAYER_TWO.length];
        System.arraycopy(DEFAULTS_PLAYER_TWO, 0, signalsPlayerTwo, 0,
                DEFAULTS_PLAYER_TWO.length);
        signalsKeyboard = new AppletInputSignal[DEFAULTS_KEYBOARD.length];
        System.arraycopy(DEFAULTS_KEYBOARD, 0, signalsKeyboard, 0,
                DEFAULTS_KEYBOARD.length);
        signalsEmulator = new AppletInputSignal[DEFAULTS_EMULATOR.length];
        System.arraycopy(DEFAULTS_EMULATOR, 0, signalsEmulator, 0,
                DEFAULTS_EMULATOR.length);
    }

    public Option[] getOptions() {
        return Option.EMPTY_CONTROLLER_ARRAY;
    }

    public void poll() {}

    public InputSignal getInputSignal(String configString) {
        try {
            return new AppletInputSignal(Integer.parseInt(configString));
        }
        catch (NumberFormatException nfe) {
            return null;
        }
    }

    public InputSignal getInputSignal(int controlID) {
        if (controlID >= PLAYER_ONE_ID_START &&
                controlID <= PLAYER_ONE_ID_END)
        {
            return signalsPlayerOne[controlID - PLAYER_ONE_ID_START];
        }
        else if (controlID >= PLAYER_TWO_ID_START &&
                controlID <= PLAYER_TWO_ID_END)
        {
            return signalsPlayerTwo[controlID - PLAYER_TWO_ID_START];
        }
        else if (controlID >= KEYBOARD_ID_START &&
                controlID <= KEYBOARD_ID_END)
        {
            return signalsKeyboard[controlID - KEYBOARD_ID_START];
        }
        else if (controlID >= EMULATOR_ID_START &&
                controlID <= EMULATOR_ID_END)
        {
            return signalsEmulator[controlID - EMULATOR_ID_START];
        }
        return null;
    }

    public void setInputSignal(int controlID, InputSignal signal) {
        AppletInputSignal inputSignal = (AppletInputSignal)signal;
        if (controlID >= PLAYER_ONE_ID_START &&
                controlID <= PLAYER_ONE_ID_END)
        {
            signalsPlayerOne[controlID - PLAYER_ONE_ID_START] = inputSignal;
        }
        else if (controlID >= PLAYER_TWO_ID_START &&
                controlID <= PLAYER_TWO_ID_END)
        {
            signalsPlayerTwo[controlID - PLAYER_TWO_ID_START] = inputSignal;
        }
        else if (controlID >= KEYBOARD_ID_START &&
                controlID <= KEYBOARD_ID_END)
        {
            signalsKeyboard[controlID - KEYBOARD_ID_START] = inputSignal;
        }
        else if (controlID >= EMULATOR_ID_START &&
                controlID <= EMULATOR_ID_END)
        {
            signalsEmulator[controlID - EMULATOR_ID_START] = inputSignal;
        }
    }

    public InputSignal getDefaultSignal(int controlID) {
        if (controlID >= PLAYER_ONE_ID_START &&
                controlID <= PLAYER_ONE_ID_END)
        {
            return DEFAULTS_PLAYER_ONE[controlID - PLAYER_ONE_ID_START];
        }
        else if (controlID >= PLAYER_TWO_ID_START &&
                controlID <= PLAYER_TWO_ID_END)
        {
            return DEFAULTS_PLAYER_TWO[controlID - PLAYER_TWO_ID_START];
        }
        else if (controlID >= KEYBOARD_ID_START &&
                controlID <= KEYBOARD_ID_END)
        {
            return DEFAULTS_KEYBOARD[controlID - KEYBOARD_ID_START];
        }
        else if (controlID >= EMULATOR_ID_START &&
                controlID <= EMULATOR_ID_END)
        {
            return DEFAULTS_EMULATOR[controlID - EMULATOR_ID_START];
        }
        return null;
    }

    public InputSignal pollForInputSignal() {
        for (int i = 0; i < keyMap.length; i++) {
            if (keyMap[i])
                return new AppletInputSignal(i);
        }
        return null;
    }

    public float getControlValue(int controlID) {
        AppletInputSignal signal = null;
        if (controlID >= PLAYER_ONE_ID_START &&
                controlID <= PLAYER_ONE_ID_END)
        {
            signal = signalsPlayerOne[controlID - PLAYER_ONE_ID_START];
        }
        else if (controlID >= PLAYER_TWO_ID_START &&
                controlID <= PLAYER_TWO_ID_END)
        {
            signal = signalsPlayerTwo[controlID - PLAYER_TWO_ID_START];
        }
        else if (controlID >= KEYBOARD_ID_START &&
                controlID <= KEYBOARD_ID_END)
        {
            signal = signalsKeyboard[controlID - KEYBOARD_ID_START];
        }
        else if (controlID >= EMULATOR_ID_START &&
                controlID <= EMULATOR_ID_END)
        {
            signal = signalsEmulator[controlID - EMULATOR_ID_START];
        }
        if (signal == null)
            return 0.0f;

        int keyCode = signal.keyCode;
        return (keyMap[keyCode] ? SIGNAL_ON : SIGNAL_OFF);
    }

    public void initConfigMode() {
/*
        Toolkit.getDefaultToolkit().addAWTEventListener(keyListener,
                AWTEvent.KEY_EVENT_MASK);
*/
    }

    public void releaseConfigMode() {
/*
        Toolkit.getDefaultToolkit().removeAWTEventListener(keyListener);
        for (int i = 0; i < keyMap.length; i++)
            keyMap[i] = false;
*/
    }

    public void init() {
        component.addKeyListener(keyListener);
    }

    public void release() {
        component.removeKeyListener(keyListener);
    }

    private static class AppletInputSignal implements InputSignal
    {
        public AppletInputSignal(int keyCode) {
            this.keyCode = keyCode;
            this.description = "'" + KeyEvent.getKeyText(keyCode) + "'";
        }

        public String getDescription() {
            return description;
        }

        public String getConfigString() {
            return Integer.toString(keyCode);
        }

        private int keyCode;
        private String description;
    }

    private Component component;
    private boolean[]        keyMap        = new boolean[0xFFFF];
    private AppletInputSignal[] signalsPlayerOne;
    private AppletInputSignal[] signalsPlayerTwo;
    private AppletInputSignal[] signalsKeyboard;
    private AppletInputSignal[] signalsEmulator;

    private KeyListener keyListener = new KeyAdapter() {
            public void keyPressed(KeyEvent ke) {
                keyMap[ke.getKeyCode()] = true;
            }
            public void keyReleased(KeyEvent ke) {
                keyMap[ke.getKeyCode()] = false;
            }
        };

    private final static AppletInputSignal[] DEFAULTS_EMULATOR = {
            new AppletInputSignal(KeyEvent.VK_F1),
            new AppletInputSignal(KeyEvent.VK_F5),
            new AppletInputSignal(KeyEvent.VK_F6),
            new AppletInputSignal(KeyEvent.VK_F9),
            new AppletInputSignal(KeyEvent.VK_F12)
        };

    private final static AppletInputSignal[] DEFAULTS_PLAYER_ONE = {
            new AppletInputSignal(KeyEvent.VK_UP),
            new AppletInputSignal(KeyEvent.VK_PAGE_UP),
            new AppletInputSignal(KeyEvent.VK_RIGHT),
            new AppletInputSignal(KeyEvent.VK_PAGE_DOWN),
            new AppletInputSignal(KeyEvent.VK_DOWN),
            new AppletInputSignal(KeyEvent.VK_END),
            new AppletInputSignal(KeyEvent.VK_LEFT),
            new AppletInputSignal(KeyEvent.VK_HOME),
            new AppletInputSignal(KeyEvent.VK_CONTROL),
            new AppletInputSignal(KeyEvent.VK_Z),
            new AppletInputSignal(KeyEvent.VK_X),
            null,
            null,
            null,
            new AppletInputSignal(KeyEvent.VK_1),
            new AppletInputSignal(KeyEvent.VK_2),
            new AppletInputSignal(KeyEvent.VK_3),
            new AppletInputSignal(KeyEvent.VK_4),
            new AppletInputSignal(KeyEvent.VK_5),
            new AppletInputSignal(KeyEvent.VK_6),
            new AppletInputSignal(KeyEvent.VK_7),
            new AppletInputSignal(KeyEvent.VK_8),
            new AppletInputSignal(KeyEvent.VK_9),
            new AppletInputSignal(KeyEvent.VK_0),
            new AppletInputSignal(KeyEvent.VK_DELETE),
            new AppletInputSignal(KeyEvent.VK_ENTER),
            null,
            null,
        };
    
    private final static AppletInputSignal[] DEFAULTS_PLAYER_TWO = {
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null
        };

    private final static AppletInputSignal[] DEFAULTS_KEYBOARD = {
            new AppletInputSignal(KeyEvent.VK_A),
            new AppletInputSignal(KeyEvent.VK_B),
            new AppletInputSignal(KeyEvent.VK_C),
            new AppletInputSignal(KeyEvent.VK_D),
            new AppletInputSignal(KeyEvent.VK_E),
            new AppletInputSignal(KeyEvent.VK_F),
            new AppletInputSignal(KeyEvent.VK_G),
            new AppletInputSignal(KeyEvent.VK_H),
            new AppletInputSignal(KeyEvent.VK_I),
            new AppletInputSignal(KeyEvent.VK_J),
            new AppletInputSignal(KeyEvent.VK_K),
            new AppletInputSignal(KeyEvent.VK_L),
            new AppletInputSignal(KeyEvent.VK_M),
            new AppletInputSignal(KeyEvent.VK_N),
            new AppletInputSignal(KeyEvent.VK_O),
            new AppletInputSignal(KeyEvent.VK_P),
            new AppletInputSignal(KeyEvent.VK_Q),
            new AppletInputSignal(KeyEvent.VK_R),
            new AppletInputSignal(KeyEvent.VK_S),
            new AppletInputSignal(KeyEvent.VK_T),
            new AppletInputSignal(KeyEvent.VK_U),
            new AppletInputSignal(KeyEvent.VK_V),
            new AppletInputSignal(KeyEvent.VK_W),
            new AppletInputSignal(KeyEvent.VK_X),
            new AppletInputSignal(KeyEvent.VK_Y),
            new AppletInputSignal(KeyEvent.VK_Z),
            new AppletInputSignal(KeyEvent.VK_0),
            new AppletInputSignal(KeyEvent.VK_1),
            new AppletInputSignal(KeyEvent.VK_2),
            new AppletInputSignal(KeyEvent.VK_3),
            new AppletInputSignal(KeyEvent.VK_4),
            new AppletInputSignal(KeyEvent.VK_5),
            new AppletInputSignal(KeyEvent.VK_6),
            new AppletInputSignal(KeyEvent.VK_7),
            new AppletInputSignal(KeyEvent.VK_8),
            new AppletInputSignal(KeyEvent.VK_9),
            new AppletInputSignal(KeyEvent.VK_UP),
            new AppletInputSignal(KeyEvent.VK_DOWN),
            new AppletInputSignal(KeyEvent.VK_LEFT),
            new AppletInputSignal(KeyEvent.VK_RIGHT),
            new AppletInputSignal(KeyEvent.VK_COMMA),
            new AppletInputSignal(KeyEvent.VK_PERIOD),
            new AppletInputSignal(KeyEvent.VK_SPACE),
            new AppletInputSignal(KeyEvent.VK_SEMICOLON),
            new AppletInputSignal(KeyEvent.VK_COLON),
            new AppletInputSignal(KeyEvent.VK_ESCAPE),
            new AppletInputSignal(KeyEvent.VK_ENTER),
            new AppletInputSignal(KeyEvent.VK_CONTROL),
            new AppletInputSignal(KeyEvent.VK_SHIFT),
        };

}
