#define INLINE __forceinline

#define VERSION "0.57"

#define GCC_ATTRIBUTE(x) /* attribute not supported */

