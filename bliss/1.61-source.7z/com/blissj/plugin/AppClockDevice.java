package com.blissj.plugin;

import com.bliss.core.devices.*;
import com.bliss.core.*;

public class AppClockDevice implements ClockDevice
{

    public Option[] getOptions() {
        return Option.EMPTY_CONTROLLER_ARRAY;
    }

    public long getTickFrequency() {
        return 1000;
    }

    public long getTick() {
        return System.currentTimeMillis();
    }

}
