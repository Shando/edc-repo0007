
#include <windows.h>
#include <jni.h>
#include "DirectInputDevice.h"
#include "DirectInputSignal.h"

extern "C"
{

jfieldID nativeInputHandleFieldID = NULL;
jfieldID nativeInputSignalHandleFieldID = NULL;
jfieldID inputStopFieldID = NULL;

JNIEXPORT jlong JNICALL Java_com_blissjx_plugin_DirectInputDevice_nativeDirectInputDevice(JNIEnv *env, jobject thisObject)
{
    if (nativeInputHandleFieldID == NULL) {
        jclass clazz = env->GetObjectClass(thisObject);
        nativeInputHandleFieldID = env->GetFieldID(clazz, "nativeHandle", "J");
        inputStopFieldID = env->GetFieldID(clazz, "stop", "Z");
        clazz = env->FindClass(
            "com/blissjx/plugin/DirectInputDevice$DirectInputSignal");
        nativeInputSignalHandleFieldID = env->GetFieldID(clazz,
                "nativeHandle", "J");

    }
    return (jlong)(new DirectInputDevice());
}

JNIEXPORT void JNICALL Java_com_blissjx_plugin_DirectInputDevice_finalize(JNIEnv *env, jobject thisObject)
{
    DirectInputDevice* nativeDevice = (DirectInputDevice*)env->
            GetLongField(thisObject, nativeInputHandleFieldID);
    delete nativeDevice;
}

JNIEXPORT void JNICALL Java_com_blissjx_plugin_DirectInputDevice_releaseSignal(JNIEnv *env, jclass clazz, jobject signal)
{
    DirectInputSignal* nativeSignal = (DirectInputSignal*)env->
            GetLongField(signal, nativeInputSignalHandleFieldID);
    delete nativeSignal;
}

JNIEXPORT void JNICALL Java_com_blissjx_plugin_DirectInputDevice_init(JNIEnv *env, jobject thisObject)
{
    env->SetBooleanField(thisObject, inputStopFieldID, FALSE);
    DirectInputDevice* nativeDevice = (DirectInputDevice*)env->
            GetLongField(thisObject, nativeInputHandleFieldID);
    INT32 result = nativeDevice->init();
    if (result != 0) {
        jclass clazz = env->FindClass("com/bliss/core/EmulationException");
        env->ThrowNew(clazz, nativeDevice->getErrorDescription(result));
    }
}

JNIEXPORT void JNICALL Java_com_blissjx_plugin_DirectInputDevice_poll(JNIEnv *env, jobject thisObject)
{
    DirectInputDevice* nativeDevice = (DirectInputDevice*)env->
            GetLongField(thisObject, nativeInputHandleFieldID);
    nativeDevice->poll();
    if (nativeDevice->stop)
        env->SetBooleanField(thisObject, inputStopFieldID, TRUE);
}

JNIEXPORT void JNICALL Java_com_blissjx_plugin_DirectInputDevice_release(JNIEnv *env, jobject thisObject)
{
    DirectInputDevice* nativeDevice = (DirectInputDevice*)env->
            GetLongField(thisObject, nativeInputHandleFieldID);
    nativeDevice->release();
}

JNIEXPORT jfloat JNICALL Java_com_blissjx_plugin_DirectInputDevice_getSignalValue(JNIEnv *env, jobject thisObject, jobject inputSignal)
{
    if (inputSignal == NULL)
        return 0.0f;

    DirectInputDevice* nativeDevice = (DirectInputDevice*)env->
            GetLongField(thisObject, nativeInputHandleFieldID);
    DirectInputSignal* nativeSignal = (DirectInputSignal*)env->GetLongField(
            inputSignal, nativeInputSignalHandleFieldID);
    return nativeDevice->getSignalValue(nativeSignal);
}

JNIEXPORT jobject JNICALL Java_com_blissjx_plugin_DirectInputDevice_getDefaultSignal(JNIEnv *env, jobject thisObject, jint controlID)
{
    DirectInputDevice* nativeDevice = (DirectInputDevice*)env->
            GetLongField(thisObject, nativeInputHandleFieldID);
    DirectInputSignal* nativeSignal;
    nativeSignal = nativeDevice->getDefaultSignal(controlID);
    if (nativeSignal == NULL)
        return NULL;

    jclass clazz = env->FindClass(
            "com/blissjx/plugin/DirectInputDevice$DirectInputSignal");
    jmethodID constructor = env->GetMethodID(clazz, "<init>",
            "(JLjava/lang/String;Ljava/lang/String;)V");
    jstring configString = env->NewStringUTF(nativeSignal->getConfigKey());
    jstring description = env->NewStringUTF(nativeSignal->getDescription());
    jobject nextObject = env->NewObject(clazz, constructor,
            (jlong)nativeSignal, configString, description);
    return nextObject;
}

JNIEXPORT jobject JNICALL Java_com_blissjx_plugin_DirectInputDevice_getInputSignal(JNIEnv *env, jobject thisObject, jstring configString)
{
    DirectInputDevice* nativeDevice = (DirectInputDevice*)env->
            GetLongField(thisObject, nativeInputHandleFieldID);
    const char *str = env->GetStringUTFChars(configString, 0);
    DirectInputSignal* nativeSignal = nativeDevice->createInputSignal(str);
    env->ReleaseStringUTFChars(configString, str);
    if (nativeSignal == NULL)
        return NULL;

    jclass clazz = env->FindClass(
            "com/blissjx/plugin/DirectInputDevice$DirectInputSignal");
    jmethodID constructor = env->GetMethodID(clazz, "<init>",
            "(JLjava/lang/String;Ljava/lang/String;)V");
    jobject description = env->NewStringUTF(nativeSignal->getDescription());
    jobject nextObject = env->NewObject(clazz, constructor,
            (jlong)nativeSignal, configString, description);
    return nextObject;
}

JNIEXPORT void JNICALL Java_com_blissjx_plugin_DirectInputDevice_initConfigMode(JNIEnv *env, jobject thisObject)
{
    DirectInputDevice* nativeDevice = (DirectInputDevice*)env->
            GetLongField(thisObject, nativeInputHandleFieldID);
    nativeDevice->initConfigMode();
}

JNIEXPORT jobject JNICALL Java_com_blissjx_plugin_DirectInputDevice_pollForInputSignal(JNIEnv *env, jobject thisObject)
{
    DirectInputDevice* nativeDevice = (DirectInputDevice*)env->
            GetLongField(thisObject, nativeInputHandleFieldID);
    DirectInputSignal* nativeSignal = nativeDevice->pollForInputSignal();
    if (nativeSignal == NULL)
        return NULL;

    jclass clazz = env->FindClass(
            "com/blissjx/plugin/DirectInputDevice$DirectInputSignal");
    jmethodID constructor = env->GetMethodID(clazz, "<init>",
            "(JLjava/lang/String;Ljava/lang/String;)V");
    jstring configString = env->NewStringUTF(nativeSignal->getConfigKey());
    jstring description = env->NewStringUTF(nativeSignal->getDescription());
    jobject nextObject = env->NewObject(clazz, constructor,
            (jlong)nativeSignal, configString, description);
    return nextObject;
}

JNIEXPORT void JNICALL Java_com_blissjx_plugin_DirectInputDevice_releaseConfigMode(JNIEnv *env, jobject thisObject)
{
    DirectInputDevice* nativeDevice = (DirectInputDevice*)env->
            GetLongField(thisObject, nativeInputHandleFieldID);
    nativeDevice->releaseConfigMode();
}

}

