package com.blissjx.plugin;

import java.awt.event.*;
import com.bliss.core.devices.*;
import com.bliss.core.*;

public class DirectInputDevice implements InputDevice
{

    DirectInputDevice() {
        nativeHandle = nativeDirectInputDevice();
        signalsPlayerOne = new DirectInputSignal[
                (PLAYER_ONE_ID_END-PLAYER_ONE_ID_START)+1];
        for (int i = 0; i < signalsPlayerOne.length; i++)
            signalsPlayerOne[i] = getDefaultSignal(PLAYER_ONE_ID_START+i);
        signalsPlayerTwo = new DirectInputSignal[
                (PLAYER_TWO_ID_END-PLAYER_TWO_ID_START)+1];
        for (int i = 0; i < signalsPlayerTwo.length; i++)
            signalsPlayerTwo[i] = getDefaultSignal(PLAYER_TWO_ID_START+i);
        signalsKeyboard = new DirectInputSignal[
                (KEYBOARD_ID_END-KEYBOARD_ID_START)+1];
        for (int i = 0; i < signalsKeyboard.length; i++)
            signalsKeyboard[i] = getDefaultSignal(KEYBOARD_ID_START+i);
        signalsEmulator = new DirectInputSignal[
                (EMULATOR_ID_END-EMULATOR_ID_START)+1];
        for (int i = 0; i < signalsEmulator.length; i++)
            signalsEmulator[i] = getDefaultSignal(EMULATOR_ID_START+i);
    }

    private native long nativeDirectInputDevice();

    public native InputSignal getDefaultSignal(int controlID);

    public native void init();

    public native void poll();

    public InputSignal getInputSignal(int controlID) {
        if (controlID <= PLAYER_ONE_ID_END) {
            return signalsPlayerOne[controlID-PLAYER_ONE_ID_START];
        }
        else if (controlID <= PLAYER_TWO_ID_END) {
            return signalsPlayerTwo[controlID-PLAYER_TWO_ID_START];
        }
        else if (controlID <= KEYBOARD_ID_END) {
            return signalsKeyboard[controlID-KEYBOARD_ID_START];
        }
        else if (controlID <= EMULATOR_ID_END) {
            return signalsEmulator[controlID-EMULATOR_ID_START];
        }
        return null;
    }

    public void setInputSignal(int controlID, InputSignal signal) {
        DirectInputSignal inputSignal = (DirectInputSignal)signal;
        if (controlID >= PLAYER_ONE_ID_START &&
                controlID <= PLAYER_ONE_ID_END)
        {
            signalsPlayerOne[controlID - PLAYER_ONE_ID_START] = inputSignal;
        }
        else if (controlID >= PLAYER_TWO_ID_START &&
                controlID <= PLAYER_TWO_ID_END)
        {
            signalsPlayerTwo[controlID - PLAYER_TWO_ID_START] = inputSignal;
        }
        else if (controlID >= KEYBOARD_ID_START &&
                controlID <= KEYBOARD_ID_END)
        {
            signalsKeyboard[controlID - KEYBOARD_ID_START] = inputSignal;
        }
        else if (controlID >= EMULATOR_ID_START &&
                controlID <= EMULATOR_ID_END)
        {
            signalsEmulator[controlID - EMULATOR_ID_START] = inputSignal;
        }
    }

    public float getControlValue(int controlID) {
        InputSignal signal = null;
        if (controlID <= PLAYER_ONE_ID_END) {
            signal = signalsPlayerOne[controlID - PLAYER_ONE_ID_START];
        }
        else if (controlID <= PLAYER_TWO_ID_END) {
            signal = signalsPlayerTwo[controlID - PLAYER_TWO_ID_START];
        }
        else if (controlID <= KEYBOARD_ID_END) {
            signal = signalsKeyboard[controlID - KEYBOARD_ID_START];
        }
        else if (controlID <= EMULATOR_ID_END) {
            signal = signalsEmulator[controlID - EMULATOR_ID_START];
        }
        if (signal == null)
            return 0.0f;

        return getSignalValue(signal);
    }

    public native float getSignalValue(InputSignal signal);

    public native void release();

    public native void initConfigMode();

    public native InputSignal pollForInputSignal();

    public native void releaseConfigMode();

    public native InputSignal getInputSignal(String configString);

    public native void finalize();

    public Option[] getOptions() {
        return Option.EMPTY_CONTROLLER_ARRAY;
    }

    private static native void releaseSignal(DirectInputSignal signal);

    boolean stop;
    long nativeHandle;
    private InputSignal[] signalsPlayerOne;
    private InputSignal[] signalsPlayerTwo;
    private InputSignal[] signalsKeyboard;
    private InputSignal[] signalsEmulator;

/*
    private final static String[] errorKeys = {
            "ErrorUnableToInitDirectInput",
            "ErrorUnableToAcquireKeyboard",
            "ErrorUnableToInitKeyboard",
            "ErrorUnableToAccessKeyboard",
            "ErrorUnableToPollKeyboard",
            "ErrorUnableToAcquireJoysticks",
            "ErrorUnableToInitJoysticks",
            "ErrorUnableToAccessJoysticks",
            "ErrorUnableToPollJoysticks",
        };
*/

    public static class DirectInputSignal implements InputSignal
    {
        public DirectInputSignal(long nativeSignalHandle, String configString,
                String desc)
        {
            this.nativeHandle = nativeSignalHandle;
            this.configString = configString;
            this.description = desc;
        }

        public String getConfigString() {
            return configString;
        }

        public String getDescription() {
            return description;
        }

        public void finalize() {
            releaseSignal(this);
        }

        long nativeHandle;
        private String configString;
        private String description;
    }

}
