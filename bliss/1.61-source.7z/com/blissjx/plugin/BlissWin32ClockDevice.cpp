#include <windows.h>
#include "jni.h"

extern "C" {


JNIEXPORT jlong JNICALL Java_com_blissjx_plugin_Win32ClockDevice_getTickFrequency(JNIEnv *env, jobject jobj)
{
    LARGE_INTEGER freq;
    QueryPerformanceFrequency(&freq);
    return freq.QuadPart;
} 

JNIEXPORT jlong JNICALL Java_com_blissjx_plugin_Win32ClockDevice_getTick(JNIEnv *env, jobject jobj)
{
    LARGE_INTEGER freq;
    QueryPerformanceCounter(&freq);
    return freq.QuadPart;
} 


}
