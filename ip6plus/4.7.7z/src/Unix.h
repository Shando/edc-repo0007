/* Unix.h */
/* Common definitons and declarations for Unix.c and Refresh.c */

// --------------- �錾����ꍇ�́A#define GLOBAL ���� -------------
#ifdef  GLOBAL
#define EXTRN
#else
#define EXTRN extern
#endif

#include "Refresh.h"

/* size of ximage -----> Refresh.h�ֈڍs�B�Ȃ��Ȃ�A�v���b�g�t�H�[�����ʃR�[�h�̂���*/
//#define M1WIDTH   256
//#define M1HEIGHT  192
//#define M5WIDTH   320
//#define M5HEIGHT  200

//#define WIDTH     M5WIDTH*2
//#define HEIGHT    M5HEIGHT*2
//#define SCRWIDTH  WIDTH+20
//#define SCRHEIGHT HEIGHT+20

/** Some typedef's **/
//typedef union {
//    XID ct_xid;
//    byte ct_byte[4]; 
//} ColTyp; /* sizeof ColTyp should be 4 */

/* functions and variables in Unix.c used by Refresh.c */
//EXTRN  int Mapped;
//EXTRN  byte *XBuf;
//EXTRN  int scale;
//EXTRN  int bitpix;
//EXTRN  ColTyp BPal[16],BPal53[32],
//  BPal11[4],BPal12[8],BPal13[8],BPal14[4],BPal15[8], BPal62[32],BPal61[16];
//EXTRN  ColTyp BPalet[32];	// for palet color

/* functions and variables in Refresh.c used by Unix.c */
//EXTRN  Bool lsbfirst;
//EXTRN  int  Width,Height;

//extern XID black;

void SLEEP(int s);


void choosefuncs(int lsbfirst, int bitpix);
void setwidth(int wide);
void PutImage(void);

void ClearScr(void);
int resize(int w,int h);		// resize window 2002/4/29
