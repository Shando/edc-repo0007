/*
 * EMU7800App.cs
 * 
 * Main application class for EMU7800.
 * 
 * Copyright (c) 2004 Mike Murphy
 * 
 */
using System;
using System.IO;
using System.Windows.Forms;

namespace EMU7800 {

public class EMU7800App {
	public const string Title = "EMU7800";	public const string Version = "0.60";
	public const string Copyright = "Copyright (c) 2003-2004 Mike Murphy";

	public Version CLRVersion {
		get { return Environment.Version; }
	}
	public OperatingSystem OSVersion {
		get { return Environment.OSVersion; }
	}

	public static readonly EMU7800App Instance = new EMU7800App();

	public readonly GlobalSettings Settings;
	public readonly ROMProperties ROMProperties;

	public Machine M;
	public InputAdapter IA = new InputAdapter();

	public void RunMachine(GameSettings gs) {
		M = Machine.New(gs, Cart.New(gs), IA);
		M.Reset();
		RunMachine();
	}

	public void RunMachine() {
		Host.New(Settings.HostSelect).Run(M);
		IA = new InputAdapter();
	}

	private EMU7800App() {
		Log.Msg("{0} v{1}", Title, Version);
#if DEBUG
		Log.Msg(" DEBUG");
#endif
		Log.Msg(" {0}\n", Copyright);

		Log.Msg("CLR Version: {0}\n", CLRVersion);
		Log.Msg("OS Version: {0}\n", OSVersion);

		Settings = GlobalSettings.Deserialize();
		ROMProperties = new ROMProperties();
	}

	private void LaunchGUI() {
		Log.Msg("Launching GUI interface\n");
		Application.Run(new ControlPanelForm());
	}

	private bool LaunchFromCL(string[] args) {
		if (args.Length == 0) {
			return false;
		}

		Log.Msg("Attempting command-line invocation of ROM file: \n{0}\n", args[0]);
		if (!File.Exists(args[0])) {
			Log.Msg("ROM file not found\n");
			return false;
		}

		FileInfo fi = new FileInfo(args[0]);
		GameSettings gs = EMU7800App.Instance.ROMProperties.GetGameSettings(MD5.ComputeMD5Digest(fi));
                if (gs == null) {
			Log.Msg("ROM file not recognized\n");
			return false;
		} else {
			gs.FileInfo = fi;
		}

		try {
			EMU7800App.Instance.RunMachine(gs);
			return true;
		} catch (Exception ex) {
			Log.Msg("Error running machine: {0}\n", ex.ToString());
			return false;
		}
	}

	public static void Main(string[] args) {
		if (!EMU7800App.Instance.LaunchFromCL(args)) {
			EMU7800App.Instance.LaunchGUI();
		}
	}
}
}