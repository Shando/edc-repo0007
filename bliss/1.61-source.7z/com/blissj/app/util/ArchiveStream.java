package com.blissj.app.util;

import java.io.*;

public abstract class ArchiveStream extends InputStream
{
    public abstract ArchiveEntry getNextEntry() throws IOException;

    public static ArchiveStream getArchiveStream(String name, InputStream is)
            throws IOException
    {
        String lower = name.toLowerCase();
        if (name.endsWith(".zip"))
            return new ZipArchiveStream(is);
        else if (name.endsWith(".res"))
            return new ResourceArchiveStream(is);
        return null;
    }

    public static boolean isArchiveFormat(String archiveName) {
        String lower = archiveName.toLowerCase();
        return (lower.endsWith(".zip") || lower.endsWith(".res"));
    }

}
