#ifndef _M68KD_H_
#define _M68KD_H_


#ifdef __cplusplus
extern "C" {
#endif


char *M68KDisasm(unsigned short (*NW)(), unsigned int (*NL)());


#ifdef __cplusplus
};
#endif

#endif

