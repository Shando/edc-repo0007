package com.bliss.core.cartridge;

import java.io.*;
import java.util.*;

public class CartridgeTypeFactory
{

    public static CartridgeType[] getCartridgeTypeList() {
        if (cartTypes == null)
            loadCartTypes();
        return cartTypes;
    }

    public static CartridgeType getCartridgeType(long crc) {
        if (cartTypes == null)
            loadCartTypes();

        return (CartridgeType)cartTypesByCrc.get(new Long(crc));
    }

    private static void loadCartTypes() {
        try {
        InputStream is = CartridgeTypeFactory.class.getResourceAsStream("games.ram");

        BufferedReader br = new BufferedReader(new InputStreamReader(is), 4096);
        Vector cartTypesList = new Vector();
        Vector configList = new Vector();
        String nextLine = br.readLine();
        while (nextLine != null) {
            if (!nextLine.equals("<Cartridge>")) {
                nextLine = br.readLine();
                continue;
            }

            nextLine = br.readLine();
            if (!nextLine.startsWith("<Name>")) {
                nextLine = br.readLine();
                continue;
            }
            String name = nextLine.substring(6, nextLine.length()-7);


            nextLine = br.readLine();
            if (!nextLine.startsWith("<Producer>")) {
                nextLine = br.readLine();
                continue;
            }
            String producer = nextLine.substring(10, nextLine.length()-11);

            nextLine = br.readLine();
            if (!nextLine.startsWith("<Year>")) {
                nextLine = br.readLine();
                continue;
            }
            String year = nextLine.substring(6, nextLine.length()-7);

            nextLine = br.readLine();
            if (!nextLine.startsWith("<CRC>")) {
                nextLine = br.readLine();
                continue;
            }

            try {
                long crc = Long.parseLong(nextLine.substring(5,
                        nextLine.length()-6), 16);

                nextLine = br.readLine();
                if (!nextLine.startsWith("<Size>")) {
                    nextLine = br.readLine();
                    continue;
                }

                int size = Integer.parseInt(nextLine.substring(6,
                        nextLine.length()-7));

                nextLine = br.readLine();
                if (!nextLine.startsWith("<Config>")) {
                    nextLine = br.readLine();
                    continue;
                }

                nextLine = br.readLine();
                configList.removeAllElements();
                while (!nextLine.equals("</Config>")) {
                    configList.addElement(nextLine);
                    nextLine = br.readLine();
                }

                boolean requiresECS = false;
                for (int i = 0; i < configList.size(); i++) {
                    nextLine = (String)configList.elementAt(i);
                    if (nextLine.startsWith("ECS")) {
                        requiresECS = true;
                        configList.removeElementAt(i);
                        i--;
                    }
                }
                    
                boolean usesIntellivoice = false;
                for (int i = 0; i < configList.size(); i++) {
                    nextLine = (String)configList.elementAt(i);
                    if (nextLine.startsWith("Intellivoice")) {
                        usesIntellivoice = true;
                        configList.removeElementAt(i);
                        i--;
                    }
                }
                    
                int[][] configs = new int[configList.size()][4];
                for (int i = 0; i < configs.length; i++) {
                    nextLine = (String)configList.elementAt(i);
                    if (nextLine.startsWith("RAM")) {
                        if (nextLine.charAt(3) == '8') {
                            configs[i][0] = Integer.parseInt(
                                    nextLine.substring(6, 10), 16);
                            configs[i][1] = Integer.parseInt(
                                    nextLine.substring(12, 16), 16);
                            configs[i][2] = -8;
                        }
                        else {
                            configs[i][0] = Integer.parseInt(
                                    nextLine.substring(7, 11), 16);
                            configs[i][1] = Integer.parseInt(
                                    nextLine.substring(13, 17), 16);
                            configs[i][2] = -16;
                        }
                        configs[i][3] = -1;
                    }
                    else {
                        configs[i][0] = Integer.parseInt(
                                nextLine.substring(1, 5), 16);
                        configs[i][1] = Integer.parseInt(
                                nextLine.substring(7, 11), 16);
                        configs[i][2] = Integer.parseInt(
                                nextLine.substring(13, 17), 16);
                        if (nextLine.length() > 17)
                            configs[i][3] = Integer.parseInt(
                                nextLine.substring(23, 24), 16);
                        else
                            configs[i][3] = -1;
                    }
                }
                CartridgeType.MemoryMap map = new CartridgeType.
                        MemoryMap(configs);

                cartTypesList.addElement(new CartridgeType(name, producer,
                        year, crc, size, requiresECS, usesIntellivoice, map));
            }
            catch(NumberFormatException nfe) {
                nextLine = br.readLine();
                continue;
            }
        }
        br.close();
        cartTypes = new CartridgeType[cartTypesList.size()];
        cartTypesList.copyInto(cartTypes);

        cartTypesByCrc = new Hashtable();
        for (int i = 0; i < cartTypes.length; i++)
            cartTypesByCrc.put(new Long(cartTypes[i].getCrc()),
                    cartTypes[i]);
        }
        catch (IOException ioe) {
            //something major wrong with the runtime environment here
            ioe.printStackTrace();
        }
    }

    private static CartridgeType[] cartTypes;
    private static Hashtable         cartTypesByCrc;


}
