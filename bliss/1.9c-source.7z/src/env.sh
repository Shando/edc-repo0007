export CVSROOT=$USERNAME@cvs.blissemu.sourceforge.net:/cvsroot/blissemu
export CVSIGNORE="*.class *.obj *.res"
export CVS_RSH=ssh
export SDL_HOME="c:\\dev\\SDL-1.2.2"
export SDL_IMAGE_HOME="c:\\dev\\SDL_image-1.2.0"
export VC_HOME="c:\\dev\\msvc6.0"
export VC_HOME_BASH="/dev/msvc6.0"
export SRC_ROOT="c:\\dev\\bliss\\bliss32\\src"
export SRC_ROOT_BASH="/dev/bliss/bliss32/src"

export INCLUDE="$SDL_HOME\\include;$SDL_IMAGE_HOME\\include;$VC_HOME\\include;$SRC_ROOT;$SRC_ROOT\\kaillera"
export CPLUS_INCLUDE_PATH="/dev/SDL-1.2.2/include:/dev/SDL_image-1.2.0/include:/dev/mingw32/gcc-2.95.2/include/g++-3:/dev/mingw32/gcc-2.95.2/i386-mingw32msvc/include:/dev/bliss/bliss32/src"
export LIB="$SDL_HOME\\lib;$SDL_IMAGE_HOME\\lib;$VC_HOME\\lib;$SRC_ROOT\\kaillera"
export PATH="$PATH:$VC_HOME_BASH/bin:$VC_HOME_BASH/common/MSDev98/bin"

