package com.blissj.app;

import java.awt.*;
import java.io.*;
import java.util.*;
import com.blissj.app.util.*;

public class Bliss
{

    public static void main(String[] args) {
        //display the splash screen
        BlissSplashWindow splash = new BlissSplashWindow();
        BlissUtilities.centerWindowOnScreen(splash);
        splash.setVisible(true);

        //give the splash screen a good half-second to appear and paint
        //the image the first time
        try { Thread.sleep(500); } catch (InterruptedException ignored) {}

        //load the configuration registry
        loadRegistry();

        //display the main frame
        BlissMainFrame frame = new BlissMainFrame();
        frame.setVisible(true);

        //get rid of the splash screen
        splash.setVisible(false);
    }

    private static void loadRegistry() {
        try {
            REGISTRY.loadRegistry();
        }
        catch (IOException ioe) {
            //ignore this.  we'll just create the file later
        }
    }

    public final static ResourceBundle RESOURCES = ResourceBundle.getBundle(
            "i18n/BlissResources");
    public final static ConfigurationRegistry REGISTRY =
            new ConfigurationRegistry(new File("Bliss.cfg"));

}
