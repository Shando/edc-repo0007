#include <windows.h>
#include <tchar.h>
#include <shellapi.h>
#include <commctrl.h>
#include <commdlg.h>

HWND CreateLogoWindow(HWND parent);
