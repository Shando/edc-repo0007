/*
 * EMU][ 0.30pt7 Lite (Dapple ][ 0.28) 2003.0606
 *
 * Dapple ][ Emulator  Version 0.11
 * Copyright (C) 2002, 2003 Dapple ][ Development.  All rights reserved.
 *
 * Component:  PIC: Parallel interface
 * Revision:   (0.11) 2003.0211
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <stdio.h>
#include <string.h>
/* used by chdir */
#include <unistd.h>
#include "dapple.h"
#include "asmlib.h"

/* dapple.c */
extern unsigned char appletype;
extern unsigned char inirompath[260];
extern unsigned char inidebugflag;
extern unsigned char inimenulanguage;
void cwdxchgslash(unsigned char *stringptr, unsigned int value);
void windowpresskey(unsigned int keyboard, unsigned int window);

/* video.c */
extern unsigned char virtvideobyte;


static unsigned char parallelrom[256];
static unsigned char parallelpresent;
unsigned char        parallelactive;


/*--------------------------------------*/


      void parallelinit() {

        memset(parallelrom, 0xaa, sizeof(parallelrom));
        parallelpresent = 0;
        parallelactive  = 1;

      } /* parallelinit */


/*--------------------------------------*/


      void parallelloadrom(unsigned int keyboard, unsigned int window) {
        FILE *file;
        unsigned char filepath[260];
        unsigned char oldcwd[260];

        cwdxchgslash(oldcwd, 256);                              /* read old directory path      */
        chdir(inirompath);                                      /* set rom directory            */

        strcpy(filepath, "slotprnt.a65");                       /* search for source code       */
        file=fopen(filepath,"rb");
        if (!file) {
          strcpy(filepath, "slotprnt.s");
          file=fopen(filepath,"rb");
          if (!file) {
            strcpy(filepath, "slotprnt.asm");
            file=fopen(filepath,"rb");
          }
        }
        if (file) {
          fclose(file);                                         /* close file again */
          stringwritemessage(window,
"!\
EAssemble source code for parallel port slot rom...\r;\
GAssembliere Source Code f�r das Parallelport-Slotrom...\r;\
;");
          imageupdate();
          memset(parallelrom, 0xaa, sizeof(parallelrom));
          assembler(parallelrom, sizeof(parallelrom), filepath);        /* assemble source code */
          parallelpresent = 1;
        }
        else {
          strcpy(filepath, "parallel.rom");;                            /* search binary rom file       */
          file=fopen(filepath,"rb");
          if (file) {
            stringwritemessage(window,
"!\
EReading parallel port slot rom from file...\r;\
GLese Parallelport-Slotrom aus Datei...\r;\
;");
            imageupdate();
            fread(parallelrom, sizeof(parallelrom), 1, file);           /* read binary rom file */
            fclose(file);
            parallelpresent = 1;
          }
          else {
            stringwritemessage(window,
"!\
ENo separate parallel port slot rom found\r;\
GKein gesondertes Parallelport-Slotrom vorhanden\r;\
;");
            parallelpresent = 0;
            parallelactive  = 0;
            imageupdate();
          }
        }
        chdir(oldcwd);                                                  /* restore original directory */
/*      windowpresskey(keyboard, window); */
/*      debugger(driverom, sizeof(driverom)); */

      } /* parallelloadrom */


/*--------------------------------------*/


      unsigned char parallelread(unsigned int addr) {

        return virtvideobyte;

      } /* parallelread */


/*--------------------------------------*/


      void parallelwrite(unsigned int addr, unsigned int value) {

        if ((inidebugflag) || (!parallelactive)) {
          return;
        }

        switch (addr & 0x0f) {
          case 0x00 :   /* load output port */
            fputc(value & 0x7F, stdprn);
            fflush(stdprn);
            break;
        } /* switch */

      } /* parallelwrite */


/*--------------------------------------*/


      unsigned char parallelromread(unsigned int addr) {

        if (parallelactive) {
          return parallelrom[addr & 0xff];      /* read from the rom which was separately loaded */
        }
        else {
          return 0xaa;
        }

      } /* parallelromread */


/*--------------------------------------*/


      void parallelromwrite(unsigned int addr, unsigned int value) {

        return;         /* Nothing happens here */

      } /* parallelromwrite */


/*---------------------------------------*/


      unsigned int parallelstore(unsigned int winprotocol, FILE *file) {
        unsigned char header[32];

        memset(header, 0x00, sizeof(header));
        strcpy(header, "PARALLEL STATE V0.27");
        fwrite(header,                  sizeof(header),                 1,file);

        fwrite(parallelrom,             sizeof(parallelrom),            1,file);
        fwrite(&parallelpresent,        sizeof(parallelpresent),        1,file);
        fwrite(&parallelactive,         sizeof(parallelactive),         1,file);

        stringwrite(winprotocol, "Parallel interface stored.\r");

        return 0;

      } /* parallelstore */


/*--------------------------------------*/


      unsigned int parallelrestore(unsigned int winprotocol, FILE *file) {
        unsigned char header[32];

        fread(header,                   sizeof(header),                 1,file);
        if (strcmp(header, "PARALLEL STATE V0.27")) {
          stringwrite(winprotocol, "Parallel interface emulation data not found.\r");
          return 1;
        }

        fread(parallelrom,              sizeof(parallelrom),            1,file);
        fread(&parallelpresent,         sizeof(parallelpresent),        1,file);
        fread(&parallelactive,          sizeof(parallelactive),         1,file);

        stringwrite(winprotocol, "Parallel interface restored.\r");

        return 0;

      } /* parallelrestore */

/*--------------------------------------*/


      void parallelmenu () {
        unsigned int    screen;
        unsigned int    keyboard;
        unsigned int    window;
        unsigned char   key;
        unsigned int    update;

        screen = screenstore();
        if (inimenulanguage == 'E') {
          update = windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1,
                                "Parallel Interface Options", &keyboard, &window);
        }
        else {
          update = windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1,
                                "Parallelschnittstelle Optionen", &keyboard, &window);
        }
        if (!update) {
          update = 1;
          do {
            if (update) {
              channelout(window, 12);           /* clear window */
              stringwritemessage(window,
"!;\
E\
\r[ESC] - Quit\r\r\
;\
G\
\r[ESC] - Verlasse Men�\r\r\
;\
");
              if (!parallelpresent) {
                stringwritemessage(window,
"!;\
E\
\rNo parallel interface present\
;\
G\
\rKeine parallele Schnittstelle vorhanden\
;\
");
              }
              else {
                if (parallelactive) {
                  stringwritemessage(window,
"!;\
E\
\r[A] - Parallel interface activated\
;\
G\
\r[A] - Parallele Schnittstelle aktiviert\
;\
");
                }
                else {
                  stringwritemessage(window,
"!;\
E\
\r[A] - Parallel interface inactive\
;\
G\
\r[A] - Parallele Schnittstelle deaktiviert\
;\
");
                }
              }
              update = 0;
            }
            do {
              imageupdate();
              key = (unsigned char)channelin(keyboard);
            }
            while ((key == 0) && (!exitprogram));
            switch (key) {
              case 'a' :
              case 'A' :
                if (parallelpresent) {
                  if (parallelactive) {
                    parallelactive = 0;
                  }
                  else {
                    parallelactive = 1;
                  }
                  update = 1;
                }
                break;
            } /* switch (key) */
          }
          while ((key != 27) && (key != 32) && (key != 13) && (!exitprogram));
          channelclose(keyboard);
          channelclose(window);
        }
        screenrestore(screen);

      } /* parallelmenu */
