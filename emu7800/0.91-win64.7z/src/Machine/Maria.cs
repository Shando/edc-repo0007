/*
 * Maria.cs
 *
 * The Maria display device.
 * 
 * Derived from much of Dan Boris' work with 7800 emulation
 * within the MESS emulator.
 *
 * Thanks to Matthias Luedtke <matthias@atari8bit.de> for correcting
 * the BuildLineRAM320B() method to correspond to what the real hardware does.
 * (Matthias credited an insightful response by Eckhard Stolberg on a forum on
 * Atari Age circa June 2005.)
 * 
 * Copyright (c) 2004-2008 Mike Murphy
 *
 */
using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;

namespace EMU7800.Machine 
{
    [Serializable]
    public sealed class Maria : IDevice
    {
        #region Constants

        const int
            INPTCTRL= 0x01,	// Write: input port control (VBLANK in TIA)
            INPT0	= 0x08,	// Read pot port: D7
            INPT1	= 0x09,	// Read pot port: D7
            INPT2	= 0x0a,	// Read pot port: D7
            INPT3	= 0x0b,	// Read pot port: D7
            INPT4	= 0x0c,	// Read P1 joystick trigger: D7
            INPT5	= 0x0d,	// Read P2 joystick trigger: D7
            AUDC0	= 0x15,	// Write: audio control 0 (D3-0)
            AUDC1	= 0x16,	// Write: audio control 1 (D4-0)
            AUDF0	= 0x17,	// Write: audio frequency 0 (D4-0)
            AUDF1	= 0x18,	// Write: audio frequency 1 (D3-0)
            AUDV0	= 0x19,	// Write: audio volume 0 (D3-0)
            AUDV1	= 0x1a,	// Write: audio volume 1 (D3-0)

            BACKGRND= 0x20,	// Background color
            P0C1	= 0x21, // Palette 0 - color 1
            P0C2	= 0x22, // Palette 0 - color 2
            P0C3	= 0x23, // Palette 0 - color 3
            WSYNC	= 0x24, // Wait for sync
            P1C1	= 0x25, // Palette 1 - color 1
            P1C2	= 0x26, // Palette 1 - color 2
            P1C3	= 0x27,	// Palette 1 - color 3
            MSTAT	= 0x28,	// Maria status
            P2C1	= 0x29,	// Palette 2 - color 1
            P2C2	= 0x2a,	// Palette 2 - color 2
            P2C3	= 0x2b,	// Palette 2 - color 3
            DPPH	= 0x2c,	// Display list list point high
            P3C1	= 0x2d,	// Palette 3 - color 1
            P3C2	= 0x2e,	// Palette 3 - color 2
            P3C3	= 0x2f,	// Palette 3 - color 3
            DPPL	= 0x30,	// Display list list point low
            P4C1	= 0x31, // Palette 4 - color 1
            P4C2	= 0x32,	// Palette 4 - color 2
            P4C3	= 0x33,	// Palette 4 - color 3
            CHARBASE= 0x34,	// Character base address
            P5C1	= 0x35,	// Palette 5 - color 1
            P5C2	= 0x36,	// Palette 5 - color 2
            P5C3	= 0x37,	// Palette 5 - color 3
            OFFSET	= 0x38,	// Future expansion (store zero here)
            P6C1	= 0x39,	// Palette 6 - color 1
            P6C2	= 0x3a,	// Palette 6 - color 2
            P6C3	= 0x3b,	// Palette 6 - color 3
            CTRL	= 0x3c,	// Maria control register
            P7C1	= 0x3d,	// Palette 7 - color 1
            P7C2	= 0x3e,	// Palette 7 - color 2
            P7C3	= 0x3f;	// Palette 7 - color 3

        #endregion

        #region Data Structures

        readonly byte[] LineRAM = new byte[512];
        [SuppressMessage("Microsoft.Performance", "CA1814:PreferJaggedArraysOverMultidimensional", MessageId = "Member")]
        readonly byte[,] MariaPalette = new byte[8, 4];
        readonly byte[] Registers = new byte[0x40];

        AddressSpace Mem;
        readonly Machine7800 M;
        readonly TIASound TIASound;

        #endregion

        #region Misc

        int ScanLine;

        byte WM;
        ushort DLL;
        ushort DL;
        int Offset;
        int Holey;
        int Width;
        byte HPOS;
        byte PaletteNo;
        bool INDMode;
        bool DLI;

        bool CtrlLock;
        byte VBlank;

        // MARIA CNTL
        bool DMAEnabled, DMAOn;
        [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
        bool ColorKill;
        bool CWidth;
        [SuppressMessage("Microsoft.Performance", "CA1823:AvoidUnusedPrivateFields")]
        bool BCntl;
        bool Kangaroo;
        byte RM;

        #endregion

        #region Public Members

        public void Reset()
        {
            CtrlLock = false;

            for (var i=0; i < 8; i++) 
            {
                for (var j=0; j < 4; j++) 
                {
                    MariaPalette[i,j] = 0;
                }
            }

            VBlank = 0x80;

            DMAEnabled = false;
            DMAOn = false;

            ColorKill = false;
            CWidth = false;
            BCntl = false;
            Kangaroo = false;
            RM = 0;
                
            TIASound.Reset();

            Trace.Write(this);
            Trace.WriteLine(" reset");
        }

        public byte this[ushort addr]
        {
            get { return peek(addr); }
            set { poke(addr, value); }
        }	

        public void Map(AddressSpace mem)
        {
            Mem = mem;
        }
    
        public override string ToString()
        {
            return "Maria";
        }

        public void StartFrame()
        {
            TIASound.StartFrame();
        }

        public void DoScanline(int scanline)
        {
            ScanLine = scanline;

            for (var i=0; i < LineRAM.Length; i++)
            {
                LineRAM[i] = Registers[BACKGRND];
            }

            if (ScanLine == 15)
            {
                VBlank = 0x00;  // End of VBLANK
                M.CPU.RunClocks -= 15; // 10-13 + 5-9

                if (DMAEnabled || DMAOn)
                {
                    DMAOn = true;
                    DLL = WORD(Registers[DPPL], Registers[DPPH]);

                    DL = WORD(Mem[(ushort)(DLL + 2)], Mem[(ushort)(DLL + 1)]);
                    byte dll0 = Mem[DLL];
                    DLI = (dll0 & 0x80) != 0;
                    Holey = (dll0 & 0x60) >> 5;
                    Offset = dll0 & 0x0f;
                }
            } 
            else if (ScanLine == (M.Scanlines - 5))
            {
                VBlank = 0x80;  // Start of VBLANK
                DMAOn = false;
            }

            if (DMAOn)
            {
                // DMA Startup
                M.CPU.RunClocks -= 5;// 5-9

                BuildLineRAM();

                if (--Offset < 0)
                {
                    DLL += 3;

                    DL = WORD(Mem[(ushort)(DLL + 2)], Mem[(ushort)(DLL + 1)]);
                    byte dll0 = Mem[DLL];
                    DLI = (dll0 & 0x80) != 0;
                    Holey = (dll0 & 0x60) >> 5;
                    Offset = dll0 & 0x0f;

                    // DMA Shutdown: Last line of zone
                    M.CPU.RunClocks -= 10;// 10-13
                } //else {
                // DMA Shutdown: Other line of zone
                M.CPU.RunClocks -= 4;// 4-7
            }

            if (DLI)
            {
                M.CPU.NMIInterruptRequest = true;
                DLI = false;

                M.CPU.RunClocks -= 1;
            }

            var fbi = (ScanLine + 1) * M.VisiblePitch;
            for (var i = 0; i < 320; i++)
            {
                M.VideoFrameBuffer[fbi++ % M.VideoFrameBuffer.Length] = LineRAM[i];
            }
        }

        public void EndFrame()
        {
            TIASound.EndFrame();
        }

        #endregion

        #region Constructors

        private Maria()
        {
        }

        public Maria(Machine7800 m) : this()
        {
            if (m == null) throw new ArgumentNullException("m");

            M = m;
            TIASound = new TIASound(M);
        }

        #endregion

        #region ScanLine Builders

        void BuildLineRAM()
        {
            var dl = DL;

            // Iterate until end of display list (DL)
            while (Mem[(ushort)(dl + 1)] != 0) 
            {
                ushort graphaddr;
                if ((Mem[(ushort)(dl + 1)] & 0x5f) == 0x40) 
                {
                    // Extended DL header
                    graphaddr = WORD(Mem[dl], Mem[(ushort)(dl + 2)]);
                    Width = ((Mem[(ushort)(dl + 3)] ^ 0xff) & 0x1f) + 1;
                    HPOS = Mem[(ushort)(dl + 4)];
                    PaletteNo = (byte)(Mem[(ushort)(dl + 3)] >> 5);
                    WM = (byte)((Mem[(ushort)(dl + 1)] & 0x80) >> 5);
                    INDMode = (Mem[(ushort)(dl + 1)] & 0x20) != 0;
                    dl += 5;

                    M.CPU.RunClocks -= 12;
                } 
                else 
                {
                    // Normal DL header
                    graphaddr = WORD(Mem[dl], Mem[(ushort)(dl + 2)]);
                    Width = ((Mem[(ushort)(dl + 1)] ^ 0xff) & 0x1f) + 1;
                    HPOS = Mem[(ushort)(dl + 3)];
                    PaletteNo = (byte)(Mem[(ushort)(dl + 1)] >> 5);
                    INDMode = false;
                    dl += 4;

                    M.CPU.RunClocks -= 8;
                }

                switch (RM | WM)
                {
                    case 0x00:
                        //case 0x01:
                        BuildLineRAM160A(graphaddr);
                        break;
                    case 0x02:
                        BuildLineRAM320D(graphaddr);
                        break;
                    case 0x03:
                        BuildLineRAM320A(graphaddr);
                        break;
                    case 0x04:
                        //case 0x05:
                        BuildLineRAM160B(graphaddr);
                        break;
                    case 0x06:
                        BuildLineRAM320B(graphaddr);
                        break;
                    case 0x07:
                        BuildLineRAM320C(graphaddr);
                        break;
                }
            }
        }

        void BuildLineRAM160A(ushort graphaddr)
        {
            var hpos = HPOS;

            for (var x=0; x < Width; x++) 
            {
                var dataaddr = (ushort)(graphaddr + x);
                if (INDMode) 
                {
                    dataaddr = WORD(Mem[dataaddr], Registers[CHARBASE]);
                    M.CPU.RunClocks -= 3;
                }
                dataaddr += (ushort)(Offset << 8);

                if (Holey == 0x02 && ((dataaddr & 0x9000) == 0x9000))
                    continue;
                if (Holey == 0x01 && ((dataaddr & 0x8800) == 0x8800))
                    continue;

                var indbytes = (INDMode && CWidth) ? 2 : 1;

                while (indbytes-- > 0) 
                {
                    int d = Mem[dataaddr++];
                    M.CPU.RunClocks -= 3;

                    var c = (d & 0xc0) >> 6;
                    if (c != 0) 
                    {
                        LineRAM[hpos << 1]
                            = LineRAM[(hpos << 1) + 1]
                            = MariaPalette[PaletteNo,c];
                    }
                    hpos++;

                    c = (d & 0x30) >> 4;
                    if (c != 0) 
                    {
                        LineRAM[hpos << 1]
                            = LineRAM[(hpos << 1) + 1]
                            = MariaPalette[PaletteNo,c];
                    }
                    hpos++;

                    c = (d & 0x0c) >> 2;
                    if (c != 0) 
                    {
                        LineRAM[hpos << 1]
                            = LineRAM[(hpos << 1) + 1]
                            = MariaPalette[PaletteNo,c];
                    }
                    hpos++;

                    c = d & 0x03;
                    if (c != 0) 
                    {
                        LineRAM[hpos << 1]
                            = LineRAM[(hpos << 1) + 1]
                            = MariaPalette[PaletteNo,c];
                    }
                    hpos++;
                }
            }
        }

        void BuildLineRAM160B(ushort graphaddr)
        {
            var hpos = HPOS;

            for (var x=0; x < Width; x++) 
            {
                var dataaddr = (ushort)(graphaddr + x);
                if (INDMode) 
                {
                    dataaddr = WORD(Mem[dataaddr], Registers[CHARBASE]);
                    M.CPU.RunClocks -= 3;
                }
                dataaddr += (ushort)(Offset << 8);

                if (Holey == 0x02 && ((dataaddr & 0x9000) == 0x9000))
                    continue;
                if (Holey == 0x01 && ((dataaddr & 0x8800) == 0x8800))
                    continue;

                var indbytes = (INDMode && CWidth) ? 2 : 1;

                while (indbytes-- > 0) 
                {
                    int d = Mem[dataaddr++];
                    M.CPU.RunClocks -= 3;

                    var c = (d & 0xc0) >> 6;
                    int p;
                    if (c != 0) 
                    {
                        p = (PaletteNo & 0x04) | ((d & 0x0c) >> 2);
                        LineRAM[hpos << 1]
                            = LineRAM[(hpos << 1) + 1]
                            = MariaPalette[p,c];
                    }
                    hpos++;

                    c = (d & 0x30) >> 4;
                    if (c != 0) 
                    {
                        p = (PaletteNo & 0x04) | (d & 0x03);
                        LineRAM[hpos << 1]
                            = LineRAM[(hpos << 1) + 1]
                            = MariaPalette[p,c];
                    }
                    hpos++;
                }
            }
        }

        void BuildLineRAM320A(ushort graphaddr)
        {
            var hpos = HPOS << 1;

            for (var x=0; x < Width; x++) 
            {
                var dataaddr = (ushort)(graphaddr + x);
                if (INDMode) 
                {
                    dataaddr = WORD(Mem[dataaddr], Registers[CHARBASE]);
                    M.CPU.RunClocks -= 3;
                }
                dataaddr += (ushort)(Offset << 8);

                if (Holey == 0x02 && ((dataaddr & 0x9000) == 0x9000))
                    continue;
                if (Holey == 0x01 && ((dataaddr & 0x8800) == 0x8800))
                    continue;

                int d = Mem[dataaddr];
                M.CPU.RunClocks -= 3;

                if ((d & 0x80) != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo,2];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                if ((d & 0x40) != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo,2];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                if ((d & 0x20) != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo,2];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                if ((d & 0x10) != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo,2];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                if ((d & 0x08) != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo,2];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                if ((d & 0x04) != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo,2];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                if ((d & 0x02) != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo,2];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                if ((d & 0x01) != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo,2];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;
            }
        }

        void BuildLineRAM320B(ushort graphaddr)
        {
            var hpos = HPOS << 1;

            for (var x = 0; x < Width; x++)
            {
                var dataaddr = (ushort)(graphaddr + x);
                if (INDMode)
                {
                    dataaddr = WORD(Mem[dataaddr], Registers[CHARBASE]);
                    M.CPU.RunClocks -= 3;
                }
                dataaddr += (ushort)(Offset << 8);

                if (Holey == 0x02 && ((dataaddr & 0x9000) == 0x9000))
                    continue;
                if (Holey == 0x01 && ((dataaddr & 0x8800) == 0x8800))
                    continue;

                var indbytes = (INDMode && CWidth) ? 2 : 1;

                while (indbytes-- > 0)
                {
                    int d = Mem[dataaddr++];
                    M.CPU.RunClocks -= 3;

                    var c = ((d & 0x80) >> 6) | ((d & 0x08) >> 3);
                    if (c != 0)
                    {
                        if ((d & 0xc0) != 0 || Kangaroo)
                            LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo, c];
                    }
                    else if (Kangaroo)
                        LineRAM[hpos & 0x1ff] = Registers[BACKGRND];
                    else if ((d & 0xcc) != 0)
                        LineRAM[hpos & 0x1ff] = Registers[BACKGRND];
                    hpos++;

                    c = ((d & 0x40) >> 5) | ((d & 0x04) >> 2);
                    if (c != 0)
                    {
                        if ((d & 0xc0) != 0 || Kangaroo)
                            LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo, c];
                    }
                    else if (Kangaroo)
                        LineRAM[hpos & 0x1ff] = Registers[BACKGRND];
                    else if ((d & 0xcc) != 0)
                        LineRAM[hpos & 0x1ff] = Registers[BACKGRND];
                    hpos++;

                    c = ((d & 0x20) >> 4) | ((d & 0x02) >> 1);
                    if (c != 0)
                    {
                        if ((d & 0x30) != 0 || Kangaroo)
                            LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo, c];
                    }
                    else if (Kangaroo)
                        LineRAM[hpos & 0x1ff] = Registers[BACKGRND];
                    else if ((d & 0x33) != 0)
                        LineRAM[hpos & 0x1ff] = Registers[BACKGRND];
                    hpos++;

                    c = ((d & 0x10) >> 3) | (d & 0x01);
                    if (c != 0)
                    {
                        if ((d & 0x30) != 0 || Kangaroo)
                            LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo, c];
                    }
                    else if (Kangaroo)
                        LineRAM[hpos & 0x1ff] = Registers[BACKGRND];
                    else if ((d & 0x33) != 0)
                        LineRAM[hpos & 0x1ff] = Registers[BACKGRND];
                    hpos++;
                }
            }
        }
        
        void BuildLineRAM320C(ushort graphaddr) 
        {
            var hpos = HPOS << 1;

            for (var x=0; x < Width; x++) 
            {
                var dataaddr = (ushort)(graphaddr + x);
                if (INDMode) 
                {
                    dataaddr = WORD(Mem[dataaddr], Registers[CHARBASE]);
                    M.CPU.RunClocks -= 3;
                }
                dataaddr += (ushort)(Offset << 8);

                if (Holey == 0x02 && ((dataaddr & 0x9000) == 0x9000))
                    continue;
                if (Holey == 0x01 && ((dataaddr & 0x8800) == 0x8800))
                    continue;

                int d = Mem[dataaddr];
                M.CPU.RunClocks -= 3;

                var p = ((d & 0x0c) >> 2) | (PaletteNo & 0x04);

                if ((d & 0x80) != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[p,2];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                if ((d & 0x40) != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[p,2];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                p = (d & 0x03) | (PaletteNo & 0x04);
                if ((d & 0x20) != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[p,2];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                if ((d & 0x10) != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[p,2];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;
            }
        }

        void BuildLineRAM320D(ushort graphaddr) 
        {
            var hpos = HPOS << 1;

            for (var x=0; x < Width; x++) 
            {
                var dataaddr = (ushort)(graphaddr + x);
                if (INDMode) 
                {
                    dataaddr = WORD(Mem[dataaddr], Registers[CHARBASE]);
                    M.CPU.RunClocks -= 3;
                }
                dataaddr += (ushort)(Offset << 8);

                if (Holey == 0x02 && ((dataaddr & 0x9000) == 0x9000))
                    continue;
                if (Holey == 0x01 && ((dataaddr & 0x8800) == 0x8800))
                    continue;

                int d = Mem[dataaddr];
                M.CPU.RunClocks -= 3;

                var c = ((d & 0x80) >> 6) | ((PaletteNo & 2) >> 1);
                if (c != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo & 0x04,c];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                c = ((d & 0x40) >> 5) | (PaletteNo & 1);
                if (c != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo & 0x04,c];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                c = ((d & 0x20) >> 4) | ((PaletteNo & 2) >> 1);
                if (c != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo & 0x04,c];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                c = ((d & 0x10) >> 3) | (PaletteNo & 1);
                if (c != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo & 0x04,c];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                c = ((d & 0x08) >> 2) | ((PaletteNo & 2) >> 1);
                if (c != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo & 0x04,c];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                c = ((d & 0x04) >> 1 ) | (PaletteNo & 1);
                if (c != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo & 0x04,c];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                c = (d & 0x02) | ((PaletteNo & 2) >> 1);
                if (c != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo & 0x04,c];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;

                c = ((d & 0x01) << 1) | (PaletteNo & 1);
                if (c != 0)
                    LineRAM[hpos & 0x1ff] = MariaPalette[PaletteNo & 0x04,c];
                else if (Kangaroo)
                    LineRAM[hpos & 0x1ff] = Registers[BACKGRND];

                hpos++;
            }
        }

        static ushort WORD(byte lsb, byte msb)
        {
            return (ushort)(lsb | msb << 8);
        }

        #endregion

        #region Maria Peek

        byte peek(ushort addr)
        {
            byte retval;
            var scanline = ScanLine;
            addr &= 0x3f;

            if (addr < 0x20) 
            {
                M.CPU.RunClocks -= 2;
            }

            switch(addr) 
            {
                case MSTAT:
                    retval = VBlank;
                    break;
                case INPT0:
                    retval = DumpedInputPort(M.InputAdapter.ReadINPT0());
                    break;
                case INPT1:
                    retval = DumpedInputPort(M.InputAdapter.ReadINPT1());
                    break;
                case INPT2:
                    retval = DumpedInputPort(M.InputAdapter.ReadINPT2());
                    break;
                case INPT3:
                    retval = DumpedInputPort(M.InputAdapter.ReadINPT3());
                    break;
                case INPT4:
                    int hpos = 114*M.CPU.RunClocksMultiple - M.CPU.RunClocks;
                    retval = M.InputAdapter.ReadINPT4(scanline, hpos) ? (byte)0x00 : (byte)0x80;
                    break;
                case INPT5:
                    hpos = 114*M.CPU.RunClocksMultiple - M.CPU.RunClocks;
                    retval = M.InputAdapter.ReadINPT5(ScanLine, hpos) ? (byte)0x00 : (byte)0x80;
                    break;
                default:
                    Debug.WriteLine(string.Format("Unhandled Maria/TIA peek:{0:x4}", addr));
                    retval = Registers[addr];
                    break;
            }
            return retval;
        }

        static byte DumpedInputPort(int resistance)
        {
            byte retval = 0;

            if (resistance == 0)
            {
                retval = 0x80;
            }
            return retval;
        }

        #endregion

        #region Maria Poke

        void poke(ushort addr, byte data)
        {
            addr &= 0x3f;

            if (addr < 0x20)
            {
                M.CPU.RunClocks -= 2;
            }

            switch (addr) 
            {
                    //		Not sure about these:
                    //		0000 0000 = ($00) disable 7800 RAM (2600 mode?)
                    //		0000 0010 = ($02) enable 7800 RAM/switch in bios
                    //		0001 0110 = ($16) switch in cart
                    //		0001 1101 - ($1d) self-test failure, enable tia/cart lockout
                case INPTCTRL:
                    if (data == 0x1d)
                    {
                        Trace.WriteLine(string.Format("7800 BIOS Error (#{0}):\n", M.CPU.Y));
                        switch (M.CPU.Y)
                        {
                            case 00: Trace.WriteLine("BADCPU: CPU ERROR"); break;
                            case 01: Trace.WriteLine("BAD6116A: ERROR IN RAM $2000-$27FF"); break;
                            case 02: Trace.WriteLine("BAD6116B: ERROR IN RAM $1800-$1FFF"); break;
                            case 03: Trace.WriteLine("BADRAM: CAN'T GET TO ANY OF THE RAM"); break;
                            case 04: Trace.WriteLine("BADMARIA: MARIA SHADOWING NOT WORING"); break;
                            case 05: Trace.WriteLine("BADVALID: BAD VALIDATION OR DECRYPTION"); break;
                            default: Trace.WriteLine("Unknown BIOS error code"); break;
                        }
                        Trace.WriteLine("Machine Halted");
                        M.MachineHalt = true;
                    }

                    if (!CtrlLock)
                    {
                        CtrlLock = (data & 0x01) != 0;
                        if ((data & 0x04) != 0) 
                        {
                            M.SwapOutBIOS();
                        } 
                        else 
                        {
                            M.SwapInBIOS();
                        }
                    }
                    break;
                case WSYNC:
                    // Request a CPU preemption to service the delay request
                    M.CPU.EmulatorPreemptRequest = true;
                    break;
                case CTRL:
                    ColorKill = (data & 0x80) != 0;
                    DMAEnabled = (data & 0x60) == 0x40;
                    if (!DMAEnabled)
                    {
                        DMAOn = false;
                    }
                    CWidth = (data & 0x10) != 0;
                    BCntl = (data & 0x08) != 0;
                    Kangaroo = (data & 0x04) != 0;
                    RM = (byte)(data & 0x03);
                    break;
                case CHARBASE:
                    Registers[CHARBASE] = data;
                    break;
                case BACKGRND:
                    Registers[BACKGRND] = data;
                    break;
                case DPPH:
                    Registers[DPPH] = data;
                    break;
                case DPPL:
                    Registers[DPPL] = data;
                    break;
                case P0C1:
                    MariaPalette[0,1] = data;
                    break;
                case P0C2:
                    MariaPalette[0,2] = data;
                    break;
                case P0C3:
                    MariaPalette[0,3] = data;
                    break;
                case P1C1:
                    MariaPalette[1,1] = data;
                    break;
                case P1C2:
                    MariaPalette[1,2] = data;
                    break;
                case P1C3:
                    MariaPalette[1,3] = data;
                    break;
                case P2C1:
                    MariaPalette[2,1] = data;
                    break;
                case P2C2:
                    MariaPalette[2,2] = data;
                    break;
                case P2C3:
                    MariaPalette[2,3] = data;
                    break;
                case P3C1:
                    MariaPalette[3,1] = data;
                    break;
                case P3C2:
                    MariaPalette[3,2] = data;
                    break;
                case P3C3:
                    MariaPalette[3,3] = data;
                    break;
                case P4C1:
                    MariaPalette[4,1] = data;
                    break;
                case P4C2:
                    MariaPalette[4,2] = data;
                    break;
                case P4C3:
                    MariaPalette[4,3] = data;
                    break;
                case P5C1:
                    MariaPalette[5,1] = data;
                    break;
                case P5C2:
                    MariaPalette[5,2] = data;
                    break;
                case P5C3:
                    MariaPalette[5,3] = data;
                    break;
                case P6C1:
                    MariaPalette[6,1] = data;
                    break;
                case P6C2:
                    MariaPalette[6,2] = data;
                    break;
                case P6C3:
                    MariaPalette[6,3] = data;
                    break;
                case P7C1:
                    MariaPalette[7,1] = data;
                    break;
                case P7C2:
                    MariaPalette[7,2] = data;
                    break;
                case P7C3:
                    MariaPalette[7,3] = data;
                    break;
                case AUDC0:
                case AUDC1:
                case AUDF0:
                case AUDF1:
                case AUDV0:
                case AUDV1:
                    TIASound.Update(addr, data);
                    break;
                case OFFSET:
                    Trace.WriteLine(string.Format("ROM wrote 0x{0:x2} to 0x{1:x4} (reserved for future expansion)", data, addr));
                    break;
                default:
                    Debug.WriteLine(string.Format("Unhandled Maria/TIA poke:{0:x4} w/{1:x2}", addr, data));
                    break;
            }

            Registers[addr] = data;
        }

        #endregion
    }
}
