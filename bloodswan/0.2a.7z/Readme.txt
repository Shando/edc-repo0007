BLOODSWAN 0.2alpha
Based Cygne


-----------------------------------------------------------------------------------------------------------------------------
Versi�n 0.2a �sea la segunda Versi�n de este emulador basado en el codigo de fuente del Cygne hasta haora solo le e corregido alguno bugs que teneia con la final fantasy y lo e traducido al espa�ol y ademas e modificado los menus espero que env�en sus quejas y Bugs que pueda tener el Emulador *no tienes el sonido implementado pero rula de forma normal 


-----------------------------------------------------------------------------------------------------------------------------



Esta es una Version Apartir del codigo de Fuente del Cygne osea que Cygne is � by Dox no tiene que ver nada con este proyecto. 





BLoodsoft
WEB: http://Gbloody.tripod.com

Email: GBLOODY@HOTMAIL.com




Cygne 
http://cygne.emuunlim.com/