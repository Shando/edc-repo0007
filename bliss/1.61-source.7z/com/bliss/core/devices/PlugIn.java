package com.bliss.core.devices;

import com.bliss.core.*;

public interface PlugIn
{

    public String getPlugInName();

    public String getPlugInDescription();

    public boolean stopRequested();

    public void init(Intellivision inty);

    public void release(Intellivision inty);

    public ClockDevice getClockDevice();

    public VideoOutputDevice getVideoOutputDevice();

    public AudioOutputDevice getAudioOutputDevice();

    public InputDevice getInputDevice();

}
