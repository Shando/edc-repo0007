package com.bliss.core.ivoice;

import com.bliss.core.*;
import com.bliss.core.devices.*;

public class Intellivoice implements Peripheral
{

    public Intellivoice(AudioMixer.AudioOutputLine aol) {
        lpc12 = new LPC12(aol);
        microSequencer = new MicroSequencer(lpc12);
    }

    public int getProcessorCount() {
        return 2;
    }

    public void setAudioEnabled(boolean b) {
        this.audioEnabled = b;
        lpc12.audioEnabled = b;
    }

    public Processor getProcessor(int i) {
        return (i == 0 ? (Processor)microSequencer : (Processor)lpc12);
    }

    public int getMemoryCount() {
        return 1;
    }

    public Memory getMemory(int i) {
        return microSequencer.registers;
    }

    public void setIntellivoiceImage(int[] image) {
        System.arraycopy(image, 0, microSequencer.ivoiceROMImage, 0,
                microSequencer.ivoiceROMImage.length);
        hasIvoiceImage = true;
    }

    public boolean hasIntellivoiceImage() {
        return hasIvoiceImage;
    }

    private boolean audioEnabled = true;
    private MicroSequencer microSequencer;
    private LPC12 lpc12;
    private boolean hasIvoiceImage = false;

}
