/*
 * EMU][ Apple ][-class emulator
 * Copyright (C) 2002, 2003 by the EMU][ Project/Dapple ][ Team
 *
 * $Header: /winc/emuiil/source/dapple.h,v 1.5 2003/08/30 10:22:29 dosius Exp $
 *
 * Component:  Header file for Dapple shared components
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Log: dapple.h,v $
 * Revision 1.5  2003/08/30 10:22:29  dosius
 * Bugfixes; work on Z80 core
 *
 */

#define structpack __attribute__((packed))

typedef enum {USA, France, Germany, UK, Denmark1, Sweden, Italy, Spain,
              Japan, Norway, Denmark2, None} Charset;
typedef unsigned char byte;
typedef unsigned short int word;


/* type of apple */
#define APPLEII 1
#define APPLEIIE 2
#define APPLEIIC 4

/* type of CPU */
#define CPU6502		0x01
#define CPU65C02	0x02
#define CPU65SC02	0x04
#define CPUZ80		0x08

/* window size of standard menus */
#define WINDOWXSIZE 512
#define WINDOWYSIZE 256

/* rgb values */
#define RGBBLACK	0x000000
#define RGBDARK		0x202020
#define RGBLIGHT	0xc0c0c0
#define RGBDGREY	0x404040
#define RGBGREY		0x808080
#define RGBLGREY	0xc0c0c0
#define RGBWHITE	0xffffff
#define RGBLBLUE	0x3050ff
/* slot drive lights */
#define SLOTX1 628
#define SLOTX2 632
#define SLOT5Y 10
#define SLOT6Y 14
#define RGBLGHTON 0xff0000
#define RGBLGHTOFF 0x404040


/* cpu65c02.c */
#define STATEHALT  0x01
#define STATERESET 0x02
#define STATENMI   0x04
#define STATEIRQ   0x08
#define STATEBRK   0x10
#define STATETRACE 0x20
#define STATEBPT   0x40
#define STATEGURU  0x80


/* video.c */
/* Color definitions */

/* Lo-res graphics */
#define COL_LGR0 0xc0
#define COL_LGR1 0xc1
#define COL_LGR2 0xc2
#define COL_LGR3 0xc3
#define COL_LGR4 0xc4
#define COL_LGR5 0xc5
#define COL_LGR6 0xc6
#define COL_LGR7 0xc7
#define COL_LGR8 0xc8
#define COL_LGR9 0xc9
#define COL_LGRA 0xca
#define COL_LGRB 0xcb
#define COL_LGRC 0xcc
#define COL_LGRD 0xcd
#define COL_LGRE 0xce
#define COL_LGRF 0xcf

/* Hi-res graphics */
#define COL_HGR0 0xd0
#define COL_HGR1 0xd1
#define COL_HGR2 0xd2
#define COL_HGR3 0xd3
#define COL_HGR4 0xd4
#define COL_HGR5 0xd5
#define COL_HGR6 0xd6
#define COL_HGR7 0xd7

/* Text mode */
#define COL_TXT_WHT0 0xd8
#define COL_TXT_WHT1 0xd9
#define COL_TXT_GRN0 0xda
#define COL_TXT_GRN1 0xdb
#define COL_TXT_AMB0 0xdc
#define COL_TXT_AMB1 0xdd


/* slot handling */

#define	SLOTTYPENONE		0
#define SLOTTYPEPARALLEL	1
#define SLOTTYPEMOUSE		2
#define SLOTTYPEZ80		3
#define SLOTTYPEMASSSTORE	4
#define	SLOTTYPEDISKDRIVE	5

/* prototypes */
unsigned int  slotnofunction	(void *slotdata);
unsigned int  slotnostore	(void *slotdata, unsigned int winprotocol, FILE *file, unsigned int percent);
unsigned int  slotnorestore	(void *slotdata, unsigned int winprotocol, FILE *file, unsigned int percent);
unsigned char slotnoget		(void *slotdata, unsigned int address);
void	      slotnoset		(void *slotdata, unsigned int address, unsigned int val);
unsigned char slotnoromget	(void *slotdata, unsigned int address);
void	      slotnoromset	(void *slotdata, unsigned int address, unsigned int val);

typedef struct {
unsigned int  (*slotclose)	(void *slotdata);					/* close slot */
unsigned int  (*slotreset)	(void *slotdata);					/* reset slot */
unsigned int  (*slotstore)	(void *slotdata, unsigned int window, FILE *file, unsigned int percent);	/* store slot */
unsigned int  (*slotrestore)	(void *slotdata, unsigned int window, FILE *file, unsigned int percent);	/* restore slot */
unsigned char (*slotget)	(void *slotdata, unsigned int address);			/* read byte from softswitch */
void          (*slotset)	(void *slotdata, unsigned int address, unsigned int val);/* write byte to softswitch */
unsigned char (*slotromget)	(void *slotdata, unsigned int address);			/* read byte from slotrom */
void          (*slotromset)	(void *slotdata, unsigned int address, unsigned int val);/* write byte to slotrom */
unsigned int  (*slotmenu)	(void *slotdata);					/* standard menu */
unsigned int  (*slotshift)	(void *slotdata);					/* <Shift-Fx> */
unsigned int  (*slotctrl)	(void *slotdata);					/* <Ctrl-Fx> */
unsigned int  (*slotshiftctrl)	(void *slotdata);					/* <Shift-Ctrl-Fx> */
void	      *slotdata;								/* specific slot data */
unsigned char slottype;									/* type of slot */
unsigned char *slotname;								/* name of slot */
} slot;


/* disk.c */
typedef struct {
  unsigned char slot		structpack;
  unsigned char drive		structpack;
  unsigned char path[260]	structpack;
  unsigned char type		structpack;
  int		volume		structpack;
  unsigned int  phase		structpack;
  unsigned int	tracksize	structpack;
  unsigned int  track		structpack;
  unsigned int  bytepointer	structpack;
  unsigned char access		structpack;
  unsigned char changed		structpack;
  unsigned char writeprotected	structpack;
  unsigned char data[233472]	structpack;
} drivedisk;
