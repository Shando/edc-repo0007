/* functions defined in the assembler library */

/*
   please note the class hierachy:

   channel <== image <== window

   IOW: Every window is an image, and every image is a channel.
   Therefore, it is possible to call stringwrite using an image as
   a channel reference pointer, and it is also possible to call
   imageline using a window as an image reference pointer.
*/

extern unsigned char exitprogram;
extern unsigned int  dvalue1;
extern unsigned int  dvalue2;
extern unsigned int  dvalue3;
extern unsigned int  dvalue4;
extern unsigned int  dvalue5;
extern unsigned int  dvalue6;
extern unsigned int  dvalue7;
extern unsigned int  dvalue8;
extern unsigned char dvalueshow;

/* general wrapper functions */
unsigned int asmopen();
unsigned int asmclose();
unsigned char *asmgeterror();
void asmseterror(unsigned char *message);
unsigned char *asmsetlanguage(unsigned char language);

/* tools */
void debugger(void *rampointer, unsigned int numbbytes);
void ramdebugger(void *rampointer, unsigned int numbbytes);
void assembler(void *rampointer, unsigned int numbbytes, unsigned char *filename);

/* class channel */
unsigned int  channelclose(unsigned int channel);
unsigned int  channelin	  (unsigned int channel);
void          channelout  (unsigned int channel, unsigned char value);

/* library keyboard */
unsigned int keyboardsetlayout(unsigned int layoutnumber);
unsigned int keyboardgetlayout();
unsigned int keyboardjoyx();
unsigned int keyboardjoyy();
unsigned int keyboardjoyb();
extern unsigned char keyboardmap[256];

/* library screen */
unsigned int screensetresolution(unsigned int xsize, unsigned int ysize, unsigned int colourbits);
unsigned int screenstore();
void screenrestore(unsigned int handle);

/* class window */
unsigned int windowaddio(         int xcoo,	         int ycoo,
			 unsigned int xsize,	unsigned int ysize,
			 unsigned int outborder,unsigned int inborder,
			 unsigned char *namestring,
			 unsigned int  directmode,
			 unsigned int *keyboard,unsigned int *window);
void windowsetcoor(unsigned int window, int xcoo, int ycoo);

/* library mouse */
unsigned int mousegetx();
unsigned int mousegety();
unsigned int mousegetbutton();

/* library string */
void stringwrite		(unsigned int channel,	unsigned char *stringpointer);
unsigned int stringcopymessage	(unsigned char *deststring, unsigned char *message, unsigned int maxchars);
void stringwritemessage		(unsigned int channel,	unsigned char *message);
unsigned int stringtoint	(unsigned char *stringpointer);
int stringcomparec		(unsigned char *string1, unsigned char *string2);

/* library int */
void intwrite		(unsigned int channel, int value);
int intread		(unsigned int keyboard, unsigned int window, int defaultvalue);

/* library hex32 */
void hex32tostringfd	(unsigned int hexvalue,	unsigned char *stringpointer);
void hex32tostringd	(unsigned int hexvalue,	unsigned char *stringpointer);
unsigned int hexread	(unsigned int keyboard, unsigned int window, unsigned int defaultvalue);

/* class image */
void imageupdate();
void imagenoupdate();
void imagesetpcolor	(unsigned int image,
			 unsigned int colourindex,
			 unsigned int rgbcolour);
void imagesetview	(unsigned int image,
			 unsigned int xleft,	unsigned int ytop,
			 unsigned int xright,	unsigned int ydown);
unsigned int imagegetpixel(unsigned int image,
			 unsigned int xcoo,	unsigned int ycoo);
void imageplot		(unsigned int image,
			 unsigned int xcoo,	unsigned int ycoo,
			 unsigned int rgbcolour);
void imageline		(unsigned int image,
			 unsigned int x1,	unsigned int y1,
			 unsigned int x2,	unsigned int y2,
			 unsigned int rgbcolour);
void imagedrawcircle	(unsigned int image,
			 unsigned int xcoo,	unsigned int ycoo,
			 unsigned int radius,
			 unsigned int rgbcolour);
void imagefillcircle	(unsigned int image,
			 unsigned int xcoo,	unsigned int ycoo,
			 unsigned int radius,
			 unsigned int rgbcolour);
void imagedrawbox	(unsigned int image,
			 unsigned int xleft,	unsigned int ytop,
			 unsigned int xright,	unsigned int ydown,
			 unsigned int rgbcolour);
void imagefillbox	(unsigned int image,
			 unsigned int xleft,	unsigned int ytop,
			 unsigned int xright,	unsigned int ydown,
			 unsigned int rgbcolour);

void imagesetcursor	(unsigned int image,
			 unsigned int xcoo,	unsigned int ycoo);
unsigned int imagegetcursorx	(unsigned int image);
unsigned int imagegetcursory	(unsigned int image);
void imagesettextcolor	(unsigned int image,
			 unsigned int rgbbackground,	unsigned int rgbforeground);

void imagesettextattribute(unsigned int image, unsigned int attribute);
unsigned int imagegettextattribute(unsigned int image);
#define IMAGEUNDERLINE 1
#define IMAGEUPPERLINE 2
#define IMAGEBOLD 4
#define IMAGEITALIC 8
#define IMAGESHADOW 16
#define IMAGEDOUBLEHEIGHT 32
#define IMAGEDOUBLEWIDTH 64

unsigned char *imagegetaddress(unsigned int image, unsigned int yline);
unsigned int imagestringread(unsigned int image, unsigned int keyboard,
			     unsigned char *stringptr, unsigned int maxlength);

//void vprinit();
//unsigned int vprline();
