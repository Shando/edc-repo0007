Capcom Play System 3 Emulator
by ElSemi
http://nebula.emulatronia.com


--- HISTORY ---
v1.0a

Fixed CHD reading for the Alt Versions
Fixed Jojoalt rom 10 CRC, it was loading the one from the parent jojo set.
Fixed crashing in sfiii3 when Ken finishes Makoto with neutral throw (kicks). It's
actually a bug in the game (fixed in sfiii3a). In the real board it would cause an address
error (misaligned jump) and would reset the machine due to watchdog. In the emu it will just
freeze the game because there is not watchdog, just hit F3 to restart the game.
Fixed Jojo games damage level. It was a core bug in the ADDC (add with carry) opcode, so it
could be causing problems in other games too.
Added support for joypads with more than 8 buttons.
Re-enabled the Unload Rom button, I disabled it because it fails more times than works, but
there is some people that actually used it, so I've enabled it again.

v1.0

This is the final version of the CPS3 emulator.

It adds transparency effects (not actual transparency, but
well it looks like that :) ), although it's not fully understood yet.

Fixed palette transformation for flashes, and fadein/outs, now 
blacks properly fade to white.

Fixed crashes in some zoomin ending sequences in SF3 games.

Fixed a 1 pixel offset in the framebuffer that was causing a 1 pixel
column problem in the left side of the screen sometimes.

Added support for Nebula external video plugins (there is some source
code and the interface documents in the plugins folder).

Added CHD (MAME's compressed Hard Disks CD Images) support. Just put 
the .chd files in the CHD folder in the main directory (sorry, no path 
selection for it). And the bios (or the full roms zip) romsets in 
the ROMS directory. When loading a CHD romset, the emulator will run 
the entire startup sequence so it will take a while to boot (early games 
just have a black screen) while the bios waits for the cd to spin up. 
You don't need to go through the flashrom rewritting sequence, although
you can see how it looks (just for fun, as it doesn't actually write
anything) by going to Test menu and selecting "Game Rewrite". Using CHDs
doesn't have an actual benefit (except for seeing the exact startup
sequence of the game machine) apart from being able to run Warzard in
any region because Warzard always checks the cd ingame unless it's set to 
asia, so by having the real CD emulation throuhg CHD, you can run it in
any region).


v0.2	TEST VERSION 3

This is a preview version of my CPS3 emulator. Here you
can see the current work-in-progress state of the emulation.

New features emulated:
Palette fadein/out
Sean stage special tile compression
Proper sprite/tilemap alignment
Proper priority handling

The CPS3 emulation is almost complete. Only the shadow/blending
emulation is missing. There is a preliminary emulation for it 
that works partially with the shadows, but is not correct in some
other places (warzard sword effects for example).

I've added savestates support. To make a savestate, first select
the slot with CTRL+number (in the main keyboard, not in the keypad)
then press F11 twice (it's done that way so you don't accidentally
delete a working state). To load a savestate, select the slot and
then press F10.

I've added an option to set a custom fullscreen resolution in the
.ini file (FullScreenWidth,FullScreenHeight). You must enable
it setting Video->Fullscreen Resolution->Custom. Using a resolution
that is not supported by your video card will cause the emulator to
crash.


v0.1	TEST VERSION 2

This is a preview version of my CPS3 emulator. Here you
can see the current work-in-progress state of the emulation.

I've fixed some problems in the emulation:
Color palettes seem right now
Fullscreen Zoom
Sprite Zoom
Linescroll

The priorities have improved but they aren't fully right yet (mainly in jojo games).
Shadow/alpha is still missing.
Linezoom is missing, but I haven't found a single place where it's used.
Sean stage in sf3ng doesn't crash now, but shows garbage in the bg.

I've added an entry to the ini so you can switch the region (except for
warzard that it won't boot unless region is Asia)

I've also tried to fix some problems that people were having with
some old and integrated graphics chipsets. Probably some problems
have been fixed, but there might still be some around.
You can now also try to fix the renderer to the vsync of your monitor
with an option in the ini file (ForceSync).


v0.0	TEST VERSION

This is a preview version of my CPS3 emulator. Here you
can see the current work-in-progress state of the emulation.

There are still a lot of missing features to emulate properly
so don't report any emulation errors yet. The missing features
include (and the effect caused by them missing) :

Sprite Zoom: you'll see the sprite tiles (squares) not being properly aligned or with gaps
Fullscreen Zoom: Sometimes it seems like the camera is not pointing to the action
Per-tile palette selection: some colors (a lot in some games) are wrong
Priorities: objects that are over the background when they should appear behind
Linescroll: Floor 3D effect missing. SF32ndi scrolling letters in intro missing.
Linezoom: I don't know where is it used :)

--- USAGE ---

Usage is easy, just load emulator, select rom and play :).
Missing rom files will be reported in a console window.


PLEASE, READ EMULATOR.INI TO CHANGE OPTIONS AND KNOW HOW TO CONFIGURE YOUR ROM DIRECTORIES


Fixed Keys:

	PAUSE	- Pauses the emulator
		while paused:
		ENTER	- Single step
		SPACE	- Unpause while held

	SCROLL LOCK - Toggle framelimit on/off
	ALT-ENTER - Toggle Fullscreen 
	CTRL+number - Select savestate slot
	F10	- Load state (press twice)
	F11	- Save state (press twice)
	F12	- Take an screenshot (to SHOTS directory)
	F9	- Show speed (Frames per second and frame time)
	CTRL-F9 - Show more stats
	Keypad+ - Increase Frameskip
	Keypad- - Decrease Frameskip

For the rest of the keys, check the input config screen after a game has been loaded (Game->Config Controls...).




