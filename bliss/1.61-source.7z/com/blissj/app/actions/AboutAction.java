package com.blissj.app.actions;

import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.blissj.app.*;

public class AboutAction extends AbstractAction
{

    public AboutAction(BlissMainFrame frame) {
        this.frame = frame;
        putValue(NAME, Bliss.RESOURCES.getString(
                "ActionAbout"));
    }

    public void actionPerformed(ActionEvent ae) {
        frame.displayAbout();
    }

    private BlissMainFrame      frame;

}
