package com.blissj.app.actions;

import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.blissj.app.*;

public class PropertiesAction extends AbstractAction
{

    public PropertiesAction(BlissMainFrame frame, JTable cartridgeTable) {
        this.frame = frame;
        this.cartTable = cartridgeTable;
        setEnabled(false);
        putValue(NAME, Bliss.RESOURCES.getString("ActionProperties"));
        cartTable.getSelectionModel().addListSelectionListener(
            new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent lse) {
                    if (lse.getValueIsAdjusting())
                        return;
                    int selection = cartTable.getSelectionModel().
                            getAnchorSelectionIndex();
                    setEnabled(!cartTable.getSelectionModel().
                            isSelectionEmpty());
                }
            });
    }

    public void actionPerformed(ActionEvent ae) {
        frame.displayProperties();
    }

    private BlissMainFrame      frame;
    private JTable              cartTable;

}
