package com.blissj.app.actions;

import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.blissj.app.*;

public class ExitBlissAction extends AbstractAction
{

    public ExitBlissAction(BlissMainFrame frame) {
        this.frame = frame;
        putValue(NAME, Bliss.RESOURCES.getString(
                "ActionExitBliss"));
    }

    public void actionPerformed(ActionEvent ae) {
        frame.exit();
    }

    private BlissMainFrame      frame;

}
