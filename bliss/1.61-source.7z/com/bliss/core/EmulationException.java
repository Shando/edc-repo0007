package com.bliss.core;

public class EmulationException extends RuntimeException
{

    public EmulationException(String presentableErrorMessage) {
        this.presentableErrorMessage = presentableErrorMessage;
    }

    public String getPresentableMessage() {
        return presentableErrorMessage;
    }

    private String presentableErrorMessage;

}
