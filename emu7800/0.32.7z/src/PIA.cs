/*
 * PIA.cs
 *
 * The Peripheral Interface Adaptor (6532) device.
 *
 * Copyright (c) 2003 Mike Murphy
 *
 */

using System;

namespace EMU7800 {

public sealed class PIA : IDevice {
	private const ushort
		SWCHA	= 0x280, // Port A; joystick (read/write)
		SWACNT	= 0x281, // Port A DDR, 0=input, 1=output
		SWCHB	= 0x282, // Port B; console switches (read only)
		SWBCNT	= 0x283, // Port B DDR (hardwired as input)
		INTIM	= 0x284, // Timer output (read only)
	
		TIM1T	= 0x294, // set 1 clock interval (838 nsec/interval)
		TIM8T	= 0x295, // set 8 clock interval (6.7 usec/interval)
		TIM64T	= 0x296, // set 64 clock interval (53.6 usec/interval)
		T1024T	= 0x297; // set 1024 clock interval (858.2 usec/interval)

	private Machine M;

	private byte[] RAM = new byte[128]; 

	private byte  Timer;
	private int   TimerIntervalShift;
	private ulong TimerStartClock;
	private int   TimerExpiredOffset;
	
	private byte DDRA;
	private const byte DDRB = 0;	// Hardwired to input
		
	public void Reset() {
		Timer = 100;
		TimerIntervalShift = 6;
		TimerStartClock = 0;
		TimerExpiredOffset = -1;
		
		DDRA = 0;
		
		Log.Msg("{0} reset\n", this);
	}

	public void Map(AddressSpace mem) {}
	
	public override string ToString() {
		return "PIA/RIOT M6532";
	}

	public byte this[ushort addr] {
		get {
			return peek(addr);
		}
		set {
			poke(addr, value);
		}
	}
		
	public byte peek(ushort addr) {
		InputAdapter ia = M.InputAdapter;
		byte retval = 0;
		
		if ((addr & 0x200) == 0) {
			retval = RAM[addr & 0x7f];
		} else if (addr == SWCHA) {
			retval = ia.ReadPortA();
		} else if (addr == SWACNT) {	// SWCHA DDR
			retval = DDRA; 
		} else if (addr == SWCHB) {	// Console switches
			retval = ia.ReadPortB();
		} else if (addr == SWBCNT) {	// SWCHB DDR
			retval = DDRB;
		} else if (addr == INTIM) {	/* NOTE: 0x286 may mirror INTIM(284)! */
			retval = getTimerOutput();
		} else if ((addr & 0x07) == 0x05 || (addr & 0x07) == 0x07) { 
			retval = getInterruptFlag();
		} else {
#if DEBUG
			// Asteroids seems to set this off with accesses to $0ef3 and $0ff4
			Log.Msg("{0}: BAD M6532 register PEEK at ${1:x4}\n", this, addr);
#endif
		}
		return retval;
	}

	public void poke(ushort addr, byte data) {
		InputAdapter ia = M.InputAdapter;

		if ((addr & 0x200) == 0) {
			RAM[addr & 0x7f] = data;
		} else if (addr == SWCHA) {
			ia.WritePortA((byte)(data & DDRA));
		} else if (addr == SWACNT) {	// SWCHA DDR
			DDRA = data;
		} else if (addr == SWCHB) {	// Console switches
			;			// (hardwired as input)
		} else if (addr == SWBCNT) {	// SWCHB DDR
			;			// (hardwired as input)
		} else if (addr == TIM1T) {	// Write timer: divide by 1 
			setTimer(data, 0);
		} else if (addr == TIM8T) {	// Write timer: divide by 8
			setTimer(data, 3);
		} else if (addr == TIM64T) {	// Write timer: divide by 64	
			setTimer(data, 6);
		} else if (addr == T1024T) {	// Write timer: divide by 1024
			setTimer(data, 10);
		} else {
#if DEBUG
			Log.Msg("{0}: BAD M6532 register POKE at ${1:x4}\n", this, addr);
#endif
		}
	}
	
	public PIA(Machine m) {
		M = m;
		Log.Msg("{0} ready\n", this);
	}
 	
//	Controller Jacks
//
//            Left Jack             Right Jack
//          -------------          -------------
//          \ 1 2 3 4 5 /          \ 1 2 3 4 5 /
//           \ 6 7 8 9 /            \ 6 7 8 9 /
//            ---------              ---------
//  
//	pin 1   D4 PIA SWCHA           D0 PIA SWCHA
//	pin 2   D5 PIA SWCHA           D1 PIA SWCHA
//	pin 3   D6 PIA SWCHA           D2 PIA SWCHA
//	pin 4   D7 PIA SWCHA           D3 PIA SWCHA
//	pin 5   D7 TIA INPT1 (Dumped)  D7 TIA INPT3 (Dumped)
//	pin 6   D7 TIA INPT4 (Latched) D7 TIA INPT5 (Latched)
//	pin 7   +5                     +5
//	pin 8   GND                    GND
//	pin 9   D7 TIA INPT0 (Dumped)  D7 TIA INPT2 (Dumped)
//
	private void setTimer(byte data, int shift) {		
		Timer = data;
		TimerIntervalShift = shift;
		TimerStartClock = M.CPU.Clock;
		TimerExpiredOffset = -1;
	}
	
	private byte getTimerOutput() {
		ulong deltaClock = M.CPU.Clock - TimerStartClock - 1;
		int timer = Timer - (int)(deltaClock >> TimerIntervalShift) - 1;
				
		if (timer < 0) {
			if (TimerExpiredOffset <= 1) {
				TimerExpiredOffset = (int)(M.CPU.Clock
				- (TimerStartClock
					+ (ulong)(Timer << TimerIntervalShift)));
			}
			timer = Timer - (int)(deltaClock >> TimerIntervalShift)
					- TimerExpiredOffset;
		}
		return (byte)timer;
	}
	
	private byte getInterruptFlag() {
		ulong deltaClock = M.CPU.Clock - TimerStartClock - 1;
		int timer = Timer - (int)(deltaClock>>TimerIntervalShift) - 1;

		if (timer >= 0 || TimerExpiredOffset > 1) {
			return 0x00;
		} else {
			return 0x80;
		}
	}
}
}