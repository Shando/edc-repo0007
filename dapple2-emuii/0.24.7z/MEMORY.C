/*
 * Dapple ][ Emulator  Version 0.24
 * Copyright (C) 2002, 2003 Dapple ][ Development.  All rights reserved.
 *
 * Component:  MEMORY: routines for emulating 64KB Apple RAM and 3072KB
 *                     RAM Works expansion RAM (3136K total)
 * Revision:   (0.24) 2003.0226
 *
 * This version always dynamically allocates the RAM Works ram.  Not all memory
 * is recognized by some programs; what memory *is* recognized passes the
 * RAM Works diagnostic tests, and more than 2MB of this RAM is recognized
 * and usable by AppleWorks 3.0.  This emulation is based on an extract of
 * the RAM Works manual provided by Paul R. Santa-Maria which was revealed
 * to the programmer by Scott Alfter.  The author would like to express his
 * thanks for providing this information to him on the Usenet newsgroup
 * <comp.sys.apple2.programmer>. -uso.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <dir.h>
#include <dos.h>
#include <pc.h>
#include <stdio.h>
#include <stdlib.h>	/* malloc(), free() */
#include <string.h>
#include <unistd.h>
#include "asmlib.h"
#include "dapple.h"

/* dapple.c */
extern unsigned int window;
extern unsigned int keyboard;
extern unsigned char appletype;
extern unsigned char inidebugflag;
extern unsigned char messageflag;
extern unsigned char callingpath[260];
extern unsigned char keyjoystick;
void windowpresskey(unsigned int keyboard, unsigned int window);
void applereset();
unsigned int applestore(unsigned char *filename);
unsigned int applerestore(unsigned char *filename);
unsigned int strright(unsigned char *firststr, unsigned char *secondstr);
unsigned int cwdxchgslash(unsigned char *stringptr, unsigned int value);

/* video.c */
extern unsigned char virtgraphic;
extern unsigned char virtmixed;
extern unsigned char virtpage2;
extern unsigned char virthgr;
extern unsigned char virt80col;
extern unsigned char virtaltchar;
extern unsigned char virtdhres;
extern unsigned char virtiou;
extern unsigned int  virtcachemode;
extern unsigned char virtvideobyte;
extern unsigned char *virtfontptr;
extern unsigned char *virtfontflashptr;
extern unsigned char virtfontalt[2048];
void virtsetmode();
void virtcacheinit();
void virtwrite0400	(unsigned int address);
void virtwrite0400aux	(unsigned int address);
void virtwrite0800	(unsigned int address);
void virtwrite0800aux	(unsigned int address);
void virtwrite2000	(unsigned int address);
void virtwrite2000aux	(unsigned int address);
void virtwrite4000	(unsigned int address);
void virtwrite4000aux	(unsigned int address);

/* cpu65c02.c */
extern unsigned int rasterline;
extern unsigned int cycle;

/* disk.c */
unsigned char driveread(unsigned int addr);
void drivewrite(unsigned int addr, unsigned int value);

/* pic.c */
void WriteParallel   (unsigned int addr, unsigned int value);

/* lldisk.c */
unsigned char ReadRawDiskIO (unsigned int addr);
void WriteRawDiskIO (unsigned int addr, unsigned int value);


/* moved here from dapple.c -uso. */
//unsigned char HDDROM[256];
//unsigned char *shiftstate;
//unsigned char dqhdv;
//unsigned char dqshift;

#define MEMAUXRAM	0x10000
#define MEMSLOTROM	0x20000
#define MEMROM		0x21000
#define MEMINTCXROM	0x24000
#define MEMROM2		0x25000
/* Maximum number of 64K auxiliary memory pages for the RAM Works card */
/* Manual says this (3072K) is the max */
#define MEMMAXRAM	48

typedef enum {IIC40, IIC80} IIC4080;

/* flags that handle memory access */
unsigned char memrompath[256];
unsigned char memram[0x28000];		/* main and aux memory + 32kb rom			*/
unsigned int  memnumbbanks;		/* number of allocated memory banks			*/
unsigned char *memramptr[MEMMAXRAM];	/* list of pointers to aux ram and ramworks ram		*/
unsigned char *memauxbankptr;		/* pointer to aux ram or ramworks ram bank		*/
unsigned char memkey;			/* apple key						*/
unsigned int  memjoyx;			/* apple joystick x					*/
unsigned int  memjoyy;			/* apple joystick y					*/
unsigned char memjoybutton0;		/* apple open button					*/
unsigned char memjoybutton1;		/* apple close button					*/
unsigned int  memjoycycle;		/* timer counter					*/
unsigned char memauxread;               /* read motherboard ram or aux ram			*/
unsigned char memauxwrite;              /* write motherboard ram or aux ram			*/
unsigned char memstore80;		/* 80column store motherboard ram or aux ram		*/
unsigned char memintcxrom;              /* read from slot rom $c100-$cfff or internal rom	*/
unsigned char memslotc3;                /* read from slot rom $c300-$c3ff or internal rom	*/
unsigned char memlcaux;                 /* read $0-$1ff + $d000-$ffff from main or aux memory	*/
unsigned char memlcramr;                /* read LC RAM or ROM?					*/
unsigned char memlcramw;                /* write LC RAM or ROM?					*/
unsigned char memlcbank2;               /* read from LC bank 1 or LC bank 2			*/
unsigned char memauxbank;		/* which bank selected?					*/
unsigned char memiic32k;		/* //c rom 16k or 32k					*/
IIC4080       memiic4080;		/* 40/80 column mode switch				*/
unsigned char memrombank;		/* for Apple//c only					*/
unsigned char memann3;                  /* annunciator #3					*/
unsigned char memnolc;			/* Is there a LC card installed?			*/
unsigned char memclearmode;		/* memory clear pattern					*/

/* flags for sound */
unsigned char soundflag;


/*--------------------------------------*/
/* Sound				*/
/*--------------------------------------*/


      void soundinit() {

	soundflag = 1;

      } /* soundinit */


/*--------------------------------------*/


      void soundclick() {
	register int al;

	if (soundflag) {
	/* Toggle the speaker */
	  al = inportb(0x61);
	  al ^= 0x02;
	  al &= 0xfe;
	  outportb(0x61,al);
	}
      } /* soundclick */


/*--------------------------------------*/


      void soundmenu () {
	unsigned int screen;
	unsigned int keyboard;
	unsigned int window;
	unsigned char key;
	unsigned char update;

	screen = screenstore();
	if (!windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1, "Sound Options", &keyboard, &window)) {

	  update = 1;
	  do {
	    if (update) {
	      channelout(window, 12);		/* clear window */
	      stringwrite(window, "\r[ESC] - Quit\r");

	      stringwrite(window, "\r\r[S] - Speaker: ");
	      if (soundflag) {
	        stringwrite(window, "enabled");
	      }
	      else {
	        stringwrite(window, "disabled");
	      }

	      update = 0;
	    }
	    do {
	      imageupdate();
	      key = (unsigned char)channelin(keyboard);
	    }
	    while ((key == 0) && (!exitprogram));
	    switch (key) {
	      case 's' :
	      case 'S' :
	        soundflag = !soundflag;
	        update = 1;
	        break;
	    } /* switch (key) */
	  }
	  while ((key != 27) && (key != 32) && (key != 13) && (!exitprogram));
	  channelclose(keyboard);
	  channelclose(window);
	}
	screenrestore(screen);

      } /* soundmenu */


/*--------------------------------------*/
/* dummy declarations			*/
/*--------------------------------------*/

      unsigned char ReadMassStorIO(unsigned int addr) {

	return 0xff;

      }

/*--------------------------------------*/

      void WriteMassStorIO(unsigned int addr, unsigned int value) {

	return;

      }

/*--------------------------------------*/
/* Memory				*/
/*--------------------------------------*/


      void memoryreset() {

	memkey		= memkey & 0x7f;
	memauxread	= 0;
	memauxwrite	= 0;
	memintcxrom	= 0;		/* read from slot rom $c100-$cfff		*/
	memslotc3	= 0x80;		/* read slot rom				*/
	memlcaux	= 0;		/* read $0-$1ff + $d000-$ffff from main memory	*/
	memlcramr	= 0;		/* read ROM					*/
	memlcramw	= 0;		/* write ROM					*/
	memlcbank2	= 0;		/* read from LC bank 1				*/
	memrombank	= 0;		/* read from ROM bank 1				*/
	memstore80	= 0;		/* 80 store off					*/
	memann3		= 0x80;		/* annunciator #3 on				*/

	memjoycycle	= cycle;

      } /* MemoryReset */


/*-------------------------------------*/


      static void memoryclearbank(unsigned char membank[65536]) {
	register unsigned int i;
	register unsigned int j;

	switch (memclearmode) {
	  case 0 :			/* None */
	    break;
	  case 1 :			/* 00 00 00 00 */
	    memset(membank, 0x00, 0x10000);
	    break;
	  case 2 :			/* 00 FF 00 FF */
	    for (i=0; i<0x10000; ) {
	      membank[i++] = 0x00;
	      membank[i++] = 0xff;
	    }
	    break;
	  case 3 :			/* 00 FF .. FF 00 */
	    for (i=0; i<0x10000; ) {
	      for (j=0; j<0x80; j++) {
	        membank[i++] = 0x00;
	        membank[i++] = 0xff;
	      }
	      for (j=0; j<0x80; j++) {
	        membank[i++] = 0xff;
	        membank[i++] = 0x00;
	      }
	    }
	    break;
	  case 4 :			/* EA EA EA EA */
	    memset(membank, 0xea, 0x10000);
	    break;
	  case 5 :
	    for (i=0; i<0x10000; i++) {
	      membank[i] = (i & 0xff);
	    }
	    break;
          case 6 :			/* Dead Beef Little Endian */
            for (i=0; i<0x10000; i=i+4) {
              membank[i+3]=0xDE;
              membank[i+2]=0xAD;
              membank[i+1]=0xBE;
              membank[i]  =0xEF;
           } /* for i */
           break;
          case 7 :			/* Dead Beef High Endian */
            for (i=0; i<0x10000; i=i+4) {
              membank[i]  =0xDE;
              membank[i+1]=0xAD;
              membank[i+2]=0xBE;
              membank[i+3]=0xEF;
           } /* for i */
           break;
	} /* switch (memclearmode) */

      } /* memoryclearbank */


      void memoryclear() {
	register unsigned int i;

	memoryclearbank(&memram[0]);		/* clear main memory */
	for (i=0; i<MEMMAXRAM; i++) {		/* clear aux and ramworks memory */
	  if (memramptr[i] != NULL) {
	    memoryclearbank(memramptr[i]);
	  }
	}

	memauxbank = 0;				/* reset ramworks */
	memauxbankptr = &memram[MEMAUXRAM];

	memkey = 0;

      } /* memoryclear */


/*-------------------------------------*/


      void memorysetclearmode(unsigned char value) {

	if (value <= 7) {
	  memclearmode = value;
	}

      } /* memorysetclearmode */


/*-------------------------------------*/


      unsigned char memorygetclearmode() {

	return memclearmode;

      } /* memorygetclearmode */


/*-------------------------------------*/


      void memoryinit() {

	memramptr[0]	= &memram[MEMAUXRAM];		/* set first pointer to standard aux ram */
	for (memnumbbanks=1; memnumbbanks<MEMMAXRAM; memnumbbanks++) {	/* clear pointer array */
	  memramptr[memnumbbanks] = NULL;
	}

	memnumbbanks = 0;				/* allocate memory */
	do {
	  memnumbbanks++;
	  memramptr[memnumbbanks] = malloc(65536);
	}
	while ((memnumbbanks < (MEMMAXRAM-1)) && (memramptr[memnumbbanks] != NULL));

	memorysetclearmode(1);
	memoryclear();
	memnolc = 0;
	memjoyx		= 0x575;
	memjoyy		= 0x575;
	memjoybutton0	= 0;
	memjoybutton1	= 0;
	memiic4080	= IIC40;
	memiic32k	= 0;

	memoryreset();
	strcpy(memrompath, "");
	appletype	= 0;	/* no roms loaded */

      } /* memoryinit */


/*-------------------------------------*/


      void memoryclose() {
	register unsigned int i;

	for (i=1; i < MEMMAXRAM; i++) {		/* free allocated memory */
	  if (memramptr[i] != NULL) {
	    free(memramptr[i]);
	  }
	}

      } /* memoryclose */


/*-------------------------------------*/


      unsigned int memoryloadrom (unsigned int keyboard, unsigned int window, unsigned char *newrompath) {
	FILE *file;
	unsigned char oldcwd[260];
	unsigned int filelength;
	register unsigned int i;

	if (!*newrompath) return 0;
	stringwrite(window, "Initializing Apple...\r");
	imageupdate();

        stringwrite(window, "Attempting to load Apple ROM '");
	stringwrite(window, newrompath);
	stringwrite(window, "'...\r");

	cwdxchgslash(oldcwd, 256);
	chdir(callingpath);			/* restore original directory at calling Dapple */

	file=fopen(newrompath,"rb");
	if (!file) {
          stringwrite(window, "Sorry, I can't seem to open the ROM file.\r");
	  windowpresskey(keyboard, window);
	  chdir(oldcwd);			/* restore original directory */
	  return 0;
	}

	fseek(file,0,SEEK_END);
	filelength=ftell(file);
	fseek(file,0,SEEK_SET);
	stringwrite(window, "Reading rom file...\r");
	imageupdate();
	switch (filelength) {
	  case 12288 :	/* AppleII+ */
	    memset(&memram[0x20000], 0x00, 0x8000);
	    fread(&memram[MEMROM],	12288, 1, file);		/* read rom */
	    appletype = APPLEII;					/* machine is Apple][+ */
	    break;
          case 16128 :	/* AppleIIe / Apple//c 16KB */
	    memset(&memram[0x20000], 0x00, 0x8000);
            fread(&memram[MEMINTCXROM+0x100], 3840, 1, file);		/* read INTCXROM */
            fread(&memram[MEMROM],12288,1,file);			/* read rom */
            if (strright(newrompath, "co.rom")){			/* 16K //c ROM (!) */
              for (i=0x0000; i<0x3000; i++) {				/* copy rom */
                memram[MEMROM2+i]       = memram[MEMROM+i];
              }
              for (i=0x0000; i<0x3000; i++) {                           /* copy slot rom -uso. */
                memram[MEMSLOTROM+i]    = memram[MEMINTCXROM+i];
              }
              appletype = APPLEIIC;
              memiic32k=0;						/* old 16 KB rom */
            }
            else {	/* AppleIIe */
              appletype = APPLEIIE;                     		/* machine is Apple//e */
            }
            break;
	  case 16384 :
	    memset(&memram[0x20000], 0x00, 0x8000);
	    fread(&memram[MEMROM],	12288,	1, file);		/* read rom */
	    fread(&memram[MEMSLOTROM],   4096,	1, file);		/* read slot rom */
	    appletype = APPLEII;					/* machine is Apple][+ */
	    break;
	  case 20480 :	/* ApplePC/AppleWin 12K */
	    memset(&memram[0x20000], 0x00, 0x8000);
	    fseek(file,4096,SEEK_SET);
	    fread(&memram[MEMSLOTROM],	 4096,	1, file);		/* read slot rom */
	    fread(&memram[MEMROM],	12288,	1, file);		/* read rom */
	    appletype = APPLEII;					/* machine is Apple][+ */
	    break;
	  case 32768 :
	    memset(&memram[0x20000], 0x00, 0x8000);
	    if (strright(newrompath, "c.ROM") || strright(newrompath, "co.ROM")) {
	      fread(&memram[MEMSLOTROM], 4096,	1, file);		/* read slot rom */
	      fread(&memram[MEMROM],	12288,	1, file);		/* read rom */
	      fread(&memram[MEMINTCXROM],4096,	1, file);		/* read INTCXROM */
	      fread(&memram[MEMROM2],	12288,	1, file);		/* read rom bank 2 */
	      appletype = APPLEIIC;					/* machine is Apple//c */
	      memiic32k = 1;						/* new 32KB rom */
	    }
	    else {
	      fread(&memram[MEMSLOTROM], 4096,	1, file);		/* read slot rom */
	      fread(&memram[MEMROM],	12288,	1, file);		/* read rom */
	      fread(&memram[MEMINTCXROM],4096,	1, file);		/* read INTCXROM */
	      appletype = APPLEIIE;					/* machine is Apple//e */
	    }
	    break;
	  default :
	    fclose(file);
            stringwrite(window, "Unknown type of ROM file.\r");
	    windowpresskey(keyboard, window);
	    chdir(oldcwd);			/* restore original directory */
	    return 0;
	} /* switch */
	fclose(file);
	strcpy(memrompath,newrompath);
	if (appletype == APPLEII) {
          stringwrite(window, "Machine is Apple ][ or ][+.\r");
	}
	else {
	  if (appletype == APPLEIIE) {
            stringwrite(window, "Machine is Apple //e.\r");
	  }
	  else {
	    if (memiic32k) {
              stringwrite(window, "Machine is Apple //c.\r");
	    }
	    else {
              stringwrite(window, "Machine is Apple //c (16K ROM).\r");
	    }
	  }
	}
	imageupdate();

/* load parallelport slot rom */
	if (!((appletype & APPLEIIC) && (memiic32k))) {
	  file=fopen("parallel.rom","rb");
	  if (!file) {
	    stringwrite(window, "Parallel port : ROM not available.\r");
	    imageupdate();
	  }
	  else {
            stringwrite(window, "Parallel port ROM found.\r");
	    imageupdate();
	    fread(&memram[MEMSLOTROM+0x100],256,1,file);
	    fclose(file);
	  }

/* load disk slot rom */
	  file=fopen("disk.rom","rb");
	  if (!file) {
	    stringwrite(window, "disk ][ : ROM not available.\r");
	    imageupdate();
	  }
	  else {
            stringwrite(window, "disk ][ slot ROM found.\r");
	    imageupdate();
	    fread(&memram[MEMSLOTROM+0x600],256,1,file);	/* never load this on Apple//c with 32kb! */
	    fclose(file);
	  }

/* load mass storage slot rom */
	  file=fopen("massstor.rom","rb");
	  if (!file) {
	    stringwrite(window, "Mass storage devices : ROM not available.\r");
	    imageupdate();
	  }
	  else {
            stringwrite(window, "Mass storage device ROM found.\r");
	    imageupdate();
	    fread(&memram[MEMSLOTROM+0x500],256,1,file);
	    fclose(file);
	  }
	} /* if (appletype & (APPLEII | APPLEIIE)) */

/* init memory */

	stringwrite(window, "Resetting Apple...\r");
	imageupdate();

	memoryclear();
	applereset();

	chdir(oldcwd);			/* restore original directory */
	return -1;
      } /* memoryloadrom */


/*-------------------------------------*/


/* automatic search for rom file */
      unsigned int memoryautoloadrom(unsigned int keyboard, unsigned int window) {
	FILE *rom;
	unsigned int i;

/* Try Apple//e first, then Apple//c, then Apple][+ */

	rom = fopen(memrompath,"rb");
	i = (unsigned int)(rom);
	if (i) {
	  fclose(rom);
	  i = memoryloadrom(keyboard, window, memrompath);
	}
	if (!i) {
	  strcpy(memrompath,"apple2e.rom");
	  rom = fopen(memrompath,"rb");
	  i = (unsigned int)(rom);
	  if (i) {
	    fclose(rom);
	    i = memoryloadrom(keyboard, window, memrompath);
	  }
	  if (!i) {
	    strcpy(memrompath,"apple2eo.rom");
	    rom = fopen(memrompath,"rb");
	    i = (unsigned int)(rom);
	    if (i) {
	      fclose(rom);
	      i = memoryloadrom(keyboard, window, memrompath);
	    }
            if (!i) {
              strcpy(memrompath,"apple2co.rom");
              rom = fopen(memrompath,"rb");
              i = (unsigned int)(rom);
              if (i) {
                fclose(rom);
                i = memoryloadrom(keyboard, window, memrompath);
              }
              if (!i) {
                strcpy(memrompath,"apple2c.rom");
                rom = fopen(memrompath,"rb");
                i = (unsigned int)(rom);
                if (i) {
                  fclose(rom);
                  i = memoryloadrom(keyboard, window, memrompath);
                }
                if (!i) {
                  strcpy(memrompath,"apple2.rom");
                  rom = fopen(memrompath,"rb");
                  i = (unsigned int)(rom);
                  if (i) {
                    fclose(rom);
                    i = memoryloadrom(keyboard, window, memrompath);
                  }
                  if (!i) {
                    strcpy(memrompath,"apple2m.rom");
                    rom = fopen(memrompath,"rb");
                    i = (unsigned int)(rom);
                    if (i) {
                      fclose(rom);
                      i = memoryloadrom(keyboard, window, memrompath);
                    }
                    if (!i) {
                      strcpy(memrompath,"apple2o.rom");
                      rom = fopen(memrompath,"rb");
                      i = (unsigned int)(rom);
                      if (i) {
                        fclose(rom);
                        i = memoryloadrom(keyboard, window, memrompath);
                      }
                      if (!i) {
                        strcpy(memrompath, "");
                        stringwrite(window, "No Apple ROMs found\r");
                        windowpresskey(keyboard, window);
                        return 0;
		      }
		    }
		  }
		}
	      }
	    }
	  }
	}
	return -1;
      } /* memoryautoloadrom */


/*-------------------------------------*/


      unsigned int memorystore(unsigned int window, FILE *file) {

	fwrite(&soundflag,	sizeof(soundflag),	1,file);
	fwrite(&appletype,	sizeof(appletype),	1,file);
	fwrite(memrompath,	sizeof(memrompath),	1,file);
	fwrite(&memnolc,	sizeof(memnolc),	1,file);
	fwrite(&memram[0],	49152,			1,file);
	if ((!memnolc) || (!(appletype & APPLEII))) {
	  fwrite(&memram[49152],16384,			1,file);
	}
	if (appletype & (APPLEIIE | APPLEIIC)) {
	  fwrite(&memram[65536],49152,			1,file);
	  if ((!memnolc) || (!(appletype & APPLEII))) {
	    fwrite(&memram[65536+49152],16384,		1,file);
	  }
	}
	fwrite(&memram[0x20000],32768,			1,file);
	fwrite(&memauxbank,	sizeof(memauxbank),	1,file);
	fwrite(&memauxread,	sizeof(memauxread),	1,file);
	fwrite(&memauxwrite,	sizeof(memauxwrite),	1,file);
	fwrite(&memintcxrom,	sizeof(memintcxrom),	1,file);
	fwrite(&memslotc3,	sizeof(memslotc3),	1,file);
	fwrite(&memlcaux,	sizeof(memlcaux),	1,file);
	fwrite(&memlcramr,	sizeof(memlcramr),	1,file);
	fwrite(&memlcramw,	sizeof(memlcramw),	1,file);
	fwrite(&memlcbank2,	sizeof(memlcbank2),	1,file);
	fwrite(&memstore80,	sizeof(memstore80),	1,file);
	fwrite(&memrombank,	sizeof(memrombank),	1,file);
	fwrite(&memiic32k,	sizeof(memiic32k),	1,file);
	fwrite(&memiic4080,	sizeof(memiic4080),	1,file);
	fwrite(&memann3,	sizeof(memann3),	1,file);
	fwrite(&memkey,		sizeof(memkey),		1,file);
	fwrite(&memjoyx,	sizeof(memjoyx),	1,file);
	fwrite(&memjoyy,	sizeof(memjoyy),	1,file);
	fwrite(&memjoybutton0,	sizeof(memjoybutton0),	1,file);
	fwrite(&memjoybutton1,	sizeof(memjoybutton1),	1,file);
	fwrite(&memjoycycle,	sizeof(memjoycycle),	1,file);

	stringwrite(window, "Memory stored.\r");

	return 0;

      } /* memorystore */


/*-------------------------------------*/


      unsigned int memoryrestore(unsigned int window, FILE *file) {

	fread(&soundflag,	sizeof(soundflag),	1,file);
	fread(&appletype,	sizeof(appletype),	1,file);
	fread(memrompath,	sizeof(memrompath),	1,file);
	fread(&memnolc,		sizeof(memnolc),	1,file);
	fread(&memram[0],	49152,			1,file);
	if ((!memnolc) || (!(appletype & APPLEII))) {
	  fread(&memram[49152],	16384,			1,file);
	}
	if (appletype & (APPLEIIE | APPLEIIC)) {
	  fread(&memram[65536],	49152,			1,file);
	  if ((!memnolc) || (!(appletype & APPLEII))) {
	    fread(&memram[65536+49152],16384,		1,file);
	  }
	}
	fread(&memram[0x20000],	32768,			1,file);
	fread(&memauxbank,	sizeof(memauxbank),	1,file);
	fread(&memauxread,      sizeof(memauxread),     1,file);
	fread(&memauxwrite,     sizeof(memauxwrite),    1,file);
	fread(&memintcxrom,     sizeof(memintcxrom),    1,file);
	fread(&memslotc3,       sizeof(memslotc3),      1,file);
	fread(&memlcaux,        sizeof(memlcaux),       1,file);
	fread(&memlcramr,       sizeof(memlcramr),      1,file);
	fread(&memlcramw,       sizeof(memlcramw),      1,file);
	fread(&memlcbank2,      sizeof(memlcbank2),     1,file);
	fread(&memstore80,      sizeof(memstore80),     1,file);
	fread(&memrombank,	sizeof(memrombank),	1,file);
	fread(&memiic32k,	sizeof(memiic32k),	1,file);
	fread(&memiic4080,	sizeof(memiic4080),	1,file);
	fread(&memann3,         sizeof(memann3),        1,file);
	fread(&memkey,		sizeof(memkey),		1,file);
	fread(&memjoyx,		sizeof(memjoyx),	1,file);
	fread(&memjoyy,		sizeof(memjoyy),	1,file);
	fread(&memjoybutton0,	sizeof(memjoybutton0),	1,file);
	fread(&memjoybutton1,	sizeof(memjoybutton1),	1,file);
	fread(&memjoycycle,	sizeof(memjoycycle),	1,file);

	stringwrite(window, "Memory restored.\r");

	return 0;

      } /* memoryrestore */


/*-------------------------------------*/


unsigned char memoryread(unsigned int addr) {

  if (addr < 0xc000) {
    if (addr < 0x2000) {
      if (addr < 0x400) {
        if (addr < 0x200) {
/* $0000 - $01ff */
          if (memlcaux)         { return memauxbankptr[addr]; }			/* aux 64 */
          else                  { return memram[addr]; }			/* main 64 */
        }
        else {
/* $0200 - $03ff */
          if (memauxread)       { return memauxbankptr[addr]; }			/* aux 64 */
          else                  { return memram[addr]; }			/* main 64 */
        }
      }
      else {
        if (addr < 0x800) {
/* $0400 - $07ff */
          if (memstore80) {
            if (virtpage2)      { return memram[addr+MEMAUXRAM]; }		/* aux 64 */
            else                { return memram[addr]; }			/* main 64 */
          }
          else {
            if (memauxread)     { return memauxbankptr[addr]; }			/* aux 64 */
            else                { return memram[addr]; }			/* main 64 */
          }
        }
        else {
/* $0800 - $1fff */
          if (memauxread)       { return memauxbankptr[addr]; }			/* aux 64 */
          else                  { return memram[addr]; }			/* main 64 */
        }
      }
    } /* if (addr < 0x2000) */
    else {
      if (addr < 0x4000) {
/* $2000 - $3fff */
        if ((memstore80) && (virthgr)) {
          if (virtpage2)	{ return memram[addr+MEMAUXRAM]; }		/* aux 64 */
          else                  { return memram[addr]; }			/* main 64 */
        }
        else {
          if (memauxread)       { return memauxbankptr[addr]; }			/* aux 64 */
          else                  { return memram[addr]; }			/* main 64 */
        }
      }
      else {
/* $4000 - $bfff */
        if (memauxread)         { return memauxbankptr[addr]; }			/* aux 64 */
        else                    { return memram[addr]; }			/* main 64 */
      }
    }
  } /* if (addr < 0xc000) */
  else {
    if (addr >= 0xd000) {
      if ((!memlcramr) || (memnolc && (appletype & APPLEII)) ) {
        if (memrombank) {
          return memram[addr-0xd000+MEMROM2];	/* ROM bank 2 */
        }
        else {
          return memram[addr-0xd000+MEMROM];	/* ROM is the same for whatever memlcaux is set to */
        }
      }
      else {
        if (memlcaux) {
          if (addr < 0xe000) {
            if (!memlcbank2) {
              return memauxbankptr[(addr-0x1000)];
            }
          }
          return memauxbankptr[addr];
        }
        else {
          if (addr < 0xe000) {
            if (!memlcbank2) {
              return memram[addr-0x1000];
            }
          }
          return memram[addr];
        }
      } /* else if (memlcramr) */
    } /* if (addr => 0xd000 */
    else {

 /* test for softswitch area */
      if (addr <= 0xc0ff) {

        if (addr <= 0xc00f) { return memkey; }	/* keyboard */

        if (inidebugflag) return 0x0d;		/* avoid accessing softswitches from the debugger */

        if (addr <= 0xc01f) {
          if (appletype & (APPLEIIE | APPLEIIC)) {	/* not on Apple][+ */
            switch (addr) {
              case 0xc010 :     { memkey = memkey & 0x7f;
                                  return memkey;	/* not correct (undefined so far) */
                                }
              case 0xc011 :     return (memlcbank2  | (memkey&0x7f));
              case 0xc012 :     return (memlcramr   | (memkey&0x7f));
              case 0xc013 :     return (memauxread  | (memkey&0x7f));
              case 0xc014 :     return (memauxwrite | (memkey&0x7f));
              case 0xc015 :	if (appletype & APPLEIIE) {
				  return (memintcxrom | (memkey&0x7f));
				}
				else {
				  return memkey&0x7f;
				}
              case 0xc016 :     return (memlcaux    | (memkey&0x7f));
	      case 0xc017 :	if (appletype & APPLEIIE) {
				  return (memslotc3   | (memkey&0x7f));
				}
				else {
				  return memkey&0x7f;
				}
              case 0xc018 :     return (memstore80  | (memkey&0x7f));
              case 0xc019 :	if (appletype & APPLEIIE) {
              			  return (rasterline<192) ? ((memkey&0x7f)|0x80) : (memkey&0x7f);
              			}
              			else {
              			  return memkey&0x7f;
              			}
              case 0xc01a :     return ((virtgraphic ^ 0x80) | (memkey&0x7f));
              case 0xc01b :     return (virtmixed   | (memkey&0x7f));
              case 0xc01c :     return (virtpage2   | (memkey&0x7f));
              case 0xc01d :     return (virthgr     | (memkey&0x7f));
              case 0xc01e :     return (virtaltchar | (memkey&0x7f));
              case 0xc01f :     return (virt80col   | (memkey&0x7f));
            } /* switch */
          }
          else {
            memkey = memkey & 0x7f;
            return memkey;	/* not correct (undefined so far) */
          }
        }


        if (addr <= 0xc02f) {
          if (appletype & APPLEIIC) {
            if (addr == 0xc028) {
              memrombank = !memrombank;
            }
            return memkey&0x7f;
          }
          else {
            return memkey&0x7f;		/* Cassette output toggle */
          }
        }

        if (addr <= 0xc03f)     { soundclick();		return memkey&0x7f; } /* Speaker */

        if (addr <= 0xc04f)                             return memkey&0x7f;   /* Utility output strobe - nani yo? */

        if (addr <= 0xc08f) {
          switch (addr) {
            case 0xc050 : { if (!virtgraphic) {
                              virtgraphic = 0x80;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc051 : { if (virtgraphic) {
                              virtgraphic = 0;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc052 : { if (virtmixed) {
                              virtmixed = 0;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc053 : { if (!virtmixed) {
                              virtmixed = 0x80;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc054 : { if (virtpage2) {
                              virtpage2 = 0;
                              if (!memstore80) {
                                virtcachemode = (((virtcachemode & 0xfe) + 2) & 0xfe) | (virtcachemode & 0xff00);
                                virtsetmode();
                              }
                            }
                            return virtvideobyte;
                          }
            case 0xc055 : { if (!virtpage2) {
                              virtpage2 = 0x80;
                              if (!memstore80) {
                                virtsetmode();
                              }
                            }
                            return virtvideobyte;
                          }
            case 0xc056 : { if (virthgr) {
                              virthgr = 0;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }
            case 0xc057 : { if (!virthgr) {
                              virthgr = 0x80;
                              virtsetmode();
                            }
                            return virtvideobyte;
                          }

            case 0xc058 : return virtvideobyte; /* Out0-off - nani yo? */
            case 0xc059 : return virtvideobyte; /* Out0-on - nani yo? */
            case 0xc05a : return virtvideobyte; /* Out1-off - nani yo? */
            case 0xc05b : return virtvideobyte; /* Out1-on - nani yo? */
            case 0xc05c : return virtvideobyte; /* Out2-off - nani yo? */
            case 0xc05d : return virtvideobyte; /* Out2-on - nani yo? */
/*
   C05E 49246 CLRAN3       OE G WR   If IOUDIS off: Annunciator 3 Off
              Y0EDGE         C  WR   If IOUDIS on: Interrupt on Y0 Rising
              DHIRESON      ECG WR   In 80-Column Mode: Double Width Graphics
*/
            case 0xc05e : if (!virtiou) {
                            memann3 = 0;              /* annunciator#3 off */
                          }
                          if (!virtdhres) {
                            virtdhres = 0x80;         /* double hires on   */
                            virtsetmode();
                          }
                          return virtvideobyte;
/*
    C05F 49247 SETAN3       OE G WR   If IOUDIS off: Annunciator 3 On
               Y0EDGE         C  WR   If IOUDIS on: Interrupt on Y0 Falling
               DHIRESOFF     ECG WR   In 80-Column Mode: Single Width Graphics
*/
            case 0xc05f : if (!virtiou) {
                            memann3 = 0x80;           /* annunciator#3 on */
                          }
                          if (virtdhres) {
                            virtdhres = 0;            /* double hires off */
                            virtsetmode();
                          }
                          return virtvideobyte;
/* C060 49248              OE    R7  Read Cassette Input
                             C   R7  Status of 80/40 Column Switch
              BUTN3           G  R7  Switch Input 3 */
            case 0xc060 : if (appletype & APPLEIIC) {
			    if (memiic4080) return virtvideobyte & 0x7f; /* 80 */
					    return virtvideobyte | 0x80; /* 40 */
			  }
			  else {
			    return virtvideobyte & 0x7f;
			  }
            case 0xc068 : return 0x00; /* Cassette input */
/* C061 49249 RDBTN0        EC   R7  Switch Input 0 / Open Apple */
            case 0xc061 :
            case 0xc069 : return memjoybutton0;		/* here: also possible on AppleII */
/* C062 49250 BUTN1         E    R7  Switch Input 1 / Solid Apple */
            case 0xc062 :
            case 0xc06a : return memjoybutton1;		/* here: also possible on AppleII */
/* C063 49251 RD63          E    R7  Switch Input 2 / Shift Key
                             C   R7  Bit 7 = Mouse Button Not Pressed */
  /* Switched values, and added the ability to use this on the ][+.  It is
     possible to have the Shift Key Mod on any ][ - it was just *standard*
     on the Platinum //e only. -uso. */
            case 0xc063 :
            case 0xc06b : if (appletype & (APPLEIIE | APPLEII)) {
			    if ((keyboardmap[0x80]) || (keyboardmap[0x81])) {
                              return 0x00;
			    }
			    else {
                              return 0x80;
			    }
			  }
			  else {
			    if (appletype & APPLEIIC) {
			      return 0x80;			/* always not pressed for now */
			    }
			    else {
			      return 0x7f;
			    }
		          }
/* C064 49252 PADDL0       OECG  R7  Analog Input 0 */
            case 0xc064 :
            case 0xc06c : if ((cycle - memjoycycle - memjoyx) > 0x7fffffff) {
                            return 0x80;
                          }
                          else {
                            return 0;
                          }
/* C065 49253 PADDL1       OECG  R7  Analog Input 1 */
            case 0xc065 :
            case 0xc06d : if ((cycle - memjoycycle - memjoyy) > 0x7fffffff) {
                            return 0x80;
                          }
                          else {
                            return 0;
                          }
/* C066 49254 PADDL2       OE G  R7  Analog Input 2
              RDMOUX1        C   R7  Mouse Horiz Position */
            case 0xc066 :
            case 0xc06e : return 0xa0; /* Pdl2 */
/* C067 49255 PADDL3       OE G  R7  Analog Input 3
              RDMOUY1        C   R7  Mouse Vert Position */
            case 0xc067 :
            case 0xc06f : return 0xa0; /* Pdl3 */

/* C070 49364 PTRIG         E    R   Analog Input Reset
                             C  WR   Analog Input Reset + Reset VBLINT Flag */
            case 0xc070 :
              if (keyjoystick) {
	        union REGS regs;

	        regs.h.ah=0x84;		/* Get the current position of the game controller */
	        regs.x.dx=0x0001;
	        int86(0x15,&regs,&regs);
	        memjoyx=(27*(regs.x.ax&0xFFFF));
	        memjoyy=(27*(regs.x.bx&0xFFFF));
              }
              memjoycycle = cycle;	/* save cpu cycle */
              return virtvideobyte;
            case 0xc071 :
            case 0xc072 :
            case 0xc073 :
            case 0xc074 :
            case 0xc075 :
            case 0xc076 :
            case 0xc077 :
            case 0xc078 :
            case 0xc079 :
            case 0xc07a :
            case 0xc07b :
            case 0xc07c :
            case 0xc07d : return virtvideobyte;

/* C07E 49278 IOUDISON      EC  W    Disable IOU
              RDIOUDIS      EC   R7  Status of IOU Disabling */
            case 0xc07e : if (appletype & (APPLEIIE | APPLEIIC)) {
                            return ((virtiou) | (virtvideobyte & 0x7f));
                          }
                          else {
                            return virtvideobyte;
                          }
/* C07F 49279 IOUDISOFF     EC  W    Enable IOU
              RDDHIRES      EC   R7  Status of Double HiRes */
            case 0xc07f : if (appletype & (APPLEIIE | APPLEIIC)) {
                            return ((virtdhres) | (virtvideobyte & 0x7f));
                          }
                          else {
                            return virtvideobyte;
                          }

/* Language Card Handling */
            case 0xc080 :
            case 0xc084 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0;     /* Write Rom */
                            return (memkey&0x7f);
                          }
            case 0xc081 :
            case 0xc085 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0x80;  /* Write Bank */
                            return (memkey&0x7f);
                          }
            case 0xc082 :
            case 0xc086 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0;     /* Write Rom */
                            return (memkey&0x7f);
                          }
            case 0xc083 :
            case 0xc087 : {
                            memlcbank2 = 0x80;  /* Bank 2 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0x80;  /* Write Bank */
                            return (memkey&0x7f);
                          }
            case 0xc088 :
            case 0xc08c : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0;     /* Write Rom */
                            return (memkey&0x7f);
                          }
            case 0xc089 :
            case 0xc08d : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0x80;  /* Write Bank */
                            return (memkey&0x7f);
                          }
            case 0xc08a :
            case 0xc08e : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0;     /* Read Rom */
                            memlcramw  = 0;     /* Write Rom */
                            return (memkey&0x7f);
                          }
            case 0xc08b :
            case 0xc08f : {
                            memlcbank2 = 0;     /* Bank 1 */
                            memlcramr  = 0x80;  /* Read Bank */
                            memlcramw  = 0x80;  /* Write Bank */
                            return (memkey&0x7f);
                          }
          } /* switch */
        } /* if (addr <= 0xc08f) */

/* Slot #1 Softswitches: Parallel Port */
	if (addr <= 0xc09f) {
	  if (appletype & (APPLEII | APPLEIIE)) {
/*	    return ReadParallel (addr); */
	  }
          return virtvideobyte;
        }

/* Slot #5 Softswitches */
	if (addr >= 0xc0d0 && addr <= 0xc0df) {
          if (appletype & (APPLEII | APPLEIIE)) {
	    return ReadRawDiskIO (addr);
	  }
	  else {
	    return virtvideobyte;
	  }
	}

/* Slot #6 Softswitches */
        if (addr >= 0xc0e0 && addr <= 0xc0ef) {
          return driveread(addr);
        }

/* Slot #7 Softswitches */
	if (addr >= 0xc0f0 && addr <= 0xc0ff) {
	  if (appletype & (APPLEII | APPLEIIE)) {
	    return virtvideobyte; /* dqhdv? virtvideobyte : ReadMassStorIO (addr); */
	  }
	  else {
	    return virtvideobyte;
	  }
        }

/* The remaining addresses between 0xc000 and 0xc0ff are simply ignored. */
        return virtvideobyte;
      } /* if (addr <= 0xc0ff */
      else {
/* $c100 - $cfff */
	if ((memintcxrom) || (memrombank)) {
	  return memram[(addr-0xc000)+MEMINTCXROM];
	}
        else {
          if (addr <= 0xc1ff) return memram[(addr-0xc000)+MEMSLOTROM];		/* 1 */
          if (addr <= 0xc2ff) return memram[(addr-0xc000)+MEMSLOTROM];		/* 2 */
          if (addr <= 0xc3ff) {							/* 3 */
            if (appletype & APPLEIIE) {
              if (memslotc3)	{ return memram[(addr-0xc000)+MEMSLOTROM]; }	/* slot */
              else		{ return memram[(addr-0xc000)+MEMINTCXROM]; }	/* copy of INTCXROM */
            }
            else		{ return memram[(addr-0xc000)+MEMSLOTROM]; }	/* slot */
          }
          if (addr <= 0xc4ff) return memram[(addr-0xc000)+MEMSLOTROM];		/* 4 */
          if (addr <= 0xc5ff) return memram[(addr-0xc000)+MEMSLOTROM];		/* 5 */
          if (addr <= 0xc6ff) return memram[(addr-0xc000)+MEMSLOTROM];		/* 6 */
          if (addr <= 0xc7ff) return memram[(addr-0xc000)+MEMSLOTROM];		/* 7 */
          if (appletype & APPLEII) {
            return 0xaa;
          }
          else {
            if (appletype & APPLEIIE) {
	      return memram[(addr-0xc000)+MEMINTCXROM];
	    }
	    else {
              return memram[(addr-0xc000)+MEMSLOTROM];
            }
          }
        }
      } /* else if (addr <= 0xc0ff */
    } /* else if (addr >= 0xd000) */
  } /* else if (addr < 0xc000) */
} /* memoryread() */


/*-------------------------------------*/


      void memorywrite(unsigned int addr, unsigned int val) {

	if (addr < 0xc000) {
	  if (addr < 0x2000) {
	    if (addr < 0x400) {
	      if (addr < 0x200) {
/* $0000 - $01ff */
		if (memlcaux)	{ memauxbankptr[addr]	= val; return; }	/* aux 64 */
		else		{ memram[addr]		= val; return; }	/* main 64 */
	      }
	      else {
/* $0200 - $03ff */
		if (memauxwrite){ memauxbankptr[addr]	= val; return; }	/* aux 64 */
		else		{ memram[addr]		= val; return; }	/* main 64 */
	      }
	    }
	    else {
	      if (addr < 0x800) {
/* $0400 - $07ff */
		if (memstore80) {
		  if (virtpage2) {
		    if (memram[addr+MEMAUXRAM] != val) {
		      memram[addr+MEMAUXRAM] = val;				/* aux 64 */
		      virtwrite0400aux(addr);
		    }
		  }
		  else {
		    if (memram[addr] != val) {
		      memram[addr] = val;					/* main 64 */
		      virtwrite0400(addr);
		    }
		    return;
		  }
		} /* if (memstore80) */
		else {
		  if (memauxwrite) {
		    if (!memauxbank) {
		      if (memram[addr+MEMAUXRAM] != val) {
		        memram[addr+MEMAUXRAM] = val;				/* aux 64 */
		        virtwrite0400aux(addr);
		      }
		    }
		    else {
		      memauxbankptr[addr] = val;
		    }
		    return;
		  }
		  else {
		    if (memram[addr] != val) {
		      memram[addr] = val;					/* main 64 */
		      virtwrite0400(addr);
		    }
		    return;
		  }
		} /* else if (memstore80) */
	      } /* if (addr < 0x800 */
	      else {
		if (addr < 0xc00) {
/* $0800 - $0bff */
		  if (memauxwrite) {
		    if (!memauxbank) {
		      if (memram[addr+MEMAUXRAM] != val) {
			memram[addr+MEMAUXRAM] = val;				/* aux 64 */
			virtwrite0800aux(addr);
		      }
		    }
		    else {
		      memauxbankptr[addr] = val;
		    }
		    return;
		  }
		  else {
		    if (memram[addr] != val) {
		      memram[addr] = val;					/* main 64 */
		      virtwrite0800(addr);
		    }
		    return;
		  }
		}
		else {
/* $0c00 - $1fff */
		  if (memauxwrite)	{ memauxbankptr[addr]	= val; return; }	/* aux 64 */
		  else			{ memram[addr]		= val; return; }	/* main 64 */
		}
	      }
	    }
	  } /* if (addr < 0x2000) */
	  else {
	    if (addr < 0x4000) {
/* $2000 - $3fff */
	      if ((memstore80) && (virthgr)) {
		if (virtpage2) {
		  if (memram[addr+MEMAUXRAM] != val) {
		    memram[addr+MEMAUXRAM] = val;				/* aux 64 */
		    virtwrite2000aux(addr);
		  }
		  return;
		}
		else {
		  if (memram[addr] != val) {
		    memram[addr] = val;						/* main 64 */
		    virtwrite2000(addr);
		  }
		  return;
		}
	      }
	      else {
		if (memauxwrite) {
		  if (!memauxbank) {
		    if (memram[addr+MEMAUXRAM] != val) {
		      memram[addr+65536] = val;					/* aux 64 */
		      virtwrite2000aux(addr);
		    }
		  }
		  else {
		    memauxbankptr[addr] = val;
		  }
		  return;
		}
		else {
		  if (memram[addr] != val) {
		    memram[addr] = val;						/* main 64 */
		    virtwrite2000(addr);
		  }
		  return;
		}
	      }
	    }
	    else {
	      if (addr < 0x6000) {
/* $4000 - $5fff */
		if (memauxwrite) {
		  if (!memauxbank) {
		    if (memram[addr+MEMAUXRAM] != val) {
		      memram[addr+MEMAUXRAM] = val;				/* aux 64 */
		      virtwrite4000aux(addr);
		    }
		  }
		  else {
		    memauxbankptr[addr] = val;
		  }
		  return;
		}
		else {
		  if (memram[addr] != val) {
		    memram[addr] = val;						/* main 64 */
		    virtwrite4000(addr);
		  }
		  return;
		}
	      }
	      else {
/* $6000 - $bfff */
		if (memauxwrite)	{ memauxbankptr[addr]	= val; return; }/* aux 64 */
		else			{ memram[addr]		= val; return; }/* main 64 */
	      }
	    }
	  }
	} /* if (addr < 0xc000) */
	else {
	  if (addr >= 0xd000) {
	    if ((!memlcramw) || (memnolc && (appletype & APPLEII)) ) {
	      return;         /* ROM is the same for whatever memlcaux is set to */
	    }
	    else {
	      if (memlcaux) {
		if (addr < 0xe000) {
		  if (!memlcbank2) {
		     memauxbankptr[(addr-0x1000)] = val;
		    return;
		  }
		}
		memauxbankptr[addr] = val;
		return;
	      }
	      else {
		if (addr < 0xe000) {
		  if (!memlcbank2) {
		    memram[addr-0x1000] = val;
		    return;
		  }
		}
		memram[addr] = val;
		return;
	      }
	    } /* else if (memlcramw) */
	  } /* if (addr => 0xd000 */
	  else {

 /* test for softswitch area */
	    if (addr <= 0xc0ff) {

	      if (inidebugflag) return;

		if (addr <= 0xc00f) {
		  if (appletype & (APPLEIIE | APPLEIIC)) {	/* not on Apple][+ */
		    switch (addr) {
		      case 0xc000 : if (memstore80) {
				      memstore80 = 0;
				      virtsetmode();
				    }
				    return;
		      case 0xc001 : if (!memstore80) {
				      memstore80 = 0x80;
				      virtsetmode();
				    }
				    return;
		      case 0xc002 : memauxread		= 0;    return;
		      case 0xc003 : memauxread		= 0x80; return;
		      case 0xc004 : memauxwrite		= 0;    return;
		      case 0xc005 : memauxwrite		= 0x80; return;
		      case 0xc006 : if (appletype & APPLEIIE) {
		      		      memintcxrom	= 0;			/* SLOTCXROM Off */
		      		    }
		      		    return;
		      case 0xc007 : if (appletype & APPLEIIE) {
		      		      memintcxrom	= 0x80;			/* SLOTCXROM On */
		      		    }
		      		    return;
		      case 0xc008 : memlcaux		= 0;    return;
		      case 0xC009 : memlcaux		= 0x80; return;
		      case 0xc00a : if (appletype & APPLEIIE) {
		      		      memslotc3		= 0;			/* SLOTC3ROM Off */
		      		    }
		      		    return;
		      case 0xc00b : if (appletype & APPLEIIE) {
		      		      memslotc3		= 0x80;			/* SLOTC3ROM On */
		      		    }
		      		    return;
		      case 0xc00c : if (virt80col) {
				      virt80col = 0;
				      virtsetmode();
				    }
				    return;
		      case 0xc00d : if (!virt80col) {
				      virt80col = 0x80;
				      virtsetmode();
				    }
				    return;
	      case 0xc00e :
		if (virtaltchar) {			/* only update if there was a change */
		  virtaltchar = 0;
		  virtfontptr = virtfontflashptr;
		  virtcacheinit();
		}
		return;
	      case 0xc00f :
		if (!virtaltchar) {			/* only update if there was a change */
		  virtaltchar = 0x80;
		  virtfontptr = virtfontalt;
		  virtcacheinit();
		}
		return;
            } /* switch */
          } /* if (appletype & (APPLEIIE | APPLEIIC)) */
          else return;
        } /* if (addr <= 0xc00f */

        if (addr <= 0xc01f) {
          memkey = memkey & 0x7f;
          return;
        }

        if (addr <= 0xc02f) {
          if (appletype & APPLEIIC) {
            if (addr == 0xc028) {
              memrombank = !memrombank;
            }
          }
          return;				/* Cassette output toggle */
        }

        if (addr <= 0xc03f)     { soundclick(); /*soundclick();*/ return; } /* Speaker */

        if (addr <= 0xc04f)                             return;   /* Utility output strobe - nani yo? */

        if (addr <= 0xc08f) {
          switch (addr) {
            case 0xc050 :
              if (!virtgraphic) {
                virtgraphic = 0x80;
                virtsetmode();
              }
              return;
            case 0xc051 :
              if (virtgraphic) {
                virtgraphic = 0;
                virtsetmode();
              }
              return;
            case 0xc052 :
              if (virtmixed) {
                virtmixed = 0;
                virtsetmode();
              }
              return;
            case 0xc053 :
              if (!virtmixed) {
                virtmixed = 0x80;
                virtsetmode();
              }
              return;
            case 0xc054 :
              if (virtpage2) {
                virtpage2 = 0;
                if (!memstore80) {
                  virtcachemode = (((virtcachemode & 0xfe) + 2) & 0xfe) | (virtcachemode & 0xff00);
                  virtsetmode();
                }
              }
              return;
            case 0xc055 :
              if (!virtpage2) {
                virtpage2 = 0x80;
                if (!memstore80) {
                  virtsetmode();
                }
              }
              return;
            case 0xc056 :
              if (virthgr) {
                virthgr = 0;
                virtsetmode();
              }
              return;
            case 0xc057 :
              if (!virthgr) {
                virthgr = 0x80;
                virtsetmode();
              }
              return;

            case 0xc058 : return; /* Out0-off - nani yo? */
            case 0xc059 : return; /* Out0-on - nani yo? */
            case 0xc05a : return; /* Out1-off - nani yo? */
            case 0xc05b : return; /* Out1-on - nani yo? */
            case 0xc05c : return; /* Out2-off - nani yo? */
            case 0xc05d : return; /* Out2-on - nani yo? */
/*
   C05E 49246 CLRAN3       OE G WR   If IOUDIS off: Annunciator 3 Off
              Y0EDGE         C  WR   If IOUDIS on: Interrupt on Y0 Rising
              DHIRESON      ECG WR   In 80-Column Mode: Double Width Graphics
*/
            case 0xc05e : {
                            if (!virtiou) {
                              memann3 = 0;              /* annunciator#3 off */
                            }
                            if (!virtdhres) {
                              virtdhres = 0x80; /* double hires on   */
                              virtsetmode();
                            }
                            return;
                          }
/*
    C05F 49247 SETAN3       OE G WR   If IOUDIS off: Annunciator 3 On
               Y0EDGE         C  WR   If IOUDIS on: Interrupt on Y0 Falling
               DHIRESOFF     ECG WR   In 80-Column Mode: Single Width Graphics
*/
            case 0xc05f : {
                            if (!virtiou) {
                              memann3 = 0x80;           /* annunciator#3 on */
                            }
                            if (virtdhres) {
                              virtdhres = 0;            /* double hires off */
                              virtsetmode();
                            }
                            return;
                          }
            case 0xc060 :
            case 0xc068 : return; /* Cassette input */
            case 0xc061 :
            case 0xc069 : return;
            case 0xc062 :
            case 0xc06a : return;
/* C063 49251 RD63          E    R7  Switch Input 2 / Shift Key
                             C   R7  Bit 7 = Mouse Button Not Pressed */
            case 0xc063 :
            case 0xc06b : return;
            case 0xc064 :
            case 0xc06c : return; /* Pdl0 */
            case 0xc065 :
            case 0xc06d : return; /* Pdl1 */
            case 0xc066 :
            case 0xc06e : return; /* Pdl2 */
            case 0xc067 :
            case 0xc06f : return; /* Pdl3 */

            case 0xc070 :
              if (keyjoystick) {
	        union REGS regs;
	        regs.h.ah=0x84;		/* Get the current position of the game controller */
	        regs.x.dx=0x0001;
	        int86(0x15,&regs,&regs);
	        memjoyx=(27*(regs.x.ax&0xFFFF));
	        memjoyy=(27*(regs.x.bx&0xFFFF));
	      }
              memjoycycle = cycle;	/* save cpu cycle */
              return;
            case 0xc071 : return;
            case 0xc072 : return;
/* C073 49367 BANKSEL       ECG W    Memory Bank Select for > 128K */
            case 0xC073:
              if (appletype & (APPLEIIE | APPLEIIC)) {
		if (val < MEMMAXRAM) {	/* nani? what is one to do upon hitting an invalid page? */
		  memauxbank = val;
		  if (memramptr[val] != NULL) {
		    memauxbankptr = memramptr[val];
		  }
		}
	      }
              return;
            case 0xc074 :
            case 0xc075 :
            case 0xc076 :
            case 0xc077 :
            case 0xc078 :
            case 0xc079 :
            case 0xc07a :
            case 0xc07b :
            case 0xc07c :
            case 0xc07d : return;
/* C07E 49278 IOUDISON      EC  W    Disable IOU
              RDIOUDIS      EC   R7  Status of IOU Disabling */
            case 0xc07e : if (appletype & (APPLEIIE | APPLEIIC)) {
			    virtiou = 0;
			  }
			  return;
/* C07F 49279 IOUDISOFF     EC  W    Enable IOU
              RDDHIRES      EC   R7  Status of Double HiRes */
            case 0xc07f : if (appletype & (APPLEIIE | APPLEIIC)) {
			    virtiou = 0x80;
			  }
			  return;

/* Language Card Handling */
	    case 0xc080 :
	    case 0xc084 :
	      memlcbank2 = 0x80;  /* Bank 2 */
	      memlcramr  = 0x80;  /* Read Bank */
	      memlcramw  = 0;     /* Write Rom */
	      return;
	    case 0xc081 :
	    case 0xc085 :
	    memlcbank2 = 0x80;  /* Bank 2 */
	      memlcramr  = 0;     /* Read Rom */
	      memlcramw  = 0x80;  /* Write Bank */
	      return;
	    case 0xc082 :
	    case 0xc086 :
	      memlcbank2 = 0x80;  /* Bank 2 */
	      memlcramr  = 0;     /* Read Rom */
	      memlcramw  = 0;     /* Write Rom */
	      return;
	    case 0xc083 :
	    case 0xc087 :
	      memlcbank2 = 0x80;  /* Bank 2 */
	      memlcramr  = 0x80;  /* Read Bank */
	      memlcramw  = 0x80;  /* Write Bank */
	      return;
	    case 0xc088 :
	    case 0xc08c :
	      memlcbank2 = 0;     /* Bank 1 */
	      memlcramr  = 0x80;  /* Read Bank */
	      memlcramw  = 0;     /* Write Rom */
	      return;
	    case 0xc089 :
	    case 0xc08d :
	      memlcbank2 = 0;     /* Bank 1 */
	      memlcramr  = 0;     /* Read Rom */
	      memlcramw  = 0x80;  /* Write Bank */
	      return;
	    case 0xc08a :
	    case 0xc08e :
	      memlcbank2 = 0;     /* Bank 1 */
	      memlcramr  = 0;     /* Read Rom */
	      memlcramw  = 0;     /* Write Rom */
	      return;
	    case 0xc08b :
	    case 0xc08f :
	      memlcbank2 = 0;     /* Bank 1 */
	      memlcramr  = 0x80;  /* Read Bank */
	      memlcramw  = 0x80;  /* Write Bank */
	      return;
	  } /* switch */
	}

/* Slot #1 Softswitches: Parallel Port */
	if (addr <= 0xc09f) {
	  WriteParallel (addr, val);
	  return;
	}

/* Slots #2 .. #4 ignored for now */
	if (addr <= 0xc0cf) {
	  return;
	}

/* Slot #5 Softswitches */
	if (addr <= 0xc0df) {
	  WriteRawDiskIO (addr, val);
	  return;
	}

/* Slot #6 Softswitches */
	if (addr <= 0xc0ef) {
	  drivewrite (addr, val);
	  return;
	}

/* Slot #7 Softswitches */
	if (addr <= 0xc0ff) {
	  return;
	}
/*	if (addr >= 0xc0f0 && addr <= 0xc0ff && (!dqhdv)) {
	  WriteMassStorIO (addr, val);  return;
	}
*/

/* The remaining addresses between 0xc000 and 0xc0ff are simply ignored. */
	  return;
	} /* if (addr <= 0xc0ff */

	if (memintcxrom) { return; }

/* Slot #4: Z80 */
// if (Addr>=50432 && Addr<=50687)
#ifdef EMUZ80
	    if (addr==0xc400) {
	      if (cpuinuse==emuZ80) { /* from manual */
	        cpuinuse=emu6502;
	        return;
	      }
	      cpuinuse=emuZ80;
	      return;
	    }
#endif
	    return;
	  } /* else (if addr >= 0xd000 */
	} /* else (if (addr < 0xc000 */
      } /* memorywrite */


/*-------------------------------------*/


      void memorymenu () {
	unsigned int screen;
	unsigned int keyboard;
	unsigned int window;
	unsigned char key;
	unsigned char update;

	screen = screenstore();
	if (!windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1, "Memory Options", &keyboard, &window)) {

	  messageflag = 0;
	  update = 1;
	  do {
	    if (update) {
	      channelout(window, 12);		/* clear window */
	      stringwrite(window, "\r[ESC] - Quit\r\r");

	      stringwrite(window, "\rCurrent ROM file is: ");
	      stringwrite(window, memrompath);
	      channelout(window, 13);

	      stringwrite(window, "\r[1] - Apple ][ - Monitor              ");
	      channelout(window,  0!=strstr(memrompath,"apple2m.rom")  ? '*': ' ');
	      stringwrite(window, "\r[2] - Apple ][ - Autostart            ");
	      channelout(window,  0!=strstr(memrompath,"apple2o.rom")  ? '*': ' ');
	      stringwrite(window, "\r[3] - Apple ][ Plus                   ");
	      channelout(window,  0!=strstr(memrompath,"apple.rom")    ? '*': ' ');
	      stringwrite(window, "\r[4] - Apple //e (Original)            ");
	      channelout(window,  0!=strstr(memrompath,"apple2eo.rom") ? '*': ' ');
	      stringwrite(window, "\r[5] - Apple //e (Enhanced)            ");
              channelout(window,  0!=strstr(memrompath,"apple2e.rom") ? '*': ' ');
              stringwrite(window, "\r[6] - Apple //c (16 KB experimental!) ");
	      channelout(window,  0!=strstr(memrompath,"apple2co.rom") ? '*': ' ');
              stringwrite(window, "\r[7] - Apple //c (32 KB experimental!) ");
	      channelout(window,  0!=strstr(memrompath,"apple2c.rom")  ? '*': ' ');

	      stringwrite(window, "\r\r[M] - Maximum ][/][+ RAM ");
	      if (memnolc) { stringwrite(window, "48k"); }
	      else         { stringwrite(window, "64k"); }

	      stringwrite(window, "\r(RAM in //e + //c mode is always ");
	      intwrite(window, (memnumbbanks+1) << 6);
	      stringwrite(window, "KB)\r");

	      stringwrite(window, "\r[T] - //c text 40/80 column switch ");
	      stringwrite(window, memiic4080?"(80)\r":"(40)\r");

	      stringwrite(window, "\r[L] - Quickload emulator state");
	      stringwrite(window, "\r[S] - Quicksave emulator state");

	      stringwrite(window, "\r\r[R] - Reset computer");
	      stringwrite(window, "\r[C] - Clear memory and reset computer");
	      stringwrite(window, "\r[P] - Clear pattern = ");
	      switch (memorygetclearmode()) {
		case 1 :
		  stringwrite(window, "00 00 00...");
		  break;
		case 2 :
		  stringwrite(window, "00 FF 00 FF...");
		  break;
		case 3 :
		  stringwrite(window, "00 FF ... FF 00...");
		  break;
		case 4 :
		  stringwrite(window, "EA EA EA...");
		  break;
		case 5 :
		  stringwrite(window, "00 01 02...");
		  break;
		case 6 :
		  stringwrite(window, "$DEADBEEF (6502 Little Endian)");
		  break;
		case 7 :
		  stringwrite(window, "$DEADBEEF (High Endian)");
		  break;
	      } /* switch */
	      update = 0;
	    }
	    do {
	      imageupdate();
	      key = (unsigned char)channelin(keyboard);
	    }
	    while ((key == 0) && (!exitprogram));
	    switch (key) {
	      case '1' :
		channelout(window, 12);
		memoryloadrom(keyboard, window, "apple2m.rom");
		update = 1;
		break;
	      case '2' :
		channelout(window, 12);
		memoryloadrom(keyboard, window, "apple2o.rom");
		update = 1;
		break;
	      case '3' :
		channelout(window, 12);
		memoryloadrom(keyboard, window, "apple.rom");
		update = 1;
		break;
	      case '4' :
		channelout(window, 12);
		memoryloadrom(keyboard, window, "apple2eo.rom");
		update = 1;
		break;
	      case '5' :
		channelout(window, 12);
                memoryloadrom(keyboard, window, "apple2e.rom");
		update = 1;
		break;
              case '6' :
		channelout(window, 12);
		memoryloadrom(keyboard, window, "apple2co.rom");
		update = 1;
		break;
              case '7' :
		channelout(window, 12);
		memoryloadrom(keyboard, window, "apple2c.rom");
		update = 1;
		break;

	      case 't' :			/* 40/80 -uso. */
	      case 'T' :
		memiic4080 = !memiic4080;
		update=1;
		break;

	      case 'c' :
	      case 'C' :
		stringwrite(window, "\r\rClear memory and reset Apple...\rAre you sure? (y/n)");
		do {
		  imageupdate();
		  key = (unsigned char)channelin(keyboard);
		}
		while ((key == 0) && (!exitprogram));
		if ((key == 'y') || (key == 'Y') || (exitprogram)) {
		  memoryclear();
		  applereset();
		}
		key = 0;
		update = 1;
		break;

	      case 'l' :
	      case 'L' :
		applerestore("DAPPLE2.DAT");
		update = 1;
		break;
	      case 's' :
	      case 'S' :
		applestore("DAPPLE2.DAT");
		update = 1;
		break;

	      case 'm' :
	      case 'M' :
		memnolc = !memnolc;
		update = 1;
		break;
	      case 'p' :
	      case 'P' :
		update = memorygetclearmode();
		update++;
		if (update > 7) { update = 1; }
		memorysetclearmode(update);
		update = 1;
		break;
	      case 'r' :
	      case 'R' :
		stringwrite(window, "\r\rReset Apple...\rAre you sure? (y/n)");
		do {
		  imageupdate();
		  key = (unsigned char)channelin(keyboard);
		}
		while ((key == 0) && (!exitprogram));
		if ((key == 'y') || (key == 'Y') || (exitprogram)) {
		  applereset();
		}
		key = 0;
		update = 1;
		break;
	    } /* switch (key) */
	  }
	  while ((key != 27) && (key != 32) && (key != 13) && (!exitprogram));
	  channelclose(keyboard);
	  channelclose(window);
	  messageflag = 1;
	}
	screenrestore(screen);

      } /* drivemenu */
