/*
 * CommandLine.cs
 *
 * Supporting class for executable command lines.
 *
 * Copyright (c) 2003 Mike Murphy
 *
 */

using System;
using System.Collections;
using System.Globalization;
using System.Text;

namespace EMU7800 {

public struct Parameter {
	public string StrValue;

	public int IntValue;
	public bool IsInteger;
}

public class CommandLine {
	public string Verb;
	public Parameter[] Parms;

	public bool CheckParms(string chkstr) {
		if (chkstr.Length != Parms.Length) {
			return false;
		}
		for (int i=0; i < chkstr.Length; i++) {
			if (chkstr.Substring(i, 1) == "i") {
				if (!Parms[i].IsInteger) {
					return false;
				}
			}
		}
		return true;
	}

	public CommandLine(string commandLine) {
		string[] toks = commandLine.Split();

		Verb = toks[0];
		ArrayList al = new ArrayList();

		for (int i=1; i < toks.Length; i++) {
			string tok = toks[i];

			Parameter p = new Parameter();

			p.StrValue = tok;
			p.IsInteger = false;

			if (tok.Substring(0, 1) == "$") {
				try {					p.IntValue = Int32.Parse(						tok.Substring(1),						NumberStyles.HexNumber);					p.IsInteger = true;				} catch {}			} else if (tok.Length >= 2 && tok.Substring(0, 2) == "0x") {				try {					p.IntValue = Int32.Parse(						tok.Substring(2),						NumberStyles.HexNumber);					p.IsInteger = true;				} catch {}			} else {
				try {					p.IntValue = Int32.Parse(						tok,						NumberStyles.Number);					p.IsInteger = true;				} catch {}
			}

			al.Add(p);
		}

		Parms = new Parameter[al.Count];
		object[] objs = al.ToArray();
		for (int i=0; i < al.Count; i++) {
			Parms[i] = (Parameter)objs[i];
		}
	}
}
}
