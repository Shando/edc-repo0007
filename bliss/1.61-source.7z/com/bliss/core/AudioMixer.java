package com.bliss.core;

import com.bliss.core.devices.*;

public class AudioMixer extends Processor
{

    public AudioMixer(ProcessorBus pb) {
        this.processorBus = pb;
    }

    public void setAudioOutputDevice(AudioOutputDevice aod) {
        this.aod = aod;
    }

    public int getClockSpeed() {
        return aod.getSampleRate();
    }

    public void setHighQualityMixing(boolean b) {
        this.highQualityMixing = b;
    }

    public boolean isHighQualityMixing() {
        return highQualityMixing;
    }

    public void reset() {
        for (int i = 0; i < lineCount; i++)
            lines[i].reset();
    }

    public void save(SaveOutputStream sos) {}

    public void load(LoadInputStream lis) {}

    public int tick() {
        int totalSample = 0;

        //mix and flush the sample buffers
        for (int i = 0; i < lineCount; i++) {
            AudioOutputLine nextLine = lines[i];

            //calculate the sample for this line
            if (highQualityMixing) {
                nextLine.sampleBuffer += ((long)nextLine.currentSample) * 
                        (long)(processorBus.clock - nextLine.lastWriteClockMark);
                totalSample += (int)(nextLine.sampleBuffer / processorBus.clock);
            }
            else
                totalSample += nextLine.currentSample;

            //clear the sample buffer for this line
            nextLine.sampleBuffer = 0;
            nextLine.lastWriteClockMark = 0;
        }
        processorBus.clock = 0;

        totalSample /= lineCount;

        //apply the saturation clipping to correctly model the
        //cross-channel modulation that occurs on a real Intellivision
        totalSample <<= 1;
        if (totalSample > 0x6000)
            totalSample = 0x6000 + ((totalSample - 0x6000)/6);

        aod.playSample(totalSample);

        return 1;
    }

    public AudioOutputLine getAudioOutputLine() {
        return new AudioOutputLine();
    }

    private PlugIn            plugIn;
    private AudioOutputDevice aod;
    private AudioOutputLine[] lines = new AudioOutputLine[MAX_LINES];
    private int               lineCount;

    //these variables intentially given default access because access to
    //them from instances of the inner class are *much* faster this way
    ProcessorBus      processorBus;
    boolean           highQualityMixing = true;

    private final static int MAX_LINES= 10;

    public class AudioOutputLine
    {
        private void reset() {
            currentSample = 0;
            sampleBuffer = 0;
            lastWriteClockMark = 0;
        }

        public void acquire() {
            lines[lineCount] = this;
            lineCount++;
        }

        public void release() {
            for (int i = 0; i < lineCount; i++) {
                if (lines[i] == this) {
                    for (int j = i+1; j < lineCount-1; j++)
                        lines[j] = lines[j+1];
                    lineCount--;
                    return;
                }
            }
        }

        public void writeSample(int sample) {
            if (highQualityMixing) {
                sampleBuffer += ((long)currentSample) *
                        (long)(processorBus.clock-lastWriteClockMark);
                lastWriteClockMark = processorBus.clock;
            }
            currentSample = sample;
        }

        private AudioOutputLine() {}

        //these variables intentially given default access because access to
        //them from instances of the outer class are *much* faster this way
        int               currentSample;
        long              lastWriteClockMark;
        long              sampleBuffer;
    }

}
