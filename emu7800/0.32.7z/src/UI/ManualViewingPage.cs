/*
 * ManualViewPage.cs
 * 
 * A ControlPanelTabPage that views game manuals.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */

using System;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace EMU7800 {

public class ManualViewingPage : ControlPanelTabPage {
	private ControlPanelForm ControlPanelForm;

	public static string ManualDir {
		get {
			return Globals.RootDir + "/manuals";
		}
	}
	
	public override void ClearChanges() {
		if (ControlPanelForm.CurrGameSettings.Manual == null) {
			TxtManual = false;
			JpgManual = false;
			btnPrev.Visible = false;
			btnNext.Visible = false;
			txtBox.Visible = false;
			return;
		}
		if (CurrManual != ControlPanelForm.CurrGameSettings.Manual) {
			CurrManual = ControlPanelForm.CurrGameSettings.Manual;
			if (File.Exists(GetJpgPath(1)) && !Globals.FullScreenMode) {
				TxtManual = false;
				JpgManual = true;
				CurrPage = 1;
				btnPrev.Visible = true;
				btnNext.Visible = true;
				txtBox.Visible = false;
			} else if (File.Exists(GetTxtPath())) {
				TxtManual = true;
				JpgManual = false;
				btnPrev.Visible = false;
				btnNext.Visible = false;
				txtBox.Visible = true;
			}
		}

		if (JpgManual) {
			if (!LoadImage()) {
				btnPrev.Enabled = false;
				btnNext.Enabled = false;
			} else if (CurrPage == 1) {
				btnPrev.Enabled = false;
				btnNext.Enabled = true;
			} else {
				btnPrev.Enabled = true;
				btnNext.Enabled = true;
			}
		}
		if (TxtManual) {
			if (!LoadText()) {
				txtBox.Visible = false;
			}
		}
	}

	public override void ApplyChanges() {}

	private bool TxtManual, JpgManual;
	private string CurrManual;

	private TextBox txtBox;

	private Button btnPrev, btnNext;
	private Image CurrImage;
	private int CurrPage;

	public ManualViewingPage(ControlPanelForm controlPanelForm) {
		ControlPanelForm = controlPanelForm;
		Text = "Manual";

		btnPrev = new Button();
		btnPrev.Text = "Previous";
		btnPrev.Click += new EventHandler(OnPrevClick);
		btnPrev.Visible = false;

		btnNext = new Button();
		btnNext.Text = "Next";
		btnNext.Click += new EventHandler(OnNextClick);
		btnNext.Visible = false;

		txtBox = new TextBox();
		txtBox.Text = "";
		txtBox.Multiline = true;
		txtBox.ScrollBars = ScrollBars.Both;
		txtBox.ReadOnly = true;
		txtBox.AcceptsTab = false;
		txtBox.WordWrap = false;
		txtBox.BackColor = System.Drawing.SystemColors.ControlText;
		txtBox.ForeColor = Color.Orange;
		txtBox.Font = new Font("Lucida Sans Typewriter", 10F,
			FontStyle.Regular, GraphicsUnit.Point, ((System.Byte)(0)));
		txtBox.TabStop = false;
		txtBox.Visible = false;

		Controls.AddRange(new Control[] {btnPrev, btnNext, txtBox});

		Paint += new PaintEventHandler(OnPaint);
		Layout += new LayoutEventHandler(OnLayout);

		TxtManual = false;
		JpgManual = false;
	}
	
	private void OnPaint(Object sender, PaintEventArgs e)  {
		if (!JpgManual || CurrImage == null) {
			return;
		}

		int iw = CurrImage.Width;
		int ih = CurrImage.Height;
		int w, h;

		if (ih*ClientSize.Width/iw > (ClientSize.Height - 40)) {
			w = (ClientSize.Height - 40)*iw/ih;
			h = ClientSize.Height - 40;
		} else {
			w = ClientSize.Width;
			h = ClientSize.Width*ih/iw;
		}

		int x = (ClientSize.Width - w)/2;
		int y = (ClientSize.Height - 40 - h)/2 + 40;
		e.Graphics.DrawImage(CurrImage, x, y, w, h);
	}

	private bool LoadImage() {
		try {
			CurrImage = Image.FromFile(GetJpgPath(CurrPage));
			Invalidate();
		} catch {
			CurrImage = null;
		}
		return CurrImage != null;
	}

	private bool LoadText() {
		try {
			StreamReader r = new StreamReader(File.OpenRead(GetTxtPath()));
			txtBox.Text = r.ReadToEnd();
			r.Close();
		} catch {
			txtBox.Text = null;
		}
		return txtBox.Text != null;
	}

	private void OnPrevClick(Object sender, EventArgs e) {
		if (CurrPage > 1) {
			CurrPage--;
			LoadImage();
		}
		if (CurrPage == 1) {
			btnPrev.Enabled = false;
		}
		btnNext.Enabled = true;
	}

	private void OnNextClick(Object sender, EventArgs e) {
		if (File.Exists(GetJpgPath(CurrPage + 1))) {
			CurrPage++;
			LoadImage();
			btnPrev.Enabled = true;
		}
		if (!File.Exists(GetJpgPath(CurrPage + 1))) {
			btnNext.Enabled = false;
		}
	}

	private void OnLayout(Object sender, LayoutEventArgs e) {
		btnPrev.Location = new Point(10, 10);
		btnNext.Location = new Point(
			btnPrev.Location.X + btnPrev.Size.Width + 5,
			10);

		txtBox.Location = new Point(10, 10);
		txtBox.Size = new Size(Size.Width - 20, Size.Height - 20);
	}

	private string GetJpgPath(int pageno) {
		return String.Format("{0}/{1}.{2:00}.jpg", ManualDir, CurrManual, pageno);
	}

	private string GetTxtPath() {
		return String.Format("{0}/{1}.txt", ManualDir, CurrManual);
	}
}
}
