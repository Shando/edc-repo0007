package com.bliss.core;

import com.bliss.core.devices.*;

public class ECSKeyboard implements IODevice
{

    public void setInputDevice(InputDevice inputDevice) {
        this.inputDevice = inputDevice;
    }

    public void reset() {
        for (int i = 0; i < 8; i++)
            rowInputValues[i] = 0;
    }

    public void poll() {
        for (int i = 0; i < 6; i++) {
            rowInputValues[i] = 0;

            if (inputDevice.getControlValue(CONTROL_IDS[i]) ==
                    InputDevice.SIGNAL_ON)
                rowInputValues[i] |= 0x01;
            if (inputDevice.getControlValue(CONTROL_IDS[i+6]) ==
                    InputDevice.SIGNAL_ON)
                rowInputValues[i] |= 0x02;
            if (inputDevice.getControlValue(CONTROL_IDS[i+12]) ==
                    InputDevice.SIGNAL_ON)
                rowInputValues[i] |= 0x04;
            if (inputDevice.getControlValue(CONTROL_IDS[i+18]) ==
                    InputDevice.SIGNAL_ON)
                rowInputValues[i] |= 0x08;
            if (inputDevice.getControlValue(CONTROL_IDS[i+24]) ==
                    InputDevice.SIGNAL_ON)
                rowInputValues[i] |= 0x10;
            if (inputDevice.getControlValue(CONTROL_IDS[i+30]) ==
                    InputDevice.SIGNAL_ON)
                rowInputValues[i] |= 0x20;
            if (inputDevice.getControlValue(CONTROL_IDS[i+36]) ==
                    InputDevice.SIGNAL_ON)
                rowInputValues[i] |= 0x40;
            if (i > 0 && inputDevice.getControlValue(CONTROL_IDS[i+41]) ==
                    InputDevice.SIGNAL_ON)
                rowInputValues[i] |= 0x80;
        }
        rowInputValues[6] = (inputDevice.getControlValue(CONTROL_IDS[47]) ==
                InputDevice.SIGNAL_ON ? 0x80 : 0);
        
    }

    public int getInputValue() {
        int inputValue = 0;
        int rowMask = 1;
        for (int row = 0; row < 8; row++)  {
            if ((rowsToScan & rowMask) != 0) {
                rowMask = rowMask << 1;
                continue;
            }
            inputValue |= rowInputValues[row];

            rowMask = rowMask << 1;
        }

        return (0xFF ^ inputValue);
    }

    public void setOutputValue(int value) {
        rowsToScan = value;
    }

    public int getControlCount() {
        return CONTROL_IDS.length;
    }

    public int getControlID(int controlNum) {
        return CONTROL_IDS[orderedMapping[controlNum]];
    }

    public String getControlDescription(int controlNum) {
        return Intellivision.RESOURCES.getString(descriptionKeys[orderedMapping[controlNum]]);
    }

    private int rowsToScan;
    private InputDevice inputDevice;
    private int[] rowInputValues = new int[8];

    private final static int[] CONTROL_IDS = {
            InputDevice.KEYBOARD_LEFT,
            InputDevice.KEYBOARD_COMMA,
            InputDevice.KEYBOARD_N,
            InputDevice.KEYBOARD_V,
            InputDevice.KEYBOARD_X,
            InputDevice.KEYBOARD_SPACE,
            InputDevice.KEYBOARD_PERIOD,
            InputDevice.KEYBOARD_M,
            InputDevice.KEYBOARD_B,
            InputDevice.KEYBOARD_C,
            InputDevice.KEYBOARD_Z,
            InputDevice.KEYBOARD_DOWN,
            InputDevice.KEYBOARD_SEMICOLON,
            InputDevice.KEYBOARD_K,
            InputDevice.KEYBOARD_H,
            InputDevice.KEYBOARD_F,
            InputDevice.KEYBOARD_S,
            InputDevice.KEYBOARD_UP,
            InputDevice.KEYBOARD_P,
            InputDevice.KEYBOARD_I,
            InputDevice.KEYBOARD_Y,
            InputDevice.KEYBOARD_R,
            InputDevice.KEYBOARD_W,
            InputDevice.KEYBOARD_Q,
            InputDevice.KEYBOARD_ESCAPE,
            InputDevice.KEYBOARD_9,
            InputDevice.KEYBOARD_7,
            InputDevice.KEYBOARD_5,
            InputDevice.KEYBOARD_3,
            InputDevice.KEYBOARD_1,
            InputDevice.KEYBOARD_0,
            InputDevice.KEYBOARD_8,
            InputDevice.KEYBOARD_6,
            InputDevice.KEYBOARD_4,
            InputDevice.KEYBOARD_2,
            InputDevice.KEYBOARD_RIGHT,
            InputDevice.KEYBOARD_ENTER,
            InputDevice.KEYBOARD_O,
            InputDevice.KEYBOARD_U,
            InputDevice.KEYBOARD_T,
            InputDevice.KEYBOARD_E,
            InputDevice.KEYBOARD_CONTROL,
            InputDevice.KEYBOARD_L,
            InputDevice.KEYBOARD_J,
            InputDevice.KEYBOARD_G,
            InputDevice.KEYBOARD_D,
            InputDevice.KEYBOARD_A,
            InputDevice.KEYBOARD_SHIFT,
        };

    private final static int[] orderedMapping = {
            46,  8,  9, 45, 40, 15,
            44, 14, 19, 43, 13, 42,
             7,  2, 37, 18, 23, 21,
            16, 39, 38,  3, 22,  4,
            20, 10, 30, 29, 34, 28,
            33, 27, 32, 26, 31, 25,
            17, 11,  0, 35,  1,  6,
            12,  5, 36, 41, 47, 24  };


    private final static String[] descriptionKeys = {
            "InputECSLeft",
            "InputECSComma",
            "InputECSN",
            "InputECSV",
            "InputECSX",
            "InputECSSpace",
            "InputECSPeriod",
            "InputECSM",
            "InputECSB",
            "InputECSC",
            "InputECSZ",
            "InputECSDown",
            "InputECSSemiColon",
            "InputECSK",
            "InputECSH",
            "InputECSF",
            "InputECSS",
            "InputECSUp",
            "InputECSP",
            "InputECSI",
            "InputECSY",
            "InputECSR",
            "InputECSW",
            "InputECSQ",
            "InputECSEscape",
            "InputECS9",
            "InputECS7",
            "InputECS5",
            "InputECS3",
            "InputECS1",
            "InputECS0",
            "InputECS8",
            "InputECS6",        
            "InputECS4",
            "InputECS2",
            "InputECSRight",
            "InputECSEnter",    
            "InputECSO",
            "InputECSU",
            "InputECST",
            "InputECSE",
            "InputECSControl",
            "InputECSL",
            "InputECSJ",
            "InputECSG",
            "InputECSD",
            "InputECSA",
            "InputECSShift",
        };
}
