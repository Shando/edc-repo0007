using System;
using System.Collections.Generic;
using System.Text;
using EMU7800.Host;
using EMU7800.Host.DirectX;

namespace EMU7800.UI
{
    partial class ControlPanelForm
    {
        #region Fields

        readonly IDictionary<string, string>
            _HostInputToKey = new Dictionary<string, string>(),
            _KeyToHostInput = new Dictionary<string, string>();

        List<string> _UnboundKeys = new List<string>();
        readonly List<string> _BoundKeys = new List<string>();

        #endregion

        #region GlobalSetting Properties

        static string KeyBindingsGlobalSetting
        {
            get { return GlobalSettings.Instance.KeyBindings; }
            set { GlobalSettings.Instance.KeyBindings = value; }
        }

        #endregion

        #region Event Handlers

        private void comboboxKbHostInput_SelectedIndexChanged(object sender, EventArgs e)
        {
            var boundKey = _HostInputToKey[(string)comboboxKbHostInput.SelectedItem];
            if ((string)comboboxKbKey.SelectedItem != boundKey)
            {
                comboboxKbKey.SelectedItem = boundKey;
            }
        }

        private void comboboxKbKey_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (!comboboxKbHostInput.Enabled) return;
            var boundInput = _KeyToHostInput[(string)comboboxKbKey.SelectedItem];
            if ((string)comboboxKbHostInput.SelectedItem != boundInput)
            {
                comboboxKbHostInput.SelectedItem = boundInput;
            }
        }

        private void buttonKbBindAction_Click(object sender, EventArgs e)
        {
            if (comboboxKbHostInput.Enabled)
            {
                StartUpdate();
            }
            else
            {
                CommitUpdate();
                EndUpdate();
            }
        }

        private void buttonKbCancel_Click(object sender, EventArgs e)
        {
            EndUpdate();
        }

        #endregion

        #region UI Helpers

        void InitializeKeyBindingsComboBoxes()
        {
            InitializeIndexesFromKeyBindings(HostBase.CreateDefaultKeyBindings());
            LoadKeyBindingsFromGlobalSetting();

            comboboxKbKey.DataSource = _BoundKeys;

            var hostInputList = new List<string>(_HostInputToKey.Keys);
            hostInputList.Sort();
            comboboxKbHostInput.DataSource = hostInputList;
            comboboxKbHostInput.SelectedIndex = 0;

            EndUpdate();
        }

        void StartUpdate()
        {
            comboboxKbHostInput.Enabled = false;
            buttonKbCancel.Enabled = true;
            buttonKbBindAction.Text = "Bind";
            labelKbKey.Text = "Unbound DirectX Input Key";

            comboboxKbKey.DataSource = _UnboundKeys;
        }

        void CommitUpdate()
        {
            var hostInput = (string)comboboxKbHostInput.SelectedItem;
            var newKey = (string)comboboxKbKey.SelectedItem;

            UpdateKeyBinding(hostInput, newKey);
            SaveKeyBindingsToGlobalSetting();
        }

        void EndUpdate()
        {
            comboboxKbHostInput.Enabled = true;
            buttonKbCancel.Enabled = false;
            buttonKbBindAction.Text = "Unbind";
            labelKbKey.Text = "Bound DirectX Input Key";

            var selectedInput = (string)comboboxKbHostInput.SelectedItem;
            comboboxKbKey.DataSource = _BoundKeys;
            comboboxKbHostInput.SelectedItem = selectedInput;
        }

        #endregion

        #region Helpers

        private void InitializeIndexesFromKeyBindings(IEnumerable<KeyValuePair<Key, HostInput>> keyBindings)
        {
            _UnboundKeys = new List<string>(Enum.GetNames(typeof(Key)));
            foreach (var hostInput in Enum.GetNames(typeof(HostInput)))
            {
                string key = null;
                foreach (var kvPair in keyBindings)
                {
                    if (hostInput != kvPair.Value.ToString()) continue;
                    key = kvPair.Key.ToString();
                    break;
                }
                if (key == null) continue;

                _HostInputToKey.Add(hostInput, key);
                _KeyToHostInput.Add(key, hostInput);
                _BoundKeys.Add(key);
                _UnboundKeys.Remove(key);
            }
            _BoundKeys.Sort();
            _UnboundKeys.Sort();
        }

        void LoadKeyBindingsFromGlobalSetting()
        {
            foreach (var binding in KeyBindingsGlobalSetting.Split(';'))
            {
                var keyHostInput = binding.Split(',');
                if (!keyHostInput.Length.Equals(2) || keyHostInput[0] == null || keyHostInput[1] == null) continue;
                UpdateKeyBinding(keyHostInput[1], keyHostInput[0]);
            }
        }

        void SaveKeyBindingsToGlobalSetting()
        {
            var s = new StringBuilder();
            foreach (var keyVal in _KeyToHostInput)
            {
                if (s.Length > 0) s.Append(";");
                s.AppendFormat("{0},{1}", keyVal.Key, keyVal.Value);
            }
            KeyBindingsGlobalSetting = s.ToString();
        }

        void UpdateKeyBinding(string hostInput, string newKey)
        {
            if (hostInput == null || newKey == null) return;
            try { Enum.Parse(typeof (HostInput), hostInput); } catch (ArgumentException) { return; }
            try { Enum.Parse(typeof(Key), newKey); } catch (ArgumentException) { return; }

            var priorKey = _HostInputToKey[hostInput];

            if (priorKey == newKey) return;

            _HostInputToKey[hostInput] = newKey;
            _KeyToHostInput.Remove(priorKey);
            _KeyToHostInput.Add(newKey, hostInput);
            _BoundKeys.Remove(priorKey);
            _BoundKeys.Add(newKey);
            _BoundKeys.Sort();
            _UnboundKeys.Add(priorKey);
            _UnboundKeys.Remove(newKey);
            _UnboundKeys.Sort();
        }

        #endregion
    }
}