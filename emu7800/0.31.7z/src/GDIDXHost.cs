/*
 * GDIDXHost
 *
 * A GDI/DirectX-based Host.
 *
 * Copyright (c) 2003 Mike Murphy
 *
 */

using System;

using Microsoft.DirectX;
using Microsoft.DirectX.DirectSound;

namespace EMU7800 {

public class GDIDXHost : GDIHost {
	protected Microsoft.DirectX.DirectSound.SecondaryBuffer SoundBuffer;
	protected Microsoft.DirectX.DirectSound.Device SoundDevice;
	
	protected int SoundBufferLength, SoundBufferWpos;

	protected override void InitSound() {
		Log.Msg("Initializing DirectX DirectSound...");

		SoundBufferLength = 10*TIASound.SAMPLE_RATE/60;
		SoundBufferWpos = 0;

		SoundDevice = new Microsoft.DirectX.DirectSound.Device();
		SoundDevice.SetCooperativeLevel(this, CooperativeLevel.Priority);

		Microsoft.DirectX.DirectSound.WaveFormat wf = new WaveFormat();
		wf.FormatTag = WaveFormatTag.Pcm;
		wf.Channels = 1;
		wf.SamplesPerSecond = TIASound.SAMPLE_RATE;
		wf.AverageBytesPerSecond = TIASound.SAMPLE_RATE;
		wf.BlockAlign = 1;
		wf.BitsPerSample = 8;

		Microsoft.DirectX.DirectSound.BufferDescription desc = new BufferDescription(wf);
		desc.ControlVolume = true;
		desc.BufferBytes = SoundBufferLength;
		desc.CanGetCurrentPosition = true;
		SoundBuffer = new SecondaryBuffer(desc, SoundDevice);

		Log.Msg("done\n");
	}

	protected override void ResetSound() {
		StopSound();

		SoundBuffer.SetCurrentPosition(0);
		SoundBufferWpos = 0;
		SoundBuffer.Write(0, new byte[SoundBufferLength], LockFlag.None);
	}

	protected override void StartSound() {
		SoundBuffer.Play(0, BufferPlayFlags.Looping);
	}

	protected override void StopSound() {
		SoundBuffer.Stop();
	}

	public override void UpdateSound(byte[] buf) {
		SoundBuffer.Write(SoundBufferWpos, buf, LockFlag.None);
		SoundBufferWpos += buf.Length;
		if (SoundBufferWpos >= SoundBufferLength) {
			SoundBufferWpos -= SoundBufferLength;
		}
	}

}
}