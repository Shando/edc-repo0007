package com.blissj.app;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.bliss.core.*;
import com.bliss.core.devices.InputDevice;
import com.bliss.core.devices.InputSignal;

public class BlissConfigureInputDialog extends JDialog
{

    public BlissConfigureInputDialog(Frame parent) {
        super(parent);
        initUI();
        initListeners();
    }

    public void configureInput(String title, String[] configKey,
            InputDevice inputDevice, IODevice ioDevice)
    {
        setTitle(title);
        this.configKey = configKey;
        this.inputDevice = inputDevice;
        this.ioDevice = ioDevice;
        setVisible(true);
    }

    private void initUI() {
        setModal(true);
        JPanel contentPane = new JPanel();
        contentPane.setLayout(new GridBagLayout());
        contentPane.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        setContentPane(contentPane);

        inputTableModel = new InputTableModel();
        inputTable = new JTable(inputTableModel);
        inputTable.setDefaultRenderer(Object.class,
                new BlissTableCellRenderer());
        inputTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        inputScrollPane = new JScrollPane(inputTable);
        inputScrollPane.setPreferredSize(new Dimension(100, 100));
        inputScrollPane.getViewport().setBackground(inputTable.getBackground());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.ipadx = 300;
        gbc.ipady = 200;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(0, 0, 8, 0);
        contentPane.add(inputScrollPane, gbc);

        upperButtonPanel = new JPanel();
        upperButtonPanel.setLayout(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 8, 0);
        contentPane.add(upperButtonPanel, gbc);

        clearButton = new JButton(Bliss.RESOURCES.getString("ClearButton"));
        clearButton.setEnabled(false);
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(0, 0, 0, 8);
        upperButtonPanel.add(clearButton, gbc);

        configureButton = new JButton(Bliss.RESOURCES.getString(
                "ConfigureButton") + "...");
        configureButton.setEnabled(false);
        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        upperButtonPanel.add(configureButton, gbc);

        JSeparator separator = new JSeparator();
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 8, 0);
        contentPane.add(separator, gbc);

        buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        contentPane.add(buttonPanel, gbc);

        okButton = new JButton(Bliss.RESOURCES.getString("OKButton"));
        gbc = new GridBagConstraints();
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(0, 0, 0, 8);
        buttonPanel.add(okButton, gbc);

        cancelButton = new JButton(Bliss.RESOURCES.getString("CancelButton"));
        gbc = new GridBagConstraints();
        buttonPanel.add(cancelButton, gbc);

        //make the OK button and Cancel buttons the same width
        Dimension d1 = okButton.getPreferredSize();
        Dimension d2 = cancelButton.getPreferredSize();
        int width = Math.max(d1.width, d2.width);
        okButton.setPreferredSize(new Dimension(width, d1.height));
        cancelButton.setPreferredSize(new Dimension(width, d2.height));

        pack();
    }

    private void initListeners() {
        inputTable.addMouseListener(new MouseAdapter() {
                public void mouseClicked(MouseEvent me) {
                    if (me.getClickCount() == 2 && configureButton.isEnabled())
                    {
                        configureButton.doClick();
                    }
                }
            });
        inputTable.getSelectionModel().addListSelectionListener(
            new ListSelectionListener() {
                public void valueChanged(ListSelectionEvent lse) {
                    if (lse.getValueIsAdjusting())
                        return;

                    boolean enabled = !inputTable.getSelectionModel().
                            isSelectionEmpty();
                    configureButton.setEnabled(enabled);
                    clearButton.setEnabled(enabled);
                }
            });
        clearButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    int selection = inputTable.getSelectionModel().
                            getLeadSelectionIndex();
                    inputTableModel.setControlInputSignal(
                            inputTableModel.getInputID(selection), null);
                }
            });
        configureButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    int selection = inputTable.getSelectionModel().
                            getLeadSelectionIndex();
                    configureInput(ioDevice,
                            inputTableModel.getInputID(selection));
                }
            });
        okButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    commit();
                    dispose();
                }
            });
        cancelButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    dispose();
                }
            });
        addComponentListener(new ComponentAdapter() {
                public void componentShown(ComponentEvent ce) {
                    inputTableModel.setIODevice(inputDevice, ioDevice);
                }
            });
    }

    private void configureInput(IODevice ioDevice, int inputID) {
        if (pollInputDialog == null) {
            pollInputDialog = new BlissPollInputDialog((Frame)getOwner(),
                    inputDevice);
            BlissUtilities.centerWindowOverParent(pollInputDialog);
        }
        InputSignal signal = pollInputDialog.pollForInputSignal(
                ioDevice.getControlDescription(inputID));
        if (signal != null)
            inputTableModel.setControlInputSignal(inputID, signal);
    }

    private void commit() {
        //set the new input signals into the i/o device
        inputTableModel.commitToDevice();

        //write the new configuration in the registry
        int end = ioDevice.getControlCount();
        for (int i = 0; i < end; i++) {
            InputSignal nextSignal = inputDevice.getInputSignal(
                    ioDevice.getControlID(i));
            Bliss.REGISTRY.setData(configKey, Integer.toString(i),
                    (nextSignal == null ? "" : nextSignal.getConfigString()));
        }
    }

    private InputDevice inputDevice;
    private IODevice ioDevice;
    private String[] configKey;

    private BlissPollInputDialog pollInputDialog;

    //user interface components
    private JTabbedPane     tabbedPane;
    private InputTableModel inputTableModel;
    private JTable          inputTable;
    private JScrollPane     inputScrollPane;
    private JPanel          upperButtonPanel;
    private JButton         clearButton;
    private JButton         configureButton;
    private JPanel          buttonPanel;
    private JButton         okButton;
    private JButton         cancelButton;

}
