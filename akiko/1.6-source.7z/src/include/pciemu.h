 /*
  * UAE - The Un*x Amiga Emulator
  *
  * PCI library emulation prototypes
  */

extern void pcilib_install(void);

