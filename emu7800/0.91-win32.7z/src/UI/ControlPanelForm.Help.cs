﻿using System.Windows.Forms;

namespace EMU7800.UI
{
    partial class ControlPanelForm
    {
        #region Event Handlers

        void linklabelReadMe_Clicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            webbrowserHelp.Navigate(ReadMeUri);
        }

        void linklabelGameHelp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            linklabelGameHelp.Enabled = false;
            webbrowserHelp.Navigate(CurrGameSettings.HelpUri);
        }

        void webbrowserHelp_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            linklabelGameHelp.Enabled = true;
        }

        #endregion
    }
}
