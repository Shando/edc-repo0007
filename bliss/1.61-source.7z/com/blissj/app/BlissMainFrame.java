package com.blissj.app;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.zip.*;
import javax.swing.*;
import javax.swing.table.*;
import com.bliss.core.*;
import com.bliss.core.cartridge.*;
import com.bliss.core.devices.*;
import com.blissj.app.actions.*;
import com.blissj.app.util.*;
import com.blissj.plugin.*;

public class BlissMainFrame extends JFrame
{

    public BlissMainFrame() {
        initIntellivision();
        initROMs();
        initUI();
        initListeners();
        restoreUIState();
        restoreInputDevices();
        restoreAudioVideoOptions();
        scanCartridgeDirectory();
        scanThread.waitForIdle();
    }

    /**
     * Create all of the user interface components that make up the
     * Bliss main window.
     */
    private void initUI() {
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setTitle(Bliss.RESOURCES.getString("AppName"));
        setIconImage(getToolkit().createImage(getClass().getClassLoader().
                getResource("com/blissj/app/images/Bliss.gif")));

        //init the components in the main area of the window
        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());
        
        cartTableModel = new CartridgeTableModel();
        cartTable = new JTable(cartTableModel);
        cartTable.setAutoResizeMode(JTable.AUTO_RESIZE_LAST_COLUMN);
        cartTable.setIntercellSpacing(new Dimension(0, 0));
        cartTable.setShowGrid(false);
        cartTable.setRowHeight(cartTable.getRowHeight()+2);
        cartTable.setDefaultRenderer(Object.class, new BlissTableCellRenderer());
        TableColumn tableColumn = cartTable.getColumnModel().getColumn(0);
        tableColumn.setCellRenderer(new IconTableCellRenderer());
        tableColumn.setWidth(18);
        tableColumn.setMinWidth(18);
        tableColumn.setMaxWidth(18);
        tableColumn.setResizable(false);
        cartTable.getSelectionModel().setSelectionMode(ListSelectionModel.
                SINGLE_SELECTION);
        cartScrollPane = new JScrollPane(cartTable);
        cartScrollPane.setPreferredSize(new Dimension(750, 550));
        cartScrollPane.getViewport().setBackground(Color.white);
        contentPane.add(cartScrollPane, BorderLayout.CENTER);
        pack();

        //init the menu
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        fileMenu = new JMenu(Bliss.RESOURCES.getString("FileMenu"));
        menuBar.add(fileMenu);

        playMenuItem = new JMenuItem(new PlayCartridgeAction(this,
                cartTable));
        fileMenu.add(playMenuItem);

        playIntelCartMenuItem = new JMenuItem(new LoadIntellicartAction(this));
        fileMenu.add(playIntelCartMenuItem);

        fileMenu.addSeparator();

        propertiesMenuItem = new JMenuItem(new PropertiesAction(this,
                cartTable));
        fileMenu.add(propertiesMenuItem);

        fileMenu.addSeparator();

        exitMenuItem = new JMenuItem(new ExitBlissAction(this));
        fileMenu.add(exitMenuItem);

        viewMenu = new JMenu(Bliss.RESOURCES.getString("ViewMenu"));
        menuBar.add(viewMenu);

        viewAllMenuItem = new JRadioButtonMenuItem(
                new ViewAllAction(cartTable));
        viewAllMenuItem.setSelected(true);
        viewMenu.add(viewAllMenuItem);

        viewAvailableMenuItem = new JRadioButtonMenuItem(
                new ViewAvailableAction(cartTable));
        viewMenu.add(viewAvailableMenuItem);

        viewMenu.addSeparator();

        refreshAction = new RefreshAction(this);
        refreshMenuItem = new JMenuItem(refreshAction);
        viewMenu.add(refreshMenuItem);

        viewMenu.addSeparator();

        optionsMenuItem = new JMenuItem(new OptionsAction(this));
        viewMenu.add(optionsMenuItem);

        ButtonGroup bg = new ButtonGroup();
        bg.add(viewAllMenuItem);
        bg.add(viewAvailableMenuItem);

        helpMenu = new JMenu(Bliss.RESOURCES.getString("HelpMenu"));
        menuBar.add(helpMenu);

        aboutMenuItem = new JMenuItem(new AboutAction(this));
        helpMenu.add(aboutMenuItem);

        //init the status bar
        statusPanel = new JPanel();
        statusPanel.setLayout(new GridBagLayout());

        statusLabel = new JLabel(" ");
        statusLabel.setBorder(ThinBorder.createBorder(ThinBorder.LOWERED));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(3, 2, 2, 2);
        statusPanel.add(statusLabel, gbc);

        contentPane.add(statusPanel, BorderLayout.SOUTH);

        //create the dialogs
        propertiesDialog = new BlissPropertiesDialog(this);

        //create the directory scanning thread
        scanThread = new ScanCartridgeDirectoryThread();
    }

    /**
     * Searches the default file locations for the Exec ROM, GROM and ECS ROM.
     */
    private void initROMs() {
        //try to load the exec rom from the local files
        try {
            File localExecFile = new File("exec.bin");
            if (localExecFile.exists() &&
                    getCrc(localExecFile) == BlissConfig.CRC_EXECUTIVE_ROM)
            {
                BufferedInputStream bis = new BufferedInputStream(
                        new FileInputStream(localExecFile), 4096);
                extractExecutiveROM(bis);
                bis.close();
            }
        }
        catch (IOException ioe) {
            //oh, well.  user won't be able to play any cartridges unless
            //they have an exec image in their cartridge directory
        }

        //try to load the grom from the local files
        try {
            File localGromFile = new File("grom.bin");
            if (localGromFile.exists())
            if (localGromFile.exists() &&
                    getCrc(localGromFile) == BlissConfig.CRC_GROM)
            {
                BufferedInputStream bis = new BufferedInputStream(
                        new FileInputStream(localGromFile), 4096);
                extractGROM(bis);
                bis.close();
            }
        }
        catch (IOException ioe) {
            //oh, well.  user won't be able to play any cartridges unless
            //they have an exec image in their cartridge directory
        }

        //try to load the ecs rom from the local files
        try {
            File localEcsFile = new File("ecs.bin");
            if (localEcsFile.exists() &&
                    getCrc(localEcsFile) == BlissConfig.CRC_ECS_ROM)
            {
                BufferedInputStream bis = new BufferedInputStream(
                        new FileInputStream(localEcsFile), 4096);
                extractECSROM(bis);
                bis.close();
            }
        }
        catch (IOException ioe) {
            //oh, well.  user won't be able to play any ECS cartridges unless
            //they have an ECS image in their cartridge directory
        }

        //try to load the Intellivoice rom from the local files
        try {
            File localIvoiceFile = new File("ivoice.bin");
            if (localIvoiceFile.exists() &&
                    getCrc(localIvoiceFile) == BlissConfig.CRC_IVOICE_ROM)
            {
                BufferedInputStream bis = new BufferedInputStream(
                        new FileInputStream(localIvoiceFile), 4096);
                extractIvoiceROM(bis);
                bis.close();
            }
        }
        catch (IOException ioe) {
            //oh, well.  user won't be able to play any cartridges unless
            //they have an exec image in their cartridge directory
        }
    }

    /**
     * Adds listeners to the user interface components on the main window
     * that need handling.
     */
    private void initListeners() { 
        addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent we) {
                    exit();
                }
            });
        cartTable.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent me) {
                    if (me.getClickCount() == 2)
                        playCartridge();
                }
            });
    }

    /**
     * Creates the Intellivision emulator.
     */
    private void initIntellivision() {
        //create the intellivision
        inty = new Intellivision();
        PlugIn plugIn = new com.blissj.plugin.AppPlugIn();
        String plugInClassName = System.getProperty("PlugInClass");
        if (plugInClassName != null && !plugInClassName.equals("")) {
            try {
                Class clazz = Class.forName(plugInClassName);
                plugIn = (PlugIn)clazz.newInstance();
            }
            catch (Exception e) {
                //fall back to the default plug-in
            }
        }
        inty.setPlugIn(plugIn);
        inty.addIntellivisionListener(new IntellivisionAdapter() {
                public void errorOccurred(Intellivision inty,
                        String errorMessage)
                {
                    inty.turnOff();
                    inty.removeCartridge();
                    setVisible(true);
                    JOptionPane.showMessageDialog(BlissMainFrame.this,
                            errorMessage,
                            Bliss.RESOURCES.getString("ErrorDialogTitle"),
                            JOptionPane.ERROR_MESSAGE);
                }
                public void turnedOff(Intellivision inty) {
                    inty.removeCartridge();
                    setVisible(true);
                }
            });

        player1 = inty.getHandControllerOne();
        player2 = inty.getHandControllerTwo();
        keyboard = inty.getECSKeyboard();
        director = inty.getDirector();
    }

    public void exit() {
        dispose();
        saveUIState();
        saveAudioVideoOptions();
        try {
            Bliss.REGISTRY.saveRegistry();
        }
        catch (IOException ioe) {
            JOptionPane.showMessageDialog(this,
                    Bliss.RESOURCES.getString("ErrorCannotSaveRegistry"),
                    Bliss.RESOURCES.getString("ErrorDialogTitle"),
                    JOptionPane.ERROR_MESSAGE);
        }
        System.exit(0);
    }

    public void playCartridge() {
        int selection = cartTable.getSelectionModel().
                getLeadSelectionIndex();
        CartridgeFile cartFile = cartTableModel.
                getCartridgeFile(selection);
        if (cartFile == null)
            return;

        try {
            Cartridge cart = Cartridge.loadCartridge(cartFile);
            playCartridge(cart);
        }
        catch (IOException ioe) {
            JOptionPane.showMessageDialog(this,
                    Bliss.RESOURCES.getString("ErrorLoadingROM"),
                    Bliss.RESOURCES.getString("ErrorDialogTitle"),
                    JOptionPane.ERROR_MESSAGE);
        }
        
    }

    public void playCartridge(Cartridge cart) {
        if (execImage == null) {
            JOptionPane.showMessageDialog(this,
                    Bliss.RESOURCES.getString("ErrorNoExecutiveROM"),
                    Bliss.RESOURCES.getString("ErrorDialogTitle"),
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (gromImage == null) {
            JOptionPane.showMessageDialog(this,
                    Bliss.RESOURCES.getString("ErrorNoGROM"),
                    Bliss.RESOURCES.getString("ErrorDialogTitle"),
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (cart.getType().requiresECS() && ecsImage == null) {
            JOptionPane.showMessageDialog(this,
                    Bliss.RESOURCES.getString("ErrorNoECS"),
                    Bliss.RESOURCES.getString("ErrorDialogTitle"),
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        setVisible(false);

        inty.insertCartridge(cart);
        inty.turnOn();
    }

    public void scanCartridgeDirectory() {
        statusLabel.setText(Bliss.RESOURCES.getString(
                "ScanningCartridgeDirectoryMessage"));
        cartTable.clearSelection();
        cartTableModel.setCartridgeFileList(new CartridgeFile[0]);
        scanThread.startScanning();
    }

    public void displayOptions() {
        if (optionsDialog == null)
            optionsDialog = new BlissOptionsDialog(this, inty);

        String oldCartDir = Bliss.REGISTRY.getDataAsString(
                BlissConfig.KEY_GENERAL,
                BlissConfig.VALUE_CARTRIDGE_DIRECTORY,
                BlissConfig.DEFAULT_CARTRIDGE_DIRECTORY);
        BlissUtilities.centerWindowOverParent(optionsDialog);
        optionsDialog.setVisible(true);

        String newCartDir = Bliss.REGISTRY.getDataAsString(
                BlissConfig.KEY_GENERAL,
                BlissConfig.VALUE_CARTRIDGE_DIRECTORY,
                BlissConfig.DEFAULT_CARTRIDGE_DIRECTORY);
        if (!newCartDir.equals(oldCartDir))
            scanCartridgeDirectory();
    }

    public void displayAbout() {
        if (aboutDialog == null) {
            aboutDialog = new BlissAboutDialog(this);
        }
        BlissUtilities.centerWindowOverParent(aboutDialog);
        aboutDialog.setVisible(true);
    }

    public void displayProperties() {
        int selection = cartTable.getSelectionModel().getLeadSelectionIndex();
        CartridgeType cartType = cartTableModel.getCartridgeType(selection);
        propertiesDialog.setCartridgeType(cartType);
        BlissUtilities.centerWindowOverParent(propertiesDialog);
        propertiesDialog.setVisible(true);
    }

    private boolean isNeededSystemROM(long crc) {
        return (crc == BlissConfig.CRC_EXECUTIVE_ROM && execImage == null) ||
                (crc == BlissConfig.CRC_GROM && gromImage == null) ||
                (crc == BlissConfig.CRC_ECS_ROM && ecsImage == null) ||
                (crc == BlissConfig.CRC_IVOICE_ROM && ivoiceImage == null);
    }

    private void extractSystemROM(long crc, InputStream is)
            throws IOException
    {
        if (crc == BlissConfig.CRC_EXECUTIVE_ROM)
            extractExecutiveROM(is);
        else if (crc == BlissConfig.CRC_GROM)
            extractGROM(is);
        else if (crc == BlissConfig.CRC_ECS_ROM)
            extractECSROM(is);
        else if (crc == BlissConfig.CRC_IVOICE_ROM)
            extractIvoiceROM(is);
    }

    private void extractExecutiveROM(InputStream is)
            throws IOException
    {
        if (execImage != null)
            return;

        try {
            execImage = ROM.loadROMImage(is, BlissConfig.SIZE_EXECUTIVE_ROM,
                    true);
            inty.setExecImage(execImage);
        }
        catch (IOException ioe) {
            //ignore trying to load it then.
        }
    }

    private void extractGROM(InputStream is)
            throws IOException
    {
        if (gromImage != null)
            return;

        try {
            gromImage = ROM.loadROMImage(is, BlissConfig.SIZE_GROM, false);
            inty.setGROMImage(gromImage);
        }
        catch (IOException ioe) {
            //ignore trying to load it then.
        }
    }

    private void extractECSROM(InputStream is)
            throws IOException
    {
        if (ecsImage != null)
            return;

        try {
            ecsImage = ROM.loadROMImage(is, BlissConfig.SIZE_ECS_ROM, true);
            if (inty != null)
                inty.enableECSSupport(ecsImage);
        }
        catch (IOException ioe) {
            //ignore trying to load it then.
        }
    }

    private void extractIvoiceROM(InputStream is)
            throws IOException
    {
        if (ivoiceImage != null)
            return;

        try {
            ivoiceImage = ROM.loadROMImage(is, BlissConfig.SIZE_IVOICE_ROM,
                    false);
            if (inty != null)
                inty.enableIntellivoiceSupport(ivoiceImage);
        }
        catch (IOException ioe) {
            //ignore trying to load it then.
        }
    }

    private long getCrc(File file) {
        try {
            BufferedInputStream bis = new BufferedInputStream(
                    new FileInputStream(file), 4096);
            byte[] buffer = new byte[4096];
            CRC32 crc = new CRC32();
            int read;
            while ((read = bis.read(buffer, 0, buffer.length)) != -1)
                crc.update(buffer, 0, read);
            return crc.getValue();
        }
        catch (IOException ioe) {
            return 0;
        }
    }

    private void saveUIState() {
        Bliss.REGISTRY.setData(BlissConfig.KEY_UI, "viewallgames",
                (viewAllMenuItem.isSelected() ? "true" : "false"));

        Rectangle r = getBounds();
        Bliss.REGISTRY.setData(BlissConfig.KEY_UI, "x", r.x);
        Bliss.REGISTRY.setData(BlissConfig.KEY_UI, "y", r.y);
        Bliss.REGISTRY.setData(BlissConfig.KEY_UI, "width", r.width);
        Bliss.REGISTRY.setData(BlissConfig.KEY_UI, "height", r.height);

        for (int i = 0; i < cartTableModel.getColumnCount(); i++) {
            Bliss.REGISTRY.setData(BlissConfig.KEY_UI, "column" + i,
                    cartTable.getColumnModel().getColumn(i).getWidth());
        }
    }

    /**
     * Restores the previous window location and size.
     */
    private void restoreUIState() {
        String viewAll = Bliss.REGISTRY.getDataAsString(BlissConfig.KEY_UI,
                "viewallgames", "true");
        if (!viewAll.equals("true"))
            viewAvailableMenuItem.doClick();

        Dimension screenSize = getToolkit().getScreenSize();
        Dimension frameSize = getSize();
        Rectangle r = new Rectangle();
        r.x = Bliss.REGISTRY.getDataAsInt(BlissConfig.KEY_UI, "x",
                (screenSize.width - frameSize.width)/2);
        r.y = Bliss.REGISTRY.getDataAsInt(BlissConfig.KEY_UI, "y",
                (screenSize.height - frameSize.height)/2);
        r.width = Bliss.REGISTRY.getDataAsInt(BlissConfig.KEY_UI, "width",
                750);
        r.height = Bliss.REGISTRY.getDataAsInt(BlissConfig.KEY_UI, "height",
                550);
        setBounds(r);

        int defaultColumnWidth = cartTable.getColumnModel().getColumn(0).
                getWidth();
        for (int i = 0; i < cartTableModel.getColumnCount(); i++) {
            cartTable.getColumnModel().getColumn(i).setPreferredWidth(
                    Bliss.REGISTRY.getDataAsInt(BlissConfig.KEY_UI,
                        "column" + i, defaultColumnWidth));
        }
    }

    private void saveAudioVideoOptions() {
        String[] key = new String[BlissConfig.KEY.length+2];
        System.arraycopy(BlissConfig.KEY, 0, key, 0, BlissConfig.KEY.length);
        key[key.length-2] = inty.getPlugIn().getPlugInName();

        key[key.length-1] = "video";
        Option[] options = inty.getVideoOptions();
        for (int i = 0; i < options.length; i++)  {
            Bliss.REGISTRY.setData(key,
                    options[i].getDescription(),
                    options[i].getDescription(options[i].getValue()));
        }

        key[key.length-1] = "sound";
        options = inty.getAudioOptions();
        for (int i = 0; i < options.length; i++)  {
            Bliss.REGISTRY.setData(key,
                    options[i].getDescription(),
                    options[i].getDescription(options[i].getValue()));
        }
    }

    /**
     * Loads the audio and video options.
     */
    private void restoreAudioVideoOptions() {
        String[] key = new String[BlissConfig.KEY.length+2];
        System.arraycopy(BlissConfig.KEY, 0, key, 0, BlissConfig.KEY.length);
        key[key.length-2] = inty.getPlugIn().getPlugInName();

        key[key.length-1] = "video";
        Option[] options = inty.getVideoOptions();
        for (int i = 0; i < options.length; i++)  {
            String value = Bliss.REGISTRY.getDataAsString(key,
                    options[i].getDescription(), "");
            if (value.length() == 0)
                continue;

            if (options[i] instanceof ChoiceOption) {
                ChoiceOption cc = (ChoiceOption)options[i];
                Object[] choices = cc.getChoices();
                for (int j = 0; j < choices.length; j++) {
                    if (cc.getDescription(choices[j]).equals(value)) {
                        cc.setValue(choices[j]);
                        break;
                    }
                }
            }
            else if (options[i] instanceof BooleanOption) {
                ((BooleanOption)options[i]).setEnabled(value.equals(
                        "true"));
            }
        }

        key[key.length-1] = "sound";
        options = inty.getAudioOptions();
        for (int i = 0; i < options.length; i++)  {
            String value = Bliss.REGISTRY.getDataAsString(key,
                    options[i].getDescription(), "");
            if (value.length() == 0)
                continue;

            if (options[i] instanceof ChoiceOption) {
                ChoiceOption cc = (ChoiceOption)options[i];
                Object[] choices = cc.getChoices();
                for (int j = 0; j < choices.length; j++) {
                    if (cc.getDescription(choices[j]).equals(value)) {
                        cc.setValue(choices[j]);
                        break;
                    }
                }
            }
            else if (options[i] instanceof BooleanOption) {
                ((BooleanOption)options[i]).setEnabled(value.equals(
                        "true"));
            }
        }
    }

    /**
     * Loads the input configuration.
     */
    private void restoreInputDevices() {
        //load the default input signals
        InputDevice inputDevice = inty.getPlugIn().getInputDevice();

        //now load the configured input signals over the defaults
        String[] key = new String[BlissConfig.KEY_INPUT_LEFT_CONTROLLER.
                length+1];
        System.arraycopy(BlissConfig.KEY_INPUT_LEFT_CONTROLLER, 0, key, 0,
                key.length-1);
        key[key.length-1] = inty.getPlugIn().getPlugInName();

        int end = player1.getControlCount();
        for (int i = 0; i < end; i++) {
            String nextData = Bliss.REGISTRY.getDataAsString(
                    key, Integer.toString(i), null);
            if (nextData != null)
                inputDevice.setInputSignal(player1.getControlID(i),
                        (nextData.length() == 0 ? null
                            : inputDevice.getInputSignal(nextData)));
        }

        System.arraycopy(BlissConfig.KEY_INPUT_RIGHT_CONTROLLER, 0, key, 0,
                key.length-1);
        end = player2.getControlCount();
        for (int i = 0; i < end; i++) {
            String nextData = Bliss.REGISTRY.getDataAsString(
                    key, Integer.toString(i), null);
            if (nextData != null)
                inputDevice.setInputSignal(player2.getControlID(i),
                        (nextData.length() == 0 ? null
                            : inputDevice.getInputSignal(nextData)));
        }

        System.arraycopy(BlissConfig.KEY_INPUT_ECS_KEYBOARD, 0, key, 0,
                key.length-1);
        end = keyboard.getControlCount();
        for (int i = 0; i < end; i++) {
            String nextData = Bliss.REGISTRY.getDataAsString(
                    key, Integer.toString(i), null);
            if (nextData != null)
                inputDevice.setInputSignal(keyboard.getControlID(i),
                        (nextData.length() == 0 ? null
                            : inputDevice.getInputSignal(nextData)));
        }
    }

    private Action              refreshAction;
    private ScanCartridgeDirectoryThread scanThread;
    private int[]               execImage;
    private int[]               gromImage;
    private int[]               ecsImage;
    private int[]               ivoiceImage;

    //config data
    private HashMap             cartTypeByCrcMap;

    //app components
    private JMenuBar             menuBar;
    private JMenu                fileMenu;
    private JMenuItem            playMenuItem;
    private JMenuItem            playIntelCartMenuItem;
    private JMenuItem            exitMenuItem;
    private JMenuItem            propertiesMenuItem;
    private JMenu                viewMenu;
    private JRadioButtonMenuItem viewAllMenuItem;
    private JRadioButtonMenuItem viewAvailableMenuItem;
    private JMenuItem            refreshMenuItem;
    private JMenuItem            optionsMenuItem;
    private JMenu                helpMenu;
    private JMenuItem            aboutMenuItem;
    private JMenu                Menu;
    private CartridgeTableModel  cartTableModel;
    private JTable               cartTable;
    private JScrollPane          cartScrollPane;
    private JLabel               statusLabel;
    private JPanel               statusPanel;

    //dialogs
    private BusyDialog            busyDialog;
    private BlissPropertiesDialog propertiesDialog;
    private BlissOptionsDialog    optionsDialog;
    private BlissAboutDialog      aboutDialog;

    //the emulator hardware
    private Intellivision         inty;
    private HandController        player1;
    private HandController        player2;
    private ECSKeyboard           keyboard;
    private EmulationDirector     director;

    private final static Comparator cartFileComparator = new Comparator() {
            public int compare(Object o1, Object o2) {
                return ((CartridgeFile)o1).getType().getName().
                        compareTo(
                            ((CartridgeFile)o2).getType().getName());
            }
        };

    private class ScanCartridgeDirectoryThread extends Thread
    {
        private ScanCartridgeDirectoryThread() {
            setDaemon(true);
            start();
            waitForIdle();
        }

        public void startScanning() {
            synchronized(this) {
                if (running)
                    return;

                this.notify();
                try { this.wait(); }
                catch (InterruptedException ie) { }
            }
        }

        public void waitForIdle() {
            synchronized(this) {
                if (!running)
                    return;

                try { this.wait(); }
                catch (InterruptedException ie) { }
            }
        }

        public void run() {
            while (true) {

            synchronized(this) {
                running = false;
                this.notifyAll();
                try { this.wait(); }
                catch (InterruptedException ie) { }
                this.notifyAll();
                running = true;
            }

            File cartDir = new File(Bliss.REGISTRY.getDataAsString(
                    BlissConfig.KEY_GENERAL,
                    BlissConfig.VALUE_CARTRIDGE_DIRECTORY,
                    BlissConfig.DEFAULT_CARTRIDGE_DIRECTORY));
            File[] files;
            if (cartDir.exists() && cartDir.isDirectory()) {
                files = cartDir.listFiles(new FilenameFilter() {
                        public boolean accept(File dir, String name) {
                            return (name.toLowerCase().endsWith(".bin") ||
                                    name.toLowerCase().endsWith(".int") ||
                                    name.toLowerCase().endsWith(".zip"));
                        }
                    });
            }
            else
                files = new File[0];

            ArrayList cartFilesList = new ArrayList();
            for (int i = 0; i < files.length; i++) {
                if (files[i].getName().toLowerCase().endsWith(".zip")) {
                    try {
                        ZipFile zipFile = new ZipFile(files[i]);
                        for (Enumeration e = zipFile.entries();
                                e.hasMoreElements();)
                        {
                            ZipEntry nextEntry = (ZipEntry)e.nextElement();
                            long crc = nextEntry.getCrc();
                            if (isNeededSystemROM(crc)) {
                                InputStream is = new BufferedInputStream(
                                        zipFile.getInputStream(nextEntry),
                                            4096);
                                extractSystemROM(crc, is);
                                is.close();
                            }
                            else {
                                CartridgeType cartType = CartridgeTypeFactory.
                                    getCartridgeType(crc);
                                if (cartType != null) {
                                    cartFilesList.add(new CartridgeFile(
                                            cartType, files[i], nextEntry.
                                                getName()));
                                }
                            }
                        }
                    }
                    catch (IOException ioe) {
                        //ignore this file then
                    }
                }
                else {
                    long crc = getCrc(files[i]);
                    if (isNeededSystemROM(crc)) {
                        try {
                            InputStream is = new BufferedInputStream(
                                    new FileInputStream(files[i]), 4096);
                            extractSystemROM(crc, is);
                            is.close();
                        }
                        catch (IOException ioe) {
                            //ignore this file then
                        }
                    }
                    else {
                        CartridgeType cartType = CartridgeTypeFactory.
                                getCartridgeType(crc);
                        if (cartType != null)
                            cartFilesList.add(new CartridgeFile(cartType,
                                    files[i]));
                    }
                }
            }
            cartFiles = new CartridgeFile[cartFilesList.size()];
            cartFilesList.toArray(cartFiles);
            Arrays.sort(cartFiles, cartFileComparator);

            //get back inside the UI thread and set the found list on the
            //table model
            SwingUtilities.invokeLater(new Runnable() {
                    public void run() {
                        cartTableModel.setCartridgeFileList(cartFiles);
                        statusLabel.setText(" ");
                        refreshAction.setEnabled(true);
                    }
                });

            }
        }

/*
        private void searchArchiveStreamForROMs(ArchiveStream as)
                throws IOException
        {
            ArchiveEntry nextEntry = as.getNextEntry();
            while (nextEntry != null) {
                String name = nextEntry.getName();
                if (ArchiveStream.isArchiveFormat(name)) {
                    searchArchiveStreamForROMs(ArchiveStream.getArchiveStream(
                            name, as));
                }
                else {
                    long crc = nextEntry.getCrc();
                    if (isNeededSystemROM(crc))
                        extractSystemROM(crc, as);
                    else {
                        CartridgeType cartType = CartridgeTypeFactory.
                                getCartridgeType(crc);
                        if (cartType != null)
                            cartFilesList.add(new CartridgeFile(cartType,
                                    files[i]));
                    }
                }
            }
        }
*/

        private boolean running = true;
        private CartridgeFile[] cartFiles;
    }

}
