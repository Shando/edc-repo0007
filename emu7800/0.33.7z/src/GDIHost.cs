/*
 * GDIHost
 *
 * A GDI-only based Host. 
 *
 * Copyright (c) 2003 Mike Murphy
 *
 */

using System;
using System.Drawing;
using System.Drawing.Text;
using System.Reflection;
using System.Windows.Forms;

namespace EMU7800 {

public class GDIHost : Form, IHost {
	protected Machine M;

	protected bool IsPaused;
	protected bool Mute;

	protected ControlPanelForm CP;

	protected long[] FrameTicksSamples = new long[10];

	protected string textMsg;
	protected string TextMsg {
		get {
			return textMsg;
		}
		set {
			textMsg = value;
			if (textMsg != null) {
				TextExpireTicks = PerfTimer.Ticks
					+ 2*PerfTimer.TicksPerSecond;
			}
		}
	}
	protected long TextExpireTicks;

	private Font TextFont;
	private SolidBrush TextBrush;
	private Graphics RGraphics;
	private SolidBrush SBrush = new SolidBrush(Color.Black);

	protected int CurrPlayerNo = 0;
	protected int PaddleOhms, PaddleVel = 0, PaddleLAcc = 0, PaddleRAcc = 0;

	public GDIHost() {
		MainLoop();
	}

	public Machine GetMachine() {
		return M;
	}

	public void InstallMachine(Machine m) {
		M = m;
		M.H = this;

		M.ViewPortSize = ClientSize;
		M.DrawEntireFrame = true;
		M.Reset();

		ResetSound();
		StartSound();
		RefreshDisplay();

		IsPaused = false;
	}

	protected void MainLoop() {
		CP = new ControlPanelForm(this);
		AddOwnedForm(CP);

		M = new NullMachine(new InputAdapter());
		Text = Globals.Title + " v" + Globals.Version;
		IsPaused = false;

		InitDisplay();
		InitInput();
		InitSound();

		Show();
		CP.Show();

		long frameCount = 0;
                long frameStartTicks;
		long flipTick = 0;
		long maxSpinTicks = PerfTimer.TicksPerSecond/10;

		while (true) {
			frameStartTicks = PerfTimer.Ticks;

			UpdateInput();

			if (IsPaused) {
				M.DrawPauseFrame();
			} else {
				M.Run();
			}

			if (PerfTimer.Ticks < TextExpireTicks) {
				ClearTextMsg();
				ShowTextMsg();
			} else if (TextMsg != null) {
				ClearTextMsg();
				TextMsg = null;
			}

			// Service the GUI
			do {
				Application.DoEvents();
				if (!Created) {
					return;
				}
			} while (PerfTimer.Ticks < flipTick - maxSpinTicks || !SurfacesOK());

			// Spin delay
			while (PerfTimer.Ticks < flipTick) {}

			FlipFrame();

			flipTick = PerfTimer.Ticks +
				PerfTimer.TicksPerSecond/M.FrameHZ;

                        FrameTicksSamples[frameCount++ % FrameTicksSamples.Length]
				= PerfTimer.Ticks - frameStartTicks;
		}
	}

	private void UpdateClipLocation(int dx, int dy) {
		Point l = M.ClipLocation;
		l.X += dx;
		l.Y += dy;
		M.ClipLocation = l;
		RefreshDisplay();
	}

	protected void OnKeyDown(Object sender, KeyEventArgs e) {
		if (e.KeyCode == Keys.Tab) {
			CP.Show();
			return;
		}

		if (IsPaused) {
			StartSound();
			IsPaused = false;
		}

		switch(e.KeyCode) {
		case Keys.P:
			StopSound();
			IsPaused = true;
			break;
		case Keys.F1:
			ClearPlayerInput(CurrPlayerNo);
			CurrPlayerNo = 0;
			TextMsg = "Player 1";
			break;
		case Keys.F2:
			ClearPlayerInput(CurrPlayerNo);
			CurrPlayerNo = 1;
			TextMsg = "Player 2";
			break;
		case Keys.F3:
			ClearPlayerInput(CurrPlayerNo);
			CurrPlayerNo = 2;
			TextMsg = "Player 3";
			break;
		case Keys.F4:
			ClearPlayerInput(CurrPlayerNo);
			CurrPlayerNo = 3;
			TextMsg = "Player 4";
			break;
		case Keys.F:
			long totTicks = 0;
			foreach (long ticks in FrameTicksSamples) {
				totTicks += ticks;
			}
			totTicks /= FrameTicksSamples.Length;
			double frameRate = PerfTimer.TicksPerSecond;
			frameRate /= totTicks;
			TextMsg = String.Format("{0:#.0}/{1} FPS", frameRate, M.FrameHZ);
			break;
		case Keys.M:
			Mute = !Mute;
			if (Mute) {
				TextMsg = "Mute";
				StopSound();
			} else {
				TextMsg = "Mute Off";
				StartSound();
			}
			break;
		case Keys.F6:
			UpdateClipLocation(-1, 0);
			break;
		case Keys.F5:
			UpdateClipLocation(1, 0);
			break;
		case Keys.F7:
			UpdateClipLocation(0, 1);
			break;
		case Keys.F8:
			UpdateClipLocation(0, -1);
			break;
		case Keys.F9:
			if (CP.CurrGameSettings != null) {
				CP.CurrGameSettings.ClipLocation = M.ClipLocation;
				CP.CurrGameSettings.Save();
				TextMsg = "Game Settings Saved";
			}
			break;
		default:
			DoMachineInput(e.KeyCode, true);
			break;
		}
	}
	
	protected void OnKeyUp(Object sender, KeyEventArgs e)  {
		DoMachineInput(e.KeyCode, false);
	}

	private void ClearPlayerInput(int playerno) {
		InputAdapter ia = M.InputAdapter;

		ia[playerno, ControllerAction.Trigger] = false;
		ia[playerno, ControllerAction.Booster] = false;
		ia[playerno, ControllerAction.Left] = false;
		PaddleLAcc = 0;
		ia[playerno, ControllerAction.Up] = false;
		ia[playerno, ControllerAction.Right] = false;
		PaddleRAcc = 0;
		ia[playerno, ControllerAction.Down] = false;
		ia[playerno, ControllerAction.Keypad7] = false;
		ia[playerno, ControllerAction.Keypad8] = false;
		ia[playerno, ControllerAction.Keypad9] = false;
		ia[playerno, ControllerAction.Keypad4] = false;
		ia[playerno, ControllerAction.Keypad5] = false;
		ia[playerno, ControllerAction.Keypad6] = false;
		ia[playerno, ControllerAction.Keypad1] = false;
		ia[playerno, ControllerAction.Keypad2] = false;
		ia[playerno, ControllerAction.Keypad3] = false;
		ia[playerno, ControllerAction.KeypadA] = false;
		ia[playerno, ControllerAction.Keypad0] = false;
		ia[playerno, ControllerAction.KeypadP] = false;
	}

	private void DoMachineInput(Keys key, bool onoff) {
		InputAdapter ia = M.InputAdapter;

		switch(key) {
		case Keys.Escape:
			Close();
			break;
		case Keys.ControlKey:
			ia[CurrPlayerNo, ControllerAction.Trigger] = onoff;
			break;
		case Keys.Z:
			ia[CurrPlayerNo, ControllerAction.Booster] = onoff;
			break;
		case Keys.Left:
			ia[CurrPlayerNo, ControllerAction.Left] = onoff;
			PaddleLAcc = onoff ? 1 : 0;
			break;
		case Keys.Up:
			ia[CurrPlayerNo, ControllerAction.Up] = onoff;
			break;
		case Keys.Right:
			ia[CurrPlayerNo, ControllerAction.Right] = onoff;
			PaddleRAcc = onoff ? 1 : 0;
			break;
		case Keys.Down:
			ia[CurrPlayerNo, ControllerAction.Down] = onoff;
			break;
		case Keys.NumPad7:
			ia[CurrPlayerNo, ControllerAction.Keypad7] = onoff;
			break;
		case Keys.NumPad8:
			ia[CurrPlayerNo, ControllerAction.Keypad8] = onoff;
			break;
		case Keys.NumPad9:
			ia[CurrPlayerNo, ControllerAction.Keypad9] = onoff;
			break;
		case Keys.NumPad4:
			ia[CurrPlayerNo, ControllerAction.Keypad4] = onoff;
			break;
		case Keys.NumPad5:
			ia[CurrPlayerNo, ControllerAction.Keypad5] = onoff;
			break;
		case Keys.NumPad6:
			ia[CurrPlayerNo, ControllerAction.Keypad6] = onoff;
			break;
		case Keys.NumPad1:
			ia[CurrPlayerNo, ControllerAction.Keypad1] = onoff;
			break;
		case Keys.NumPad2:
			ia[CurrPlayerNo, ControllerAction.Keypad2] = onoff;
			break;
		case Keys.NumPad3:
			ia[CurrPlayerNo, ControllerAction.Keypad3] = onoff;
			break;
		case Keys.Multiply:
			ia[CurrPlayerNo, ControllerAction.KeypadA] = onoff;
			break;
		case Keys.NumPad0:
			ia[CurrPlayerNo, ControllerAction.Keypad0] = onoff;
			break;
		case Keys.Divide:
			ia[CurrPlayerNo, ControllerAction.KeypadP] = onoff;
			break;
		case Keys.R:
			ia[ConsoleSwitch.GameReset] = onoff;
			break;
		case Keys.S:
			ia[ConsoleSwitch.GameSelect] = onoff;
			break;
		case Keys.C:
			if (!onoff)
				break;
			ia[ConsoleSwitch.GameBW] = !ia[ConsoleSwitch.GameBW];
			TextMsg = ia[ConsoleSwitch.GameBW] ? "B/W" : "Color";
			break;
		case Keys.D1:
			if (!onoff)
				break;
			ia[ConsoleSwitch.LDifficultyA] = !ia[ConsoleSwitch.LDifficultyA];
			TextMsg = "Left Difficulty: "
				+ (ia[ConsoleSwitch.LDifficultyA] ? "A (Pro)" : "B (Novice)");
			break;
		case Keys.D2:
			if (!onoff)
				break;
			ia[ConsoleSwitch.RDifficultyA] = !ia[ConsoleSwitch.RDifficultyA];
			TextMsg = "Right Difficulty: "
				+ (ia[ConsoleSwitch.RDifficultyA] ? "A (Pro)" : "B (Novice)");
			break;
		}
	}

	// These are the display virtuals
	protected virtual void InitDisplay() {
		// Try to set the icon for the form, but don't bomb the application over it
		try {
			Icon = new Icon(Assembly.GetExecutingAssembly().GetManifestResourceStream("EMU7800.Icon1.ico"));
		} catch {}

		FormBorderStyle = FormBorderStyle.Sizable;
		CenterToScreen();

		ClientSize = new Size(640, 480);
		MinimumSize = new Size(320 + 8, 240 + 27);
		
		// Enable double-buffering to avoid flicker
		SetStyle(ControlStyles.UserPaint, true);
		SetStyle(ControlStyles.AllPaintingInWmPaint, true);
		SetStyle(ControlStyles.DoubleBuffer, true);

		TextFont = new Font("Courier New", 18);
		TextBrush = new SolidBrush(Color.White);

		Paint += new PaintEventHandler(OnPaint);
		Layout += new LayoutEventHandler(OnLayout);
		
		KeyDown += new KeyEventHandler(OnKeyDown);
		KeyUp   += new KeyEventHandler(OnKeyUp);
		KeyPreview = true;
	}
		
	private void OnPaint(Object sender, PaintEventArgs e) {
		e.Graphics.Clear(Color.Black);
		M.DrawEntireFrame = true;
	}
	
	private void OnLayout(Object sender, LayoutEventArgs e) {
		RefreshDisplay();
		RGraphics = CreateGraphics();
		M.ViewPortSize = ClientSize;
	}

	protected virtual void ShowTextMsg() {
		TextBrush.Color = Color.White;
		RGraphics.TextRenderingHint = TextRenderingHint.SystemDefault;
		RGraphics.DrawString(TextMsg, TextFont, TextBrush, new PointF(0.0f, 0.0f));
	}

	protected virtual void ClearTextMsg() {
		TextBrush.Color = Color.Black;
		RGraphics.FillRectangle(TextBrush, 0, 0, ClientSize.Width, 30);
	}

	protected virtual bool SurfacesOK() { return true; }
	protected virtual void FlipFrame() {}

	protected virtual void RefreshDisplay() {
		if (RGraphics != null) {
			RGraphics.Clear(Color.Black);
		}
		M.DrawEntireFrame = true;
	}

	public virtual void UpdateRect(DisplRect r) {
		SBrush.Color = Color.FromArgb(r.Argb);
		RGraphics.FillRectangle(SBrush, r.Rectangle);
	}


	// These are the input virtuals
	protected virtual void InitInput() {}
	protected virtual void UpdateInput() {
		if (PaddleLAcc == 0 && PaddleRAcc == 0) {
			PaddleVel = 0;
		} else if (PaddleLAcc != 0 || PaddleRAcc != 0) {
			PaddleVel = 10987;
		}

		PaddleOhms += PaddleVel*(PaddleLAcc - PaddleRAcc);

		if (PaddleOhms < 100000)
			PaddleOhms = 100000;
		if (PaddleOhms > 800000)
			PaddleOhms = 800000;

		M.InputAdapter.SetOhms(CurrPlayerNo, PaddleOhms);
	}

	// These are the sound virtuals
	protected virtual void InitSound() {}
	protected virtual void ResetSound() {}
	protected virtual void StartSound() {}
	protected virtual void StopSound() {}
	public virtual void UpdateSound(byte[] buf) {}
}
}