﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("EMU7800")]
[assembly: AssemblyProduct("EMU7800")]
[assembly: AssemblyDescription("An Atari 2600/7800 .NET-based Emulator")]
[assembly: AssemblyCopyright("Copyright © 2003-2009 Mike Murphy")]
[assembly: AssemblyVersion("0.91.0.0")]
[assembly: AssemblyFileVersion("0.91.0.0")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: CLSCompliant(false)]
[assembly: ComVisible(false)]
