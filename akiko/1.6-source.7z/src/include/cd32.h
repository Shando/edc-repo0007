 /*
  * UAE - The Un*x Amiga Emulator
  *
  * CD32 emulation support code
  *
  * (c) by Andreas Falkenhahn 2001 <andreas.falkenhahn@gmx.de>
  */

#define CD32_PLAYTRACK 1
#define CD32_PLAYMSF 2
#define CD32_STOPTRACK 3
#define CD32_DETERMINEAUDIOEND 4
#define CD32_PAUSE 5

#define CD32ERR_CFGFILE 1

struct cd32control
{
	int CDAudioStopped;
	unsigned int wDeviceID;
	int IsAudioPlaying;

};

extern struct cd32control cd32ctl;

uae_u32 cd32_ExecuteCommand(uae_u32 cmd,uae_u32 offset,uae_u32 len);
void cd32_close(void);
void cd32_init(void);
