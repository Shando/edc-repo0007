/*
 * Globals.cs
 * 
 * Global attributes applicable to the entire system.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */

using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.IO.IsolatedStorage;
using System.Reflection;
using System.Windows.Forms;

namespace EMU7800 {

public class Globals {
	public const string Title = "EMU7800";	public const string Version = "0.41";
	public const string Copyright = "Copyright (c) 2003-2004 Mike Murphy";

	public static readonly Version CLRVersion = Environment.Version;
	public static readonly OperatingSystem OSVersion = Environment.OSVersion;
	
	public static double Opacity = 1.0;
	public static readonly string RootDir = Directory.GetCurrentDirectory().Replace(@"\", "/");
	public static string OutputDirectory;
	public static string HostSelect;

	// Joystick button number to function bindings
	public static int JoyBTrigger;
	public static int JoyBBooster;
	public static int JoyBReset;
	public static int JoyBSelect;
	public static int JoyBSwap;

	private static string _ROMDirectory;
	public  static string ROMDirectory {
		get {
			return _ROMDirectory;
		}
		set {
			string ndir = value.Replace(@"\", "/");
			if (Directory.Exists(ndir)) {
				_ROMDirectory = ndir;
			}
		}
	}

	public static void Load() {
		Log.Msg("[Globals]\n");

		try {

		IsolatedStorageFileStream f
			= new IsolatedStorageFileStream("Globals.txt",
				FileMode.OpenOrCreate);
		StreamReader reader
			= new StreamReader(f);

		string line;
		string[] kval;
		do {
			line = reader.ReadLine();
			if (line == null) {
				break;
			}
			kval = line.Split('=');
			string key = kval[0];
			string val = kval[1];

			switch (key) {
			case "ROMDirectory":
				_ROMDirectory = val.Replace(@"\", "/");
				Log.Msg("ROMDirectory={0}\n", ROMDirectory);
				break;
			case "Opacity":
				try {
					Opacity = Double.Parse(val);
				} catch {
					Log.Msg("Error reading {0} key\n", key);
				}
				Log.Msg("Opacity={0}%\n", Opacity*100);
				break;
			case "HostSelect":
				HostSelect = val.Trim();
				Log.Msg("HostSelect={0}\n", HostSelect);
				break;
			case "JoyBTrigger":
				JoyBTrigger = ReadInt32(key, val, 0);
				break;
			case "JoyBBooster":
				JoyBBooster = ReadInt32(key, val, 1);
				break;
			case "JoyBReset":
				JoyBReset = ReadInt32(key, val, 10);
				break;
			case "JoyBSelect":
				JoyBSelect = ReadInt32(key, val, 11);
				break;
			case "JoyBSwap":
				JoyBSwap = ReadInt32(key, val, 9);
				break;
			}
		} while (line != null);

		f.Close();

		} catch (Exception e) {
			Log.Msg("Error reading Globals.txt: {0}\n", e.Message);
		}

		Log.Msg("[/Globals]\n");
	}

	public static void Save() {
		try {

		IsolatedStorageFileStream f
			= new IsolatedStorageFileStream("Globals.txt",
				FileMode.Create);
		StreamWriter w = new StreamWriter(f);
		w.WriteLine("Title={0}", Title);
		w.WriteLine("Version={0}", Version);
		w.WriteLine("Copyright={0}", Copyright);
		w.WriteLine("ROMDirectory={0}", ROMDirectory);
		w.WriteLine("Opacity={0:f}", Opacity);
		w.WriteLine("HostSelect={0}", HostSelect);
		w.WriteLine(WriteInt32("JoyBTrigger", JoyBTrigger));
		w.WriteLine(WriteInt32("JoyBBooster", JoyBBooster));
		w.WriteLine(WriteInt32("JoyBReset", JoyBReset));
		w.WriteLine(WriteInt32("JoyBSelect", JoyBSelect));
		w.WriteLine(WriteInt32("JoyBSwap", JoyBSwap));
		w.Flush();
		w.Close();
		f.Close();

		} catch (Exception e) {
			Log.Msg("Error saving Globals.txt: {0}\n", e.Message);
		}
	}

	public static void Main(string[] args) {
		Log.Msg("{0} v{1}", Title, Version);
#if DEBUG
		Log.Msg(" DEBUG");
#endif
		Log.Msg(" {0}\n", Copyright);

		Log.Msg("CLR Version: {0}\n", Globals.CLRVersion);
		Log.Msg("OS Version: {0}\n", Globals.OSVersion);

		OutputDirectory = RootDir + "/outdir";
		if (!Directory.Exists(OutputDirectory)) {
			OutputDirectory = RootDir;
		}

		_ROMDirectory = RootDir + "/roms";
		if (!Directory.Exists(_ROMDirectory)) {
			_ROMDirectory = RootDir;
		}

		Globals.Load();

		// Ensure GameSettings static constructor is invoked
		Hashtable htbl = GameSettings.ROMProperties;

		Application.Run(new ControlPanelForm());
	}

	private static int ReadInt32(string key, string sval, int defval) {
		int val;
		try {
			val = Int32.Parse(sval);
		} catch {
			val = defval;
		}
		Log.Msg("{0}={1}\n", key, val);
		return val;
	}

	private static string WriteInt32(string key, int val) {
		return String.Format("{0}={1}", key, val);
	}
}
}