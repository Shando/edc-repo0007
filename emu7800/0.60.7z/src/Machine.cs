/*
 * Machine.cs
 * 
 * Abstraction of an emulated machine.
 * 
 * Copyright (c) 2003, 2004 Mike Murphy
 * 
 */
using System;
using System.Drawing;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace EMU7800 {

public enum MachineType {
	A2600NTSC,
	A2600PAL,
	A7800NTSC,
	A7800PAL
};

[Serializable]
public abstract class Machine {
	protected M6502 _CPU;	protected AddressSpace Mem;
	protected PIA PIA;

	[NonSerialized]
	public Host H;

	public bool MachineHalt;

	public readonly InputAdapter InputAdapter;
	public virtual M6502 CPU {
		get {
			return null;
		}
	}

	// Current frame number
	private long frameNumber;
	public  long FrameNumber {
		get {
			return frameNumber;
		}
	}

	// Number of scanlines on the display
	private int scanlines;
	public  int Scanlines {
		get {
			return scanlines;
		}
	}

	// Default starting scanline
	private int firstScanline;
	public  int FirstScanline {
		get {
			return firstScanline;
		}
	}

	// Frame rate
	private int frameHZ;
	public  int FrameHZ {
		get {
			if (frameHZ < 1)
				frameHZ = 1;
			return frameHZ;
		}
		set {
			frameHZ = value;
			if (frameHZ < 1)
				frameHZ = 1;
		}
	}

	// ...in units of samples/sec
	private int soundSampleRate;
	public  int SoundSampleRate {
		get {
			return soundSampleRate;
		}
	}

	private int[] palette;
	public  int[] Palette {
		get {
			return palette;
		}
	}

	private int visiblePitch;
	public  int VisiblePitch {
		get {
			return visiblePitch;
		}
	}

	public static Machine New(GameSettings gs, Cart c, InputAdapter ia) {
		if (gs == null || c == null || ia == null) {
			return null;
		}
		
		Machine m;

		switch (gs.MachineType) {
		default:
		case MachineType.A2600NTSC:
			m = new Machine2600NTSC(c, ia);
			break;
		case MachineType.A2600PAL:
			m = new Machine2600PAL(c, ia);
			break;
		case MachineType.A7800NTSC:
			m = new Machine7800NTSC(c, ia);
			break;
		case MachineType.A7800PAL:
			m = new Machine7800PAL(c, ia);
			break;
		}
		m.InputAdapter.Controllers[0] = gs.LController;
		m.InputAdapter.Controllers[1] = gs.RController;

		return m;
	}

	public void Serialize(string fn) {
		FileStream s = new FileStream(fn, FileMode.Create);
		BinaryFormatter f = new BinaryFormatter();
		f.Serialize(s, this);
		s.Close();
	}

	public static Machine Deserialize(string fn) {
		FileStream s = new FileStream(fn, FileMode.Open);
		BinaryFormatter f = new BinaryFormatter();
		Machine m = (Machine)f.Deserialize(s);
		s.Close();
		return m;
	}

	public void Reset() {
		frameNumber = 0;
		MachineHalt = false;
		InputAdapter.Reset();
		DoReset();
		Log.Msg("Machine {0} reset complete: {1} HZ  {2} scanlines\n",
			this, FrameHZ, Scanlines);
	}

	public void Run() {
		if (!MachineHalt) {
			InputAdapter.CheckPoint(frameNumber);
			DoRun();
			frameNumber++;
		}
	}

	protected abstract void DoReset();
	protected abstract void DoRun();

	public bool ExecuteCommandLine(CommandLine cl) {
		switch (cl.Verb) {		case "d":
			if (cl.CheckParms("ii")) {
				Log.Msg(M6502DASM.Disassemble(Mem,
					(ushort)cl.Parms[0].IntValue,
					(ushort)cl.Parms[1].IntValue)
					+ "\n");
			} else {
				Log.Msg("bad parms\n");
			}
			break;
		case "m":
			if (cl.CheckParms("ii")) {
				Log.Msg(M6502DASM.MemDump(Mem,
					(ushort)cl.Parms[0].IntValue,
					(ushort)cl.Parms[1].IntValue)
					+ "\n");
			} else if (cl.CheckParms("i")) {
				Log.Msg(M6502DASM.MemDump(Mem,
					(ushort)cl.Parms[0].IntValue,
					(ushort)cl.Parms[0].IntValue)
					+ "\n");
			} else {
				Log.Msg("bad parms\n");
			}
			break;
		case "poke":
			if (cl.CheckParms("ii")) {
				Mem[(ushort)cl.Parms[0].IntValue] = (byte)cl.Parms[1].IntValue;
				Log.Msg("poke #${0:x2} at ${1:x4} complete\n",
					cl.Parms[0].IntValue,
					cl.Parms[1].IntValue);
				Mem[(ushort)cl.Parms[1].IntValue] = (byte)cl.Parms[0].IntValue;
			} else {
				Log.Msg("bad parms\n");
			}
			break;
		case "reset":
			Reset();
			break;
		case "resume":
			MachineHalt = false;
			break;
		case "halt":
			MachineHalt = true;
			break;
		case "pc":
			if (cl.CheckParms("i")) {
				CPU.PC = (ushort)cl.Parms[0].IntValue;
				Log.Msg("PC changed to {0:x4}\n", CPU.PC);
			}
			break;
		case "r":
			Log.Msg(M6502DASM.GetRegisters(CPU) + "\n");
			break;
		case "step":
			if (cl.CheckParms("i")) {
				Step(cl.Parms[0].IntValue, (ushort)0);
			} else if (cl.CheckParms("ii")) {
				Step(cl.Parms[0].IntValue, (ushort)cl.Parms[1].IntValue);
			} else {
				Log.Msg("malformed step command");
			}
			break;
		case "help":
		case "h":
		case "?":
			Log.Msg("** Machine Specific Commands **\n"			+ " d [ataddr] [toaddr]: disassemble\n"			+ " halt: halt machine\n"			+ " m [ataddr] [toaddr]: memory dump\n"			+ " pc [addr]: change CPU program counter\n"			+ " poke [ataddr] [dataval]: poke dataval to ataddr\n"			+ " r: display CPU registers\n"			+ " reset: reset machine\n"			+ " resume: resume machine from halted state\n"			+ " step [#cpu cycles] [stop PC]: step CPU execution\n"			);			break;
		default:
			return false;
		}
		return true;
	}

	public Machine(InputAdapter ia, int slines, int startl, int fHZ, int sRate, int[] p, int vPitch) {
		InputAdapter = ia;
		scanlines = slines;
		firstScanline = startl;
		frameHZ = fHZ;
		soundSampleRate = sRate;
		palette = p;
		visiblePitch = vPitch;
	}

	private void Step(int steps, ushort stopPC) {
		StringBuilder sb = new StringBuilder();


		sb.Append(M6502DASM.Disassemble(Mem, CPU.PC, (ushort)(CPU.PC+1)));
		sb.Append(M6502DASM.GetRegisters(CPU));
		sb.Append("\n");
		for (int i=0; i < steps && CPU.PC != stopPC; i++) {
			CPU.RunClocks = 2;
			CPU.Execute();
			sb.Append(M6502DASM.Disassemble(Mem, CPU.PC, (ushort)(CPU.PC+1)));
			sb.Append(M6502DASM.GetRegisters(CPU));
			sb.Append("\n");
		}
		Log.Msg(sb.ToString() + "\n");
	}
}
}
