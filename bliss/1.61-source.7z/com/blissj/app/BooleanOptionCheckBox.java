package com.blissj.app;

import javax.swing.*;
import com.bliss.core.BooleanOption;

public class BooleanOptionCheckBox extends JCheckBox
        implements OptionEditor
{

    public BooleanOptionCheckBox(BooleanOption option) {
        this.option = option;
        setText(option.getDescription());
    }

    public void reloadOption() {
        setSelected(option.isEnabled());
    }

    public void commitSelection() {
        option.setEnabled(isSelected());
    }

    private BooleanOption option;

}
