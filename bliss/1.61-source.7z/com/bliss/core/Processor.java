package com.bliss.core;

import java.io.IOException;
import com.bliss.core.devices.*;

/**
 * An abstract class representing a processor, which is a hardware component
 * that requires a clock input.
 *
 * @author Kyle Davis
 */
public abstract class Processor
{

    public abstract void reset();

    public abstract void save(SaveOutputStream sos) throws IOException;

    public abstract void load(LoadInputStream lis) throws IOException;

    public abstract int getClockSpeed();

    /**
     * This is where the work of the peripheral is performed.
     *
     * @return the number of clock ticks used
     */
    public abstract int tick();

    public boolean isIdle;

}
