
extern struct uae_prefs config_prefs;

extern char config_romfile[256];
extern char config_keyfile[256];
extern char config_description[256];
extern char config_filename[256];
extern int config_no_gui;
extern int config_use_debugger;
extern int config_use_gfxlib;

#define CFG_FILE_PATH "$(FILE_PATH)"

struct config_fs
{
    int  hardfile;
    int  readonly;
    int  sectors;
    int  surfaces;
    int  reserved;
    int  blocksize;
    char amiga_name[256];
    char path[256];
};

#define MAX_CONFIG_FS 20

/* These are the base config-entries which are parsed purely */
typedef enum base_config_enums
{
    help,
    load_config,
    description,
    use_gui,
    allow_debugger,
    cpu_speed,
    cpu_type,
    cpu_compatible,
    cpu_24bit_addressing,
    autoconfig,
    accuracy,
    log_illegal_mem,
    fastmem_size,
    chipmem_size,
    bogomem_size,
    a3000mem_size,
    gfxcard_size,
    z3mem_size,
    gfx_test_speed,
    gfx_framerate,
    gfx_width,
    gfx_height,
    gfx_lores,
    gfx_linemode,
    gfx_fullscreen_amiga,
    gfx_fullscreen_picasso,
    gfx_correct_aspect,
    gfx_center_horizontal,
    gfx_center_vertical,
    gfx_colour_mode,
    gfx_32bit_blits,
    gfx_immediate_blits,
    gfxlib_replacement,
    sound_output,
    sound_frequency,
    sound_bits,
    sound_channels,
    sound_min_buff,
    sound_max_buff,
    parallel_on_demand,
    serial_on_demand,
    joyport0,
    joyport1,
    cfglastentry
} base_config_entries;

/* These are the types of config-entries which can accept a <architecture>.path setting */
typedef enum path_config_enums
{
    kickstart_rom_file = cfglastentry,
    kickstart_key_file,
    floppy0,
    floppy1,
    floppy2,
    floppy3,
    /* These must come last, since they're handled as one case during a write-out */
    hardfile,
    filesystem,
    real_cfglastentry
} path_config_entries;

#define num_path_entries (real_cfglastentry - cfglastentry)

struct cfg_lines
{
    char *config_label;
    char *config_help;
    void *config_var;
};

int CFGFILE_convert_option( base_config_entries entry, char *param, int direction );
int CFGFILE_load( char *filename );
int CFGFILE_save( char *filename );
int CFGFILE_get_description( char *filename, char *description );
void CFGFILE_set_longopts( struct option *options );
void CFGFILE_show_usage( void );
void CFGFILE_transfer_params( struct uae_prefs *to, struct uae_prefs *from, int direction );
