/*
 * EMU][ Apple ][-class emulator
 * Copyright (C) 2002, 2003 by the EMU][ Project/Dapple ][ Team
 *
 * $Header: /winc/emuiil/source/pic.c,v 1.3 2003/06/30 19:28:37 dosius Exp $
 *
 * Component:  PIC: Parallel interface
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
 * Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Log: pic.c,v $
 * Revision 1.3  2003/06/30 19:28:37  dosius
 * Integrated HP's changes to all files.
 *
 * Revision 1.1  2003/06/25 18:28:28  dosius
 * Initial revision
 *
 */

#include <stdio.h>
#include <string.h>
/* used by chdir */
#include <unistd.h>
#include "dapple.h"
#include "asmlib.h"

/* dapple.c */
extern unsigned char appletype;
extern unsigned char inirompath[260];
extern unsigned char inidebugflag;
extern unsigned char inimenulanguage;
void cwdxchgslash(unsigned char *stringptr, unsigned int value);
void windowpresskey(unsigned int keyboard, unsigned int window);

/* video.c */
extern unsigned char virtvideobyte;


static unsigned char parallelrom[256];
static unsigned char parallelpresent;
unsigned char        parallelactive;


/*--------------------------------------*/


      void parallelinit() {

	memset(parallelrom, 0xff, sizeof(parallelrom));
	parallelpresent = 0;
	parallelactive  = 1;

      } /* parallelinit */


/*--------------------------------------*/


      void parallelloadrom(unsigned int keyboard, unsigned int window) {
	FILE *file;
	unsigned char filepath[260];
	unsigned char oldcwd[260];

	cwdxchgslash(oldcwd, 256);				/* read old directory path	*/
	chdir(inirompath);					/* set rom directory		*/

	strcpy(filepath, "slotprnt.a65");			/* search for source code	*/
	file=fopen(filepath,"rb");
	if (!file) {
	  strcpy(filepath, "slotprnt.s");
	  file=fopen(filepath,"rb");
	  if (!file) {
	    strcpy(filepath, "slotprnt.asm");
	    file=fopen(filepath,"rb");
	  }
	}
	if (file) {
	  fclose(file);						/* close file again */
	  stringwritemessage(window,
"!\
EAssemble source code for parallel port slot rom...\r;\
GAssembliere Source Code f�r das Parallelport-Slotrom...\r;\
;");
	  imageupdate();
	  memset(parallelrom, 0xff, sizeof(parallelrom));
	  assembler(parallelrom, sizeof(parallelrom), filepath);	/* assemble source code */
	  parallelpresent = 1;
	}
	else {
	  strcpy(filepath, "parallel.rom");;				/* search binary rom file	*/
	  file=fopen(filepath,"rb");
	  if (file) {
	    stringwritemessage(window,
"!\
EReading parallel port slot rom from file...\r;\
GLese Parallelport-Slotrom aus Datei...\r;\
;");
	    imageupdate();
	    fread(parallelrom, sizeof(parallelrom), 1, file);		/* read binary rom file */
	    fclose(file);
	    parallelpresent = 1;
	  }
	  else {
	    stringwritemessage(window,
"!\
ENo separate parallel port slot rom found\r;\
GKein gesondertes Parallelport-Slotrom vorhanden\r;\
;");
	    parallelpresent = 0;
	    parallelactive  = 0;
	    imageupdate();
	  }
	}
	chdir(oldcwd);							/* restore original directory */
/*	windowpresskey(keyboard, window); */
/*	debugger(driverom, sizeof(driverom)); */

      } /* parallelloadrom */


/*--------------------------------------*/


      unsigned char parallelread(void *slotdata, unsigned int addr) {

	return virtvideobyte;

      } /* parallelread */


/*--------------------------------------*/


      void parallelwrite(void *slotdata, unsigned int addr, unsigned int value) {

	if ((inidebugflag) || (!parallelactive)) {
	  return;
	}

	switch (addr & 0x0f) {
	  case 0x00 :	/* load output port */
	    fputc(value & 0x7F, stdprn);
	    fflush(stdprn);
	    break;
 	} /* switch */

      } /* parallelwrite */


/*--------------------------------------*/


      unsigned char parallelromread(void *slotdata, unsigned int addr) {

	if (parallelactive) {
	  return parallelrom[addr & 0xff];	/* read from the rom which was separately loaded */
	}
	else {
	  return 0xff;
	}

      } /* parallelromread */


/*--------------------------------------*/


      void parallelromwrite(void *slotdata, unsigned int addr, unsigned int value) {

	return;		/* Nothing happens here */

      } /* parallelromwrite */


/*---------------------------------------*/


      unsigned int parallelstore(void *slotdata, unsigned int winprotocol, FILE *file) {
	unsigned char header[32];

	memset(header, 0x00, sizeof(header));
	strcpy(header, "PARALLEL STATE V0.27");
	fwrite(header,		 	sizeof(header),			1,file);

	fwrite(parallelrom,		sizeof(parallelrom),		1,file);
	fwrite(&parallelpresent,	sizeof(parallelpresent),	1,file);
	fwrite(&parallelactive,		sizeof(parallelactive),		1,file);

	stringwrite(winprotocol, "Parallel interface stored.\r");

	return 0;

      } /* parallelstore */


/*--------------------------------------*/


      unsigned int parallelrestore(void *slotdata, unsigned int winprotocol, FILE *file) {
        unsigned char header[32];

	fread(header,			sizeof(header),			1,file);
	if (strcmp(header, "PARALLEL STATE V0.27")) {
	  stringwrite(winprotocol, "Parallel interface emulation data not found.\r");
	  return 1;
	}

        fread(parallelrom,		sizeof(parallelrom),		1,file);
	fread(&parallelpresent,		sizeof(parallelpresent),	1,file);
	fread(&parallelactive,		sizeof(parallelactive),		1,file);

	stringwrite(winprotocol, "Parallel interface restored.\r");

	return 0;

      } /* parallelrestore */


/*--------------------------------------*/


      void parallelmenu (void *slotdata) {
	unsigned int	menukeyboard;
	unsigned int	menuwindow;
	unsigned char	key;
	unsigned int	update;

	if (!windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1,
"!\
EParallel Interface Options;\
GParallelschnittstelle Optionen;\
", 0, &menukeyboard, &menuwindow)) {
	  update = 1;
	  do {
	    if (update) {
	      channelout(menuwindow, 12);	/* clear window */
	      stringwritemessage(menuwindow,
"!\
E\r[ESC] - Quit\r\r;\
G\r[ESC] - Verlasse Men�\r\r;\
");
	      if (appletype == APPLEIIC) {
		stringwritemessage(menuwindow,
"!\
E\rNo separate parallel interface present on an Apple//c;\
G\rKeine separate parallele Schnittstelle vorhanden beim Apple//c;\
");
	      }
	      else {
		if (!parallelpresent) {
		  stringwritemessage(menuwindow,
"!\
E\rNo parallel interface present;\
G\rKeine parallele Schnittstelle vorhanden;\
");
		}
		else {
		  if (parallelactive) {
		    stringwritemessage(menuwindow,
"!\
E\r[A] - Parallel interface activated;\
G\r[A] - Parallele Schnittstelle aktiviert;\
");
		  }
		  else {
		    stringwritemessage(menuwindow,
"!\
E\r[A] - Parallel interface inactive;\
G\r[A] - Parallele Schnittstelle deaktiviert;\
");
		  }
		}
	      }
	      update = 0;
	    }
	    do {
	      imageupdate();
	      key = (unsigned char)channelin(menukeyboard);
	    }
	    while ((key == 0) && (!exitprogram));
	    switch (key) {
	      case 'a' :
	      case 'A' :
	        if (parallelpresent) {
		  if (parallelactive) {
		    parallelactive = 0;
		  }
		  else {
		    parallelactive = 1;
		  }
		  update = 1;
		}
		break;
	    } /* switch (key) */
	  }
	  while ((key != 27) && (key != 32) && (key != 13) && (!exitprogram));
	  channelclose(menukeyboard);
	  channelclose(menuwindow);
	}

      } /* parallelmenu */


/*--------------------------------------*/


      unsigned int parallelnew(slot *slotpointer, unsigned int slotnumber) {

	if (!parallelpresent) {
	  return 1;		/* no rom present ==> emulation not possible */
	}

	slotpointer->slotclose		= (void *)&slotnofunction;
	slotpointer->slotreset		= (void *)&slotnofunction;
	slotpointer->slotstore		= (void *)&parallelstore;
	slotpointer->slotrestore	= (void *)&parallelrestore;
	slotpointer->slotget		= (void *)&parallelread;
	slotpointer->slotset		= (void *)&parallelwrite;
	slotpointer->slotromget		= (void *)&parallelromread;
	slotpointer->slotromset		= (void *)&parallelromwrite;
	slotpointer->slotmenu		= (void *)&parallelmenu;
	slotpointer->slotshift		= (void *)&slotnofunction;
	slotpointer->slotctrl		= (void *)&slotnofunction;
	slotpointer->slotshiftctrl	= (void *)&slotnofunction;
	slotpointer->slotdata		= NULL;
	slotpointer->slotname		=
"!\
EParallel Interface;\
GParallele Schnittstelle;\
";

	return 0;

      } /* parallelnew */
