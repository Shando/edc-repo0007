package com.bliss.core.devices;

public interface InputSignal
{
    public String getDescription();

    public String getConfigString();
}

