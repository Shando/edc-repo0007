/*
 * Dapple ][ Emulator  Version 0.06
 * Copyright (C) 2002, 2003 Dapple ][ Development.  All rights reserved.
 *
 * Component:  DAPPLE: main menu, global functions, keyboard emulation
 * Revision:   (0.06) 2003.0131
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <dir.h>
#include <unistd.h>
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include "dapple.h"
#include "asmlib.h"

/* video.c */
extern unsigned char virtcopy;
void virtinit();
void virtreset();
void virtline(unsigned int rasterline);
void virtscreencopy();
void virtsethresmode(unsigned char mode);
unsigned char virtgethresmode();
void virtsetmonochrome(unsigned char mode);
unsigned char virtgetmonochrome();
void virtsetpalette(unsigned char mode);
unsigned char virtgetpalette();
void virtmenu();
void virtstore(FILE *file);
void virtrestore(FILE *file);

/* cpu65c02.c */
unsigned char cpuinuse();
void cpuinit();
void cpureset();
void cpusetlinecycle(unsigned int value);
unsigned int cpugetlinecycle();
void cpusetdelay(unsigned int value);
void cpusetstate(unsigned int value);
void cpuclearstate(unsigned int value);
unsigned char cpugetstate();
void cpuline();
void cpurun();
void cpumenu();
void cpustore(FILE *file);
void cpurestore(FILE *file);

/* memory.c */
extern unsigned char memkey;
extern unsigned int memjoyx;
extern unsigned int memjoyy;
extern unsigned char memjoybutton0;
extern unsigned char memjoybutton1;
extern unsigned char memram[0x28000];
void soundinit();
void soundmenu();
void memoryinit();
void memoryreset();
unsigned int memoryautoloadrom(unsigned int keyboard, unsigned int window);
void memorymenu();
void memorystore(FILE *file);
void memoryrestore(FILE *file);

/* disk.c */
extern unsigned char drivedata1 [233472];
extern unsigned char drivedata2 [233472];
extern unsigned char drivefastmode;
void driveinit();
void drivereset();
unsigned int driveload(unsigned int keyboard, unsigned int window,
		       unsigned char diskdata[233472], unsigned char *filename);
void drivemenu();
void drivestore(FILE *file);
void driverestore(FILE *file);


/* ini.c */
void readini();
void writeini();


void mainmenu();
void keyboardmenu();
unsigned int  keyboard;		/* keyboard handle		*/
unsigned int  window;		/* window handle		*/
unsigned char appletype;	/* II+/IIe/IIc */
unsigned char key;
unsigned char keyspec;
unsigned int  messagecount;
unsigned char messageflag;
unsigned int  i;
unsigned int  inicpudelay;
unsigned char inidiskpath1[256];
unsigned char inidiskpath2[256];
unsigned char inidebugflag;	/* debugger on? */
unsigned char inidrivemessageflag; /* display current drive track? */
unsigned char inidrivefastflag;
Charset       inicharmode;
unsigned char keycapslock;	/* capslock mode on? */
unsigned char keygerman;	/* switch 'Y' and 'Z' on German keyboards? */
unsigned char callingpath[260];

/* dummy declarations to let other modules compile successfully */

unsigned char HDDROM[256];
unsigned char *shiftstate;
unsigned char dqhdv;
unsigned char dqshift;

/*-------------------------------------*/

      unsigned char ReadMassStorIO(unsigned int addr) {

	return 0xff;

      }

/*-------------------------------------*/

/* Commented out because this function is provided by LLDISK -uso. (2003.0130)
      unsigned char ReadRawDiskIO(unsigned int addr) {

	return 0xff;

      }
*/

/*-------------------------------------*/

/* Commented out because this function is provided by PIC -uso. (2003.0130)
      void WriteParallel(unsigned int addr, unsigned int value) {

	return;

      }
*/

/*-------------------------------------*/

      void WriteMassStorIO(unsigned int addr, unsigned int value) {

	return;

      }

/*-------------------------------------*/

/* Commented out because this function is provided by LLDISK -uso. (2003.0130)
      void WriteRawDiskIO(unsigned int addr, unsigned int value) {

	return;

      }
*/

/*-------------------------------------*/


      void stringwritecenterx(unsigned int window, unsigned char *stringpointer) {

	imagesetcursor(window, (WINDOWXSIZE - (strlen(stringpointer) << 3)) / 2, imagegetcursory(window) );
	stringwrite(window, stringpointer);

      } /* stringwritecenterx */


/*-------------------------------------*/


      void imagetickbox(unsigned int window, unsigned int value) {

	register unsigned int cursorx;
	register unsigned int cursory;

	cursorx = imagegetcursorx(window);
	cursory = imagegetcursory(window);

	imagefillbox(window, cursorx, cursory-7, cursorx+7, cursory, RGBLIGHT);
	imagefillbox(window, cursorx, cursory-6, cursorx+6, cursory, RGBDARK);
	imagefillbox(window, cursorx+1, cursory-6, cursorx+6, cursory-1, RGBWHITE);

	if (value) {
	  imageline(window, cursorx+2, cursory-4, cursorx+3, cursory-2, RGBBLACK);
	  imageline(window, cursorx+3, cursory-2, cursorx+6, cursory-5, RGBBLACK);
	}
	imagesetcursor(window, cursorx+8, cursory);

      } /* stringwritecenterx */


/*-------------------------------------*/


     void setmessage(unsigned char *message) {

	if (messageflag) {
	  imagesetcursor	(window, 0, 399);
	  imagefillbox	(window, 0, 392, 639, 399, 0xff8000);
	  imagesettextcolor(window, 0xff8000, 0x000000);
	  stringwrite	(window, message);
	  messagecount = 50 * 4;
	  virtcopy = 1;
	}

     } /* setmessage */


/*-------------------------------------*/


      void applereset() {

	cpureset();
#ifdef EMUZ80
	Z80_Reset();
#endif
	memoryreset();
	virtreset();
	drivereset();

	setmessage("Reset Apple");

      } /* applereset */


/*-------------------------------------*/


      void applestore(FILE *file) {

	cpustore(file);
	memorystore(file);
	virtstore(file);
	drivestore(file);

      } /* applestore */


/*-------------------------------------*/


      void applerestore(FILE *file) {

	cpurestore(file);
	memoryrestore(file);
	virtrestore(file);
	driverestore(file);

      } /* applerestore */


/*-------------------------------------*/


      void keyconvert() {
	register unsigned int i;

	i = keyboardjoyx();
	if (i > 0x7fffffff) { memjoyx = 0x008; }
	else {
	  if (i == 0)	{ memjoyx = 0x575; }
	  else		{ memjoyx = 0xb7c; }
	}
	i = keyboardjoyy();
	if (i > 0x7fffffff) { memjoyy = 0x008; }
	else {
	  if (i == 0)	{ memjoyy = 0x575; }
	  else		{ memjoyy = 0xb7c; }
	}
	i = keyboardjoyb();
	if (i & 0xff00)	{ memjoybutton0 = 0x80; }
	else		{ memjoybutton0 = 0x00; }
	if (i & 0xff)	{ memjoybutton1 = 0x80; }
	else		{ memjoybutton1 = 0x00; }

	i = channelin(keyboard) & 0xffff;
	key	= (unsigned char)i;
	keyspec	= (unsigned char)(i >> 8);

	switch (key) {
	  case 0  :		/* no key pressed */
	    break;
	  case 28 :		/* function keys */
	    switch (keyspec) {
	      case 0x90 :	/* <Arrow-Left> */
		memkey = 0x88;
		break;
	      case 0x91 :	/* <Arrow-Right> */
		memkey = 0x95;
		break;
	      case 0x92 :	/* <Arrow-Up> */
		memkey = 0x8b;
		break;
	      case 0x93 :	/* <Arrow-Down> */
		memkey = 0x8a;
		break;
	      case 0xc2 :	/* <F2> */
		keyboardmenu();
		imageupdate();
		break;
	      case 0xc3 :	/* <F3> */
		virtmenu();
		imageupdate();
		break;
	      case 0xc4 :	/* <F4> */
		cpumenu();
		imageupdate();
		break;
	      case 0xc6 :	/* <F6> */
	        drivemenu();
	        imageupdate();
	        break;
	      case 0xc8 :	/* <F8> */
	        memorymenu();
	        imageupdate();
	        break;
		/* if (!nof8) prtsc(); */
		break;
	      case 0xc9 :	/* <F9> */
	        inidebugflag = 1;
		debugger(memram, sizeof(memram));
	        inidebugflag = 0;
		break;
	      case 0xca :	/* <F10> */
	        mainmenu();
	        imageupdate();
		break;
	    } /* switch (keyspec) */
	    break;
	  case 29 :		/* shift function keys */
	    switch (keyspec) {
	      case 0xc3 :	/* <Shift-F3> */
		virtsetmonochrome((virtgetmonochrome() + 1) & 0x3);
		break;
	      case 0xc4 :	/* <Shift-F4> */
		if (memjoybutton0 || memjoybutton1) { exitprogram = -1; }
		else {
		  if (cpugetlinecycle() == 65) {
		    cpusetlinecycle(65 * 8);
		    cpusetdelay(0);
		    drivefastmode = 0;
		    setmessage("Set CPU to fast mode");
		  }
		  else {
		    cpusetlinecycle(65);
		    cpusetdelay(inicpudelay);
		    drivefastmode = 0;
		    setmessage("Set CPU to 1Mhz");
		  }
		}
		break;
	    } /* switch (keyspec) */
	    break;
	  case 30 :		/* control function keys */
	    switch (keyspec) {
	      case 0xc3 :	/* <Ctrl-F3> */
		i = virtgetpalette();
		i++;
                if (i > 2/*4 -uso.2003.0130*/) { i = 0; }
		virtsetpalette(i);
		break;
	      case 0xc4 :	/* <Ctrl-F4> */
		if (memjoybutton0 || memjoybutton1) { exitprogram = -1; }
		else {
		  if (cpugetstate() & STATEHALT) {
		    cpuclearstate(STATEHALT);
		  }
		  else {
		    cpusetstate(STATEHALT);
		  }
		}
		break;
	      case 0xca :	/* <Ctrl-F10> */
	      case 0xcc :	/* <Ctrl-F12> */
	        applereset();
		break;
	    } /* switch (keyspec) */
	    break;
	  case 31 :		/* shift control function keys */
	    switch (keyspec) {
	      case 0xc3 :	/* <Shift-Ctrl-F3> */
		virtsethresmode((virtgethresmode() + 1) & 0x1);
		break;
	    } /* switch (keyspec) */
	    break;
	  default :
	    if (key <= 0x7f) {
	      if (keycapslock) {
		if ( ((key >= 'A') && (key <= 'Z')) || ((key >= 'a') && (key <= 'z')) ) {
		  key = key ^ 0x20;
		}
	      }
	      if (keygerman) {
		if (key == 'Y') { key = 'Z'; }
		else {
		  if (key == 'y') { key = 'z'; }
		  else {
		    if (key == 'Z') { key = 'Y'; }
		    else {
		      if (key == 'z') { key = 'y'; }
		    }
		  }
		}
	      }
	      memkey = key | 0x80;
	    }
	} /* switch (key) */

      } /* keyconvert */


/*-------------------------------------*/


      void keyboardinit () {

	keycapslock = 1;
	keygerman   = 0;
	keyboardsetlayout(0);	/* USA */

      } /* keyboardinit */


/*-------------------------------------*/


      void keyboardmenu () {
	unsigned int screen;
	unsigned int keyboard;
	unsigned int window;
	unsigned char key;
	unsigned char update;

	screen = screenstore();
	if (!windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1, "Keyboard Options", &keyboard, &window)) {

	  update = 1;
	  do {
	    if (update) {
	      channelout(window, 12);		/* clear window */
	      stringwrite(window, "\r[ESC] - Quit\r\r");

	      stringwrite(window, "\r[C] - ");
//	      imagetickbox(window, keycapslock);
	      stringwrite(window, "Reverse Caps Lock: ");
	      if (keycapslock) {
	        stringwrite(window, "Yes");
	      }
	      else {
	        stringwrite(window, "No");
	      }

	      stringwrite(window, "\r[S] - Switch keys 'Y' and 'Z': ");
	      if (keygerman) {
	        stringwrite(window, "Yes");
	      }
	      else {
	        stringwrite(window, "No");
	      }
	      stringwrite(window, "\r\r      Keyboard Layout:");
	      stringwrite(window, "\r\[U] - USA:     ");
	      channelout(window, keyboardgetlayout()==0 ? '*':' ');
	      stringwrite(window, "\r\[G] - Germany: ");
	      channelout(window, keyboardgetlayout()==1 ? '*':' ');

	      imageupdate();
	      update = 0;
	    }
	    do {
	      key = (unsigned char)channelin(keyboard);
	    }
	    while ((key == 0) && (!exitprogram));
	    switch (key) {
	      case 'c' :
	      case 'C' :
	        keycapslock = !keycapslock;
	        update = 1;
	        break;
	      case 'g' :
	      case 'G' :
	        keyboardsetlayout(1);
	        update = 1;
	        break;
	      case 's' :
	      case 'S' :
	        keygerman = !keygerman;
	        update = 1;
	        break;
	      case 'u' :
	      case 'U' :
	        keyboardsetlayout(0);
	        update = 1;
	        break;
	    } /* switch (key) */
	  }
	  while ((key != 27) && (key != 32) && (key != 13) && (!exitprogram));
	  channelclose(keyboard);
	  channelclose(window);
	}
	screenrestore(screen);

      } /* keyboardmenu */


/*-------------------------------------*/


/* This is nothing but a dummy function. Sorry. */

      int strright (char *tgt, char *src) {
	int x = strlen(src);

	return !stringcomparec(&(tgt[strlen(tgt)-x]), src);
      } /* strright */


      void cwdxchgslash(unsigned char *stringptr, unsigned int value) {

	getcwd(stringptr, value);

	while (*stringptr) {
	  if (*stringptr == '/') {
	    *stringptr = '\\';
	  }
	  stringptr++;
	} /* while */
      } /* cwdxchgslash */


/* maximum number of filenames for fdialog(), 256+16 bytes each */
   // change to 512 -uso. 2002.0131
#define MFN 512
#define MAXROWS 24

typedef struct {char name[260]; int attr;} fnam;


      void filesort(fnam *fnames, unsigned int *fnamesptr, int attribute,
      		    unsigned int min, unsigned int max) {

	register int i;
	register int j;
	unsigned int temp;

/* stupid bubblesort algorithm */
	for (i=min+1; i <= max; i++) {
	  for (j=max; j >= i; j--) {
	    if (fnames[fnamesptr[j-1]].attr == attribute) {
	      if (fnames[fnamesptr[j]].attr == attribute) {
		if (stringcomparec( fnames[fnamesptr[j-1]].name, fnames[fnamesptr[j]].name) > 0) {
		  temp = fnamesptr[j-1];
		  fnamesptr[j-1] = fnamesptr[j];
		  fnamesptr[j] = temp;
		}
	      }
	      else {
		temp = fnamesptr[j-1];
		fnamesptr[j-1] = fnamesptr[j];
		fnamesptr[j] = temp;
	      }
	    }
	  } /* for j */
	} /* for i */

      } /* filesort */


      unsigned int fileselectmenu (unsigned int keyboard, unsigned int window,
			   unsigned char *title,
			   unsigned char *filename, unsigned char *tail,
			   unsigned char optnew) {

	unsigned char path[260];
	unsigned char oldpath[260];
	unsigned char filestring[260];
	unsigned int fileminnumber;
	unsigned int filenumber;
	int cursor;
	int cursorx;
	int cursory;
	int columnstart;
	int i;
	struct ffblk ffblk;

	fnam fnames[MFN];
	unsigned int fnamesptr[MFN];

	unsigned char key;
	unsigned char keyspec;
	unsigned char update;
	unsigned char reload;


	cwdxchgslash(oldpath, MAXPATH);
	cursor = 0;
	update = 1;
	reload = 1;

	do {
	  if (reload) {		/* do we have to load the filename array? */
	    cwdxchgslash(path, MAXPATH);			/* get current directory */

	    filenumber = 0;					/* add fix elements to array */
	    fileminnumber = 0;
	    if (optnew) {
	      strcpy(fnames[0].name,"(New File)");
	      fnames[0].attr = -1;
	      fnamesptr[0] = 0;
	      filenumber++;
	      fileminnumber++;
	    }
	    strcpy(fnames[filenumber].name,"(Select Drive)");
	    fnames[filenumber].attr = -1;
	    fnamesptr[filenumber] = filenumber;
	    filenumber++;
	    fileminnumber++;

	    i = findfirst("*.*", &ffblk, FA_DIREC);		/* put all filenames into array */
	    while ( (!i) && (filenumber < MFN) ) {
	      strcpy(fnames[filenumber].name, ffblk.ff_name);
	      fnames[filenumber].attr = (ffblk.ff_attrib & FA_DIREC) ? FA_DIREC : 0;	/* directory? */

	      if (!stringcomparec(tail,"._img_")) {		/* Custom mode for tail "._img_" */
		if ((fnames[filenumber].attr) || (strright(fnames[filenumber].name,".DSK"))
					      || (strright(fnames[filenumber].name,".IIE"))
					      || (strright(fnames[filenumber].name,".2MG"))
					      || (strright(fnames[filenumber].name,".DO"))
					      || (strright(fnames[filenumber].name,".PO"))
					      || (strright(fnames[filenumber].name,".NIB"))) {
					        fnamesptr[filenumber] = filenumber;
					        filenumber++;
		}
	      }
	      else {
	        if (!stringcomparec(tail,".*")) {
	          fnamesptr[filenumber] = filenumber;
	          filenumber++;
	        }
	        else {
		  if ((fnames[filenumber].attr) || (strright(fnames[filenumber].name, tail))) {
		    fnamesptr[filenumber] = filenumber;
		    filenumber++;
		  }
		}
	      }
	      i = findnext(&ffblk);
	    } /* while */

	    filesort(fnames, fnamesptr, FA_DIREC, fileminnumber, filenumber-1);
	    filesort(fnames, fnamesptr, 0, fileminnumber, filenumber-1);

	    cursor	= 0;			/* set to first entry in array */
	    columnstart	= 0;
	    reload	= 0;
	  }

	  if (update) {
	    channelout(window, 12);		/* clear window */

	    if (strlen(path) > ((WINDOWXSIZE/8)-4)) {		/* print current directory path */
	      path[(WINDOWXSIZE/8)-4] = 0;
	      imagesetcursor(window, 8, 22);
	    }
	    else {
	      imagesetcursor(window, (WINDOWXSIZE - (strlen(path) << 3)) >> 1, 22);
	    }
	    stringwrite(window, path);

	    imagefillbox(window, 0, 24, WINDOWXSIZE, 25, 0xffff00);
	    imagefillbox(window, 0, WINDOWYSIZE - 34, WINDOWXSIZE, WINDOWYSIZE - 35, 0xffff00);
	    imagefillbox(window, 0, WINDOWYSIZE - 23, WINDOWXSIZE, WINDOWYSIZE - 24, 0xffff00);

	    imagesetcursor(window, 12, WINDOWYSIZE-25);
	    stringwrite(window, title);
	    imagesetcursor(window, 4, WINDOWYSIZE-13);			/* print bottom message */
	    stringwrite(window, " Arrows move, <ENTER> selects, <ESC> exits\r");
	    stringwrite(window, " Folder names end in \"\\\". ");

	    i = columnstart;
	    cursorx = 8;
	    cursory = 35;
	    while ((i < filenumber) & (cursorx < WINDOWXSIZE)) {
	      imagesetcursor(window, cursorx, cursory);
	      if (i == cursor) {
	        imagesettextcolor(window, 0xffffff, 0x03050ff);
	        imagefillbox(window, cursorx, cursory-7, cursorx+(WINDOWXSIZE/3)-1, cursory, 0xffffff);
	      }
	      strcpy(filestring, fnames[fnamesptr[i]].name);
	      if (strlen(filestring) > ((WINDOWXSIZE/24))-1) {
	        filestring[(WINDOWXSIZE/24)-4] = ' ';
	        filestring[(WINDOWXSIZE/24)-3] = '.';
	        filestring[(WINDOWXSIZE/24)-2] = '.';
	        filestring[(WINDOWXSIZE/24)-1] = 0;
	      }
	      stringwrite(window, filestring);
	      if (fnames[fnamesptr[i]].attr == FA_DIREC) {	/* directory? */
	        channelout(window, '\\');
	      }
	      if (i == cursor) {
	        imagesettextcolor(window, 0x03050ff, 0xffffff);
	      }
	      cursory = cursory + 8;
	      if (cursory >= (MAXROWS*8) + 35) {
	        cursory = 35;
	        cursorx = cursorx + (WINDOWXSIZE/3);
	      }
	      i++;
	    } /* while */

	    imageupdate();
	    update = 0;
	  } /* if (update) */

	  do {
	    i = channelin(keyboard);
	    key = (unsigned char)(i & 0xff);
	    keyspec = (unsigned char) ((i >> 8) & 0xff);
	  }
	  while ((key ==0) && (!exitprogram));
	  switch (key) {
	    case 13 :
	      if (!stringcomparec(fnames[fnamesptr[cursor]].name, "(Select Drive)")) {
		imagesetcursor(window, 12, WINDOWYSIZE-25);
		imagefillbox(window, 0, WINDOWYSIZE-32, WINDOWXSIZE, WINDOWYSIZE-25, 0x03050ff);
		stringwrite(window, "Enter drive or <ENTER> to cancel: _");
		imageupdate();
		do {
		  key = (unsigned char)channelin(keyboard);
		}
		while ((key == 0) && (!exitprogram));
		if ((key >= 'a') && (key <= 'z')) {
		  setdisk(key - 'a');
		  reload = 1;
		}
		else {
		  if ((key >= 'A') && (key <= 'Z')) {
		    setdisk(key - 'A');
		    reload = 1;
		  }
		}
		key = 0;
		update = 1;
	      }
	      else {
		if (fnames[fnamesptr[cursor]].attr) {
		  chdir(fnames[fnamesptr[cursor]].name);
		  reload = 1;
		  update = 1;
		  key    = 0;
		}
		else {
		  strcpy(filename, path);
		  if (filename[strlen(filename)-1]!='\\')
		    { strcat(filename,"\\"); }
		  strcat(filename, fnames[fnamesptr[cursor]].name);
		}
	      }
	      break;
	    case 27 :
	    case 32 :
	      chdir(oldpath);
	      break;
	    case 28 :
	      switch (keyspec) {
		case 0x90 :		/* <Arrow-Left> */
		  if (cursor >= MAXROWS) {
		    cursor = cursor - MAXROWS;
		    if (cursor < columnstart) {
		      columnstart = columnstart - MAXROWS;
		      if (columnstart < 0) { columnstart = 0; }
		    }
		  }
		  update = 1;
		  break;
		case 0x91 :		/* <Arrow-Right> */
		  if ((cursor + MAXROWS) < filenumber) {
		    cursor = cursor + MAXROWS;
		    if (cursor >= (columnstart+3*MAXROWS)) {
		      columnstart = columnstart + MAXROWS;
		    }
		  }
		  update = 1;
		  break;
		case 0x92 :		/* <Arrow-Up> */
		  if (cursor > 0) {
		    cursor--;
		    if (cursor < columnstart) {
		      columnstart = columnstart - MAXROWS;
		      if (columnstart < 0) { columnstart = 0; }
		    }
		  }
		  update = 1;
		  break;
		case 0x93 :		/* <Arrow-Down> */
		  if (cursor < (filenumber-1)) {
		    cursor++;
		    if (cursor >= (columnstart+3*MAXROWS)) {
		      columnstart = columnstart + MAXROWS;
		    }
		  }
		  update = 1;
		  break;
	      } /* switch (keyspec) */
	  } /* switch (key) */

	}
	while ((key != 13) && (key != 27) && (key != 32) && (!exitprogram));
	return (key == 13);
      } /* fileselectmenu */


/*-------------------------------------*/


      void mainmenu () {
	unsigned int screen;
	unsigned int keyboard;
	unsigned int window;
	unsigned char key;
	unsigned char update;
	unsigned char menu;

	do {
	  screen = screenstore();
	  if (windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1, "Dapple ][ Menu", &keyboard, &window)) {
	    menu = 1;
	    exitprogram = 1;
	  }
	  else {
	    menu   = 0;
	    update = 1;
	    do {
	      if (update) {
	        channelout(window, 12);		/* clear window */
	        channelout(window, 13);
                /* Concatenating string constants should be ok -uso. */
                stringwritecenterx(window, "Dapple ][ v" DappleVersion);
	        channelout(window, 13);
                stringwritecenterx(window, "(C) 2002, 2003 Dapple ][ Development Team");
	        channelout(window, 13);

	        stringwrite(window, "\r\r[ESC] - Resume emulation\r");

		stringwrite(window, "\r[C] - CPU options");
	        stringwrite(window, "\r[D] - Drive options");
	        stringwrite(window, "\r[K] - Keyboard Options");
	        stringwrite(window, "\r[M] - Memory Options");
	        stringwrite(window, "\r[N] - Sound Options");
	        stringwrite(window, "\r[V] - Video Options");
	        stringwrite(window, "\r[Q] - Quit to DOS");
	        imageupdate();
	        update = 0;
	      }
	      do {
	        key = (unsigned char)channelin(keyboard);
	      }
	      while (key == 0);
	      switch (key) {
	        case 13 :
	        case 27 :
	        case 32 :
	          menu = 1;
	          break;
	        case 'c' :
	        case 'C' :
	          menu = 2;
	          break;
	        case 'd' :
	        case 'D' :
	          menu = 3;
	          break;
	        case 'k' :
	        case 'K' :
	          menu = 4;
	          break;
	        case 'm' :
	        case 'M' :
	          menu = 5;
	          break;
	        case 'n' :
	        case 'N' :
	          menu = 6;
	          break;
	        case 'v' :
	        case 'V' :
	          menu = 7;
	          break;
	        case 'q' :
	        case 'Q' :
	          stringwrite(window, "\r\rQuit to DOS: Are you sure? (y/n)");
	          imageupdate();
		  do {
		    key = (unsigned char)channelin(keyboard);
		  }
		  while ((key == 0) && (!exitprogram));
		  if ((key == 'y') || (key == 'Y') || (exitprogram)) {
		    menu = 1;
		    exitprogram = 1;
		  }
		  else {
		    update = 1;
		  }
		  key = 0;
	          break;
	      } /* switch (key) */
	    }
	    while (menu == 0);
	    channelclose(keyboard);
	    channelclose(window);
	  }
	  screenrestore(screen);
	  switch (menu) {
	    case 2 :
	      cpumenu();
	      break;
	    case 3 :
	      drivemenu();
	      break;
	    case 4 :
	      keyboardmenu();
	      break;
	    case 5 :
	      memorymenu();
	      break;
	    case 6 :
	      soundmenu();
	      break;
	    case 7 :
	      virtmenu();
	      break;
	  } /* switch (menu) */
	} while (menu != 1);

      } /* mainmenu */


/*-------------------------------------*/


      int main () {
	unsigned int keyprotocol;
	unsigned int winprotocol;

/* prevent ^C from killing us -uso. (2002.0130) */
//      signal (SIGINT, SIG_IGN);
        _go32_want_ctrl_break(0);
        __djgpp_set_ctrl_c(0);

/* initialize global variables */
	keyboard	= 0;
	window		= 0;
	cwdxchgslash(callingpath, 260);		/* store original directory at calling Dapple */

/* initialize asm library */
	asmopen();

/* set resolution */
	if (screensetresolution(640,400,8)) {
	  if (screensetresolution(640,480,8)) {
	    goto endofprogram2;
	  }
	}

/* open emulation window */
	if (windowaddio( -1, -1, 640, 400, 0, 0, NULL, &keyboard, &window)) { goto endofprogram2; }
	imagefillbox(window, 0, 0, 640, 400, 0x000000);

	if (windowaddio( -1, -1, 544, 304, -1, 1, "Protocol", &keyprotocol, &winprotocol)) { goto endofprogram; }

	stringwrite(winprotocol, "Welcome to Dapple ][ ");
	stringwrite(winprotocol, DappleVersion);
	stringwrite(winprotocol, " experimental version\r");
	stringwrite(winprotocol, "=============================================\r\r");
	imageupdate();

	messagecount = 0;
	messageflag = 0;

/* initialize default values */

	strcpy(inidiskpath1, "");
	strcpy(inidiskpath2, "");
	inicpudelay	= 0x120;
	inidebugflag	= 0;
	inicharmode	= USA;

/* initialize emulator */

	memoryinit();
	driveinit();
	cpuinit();
	keyboardinit();
	soundinit();
	virtinit();

/* get default values from file */

	readini();

/* automatic search for rom file */

	if (!memoryautoloadrom(keyprotocol, winprotocol)) { goto endofprogram; }


	if (inidiskpath1[0]) {
	  if (!driveload(keyprotocol, winprotocol, drivedata1, inidiskpath1)) {
	    strcpy(inidiskpath1, "");
	  }
	}
	if (inidiskpath2[0]) {
	  if (!driveload(keyprotocol, winprotocol, drivedata2, inidiskpath2)) {
	    strcpy(inidiskpath2, "");
	  }
	}
	channelclose(keyprotocol);
	channelclose(winprotocol);

	imagefillbox(window, 40, 8, 559 + 40, 391, 0x000000);
	messageflag = 1;	/* allow messages */
	setmessage("Welcome to the new experimental Dapple ][. Have fun!");
	cpusetdelay(inicpudelay);
	mainmenu();
	if (!exitprogram) {
	  cpurun();
	}

	chdir(callingpath);			/* restore original directory at calling Dapple */
	writeini();

endofprogram:
	channelclose(window);
	channelclose(keyboard);

endofprogram2:
	asmclose();

	return 0;

      } /* main */
