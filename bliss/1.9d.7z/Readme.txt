Bliss!

WHAT IS BLISS
Bliss is an Intellivision emulator which allows you to play 
Intellivision games without an Intellivision.  Since Bliss is released 
under the terms of the GNU Public License (GPL), you must agree to the 
terms of the GPL to use Bliss.  The complete terms of the GPL license 
can be found in the file 'GPL.txt'.


WHAT ELSE DO YOU NEED TO USE BLISS

1.	You'll need images of the two ROM chips that were in the original 
Intellivision: the Executive ROM (EXEC) and the Graphics ROM (GROM).  
These files must be renamed to be "exec.bin" and "grom.bin" and they 
must be placed in the same directory as the Bliss emulator.  If you 
do not have the ability to dump these ROMs from your own 
Intellivision, they can be easily found by doing a web search.
2.	If you wish to play ECS games, you'll also need the ECS ROM image.  
You must rename this file to be "ecs.bin" and place it in the same 
directory as the Bliss emulator.
3.	If you wish to hear the Intellivoice in the games that supported it, 
you'll also need the Intellivoice ROM image. You must rename this 
file to be "ivoice.bin" and place it in the same directory as the 
Bliss emulator.
4.	Finally, you'll need some images of some cartridge ROMs.  The names 
of these do not matter.  You must places these files in the 'roms' 
subdirectory.  Bliss includes zip file support, so there is no need 
to extract the ROMs 


HOW DO I PLAY THE GAMES
Because there is currently no provision in the front-end user interface 
to reconfigure the controls to your liking, Bliss only supports the 
following keys on the keyboard for control.

    ESCAPE         Display/hide the menu
    F1             Pause the current game
    F9             Reset the current game
    0-9            Intellivision Keypad
    DELETE         Clear
    ENTER          Enter
    CTRL           Top Action Buttons
    Z              Bottom Left Action Button
    X              Bottom Right Action Button
    ARROW KEYS     Disc Pad


CONTRIBUTORS
I want to give a special "Thanks!" to the direct contributors to Bliss, 
listed below.

Kyle Davis (Me!) � Initial development of the Bliss codebase.

Jesse Litton � Develops and maintains the integrated front-end user 
interface, Simple DirectMedia Layer (SDL) drivers, and many other 
portions of the codebase.

Mike Dunston � Contributes the Linux port of Bliss, zip file support, 
general portability improvements , and many other contributions to the 
source code.

Joseph Zbiciak � Provides technical information on the Intellivision 
and continues to offer reverse engineering research.  He also provides 
all of the free GPL ROMs that are available with each of the Bliss 
releases.

Many other people have unknowingly contributed to the development of 
Bliss, either by documenting the Intellivision hardware or providing 
some other public information about the Intellivision.  Thanks very 
much for your efforts in continuing to keep the memories of the 
Intellivision alive!

