/*
 * UAE - The U*nix Amiga Emulator
 *
 * CyberVision64 Support Module Header
 *
 * Copyright 2000 Bernie Meyer
 */

#if defined CYBER64_SUPPORTED

#define CYBER64

#include "newcpu.h"

#endif
