// Implement MMAN and SHM functionality for Win32
// Copyright (C) 2000, Brian King
// GNU Public License

#ifndef _MMAN_H_
#define _MMAN_H_

#include <windows.h>
#include <stdio.h> // for size_t
#include <time.h>

#define MAX_SHMID 256

typedef int key_t;
typedef USHORT ushort;

#define BERNDROESCH

/* One shmid data structure for each shared memory segment in the system. */
struct shmid_ds {
    key_t  key;
    size_t size;
    void  *addr;
    char   name[ MAX_PATH ];
#ifdef BERNDROESCH
    void  *attached;
#else
    HANDLE filemapping;
    DWORD  attached;
#endif
};

int mprotect(void *addr, size_t len, int prot);
void *shmat(int shmid, LPVOID shmaddr, int shmflg);
int shmdt(const void *shmaddr);
int shmget(key_t key, size_t size, int shmflg, char *name);
int shmctl(int shmid, int cmd, struct shmid_ds *buf);

int isinf( double x );
int isnan( double x );

#define PROT_READ  0x01
#define PROT_WRITE 0x02
#define PROT_EXEC  0x04

#define IPC_PRIVATE 0x01
#define IPC_RMID    0x02
#define IPC_CREAT   0x04
#define IPC_STAT    0x08
#endif