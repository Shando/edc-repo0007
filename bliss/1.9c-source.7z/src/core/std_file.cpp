// std_file:  Standard File Functions.
//////////////////////////////////////////////////////

#include "std_file.h"
#include <fstream.h>


// fileExists:  See if a file exists
//
bool fileExists(const char* sFile)
{
	ifstream stream(sFile, ios::in|ios::nocreate);
//		filebuf::sh_read||filebuf::sh_write);
	if(!stream.fail()) {							// File found
		stream.close();
		return true;
	}

	return false;
}
