package com.bliss.core;

import java.io.IOException;

/**
 * Emulates a 16-bit memory map which may be composed of memories of the same
 * size or narrower (10-bit, 8-bit, etc.)
 *
 * @author Kyle Davis
 */
public class MemoryBus extends Memory
{

    public MemoryBus(int size) {
        memory = new Memory[size];
        for (int i = 0; i < memory.length; i++)
            memory[i] = unmappedMemory;
    }

    public void reset() {
        for (int i = 0; i < mappedMemoryCount; i++)
            mappedMemories[i].reset();
    }

    public void save(SaveOutputStream sos) throws IOException {
        for (int i = 0; i < mappedMemoryCount; i++)
            mappedMemories[i].save(sos);
    }

    public void load(LoadInputStream lis) throws IOException {
        for (int i = 0; i < mappedMemoryCount; i++)
            mappedMemories[i].load(lis);
    }

    public void addMemory(Memory m) {
        //get the important info
        int location = m.getLocation();
        int size = m.getSize();
        int end = location + size;

        if (m.isBanked()) {
            if (memory[location] == unmappedMemory) {
                //check to be sure no memory exists in the locations to which
                //the memory is to be mapped
                for (int i = location; i < end; i++) {
                    if (memory[i] != unmappedMemory)
                        throw new IllegalArgumentException(
                               "Memory mapping collision error at: " +
                               Integer.toString(location, 16));
                }

                //create a new MemoryBanker and map it in
                MemoryBanker mb = new MemoryBanker(location, size);
                mb.setMemoryBank(m.getBank(), m);
                for (int i = location; i < end; i++)
                    memory[i] = mb;
            }
            else if (!(memory[location] instanceof MemoryBanker)) {
                throw new IllegalArgumentException(
                       "Memory mapping collision error at: " +
                       Integer.toString(location, 16));
            }
            else if (memory[location].getLocation() != location ||
                    memory[location].getSize() != size)
            {
                throw new IllegalArgumentException(
                       "Memory mapping collision error at: " +
                       Integer.toString(location, 16));
            }
            else {
                MemoryBanker mb = (MemoryBanker)memory[location];
                if (mb.getMemoryBank(m.getBank()) != null) {
                    throw new IllegalArgumentException(
                           "Memory mapping collision error at: " +
                           Integer.toString(location, 16));
                }

                //just add this memory to the memory banker
                mb.setMemoryBank(m.getBank(), m);
            }
        }
        else {
            //check to be sure no memory exists in the locations to which
            //the memory is to be mapped
            for (int i = location; i < end; i++) {
                if (memory[i] != unmappedMemory)
                    throw new IllegalArgumentException(
                           "Memory mapping collision error at: " +
                           Integer.toString(location, 16));
            }

            //we're OK, so just map the memory
            for (int i = location; i < end; i++)
                memory[i] = m;
        }

        //this memory was successfully mapped, so add it to our list
        mappedMemories[mappedMemoryCount] = m;
        mappedMemoryCount++;
    }

    public void removeMemory(Memory m) {
        for (int i = 0; i < mappedMemoryCount; i++) {
            if (mappedMemories[i] == m) {
                for (int j = i; j < (mappedMemoryCount-1); j++)
                    mappedMemories[j] = mappedMemories[j+1];
                mappedMemoryCount--;

                int location = m.getLocation();
                int size = m.getSize();
                int end = location + size;
                if (m.isBanked()) {
                    MemoryBanker mb = (MemoryBanker)memory[location];
                    mb.setMemoryBank(m.getBank(), null);
                    boolean bankerEmpty = true;
                    for (int b = 0; b < 16; b++) {
                        if (mb.getMemoryBank(b) != null)
                            bankerEmpty = false;
                    }
                    if (bankerEmpty)
                        for (int j = location; j < end; j++)
                            memory[j] = unmappedMemory;
                }
                else {
                    for (int j = location; j < end; j++)
                        memory[j] = unmappedMemory;
                }
            }
        }

    }

    public int getLocation() {
        return 0;
    }

    public int peek(int location) {
        return memory[location].peek(location);
    }

    public void poke(int location, int value) {
        memory[location].poke(location, value);
    }

    public int getSize() {
        return memory.length;
    }

    private Memory[] mappedMemories = new Memory[MAX_MAPPED_MEMORIES];
    private int      mappedMemoryCount;

    //we are going to make this memory array package accessible to decrease
    //the performance issues with MemoryBus.peek();
    Memory[] memory;

    private final static int MAX_MAPPED_MEMORIES = 50;

    //we'll use this for unmapped memory references
    protected Memory unmappedMemory = new Memory() {
            public void reset() {}
            public void save(SaveOutputStream sos) throws IOException {}
            public void load(LoadInputStream lis) throws IOException {}
            public int getSize() {
                return 1;
            }
            public int getLocation() {
                return 0;
            }
            public void poke(int location, int value) {
            }
            public int peek(int location) {
                return UNMAPPED_PEEK;
            }
        };

}
