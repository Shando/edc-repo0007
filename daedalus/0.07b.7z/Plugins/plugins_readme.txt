Currently Daedalus only supports plugins that conform to Zilmar's audio
plugin spec. Thanks to Azimer, Daedalus now ships with a demo of his
forthcoming pluging for TrueReality. This demos plugin works with all
ABI 1 ucodes.

When you get the plugin, copy it to the Plugins directory and run Daedalus.
You can select the audio plugin to use from the Config->Audio Configuration...
menu option. When you select the plugin, you must restart Daedalus for the 
changes to stake effect.

