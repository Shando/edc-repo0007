// Win32Functions - native method interface DLL to selected Win32 functions

#include <windows.h>
#include <iostream>
#include <stdio.h>
#include "DirectXVideoOutputDevice.h"

using namespace std;

//error messages
const CHAR* videoErrorMessages[12] = {
    "Unable to initialize window",
    "Unable to retrieve video mode",
    "Unable to set requested video mode",
    "Request for memory-based texture failed",
    "Request for hardware texture failed",
    "Request for vertex buffer failed",
    "Unable to lock vertex buffer",
    "Request to clear back buffer failed",
    "Request for DirectX 8.0 compatible device failed",
    "Unable to get surface attributes",
    "Unable to get drawing buffer",
    "Cannot create font",
};

//function prototypes
LRESULT CALLBACK MsgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

struct CUSTOMVERTEX
{
    FLOAT       x, y, z, rhw;
    FLOAT       tu, tv;
};

//the window class
WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC | CS_VREDRAW | CS_HREDRAW,
        MsgProc, 0L, 0L, GetModuleHandle(NULL), NULL,
        LoadCursor(NULL, IDC_ARROW) , NULL, NULL, "BlissDirectXWindow",
        NULL };


#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZRHW|D3DFVF_TEX1)

BYTE g_P8Palette[32] = {
    0x00, 0x01, 0x02, 0x03,
    0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0A, 0x0B,
    0x0C, 0x0D, 0x0E, 0x0F,
    0x00, 0x01, 0x02, 0x03,
    0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0A, 0x0B,
    0x0C, 0x0D, 0x0E, 0x0F,
};

WORD g_R5G6B5Palette[32] = {
    0x0000, 0x017F, 0xF9E1, 0xC694,
    0x3368, 0x054B, 0xF749, 0xFFDF,
    0xBD58, 0x2DBF, 0xFD84, 0x5B80,
    0xFA8B, 0xA4DF, 0x7E4F, 0xB8EA,
    0x0000, 0x017F, 0xF9E1, 0xC694,
    0x3368, 0x054B, 0xF749, 0xFFDF,
    0xBD58, 0x2DBF, 0xFD84, 0x5B80,
    0xFA8B, 0xA4DF, 0x7E4F, 0xB8EA,
};

WORD g_X1R5G5B5Palette[32] = {
    0x0000, 0x00DF, 0x7D01, 0x6354,
    0x19A8, 0x02AB, 0x7B89, 0x7FFF,
    0x5EB8, 0x16DF, 0x7EC4, 0x2DC0,
    0x7D4B, 0x527F, 0x3F2F, 0x5C6A,
    0x0000, 0x00DF, 0x7D01, 0x6354,
    0x19A8, 0x02AB, 0x7B89, 0x7FFF,
    0x5EB8, 0x16DF, 0x7EC4, 0x2DC0,
    0x7D4B, 0x527F, 0x3F2F, 0x5C6A,
};

DWORD g_R8G8B8Palette[32] = {
    0x000000, 0x002DFF, 0xFF3D10, 0xC9CFAB,
    0x386B3F, 0x00A756, 0xFAEA50, 0xFFFCFF,
    0xBDACC8, 0x24B8FF, 0xFFB41F, 0x546E00,
    0xFF4E57, 0xA496FF, 0x75CC80, 0xB51A58,
    0x000000, 0x002DFF, 0xFF3D10, 0xC9CFAB,
    0x386B3F, 0x00A756, 0xFAEA50, 0xFFFCFF,
    0xBDACC8, 0x24B8FF, 0xFFB41F, 0x546E00,
    0xFF4E57, 0xA496FF, 0x75CC80, 0xB51A58,
};

DWORD g_A8R8G8B8Palette[32] = {
    0xFF000000, 0xFF002DFF, 0xFFFF3D10, 0xFFC9CFAB,
    0xFF386B3F, 0xFF00A756, 0xFFFAEA50, 0xFFFFFCFF,
    0xFFBDACC8, 0xFF24B8FF, 0xFFFFB41F, 0xFF546E00,
    0xFFFF4E57, 0xFFA496FF, 0xFF75CC80, 0xFFB51A58,
    0xFF000000, 0xFF002DFF, 0xFFFF3D10, 0xFFC9CFAB,
    0xFF386B3F, 0xFF00A756, 0xFFFAEA50, 0xFFFFFCFF,
    0xFFBDACC8, 0xFF24B8FF, 0xFFFFB41F, 0xFF546E00,
    0xFFFF4E57, 0xFFA496FF, 0xFF75CC80, 0xFFB51A58,
};

PALETTEENTRY g_A8R8G8B8PaletteEntries[32] = {
    { 0x00, 0x00, 0x00, 0xFF }, //BLACK
    { 0x00, 0x2D, 0xFF, 0xFF }, //BLUE
    { 0xFF, 0x3D, 0x10, 0xFF }, //RED
    { 0xC9, 0xCF, 0xAB, 0xFF }, //TAN
    { 0x38, 0x6B, 0x3F, 0xFF }, //DARK GREEN
    { 0x00, 0xA7, 0x56, 0xFF }, //GREEN
    { 0xFA, 0xEA, 0x50, 0xFF }, //YELLOW
    { 0xFF, 0xFC, 0xFF, 0xFF }, //WHITE
    { 0xBD, 0xAC, 0xC8, 0xFF }, //GRAY
    { 0x24, 0xB8, 0xFF, 0xFF }, //CYAN
    { 0xFF, 0xB4, 0x1F, 0xFF }, //ORANGE
    { 0x54, 0x6E, 0x00, 0xFF }, //BROWN
    { 0xFF, 0x4E, 0x57, 0xFF }, //PINK
    { 0xA4, 0x96, 0xFF, 0xFF }, //LIGHT BLUE
    { 0x75, 0xCC, 0x80, 0xFF }, //YELLOW GREEN
    { 0xB5, 0x1A, 0x58, 0xFF }, //PURPLE
    { 0x00, 0x00, 0x00, 0xFF }, //BLACK
    { 0x00, 0x2D, 0xFF, 0xFF }, //BLUE
    { 0xFF, 0x3D, 0x10, 0xFF }, //RED
    { 0xC9, 0xCF, 0xAB, 0xFF }, //TAN
    { 0x38, 0x6B, 0x3F, 0xFF }, //DARK GREEN
    { 0x00, 0xA7, 0x56, 0xFF }, //GREEN
    { 0xFA, 0xEA, 0x50, 0xFF }, //YELLOW
    { 0xFF, 0xFC, 0xFF, 0xFF }, //WHITE
    { 0xBD, 0xAC, 0xC8, 0xFF }, //GRAY
    { 0x24, 0xB8, 0xFF, 0xFF }, //CYAN
    { 0xFF, 0xB4, 0x1F, 0xFF }, //ORANGE
    { 0x54, 0x6E, 0x00, 0xFF }, //BROWN
    { 0xFF, 0x4E, 0x57, 0xFF }, //PINK
    { 0xA4, 0x96, 0xFF, 0xFF }, //LIGHT BLUE
    { 0x75, 0xCC, 0x80, 0xFF }, //YELLOW GREEN
    { 0xB5, 0x1A, 0x58, 0xFF }, //PURPLE
};

DirectXVideoOutputDevice* currentDevice;


const INT32 DirectXVideoOutputDevice::DEFAULT_RESOLUTION_WIDTH = 640;
const INT32 DirectXVideoOutputDevice::DEFAULT_RESOLUTION_HEIGHT = 480;

DirectXVideoOutputDevice::DirectXVideoOutputDevice()
    : modes(NULL),
      modeCount(0),
      is32bit(FALSE),
      m_paStretch(NULL),
      fullScreen(FALSE),
      stretchMode(STRETCH_SOFTWARE),
      filtered(FALSE),
      defaultFullScreenMode(NULL)
{
	m_bHardware		= false;
    m_pD3D          = NULL;
    m_pd3dDevice    = NULL;
    m_pBackBuffer   = NULL;
    m_pCardTexture  = NULL;
    m_pMemTexture   = NULL;
    m_pVB           = NULL;

	m_pBigFont		= NULL;
	m_pSmallFont	= NULL;

    m_width         = DEFAULT_RESOLUTION_WIDTH;
    m_height        = DEFAULT_RESOLUTION_HEIGHT;

    getDisplayModes();
}

DirectXVideoOutputDevice::~DirectXVideoOutputDevice()
{
	destroyResources();		// Used when menu is brought up but exit chosen
	destroyDirectX();
}

void DirectXVideoOutputDevice::setFullScreenMode(BOOL b)
{
    if (!b || (b && defaultFullScreenMode))
        fullScreen = b;

    return;
}

BOOL DirectXVideoOutputDevice::isFullScreenMode()
{
    return fullScreen;
}

void DirectXVideoOutputDevice::setStretchMode(STRETCHMODE mode)
{
    this->stretchMode = mode;
}

STRETCHMODE DirectXVideoOutputDevice::getStretchMode() 
{
    return stretchMode;
}

INT32 DirectXVideoOutputDevice::init(const CHAR* windowTitle)
{
    stop = FALSE;

    //this becomes the current device
    currentDevice = this;

    // Set the window icon
    //
    // I'm not sure how well this will translate to the java versions,
    // since I'm unfamiliar with how they handle resources.  Your icon
    // should have an ID of 101.
    // 
    // If it doesn't work, just comment out this line.
    wc.hIcon = LoadIcon(wc.hInstance, MAKEINTRESOURCE(101));

    //initialize the window
    INT32 status = initWindow(windowTitle);
    if (status != 0)
        return status;

    //initialize DirectX
    status = initDirectX();
    if (status != 0) {
        destroyWindow();
        return status;
    }

    status = createResources();
    if (status != 0) {
        destroyDirectX();
        destroyWindow();
        return status;
    }

    //clear the back buffer to black
    m_pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET,
            D3DCOLOR_XRGB(0,0,0), 1.0f, 0L);

    //display the now cleared back buffer
    if (FAILED(m_pd3dDevice->Present(NULL, NULL, NULL, NULL)))
    {
        destroyDirectX();
        destroyWindow();
        return ERR_REQUEST_TO_CLEAR_BACK_BUFFER_FAILED;
    }

    ValidateRect(m_hWnd, NULL);
    paintNeeded = FALSE;

    //pump any pending window messages through before we return
    MSG	msg;
    while (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}

const CHAR* DirectXVideoOutputDevice::getErrorDescription(INT32 errorCode)
{
    return videoErrorMessages[errorCode-1];
}

void DirectXVideoOutputDevice::displayImage(UINT8* image, BOOL hasChanged)
{
    //pump any pending window messages through
    MSG	msg;
    while (PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE)) {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    //discard the image if it has not changed and if we do not need to
    //repaint a damaged display
    if (!hasChanged && !paintNeeded)
        return;
    paintNeeded = FALSE;

    //check if the device was lost and try to reset it if possible
    HRESULT result;
    if ((result = m_pd3dDevice->TestCooperativeLevel()) != D3D_OK) {
        if (result != D3DERR_DEVICENOTRESET) {
            return;
        }

        destroyResources();
        if (m_pd3dDevice->Reset(&presentation) != D3D_OK) {
            return;
        }

        if (createResources() != 0) {
            return;
        }

        if (m_pd3dDevice->TestCooperativeLevel() != D3D_OK) {
            return;
        }
    }

    //now render the image onto the device
    switch (stretchMode) {
        case STRETCH_HARDWARE3D:
            displayImageUsingTexturedPolygon(this, image);
            //present the new image
            if (FAILED(m_pd3dDevice->Present(NULL, NULL, NULL, NULL))) {
                return;
            }
            break;
        case STRETCH_HARDWARE2D:
            {
            displayImageUsingSoftwareCopyHardwareStretch(this, image);
            //present AND STRETCH the new image
            RECT rect = { 0, 0, 320, 192 };
            if (FAILED(m_pd3dDevice->Present(&rect, NULL, NULL, NULL))) {
                return;
            }
            }
            break;
        case STRETCH_SOFTWARE:
            displayImageUsingPrecalculatedStretch(this, image);
            //present the new image
            if (FAILED(m_pd3dDevice->Present(NULL, NULL, NULL, NULL))) {
                return;
            }
            break;
    }
}

//direct software copy and precalculated stretch into the back buffer
void displayImageUsingPrecalculatedStretch(
        DirectXVideoOutputDevice* thisDevice, UINT8* image)
{
    //lock the backbuffer
    D3DLOCKED_RECT locked;
    if (FAILED(thisDevice->m_pBackBuffer->LockRect(&locked, NULL, 0))) {
        return;
    }

    //copy and stretch the image
    if (thisDevice->is32bit) {
        DWORD* backBuffer = (DWORD*)locked.pBits;
        DWORD* palette = (DWORD*)thisDevice->m_pMemPalette;
        INT32 pitch = locked.Pitch>>2;
        INT32 x = 0, y = 0, z = 0, nextbyte = 0;
        for (y = 0; y < thisDevice->m_height; y++) {
            for (x = 0; x < thisDevice->m_width; x++) {
                backBuffer[z+x] = palette[image[
                        thisDevice->m_paStretch[nextbyte]]];
                nextbyte++;
            }
            z += pitch;
        }
    }
    else {
        WORD* backBuffer = (WORD*)locked.pBits;
        WORD* palette = (WORD*)thisDevice->m_pMemPalette;
        INT32 pitch = locked.Pitch>>1;
        INT32 x = 0, y = 0, z = 0, nextbyte = 0, diff = 0;
        INT32 targetWidth = thisDevice->m_width-10;
        for (y = 0; y < thisDevice->m_height; y++) {
            for (x = 0; x < targetWidth; x+=10) {
                backBuffer[z+x] = palette[image[
                        thisDevice->m_paStretch[nextbyte]]];
                backBuffer[z+x+1] = palette[image[
                        thisDevice->m_paStretch[nextbyte+1]]];
                backBuffer[z+x+2] = palette[image[
                        thisDevice->m_paStretch[nextbyte+2]]];
                backBuffer[z+x+3] = palette[image[
                        thisDevice->m_paStretch[nextbyte+3]]];
                backBuffer[z+x+4] = palette[image[
                        thisDevice->m_paStretch[nextbyte+4]]];
                backBuffer[z+x+5] = palette[image[
                        thisDevice->m_paStretch[nextbyte+5]]];
                backBuffer[z+x+6] = palette[image[
                        thisDevice->m_paStretch[nextbyte+6]]];
                backBuffer[z+x+7] = palette[image[
                        thisDevice->m_paStretch[nextbyte+7]]];
                backBuffer[z+x+8] = palette[image[
                        thisDevice->m_paStretch[nextbyte+8]]];
                backBuffer[z+x+9] = palette[image[
                        thisDevice->m_paStretch[nextbyte+9]]];
                nextbyte+=10;
            }
            diff = thisDevice->m_width-x;
            switch (diff) {
                case 10:
                    backBuffer[z+x+9] = palette[image[
                            thisDevice->m_paStretch[nextbyte+9]]];
                case 9:
                    backBuffer[z+x+8] = palette[image[
                            thisDevice->m_paStretch[nextbyte+8]]];
                case 8:
                    backBuffer[z+x+7] = palette[image[
                            thisDevice->m_paStretch[nextbyte+7]]];
                case 7:
                    backBuffer[z+x+6] = palette[image[
                            thisDevice->m_paStretch[nextbyte+6]]];
                case 6:
                    backBuffer[z+x+5] = palette[image[
                            thisDevice->m_paStretch[nextbyte+5]]];
                case 5:
                    backBuffer[z+x+4] = palette[image[
                            thisDevice->m_paStretch[nextbyte+4]]];
                case 4:
                    backBuffer[z+x+3] = palette[image[
                            thisDevice->m_paStretch[nextbyte+3]]];
                case 3:
                    backBuffer[z+x+2] = palette[image[
                            thisDevice->m_paStretch[nextbyte+2]]];
                case 2:
                    backBuffer[z+x+1] = palette[image[
                            thisDevice->m_paStretch[nextbyte+1]]];
                case 1:
                    backBuffer[z+x] = palette[image[
                            thisDevice->m_paStretch[nextbyte]]];
            }
            nextbyte += diff;
            z += pitch;
        }
    }

    //unlock the back buffer
    if (FAILED(thisDevice->m_pBackBuffer->UnlockRect())) {
        return;
    }

}

//use a polygon to display and stretch the image
void displayImageUsingTexturedPolygon(
        DirectXVideoOutputDevice* thisDevice, UINT8* image)
{
    //lock the rectangle in the texture that we're going to update
    D3DLOCKED_RECT locked;
    RECT rect = { 0, 0, 160, 192 };
    if (FAILED(thisDevice->m_pMemTexture->LockRect(0, &locked, &rect, 0))) {
        return;
    }

    //copy the image data into the memory texture
    WORD* backBuffer = (WORD*)locked.pBits;
    WORD* palette = (WORD*)thisDevice->m_pMemPalette;
    INT32 x = 0;
    INT32 y = 0;
    for (INT32 i = 0; i < 61440; i += 64) {
        backBuffer[y+x]    = palette[image[i]];
        backBuffer[y+x+1]  = palette[image[i+2]];
        backBuffer[y+x+2]  = palette[image[i+4]];
        backBuffer[y+x+3]  = palette[image[i+6]];
        backBuffer[y+x+4]  = palette[image[i+8]];
        backBuffer[y+x+5]  = palette[image[i+10]];
        backBuffer[y+x+6]  = palette[image[i+12]];
        backBuffer[y+x+7]  = palette[image[i+14]];
        backBuffer[y+x+8]  = palette[image[i+16]];
        backBuffer[y+x+9]  = palette[image[i+18]];
        backBuffer[y+x+10] = palette[image[i+20]];
        backBuffer[y+x+11] = palette[image[i+22]];
        backBuffer[y+x+12] = palette[image[i+24]];
        backBuffer[y+x+13] = palette[image[i+26]];
        backBuffer[y+x+14] = palette[image[i+28]];
        backBuffer[y+x+15] = palette[image[i+30]];
        backBuffer[y+x+16] = palette[image[i+32]];
        backBuffer[y+x+17] = palette[image[i+34]];
        backBuffer[y+x+18] = palette[image[i+36]];
        backBuffer[y+x+19] = palette[image[i+38]];
        backBuffer[y+x+20] = palette[image[i+40]];
        backBuffer[y+x+21] = palette[image[i+42]];
        backBuffer[y+x+22] = palette[image[i+44]];
        backBuffer[y+x+23] = palette[image[i+46]];
        backBuffer[y+x+24] = palette[image[i+48]];
        backBuffer[y+x+25] = palette[image[i+50]];
        backBuffer[y+x+26] = palette[image[i+52]];
        backBuffer[y+x+27] = palette[image[i+54]];
        backBuffer[y+x+28] = palette[image[i+56]];
        backBuffer[y+x+29] = palette[image[i+58]];
        backBuffer[y+x+30] = palette[image[i+60]];
        backBuffer[y+x+31] = palette[image[i+62]];
        x += 32;
        if (x == 160) {
            x = 0;
            y += thisDevice->m_pMemDesc.Width;
        }
    }

    //unlock the rectangle in the texture
    if (FAILED(thisDevice->m_pMemTexture->UnlockRect(0))) {
        return;
    }

    //render the polygon on the screen
    if (FAILED(thisDevice->m_pd3dDevice->BeginScene())) {
        return;
    }
    //update the hardware texture
    if (FAILED(thisDevice->m_pd3dDevice->UpdateTexture(
            thisDevice->m_pMemTexture, thisDevice->m_pCardTexture)))
    {
        return;
    }
    if (FAILED(thisDevice->m_pd3dDevice->SetTexture(0, thisDevice->m_pCardTexture)))
    {
        return;
    }
    if (FAILED(thisDevice->m_pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP,
            D3DTOP_SELECTARG1)))
    {
        return;
    }
    if (FAILED(thisDevice->m_pd3dDevice->SetTextureStageState(0,
            D3DTSS_COLORARG1,
            D3DTA_TEXTURE)))
    {
        return;
    }
    if (thisDevice->filtered) {
        if (FAILED(thisDevice->m_pd3dDevice->SetTextureStageState(0,
                D3DTSS_MAGFILTER, D3DTEXF_LINEAR)))
        {
            return;
        }
    }
    if (FAILED(thisDevice->m_pd3dDevice->SetStreamSource(0, thisDevice->m_pVB,
             sizeof(CUSTOMVERTEX))))
    {
        return;
    }
    if (FAILED(thisDevice->m_pd3dDevice->SetVertexShader(D3DFVF_CUSTOMVERTEX)))
    {
        return;
    }
    if (FAILED(thisDevice->m_pd3dDevice->DrawPrimitive(
            D3DPT_TRIANGLESTRIP, 0, 2)))
    {
        return;
    }
    if (FAILED(thisDevice->m_pd3dDevice->SetTexture(0, NULL))) {
        return;
    }
	if (FAILED(thisDevice->m_pd3dDevice->EndScene())) {
        return;
    }
}

//direct software copy into the back buffer and stretch with Present()
void displayImageUsingSoftwareCopyHardwareStretch(
        DirectXVideoOutputDevice* thisDevice, UINT8* image)
{
    //lock the upper left 320x192 of the back buffer
    D3DLOCKED_RECT locked;
    RECT rect = { 0, 0, 320, 192 };
    if (FAILED(thisDevice->m_pBackBuffer->LockRect(&locked, &rect, 0))) {
        return;
    }

    //copy the image into the back buffer without stretching
    WORD* backBuffer = (WORD*)locked.pBits;
    WORD* palette = (WORD*)thisDevice->m_pMemPalette;
    int n = 0;
    for (int i = 0; i < 61440; i += 64) {
        backBuffer[n] = palette[image[i]];
        backBuffer[n+1] = palette[image[i+1]];
        backBuffer[n+2] = palette[image[i+2]];
        backBuffer[n+3] = palette[image[i+3]];
        backBuffer[n+4] = palette[image[i+4]];
        backBuffer[n+5] = palette[image[i+5]];
        backBuffer[n+6] = palette[image[i+6]];
        backBuffer[n+7] = palette[image[i+7]];
        backBuffer[n+8] = palette[image[i+8]];
        backBuffer[n+9] = palette[image[i+9]];
        backBuffer[n+10] = palette[image[i+10]];
        backBuffer[n+11] = palette[image[i+11]];
        backBuffer[n+12] = palette[image[i+12]];
        backBuffer[n+13] = palette[image[i+13]];
        backBuffer[n+14] = palette[image[i+14]];
        backBuffer[n+15] = palette[image[i+15]];
        backBuffer[n+16] = palette[image[i+16]];
        backBuffer[n+17] = palette[image[i+17]];
        backBuffer[n+18] = palette[image[i+18]];
        backBuffer[n+19] = palette[image[i+19]];
        backBuffer[n+20] = palette[image[i+20]];
        backBuffer[n+21] = palette[image[i+21]];
        backBuffer[n+22] = palette[image[i+22]];
        backBuffer[n+23] = palette[image[i+23]];
        backBuffer[n+24] = palette[image[i+24]];
        backBuffer[n+25] = palette[image[i+25]];
        backBuffer[n+26] = palette[image[i+26]];
        backBuffer[n+27] = palette[image[i+27]];
        backBuffer[n+28] = palette[image[i+28]];
        backBuffer[n+29] = palette[image[i+29]];
        backBuffer[n+30] = palette[image[i+30]];
        backBuffer[n+31] = palette[image[i+31]];
        backBuffer[n+32] = palette[image[i+32]];
        backBuffer[n+33] = palette[image[i+33]];
        backBuffer[n+34] = palette[image[i+34]];
        backBuffer[n+35] = palette[image[i+35]];
        backBuffer[n+36] = palette[image[i+36]];
        backBuffer[n+37] = palette[image[i+37]];
        backBuffer[n+38] = palette[image[i+38]];
        backBuffer[n+39] = palette[image[i+39]];
        backBuffer[n+40] = palette[image[i+40]];
        backBuffer[n+41] = palette[image[i+41]];
        backBuffer[n+42] = palette[image[i+42]];
        backBuffer[n+43] = palette[image[i+43]];
        backBuffer[n+44] = palette[image[i+44]];
        backBuffer[n+45] = palette[image[i+45]];
        backBuffer[n+46] = palette[image[i+46]];
        backBuffer[n+47] = palette[image[i+47]];
        backBuffer[n+48] = palette[image[i+48]];
        backBuffer[n+49] = palette[image[i+49]];
        backBuffer[n+50] = palette[image[i+50]];
        backBuffer[n+51] = palette[image[i+51]];
        backBuffer[n+52] = palette[image[i+52]];
        backBuffer[n+53] = palette[image[i+53]];
        backBuffer[n+54] = palette[image[i+54]];
        backBuffer[n+55] = palette[image[i+55]];
        backBuffer[n+56] = palette[image[i+56]];
        backBuffer[n+57] = palette[image[i+57]];
        backBuffer[n+58] = palette[image[i+58]];
        backBuffer[n+59] = palette[image[i+59]];
        backBuffer[n+60] = palette[image[i+60]];
        backBuffer[n+61] = palette[image[i+61]];
        backBuffer[n+62] = palette[image[i+62]];
        backBuffer[n+63] = palette[image[i+63]];
        n += 64;
        if (!(n % 320))
            n += thisDevice->m_BackDesc.Width-320;
    }

    //unlock the back buffer
    if (FAILED(thisDevice->m_pBackBuffer->UnlockRect())) {
        return;
    }

}

void DirectXVideoOutputDevice::release() {
    //clean up DirectX
    destroyResources();
    destroyDirectX();

    //destroy the window
    destroyWindow();

    //give Win32Mutex a chance to release (required for fullscreen in
    //Win2000 only)
    if (fullScreen)
        Sleep(500);
} 

INT32 DirectXVideoOutputDevice::initWindow(const CHAR* windowTitle)
{
    //register the window class
    RegisterClassEx(&wc);

    DWORD windowStyle = WS_OVERLAPPED |
            (!fullScreen ? WS_CAPTION | WS_THICKFRAME | WS_SYSMENU : 0);

    //center the window on the desktop
    RECT windowRect;
    HWND desktopWnd;
    desktopWnd = GetDesktopWindow();
    RECT desktopDimensions;
    GetWindowRect(desktopWnd, &desktopDimensions);
    windowRect.left = ((desktopDimensions.right-desktopDimensions.left)-
            m_width)/2;
    windowRect.top = ((desktopDimensions.bottom-desktopDimensions.top)-
            m_height)/2;
    windowRect.right = windowRect.left + m_width;
    windowRect.bottom = windowRect.top + m_height;
    if (!fullScreen)
        AdjustWindowRect(&windowRect, windowStyle, FALSE);

    //create a window of the class
    m_hWnd = CreateWindow("BlissDirectXWindow",
            windowTitle, windowStyle,
            windowRect.left, windowRect.top,
            windowRect.right-windowRect.left,
            windowRect.bottom-windowRect.top,
            NULL, NULL, GetModuleHandle(NULL), NULL);

    if (m_hWnd == NULL)
        return ERR_UNABLE_TO_INIT_WINDOW;

    //finally, show the window
    ShowWindow(m_hWnd, SW_SHOWNORMAL);
    BringWindowToTop(m_hWnd);
    UpdateWindow(m_hWnd);

    return 0;
}

void DirectXVideoOutputDevice::destroyWindow()
{
    if (m_hWnd) {
        DestroyWindow(m_hWnd);

        //wait for the message pump to empty
        MSG	msg;
        while(GetMessage(&msg, NULL, 0, 0)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }

		m_hWnd = NULL;
    }

    //unregister the window class
    UnregisterClass(wc.lpszClassName, wc.hInstance);
}

INT32 DirectXVideoOutputDevice::initDirectX()
{
    //initialize DirectX
    if((m_pD3D = Direct3DCreate8(D3D_SDK_VERSION)) == NULL) {
        return ERR_INCORRECT_API_LEVEL;
    }

    //get the current display mode
    D3DDISPLAYMODE d3ddm;
    if(FAILED(m_pD3D->GetAdapterDisplayMode(D3DADAPTER_DEFAULT,
            &d3ddm)))
    {
        m_pD3D->Release();
        m_pD3D = NULL;
        return ERR_UNABLE_TO_RETRIEVE_VIDEO_MODE;
    }

    //set up our request for a DirectX device
    ZeroMemory(&presentation, sizeof(presentation));
    presentation.BackBufferWidth = m_width;
    presentation.BackBufferHeight = m_height;
    presentation.BackBufferFormat =
            (fullScreen ? defaultFullScreenMode->Format : d3ddm.Format);
    presentation.BackBufferCount = 1;
    presentation.MultiSampleType = D3DMULTISAMPLE_NONE;
    switch (stretchMode) {
        case STRETCH_HARDWARE3D:
            presentation.SwapEffect = D3DSWAPEFFECT_DISCARD;
            break;
        case STRETCH_HARDWARE2D:
            presentation.SwapEffect = D3DSWAPEFFECT_COPY;
            break;
        case STRETCH_SOFTWARE:
        default:
            presentation.SwapEffect = D3DSWAPEFFECT_FLIP;
            break;
    }
    presentation.hDeviceWindow = m_hWnd;
    presentation.Windowed = !fullScreen;
    presentation.EnableAutoDepthStencil = FALSE;
    presentation.Flags = D3DPRESENTFLAG_LOCKABLE_BACKBUFFER;
    presentation.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
    presentation.FullScreen_PresentationInterval = D3DPRESENT_INTERVAL_DEFAULT;


    //request the DirectX device
	HRESULT rCode = m_pD3D->CreateDevice(D3DADAPTER_DEFAULT,
            D3DDEVTYPE_HAL, m_hWnd,
            D3DCREATE_SOFTWARE_VERTEXPROCESSING, &presentation,
            &m_pd3dDevice);
    if(FAILED(rCode))
    {
		if(FAILED(m_pD3D->CreateDevice(D3DADAPTER_DEFAULT,
				D3DDEVTYPE_REF, m_hWnd,
				D3DCREATE_SOFTWARE_VERTEXPROCESSING, &presentation,
				&m_pd3dDevice)))
		{
			m_pD3D->Release();
			m_pD3D = NULL;
			return ERR_UNABLE_TO_SET_REQUESTED_VIDEO_MODE;
		}
    }
	else {
		m_bHardware = true;
	}


    return 0;
}

bool DirectXVideoOutputDevice::deviceIsHAL() {
	return m_bHardware;
}


INT32 DirectXVideoOutputDevice::createResources()
{
	m_nRelative = (m_width / 320);

	// Create font for DrawText
	AddFontResource("intellec.ttf");
    HFONT hFont    = CreateFont( (m_nRelative * 16), 0, 0, 0, FW_NORMAL, FALSE,
                          FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                          CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
                          VARIABLE_PITCH, "intellect\0" );
 	if(FAILED(D3DXCreateFont(m_pd3dDevice, hFont, &m_pBigFont)))
		return ERR_UNABLE_TO_CREATE_FONT;
	DeleteObject(hFont);	// We don't need original font after D3DXFont is created.

    hFont    = CreateFont( (m_nRelative * 11), 0, 0, 0, FW_NORMAL, FALSE,
                          FALSE, FALSE, DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                          CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY,
                          VARIABLE_PITCH, "intellect\0" );
 	if(FAILED(D3DXCreateFont(m_pd3dDevice, hFont, &m_pSmallFont)))
		return ERR_UNABLE_TO_CREATE_FONT;
	DeleteObject(hFont);	



	//Get BackBuffer attributes - JJL010426
	if(FAILED(m_pd3dDevice->GetBackBuffer(
			0, D3DBACKBUFFER_TYPE_MONO, &m_pBackBuffer)))
		return ERR_UNABLE_TO_GET_DRAWING_BUFFER;
	if(FAILED(m_pBackBuffer->GetDesc( &m_BackDesc )))
		return ERR_UNABLE_TO_GET_SURFACE_ATTRIBUTES;

    if (stretchMode == STRETCH_HARDWARE3D) {
        //create our in-memory texture
        if (FAILED(D3DXCreateTexture(m_pd3dDevice, 160, 192, 1, 0,
                D3DFMT_X1R5G5B5, D3DPOOL_SYSTEMMEM, &m_pMemTexture)))
        {
            m_pBackBuffer->Release();
            m_pBackBuffer = NULL;
            return ERR_REQUEST_FOR_IN_MEMORY_TEXTURE_FAILED;
        }

        if (FAILED(m_pMemTexture->GetLevelDesc(0, &m_pMemDesc))) {
            m_pMemTexture->Release();
            m_pMemTexture = NULL;
            m_pBackBuffer->Release();
            m_pBackBuffer = NULL;
            return ERR_REQUEST_FOR_IN_MEMORY_TEXTURE_FAILED;
        }

        //create the displayable texture on the video card
        if (FAILED(D3DXCreateTexture(m_pd3dDevice, 160, 192, 1, 0,
                D3DFMT_X1R5G5B5, D3DPOOL_DEFAULT, &m_pCardTexture)))
        {
            m_pMemTexture->Release();
            m_pMemTexture = NULL;
            m_pBackBuffer->Release();
            m_pBackBuffer = NULL;
            return ERR_REQUEST_FOR_HARDWARE_TEXTURE_FAILED;
        }

        //create our vertex buffer
        float right = (float)m_width;
        float bottom = (float)m_height;
        float rightTexPin = (160.2f/(float)m_pMemDesc.Width);
        float bottomTexPin = (192.3f/(float)m_pMemDesc.Height);
        CUSTOMVERTEX Vertices[4] =
        {
            {  0.0f,   0.0f, 1.0f, 1.0f, 0.0f, 0.0f },
            { right,   0.0f, 1.0f, 1.0f, rightTexPin,         0.0f },
            {  0.0f, bottom, 1.0f, 1.0f,        0.0f, bottomTexPin },
            { right, bottom, 1.0f, 1.0f, rightTexPin, bottomTexPin },
        };

        if (FAILED(m_pd3dDevice->CreateVertexBuffer(
                4*sizeof(CUSTOMVERTEX), 0, D3DFVF_CUSTOMVERTEX, D3DPOOL_DEFAULT,
                &m_pVB)))
        {
            m_pCardTexture->Release();
            m_pCardTexture = NULL;
            m_pMemTexture->Release();
            m_pMemTexture = NULL;
            m_pBackBuffer->Release();
            m_pBackBuffer = NULL;
            return ERR_REQUEST_FOR_VERTEX_BUFFER_FAILED;
        }

        VOID* pVertices;
        if (FAILED(m_pVB->Lock(0, sizeof(Vertices),
                (BYTE**)&pVertices, 0)))
        {
            m_pVB->Release();
            m_pVB = NULL;
            m_pCardTexture->Release();
            m_pCardTexture = NULL;
            m_pMemTexture->Release();
            m_pMemTexture = NULL;
            m_pBackBuffer->Release();
            m_pBackBuffer = NULL;
            return ERR_UNABLE_TO_LOCK_VERTEX_BUFFER;
        }
        memcpy(pVertices, Vertices, sizeof(Vertices));
        m_pVB->Unlock();

        if (m_pMemDesc.Format == D3DFMT_A8R8G8B8 ||
                m_pMemDesc.Format == D3DFMT_X8R8G8B8)
        {
            is32bit = TRUE;
            m_pMemPalette = g_A8R8G8B8Palette;
        }
        if (m_pMemDesc.Format == D3DFMT_R8G8B8) {
            is32bit = TRUE;
            m_pMemPalette = g_R8G8B8Palette;
        }
        else if (m_pMemDesc.Format == D3DFMT_X1R5G5B5) {
            is32bit = FALSE;
            m_pMemPalette = g_X1R5G5B5Palette;
        }
        else {
            is32bit = FALSE;
            m_pMemPalette = g_R5G6B5Palette;
        }
    }
    else {
        if (m_BackDesc.Format == D3DFMT_A8R8G8B8 ||
                m_BackDesc.Format == D3DFMT_X8R8G8B8)
        {
            is32bit = TRUE;
            m_pMemPalette = g_A8R8G8B8Palette;
        }
        if (m_BackDesc.Format == D3DFMT_R8G8B8) {
            is32bit = TRUE;
            m_pMemPalette = g_R8G8B8Palette;
        }
        else if (m_BackDesc.Format == D3DFMT_X1R5G5B5) {
            is32bit = FALSE;
            m_pMemPalette = g_X1R5G5B5Palette;
        }
        else {
            is32bit = FALSE;
            m_pMemPalette = g_R5G6B5Palette;
        }
    }

    ShowCursor(!fullScreen);

    // Scaling prep work
    // -------------------------------------------------------------------
    float m_wScale = 320.0f / m_width;
    float m_hScale = 192.0f / m_height;

    if(m_paStretch)
        delete[] m_paStretch;

    m_paStretch = new INT32[m_width*m_height];
    INT32 nextbyte = 0;
    for (INT32 y = 0; y < m_height; y++) {
        INT32 readline = (y * m_hScale);
        readline = (readline << 8) + (readline << 6);   // multiply * 320
        for(INT32 x = 0; x < m_width; x++) {
            m_paStretch[nextbyte] = readline + (x * m_wScale);
            nextbyte++;
        }
    }


    return 0;
}

void DirectXVideoOutputDevice::destroyResources() {
    //release the stretch matrix
    if(m_paStretch) {
        delete[] m_paStretch;
		m_paStretch = NULL;
	}
    if (m_pVB) {
        m_pVB->Release();
        m_pVB = NULL;
    }
    if (m_pCardTexture) {
        m_pCardTexture->Release();
        m_pCardTexture = NULL;
    }
    if (m_pMemTexture) {
        m_pMemTexture->Release();
        m_pMemTexture = NULL;
    }
	if (m_pBackBuffer) {
		m_pBackBuffer->Release();
		m_pBackBuffer = NULL;
	}
	if (m_pBigFont) {
		m_pBigFont->Release();
		m_pBigFont = NULL;
	}
	if (m_pSmallFont) {
		m_pSmallFont->Release();
		m_pSmallFont = NULL;
	}
}

void DirectXVideoOutputDevice::destroyDirectX() {
    if (m_pd3dDevice) {
        m_pd3dDevice->Release();
        m_pd3dDevice = NULL;
    }
    if (m_pD3D) {
        m_pD3D->Release();
        m_pD3D= NULL;
    }
}

void DirectXVideoOutputDevice::getDisplayModes()
{
    //clear the current list of video modes
    if (modes != NULL) {
        delete[] modes;
        modes = NULL;
        modeCount = 0;
        defaultFullScreenMode = NULL;
    }
    
    //initialize DirectX
    if((m_pD3D = Direct3DCreate8(D3D_SDK_VERSION)) == NULL) {
        return;
    }

    UINT modeCount;
    INT32 totalModeCount = m_pD3D->GetAdapterModeCount(D3DADAPTER_DEFAULT);

    //get the list of all valid modes
    modes = new D3DDISPLAYMODE[totalModeCount];
    modeCount = 0;
    BOOL alreadyHaveIt;
    for (UINT i = 0; i < totalModeCount; i++) {
        m_pD3D->EnumAdapterModes(D3DADAPTER_DEFAULT, i, &modes[modeCount]);

        //ignore 32-bit modes.  even 16-bit is overkill for an Intellivision
        if (modes[modeCount].Format == D3DFMT_X8R8G8B8 ||
                modes[modeCount].Format == D3DFMT_A8R8G8B8)
            continue;

        //if this mode is 640x400, then we want to use it as the default
        //display mode
        if (modes[modeCount].Width == DEFAULT_RESOLUTION_WIDTH &&
                modes[modeCount].Height == DEFAULT_RESOLUTION_HEIGHT )
            defaultFullScreenMode = &modes[modeCount];

        //check to see if we've already found a similar mode
        alreadyHaveIt = FALSE;
        for (UINT j = modeCount; j > 0; j--) {
            if (modes[j-1].Width == modes[modeCount].Width &&
                    modes[j-1].Height == modes[modeCount].Height)
            {
                alreadyHaveIt = TRUE;
                break;
            }
        }

        if (!alreadyHaveIt)
            modeCount++;
    }

    m_pD3D->Release();
    m_pD3D = NULL;
}

LRESULT CALLBACK MsgProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
//    int status;
    switch (msg) {
        case WM_CLOSE:
            currentDevice->stop = TRUE;
            return 0;

        case WM_PAINT:
            currentDevice->paintNeeded = TRUE;
            ValidateRect(hWnd, NULL);
            return 0;

        case WM_DESTROY:
            PostQuitMessage(0);
            return 0;
    }
    return DefWindowProc(hWnd, msg, wParam, lParam);
}

