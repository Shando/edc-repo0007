#define INLINE __forceinline

#define VERSION "0.50"

/* Euhm */
