package com.blissj.plugin;

import java.util.*;
import com.bliss.core.Intellivision;
import com.bliss.core.cartridge.*;
import com.bliss.core.devices.*;

public class AppPlugIn implements PlugIn
{

    public void init(Intellivision inty) {
        String windowTitle = "";
        if (inty != null) {
            Cartridge cart = inty.getCartridge();
            if (cart != null)
                windowTitle = cart.getType().getName();
        }
        vod.init(windowTitle, inty.getImageBank());
        aod.init();
        id.init();
    }

    public void release(Intellivision inty) {
        id.release();
        aod.release();
        vod.release();
    }

    public boolean stopRequested() {
        return (vod.stop || id.stop);
    }

    public String getPlugInName() {
        return RESOURCES.getString("AppPlugInName");
    }

    public String getPlugInDescription() {
        return RESOURCES.getString("AppPlugInDescription");
    }

    public ClockDevice getClockDevice() {
        return cd;
    }

    public VideoOutputDevice getVideoOutputDevice() {
        return vod;
    }

    public AudioOutputDevice getAudioOutputDevice() {
        return aod;
    }

    public InputDevice getInputDevice() {
        return id;
    }

    private AppClockDevice cd = new AppClockDevice();
    private AppVideoOutputDevice vod = new AppVideoOutputDevice();
    private AppAudioOutputDevice aod = new AppAudioOutputDevice();
    private AppInputDevice id = new AppInputDevice();

    static ResourceBundle RESOURCES = ResourceBundle.getBundle(
            "i18n/AppPlugInResources");

}
