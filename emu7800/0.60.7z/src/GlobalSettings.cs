using System;
using System.Drawing;
using System.IO;
using System.IO.IsolatedStorage;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace EMU7800 {
	public enum HostType {GDI, SDL};

[Serializable]
public class GlobalSettings {
	public string RootDir {
		get { return Directory.GetCurrentDirectory(); }
	}
	public string OutputDirectory {
		get {
			string od = Path.Combine(RootDir, "outdir");
			return Directory.Exists(od) ? od : RootDir;
		}
	}

	private bool IsDirty;

	private string _ROMDirectory;
	public string ROMDirectory {
		get { return _ROMDirectory; }
		set { IsDirty = _ROMDirectory != value; _ROMDirectory = value; }
	}
	private HostType _HostSelect;
	public HostType HostSelect {
		get { return _HostSelect; }
		set { IsDirty = _HostSelect != value; _HostSelect = value; }
	}
	private int _FrameRateAdjust;
	public int FrameRateAdjust {
		get { return _FrameRateAdjust; }
		set { IsDirty = _FrameRateAdjust != value; _FrameRateAdjust = value; }
	}
	private int _NumSoundBuffers;
	public int NumSoundBuffers {
		get { return _NumSoundBuffers; }
		set { IsDirty = _NumSoundBuffers != value; _NumSoundBuffers = value; }
	}
	private int _SoundVolume;
	public int SoundVolume {
		get { return _SoundVolume; }
		set { IsDirty = _SoundVolume != value; _SoundVolume = value; }
	}
	private bool _Skip7800BIOS;
	public bool Skip7800BIOS {
		get { return _Skip7800BIOS; }
		set { IsDirty = _Skip7800BIOS != value; _Skip7800BIOS = value; }
	}
	private bool _NOPRegisterDumping;
	public bool NOPRegisterDumping {
		get { return _NOPRegisterDumping; }
		set { IsDirty = _NOPRegisterDumping != value; _NOPRegisterDumping = value; }
	}
	private bool _DeactivateMouseInput;
	public bool DeactivateMouseInput {
		get { return _DeactivateMouseInput; }
		set { IsDirty = _DeactivateMouseInput != value; _DeactivateMouseInput = value; }
	}

	// Joystick button number to function bindings
	private int _JoyBTrigger;
	public int JoyBTrigger {
		get { return _JoyBTrigger; }
		set { IsDirty = _JoyBTrigger != value; _JoyBTrigger = value; }
	}
	private int _JoyBBooster;
	public int JoyBBooster {
		get { return _JoyBBooster; }
		set { IsDirty = _JoyBBooster != value; _JoyBBooster = value; }
	}

	// Non-critial, but convenient settings to have persistent
	private Size _ControlPanelFormSize;
	public Size ControlPanelFormSize {
		get { return _ControlPanelFormSize; }
		set { IsDirty = _ControlPanelFormSize != value; _ControlPanelFormSize = value; }
	}

	private const string GLOBALS_FILENAME = "Globals.bin";

	public void Serialize() {
		IsolatedStorageFileStream s = null;
		BinaryFormatter f = new BinaryFormatter();
		
		if (IsDirty) {
			try {
				IsDirty = false;
				s = new IsolatedStorageFileStream(GLOBALS_FILENAME, FileMode.OpenOrCreate);
				f.Serialize(s, this);
				s.Close();
				Log.Msg("Saved {0}\n", GLOBALS_FILENAME);
			} catch (Exception e) {
				IsDirty = true;
				if (s != null) {
					s.Close();
				}
				Log.Msg("Error saving {0}: {1}\n", GLOBALS_FILENAME, e.Message);
			}
		}
	}

	public static GlobalSettings Deserialize() {
		IsolatedStorageFileStream s = null;
		BinaryFormatter f = new BinaryFormatter();
		GlobalSettings settings = null;

		Log.Msg("Loading global settings...\n");
		try {
			s = new IsolatedStorageFileStream(GLOBALS_FILENAME, FileMode.Open);
			settings = (GlobalSettings)f.Deserialize(s);
			s.Close();
		} catch (Exception e) {
			if (s != null) {
				s.Close();
			}
			Log.Msg("Error reading {0}: {1}\nInitializing settings...\n", GLOBALS_FILENAME, e.Message);
			settings = new GlobalSettings();
			settings.Serialize();
		} finally {
			Log.Msg("Global settings loaded\n");
		}

		return settings;
	}

	private GlobalSettings() {
		ROMDirectory = Path.Combine(RootDir, "roms");
		if (!Directory.Exists(ROMDirectory)) {
			ROMDirectory = RootDir;
		}
		IsDirty = true;
		HostSelect = HostType.SDL;
		FrameRateAdjust = 0;
		NumSoundBuffers = 10;
		SoundVolume = 8;
		Skip7800BIOS = false;
		NOPRegisterDumping = false;

		JoyBTrigger = 0;
		JoyBBooster = 1;
	}
}
}
