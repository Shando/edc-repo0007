/*
 * IHost.cs
 * 
 * An interface of an emulator host.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */

using System;

namespace EMU7800 {

public interface IHost {
	Machine GetMachine();
	void InstallMachine(Machine m);
	void UpdateRect(DisplRect r);
	void UpdateSound(byte[] buf);
}
}
