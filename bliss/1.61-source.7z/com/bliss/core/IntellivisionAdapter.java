package com.bliss.core;

import com.bliss.core.cartridge.*;

public class IntellivisionAdapter implements IntellivisionListener
{

    public void turnedOn(Intellivision inty) { }

    public void cartridgeChanged(Intellivision inty, Cartridge oldCart,
            Cartridge newCart) { }

    public void errorOccurred(Intellivision inty, String errorMessage) { }

    public void turnedOff(Intellivision inty) { }

}
