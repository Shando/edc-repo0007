/*
 * UAE - The Un*x Amiga Emulator
 *
 * Win32 WaveOut and DirectSound interfaces
 *
 * Copyright 1997 Mathias Ortmann
 * Copyright 1999, 2000 - Brian King
 */
#include <windows.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <io.h>

#if 0 // MUMIT - CHANGE THIS LINE to #if 1, and run 'testsound.exe' - you'll see that the handle is NULL

#include <mmsystem.h>

#else

typedef UINT        MMRESULT;   /* error return code, 0 means no error */
#ifndef _WAVEFORMATEX_
#define _WAVEFORMATEX_

/*
 *  extended waveform format structure used for all non-PCM formats. this
 *  structure is common to all non-PCM formats.
 */
typedef struct tWAVEFORMATEX
{
    WORD        wFormatTag;         /* format type */
    WORD        nChannels;          /* number of channels (i.e. mono, stereo...) */
    DWORD       nSamplesPerSec;     /* sample rate */
    DWORD       nAvgBytesPerSec;    /* for buffer estimation */
    WORD        nBlockAlign;        /* block size of data */
    WORD        wBitsPerSample;     /* number of bits per sample of mono data */
    WORD        cbSize;             /* the count in bytes of the size of */
				    /* extra information (after cbSize) */
} WAVEFORMATEX, *PWAVEFORMATEX, *LPWAVEFORMATEX;
typedef const WAVEFORMATEX *LPCWAVEFORMATEX;

#endif /* _WAVEFORMATEX_ */
DECLARE_HANDLE(HWAVEOUT);

/* device ID for wave device mapper */
#define WAVE_MAPPER     ((UINT)-1)

/* flags for dwFlags parameter in waveOutOpen() and waveInOpen() */
#define  WAVE_FORMAT_QUERY         0x0001
#define  WAVE_ALLOWSYNC            0x0002
#if(WINVER >= 0x0400)
#define  WAVE_MAPPED               0x0004
#define  WAVE_FORMAT_DIRECT        0x0008
#define  WAVE_FORMAT_DIRECT_QUERY  (WAVE_FORMAT_QUERY | WAVE_FORMAT_DIRECT)
#endif /* WINVER >= 0x0400 */

/* wave data block header */
typedef struct wavehdr_tag {
    LPSTR       lpData;                 /* pointer to locked data buffer */
    DWORD       dwBufferLength;         /* length of data buffer */
    DWORD       dwBytesRecorded;        /* used for input only */
    DWORD       dwUser;                 /* for client's use */
    DWORD       dwFlags;                /* assorted flags (see defines) */
    DWORD       dwLoops;                /* loop control counter */
    struct wavehdr_tag FAR *lpNext;     /* reserved for driver */
    DWORD       reserved;               /* reserved for driver */
} WAVEHDR, *PWAVEHDR, NEAR *NPWAVEHDR, FAR *LPWAVEHDR;

/* flags for dwFlags field of WAVEHDR */
#define WHDR_DONE       0x00000001  /* done bit */
#define WHDR_PREPARED   0x00000002  /* set if this header has been prepared */
#define WHDR_BEGINLOOP  0x00000004  /* loop start block */
#define WHDR_ENDLOOP    0x00000008  /* loop end block */
#define WHDR_INQUEUE    0x00000010  /* reserved for driver */

#define MMSYSERR_BASE          0
#define WAVERR_BASE            32
#define MIDIERR_BASE           64
#define TIMERR_BASE            96
#define JOYERR_BASE            160
#define MCIERR_BASE            256
#define MIXERR_BASE            1024

#define MCI_STRING_OFFSET      512
#define MCI_VD_OFFSET          1024
#define MCI_CD_OFFSET          1088
#define MCI_WAVE_OFFSET        1152
#define MCI_SEQ_OFFSET         1216

/****************************************************************************

			General error return values

****************************************************************************/

/* general error return values */
#define MMSYSERR_NOERROR      0                    /* no error */
#define MMSYSERR_ERROR        (MMSYSERR_BASE + 1)  /* unspecified error */
#define MMSYSERR_BADDEVICEID  (MMSYSERR_BASE + 2)  /* device ID out of range */
#define MMSYSERR_NOTENABLED   (MMSYSERR_BASE + 3)  /* driver failed enable */
#define MMSYSERR_ALLOCATED    (MMSYSERR_BASE + 4)  /* device already allocated */
#define MMSYSERR_INVALHANDLE  (MMSYSERR_BASE + 5)  /* device handle is invalid */
#define MMSYSERR_NODRIVER     (MMSYSERR_BASE + 6)  /* no device driver present */
#define MMSYSERR_NOMEM        (MMSYSERR_BASE + 7)  /* memory allocation error */
#define MMSYSERR_NOTSUPPORTED (MMSYSERR_BASE + 8)  /* function isn't supported */
#define MMSYSERR_BADERRNUM    (MMSYSERR_BASE + 9)  /* error value out of range */
#define MMSYSERR_INVALFLAG    (MMSYSERR_BASE + 10) /* invalid flag passed */
#define MMSYSERR_INVALPARAM   (MMSYSERR_BASE + 11) /* invalid parameter passed */
#define MMSYSERR_HANDLEBUSY   (MMSYSERR_BASE + 12) /* handle being used */
						   /* simultaneously on another */
						   /* thread (eg callback) */
#define MMSYSERR_INVALIDALIAS (MMSYSERR_BASE + 13) /* specified alias not found */
#define MMSYSERR_BADDB        (MMSYSERR_BASE + 14) /* bad registry database */
#define MMSYSERR_KEYNOTFOUND  (MMSYSERR_BASE + 15) /* registry key not found */
#define MMSYSERR_READERROR    (MMSYSERR_BASE + 16) /* registry read error */
#define MMSYSERR_WRITEERROR   (MMSYSERR_BASE + 17) /* registry write error */
#define MMSYSERR_DELETEERROR  (MMSYSERR_BASE + 18) /* registry delete error */
#define MMSYSERR_VALNOTFOUND  (MMSYSERR_BASE + 19) /* registry value not found */
#define MMSYSERR_NODRIVERCB   (MMSYSERR_BASE + 20) /* driver does not call DriverCallback */
#define MMSYSERR_LASTERROR    (MMSYSERR_BASE + 20) /* last error in range */

#define WAVE_FORMAT_PCM     1

typedef HWAVEOUT *LPHWAVEOUT;

#define CALLBACK_TYPEMASK   0x00070000l    /* callback type mask */
#define CALLBACK_NULL       0x00000000l    /* no callback */
#define CALLBACK_WINDOW     0x00010000l    /* dwCallback is a HWND */
#define CALLBACK_TASK       0x00020000l    /* dwCallback is a HTASK */
#define CALLBACK_FUNCTION   0x00030000l    /* dwCallback is a FARPROC */
#ifdef _WIN32
#define CALLBACK_THREAD     (CALLBACK_TASK)/* thread ID replaces 16 bit task */
#define CALLBACK_EVENT      0x00050000l    /* dwCallback is an EVENT Handle */
#endif

#define	WINMMAPI DECLSPEC_IMPORT

WINMMAPI MMRESULT WINAPI waveOutOpen(LPHWAVEOUT phwo, UINT uDeviceID,
    LPCWAVEFORMATEX pwfx, DWORD dwCallback, DWORD dwInstance, DWORD fdwOpen);

WINMMAPI MMRESULT WINAPI waveOutClose(HWAVEOUT hwo);
WINMMAPI MMRESULT WINAPI waveOutPrepareHeader(HWAVEOUT hwo, LPWAVEHDR pwh, UINT cbwh);
WINMMAPI MMRESULT WINAPI waveOutUnprepareHeader(HWAVEOUT hwo, LPWAVEHDR pwh, UINT cbwh);
WINMMAPI MMRESULT WINAPI waveOutWrite(HWAVEOUT hwo, LPWAVEHDR pwh, UINT cbwh);
WINMMAPI MMRESULT WINAPI waveOutPause(HWAVEOUT hwo);
WINMMAPI MMRESULT WINAPI waveOutRestart(HWAVEOUT hwo);
WINMMAPI MMRESULT WINAPI waveOutReset(HWAVEOUT hwo);
WINMMAPI MMRESULT WINAPI waveOutBreakLoop(HWAVEOUT hwo);
WINMMAPI MMRESULT WINAPI waveOutGetPitch(HWAVEOUT hwo, LPDWORD pdwPitch);
WINMMAPI MMRESULT WINAPI waveOutSetPitch(HWAVEOUT hwo, DWORD dwPitch);
WINMMAPI MMRESULT WINAPI waveOutGetPlaybackRate(HWAVEOUT hwo, LPDWORD pdwRate);
WINMMAPI MMRESULT WINAPI waveOutSetPlaybackRate(HWAVEOUT hwo, DWORD dwRate);
WINMMAPI MMRESULT WINAPI waveOutGetID(HWAVEOUT hwo, LPUINT puDeviceID);

#endif


#define write_log printf

char *sndptr, *sndptrmax, soundneutral;

static MMRESULT uPeriodicTimerID = 0;

static WAVEFORMATEX wavfmt;

static HWAVEOUT hWaveOut = NULL, hSoundCompleteEvent = NULL;

static DWORD tooslow = 0;

static HGLOBAL hData;
static LPSTR lpData;
static LPSTR lpDSBData[2];

static HGLOBAL hWaveHdr;
static LPWAVEHDR lpWaveHdr;
static BOOL sound_stopped = TRUE;
signed long bufsamples;
unsigned int samplecount;
DWORD soundbufsize;

UINT timer_period = 0;

static HANDLE hVBlankEvent;

MMRESULT idVBlankTimer;

static int last_sound_setting;

static int num_sound_buffers = 1;
static int which_sound_buffer = 0;
static int sound_flushes  = 0;

void close_sound (void)
{
    int i;

        if( hWaveOut )
        {
	    waveOutReset( hWaveOut );
    	    waveOutUnprepareHeader( hWaveOut, lpWaveHdr, sizeof( WAVEHDR ) );
	    GlobalUnlock( hWaveHdr );
	    GlobalFree( hWaveHdr );
	    waveOutClose( hWaveOut );
	    GlobalUnlock( hData );
	    GlobalFree( hData );
	    hWaveOut = NULL;
	    write_log( "WAVEOUT: closed\n" );
        }
        if( hSoundCompleteEvent )
        {
            CloseHandle( hSoundCompleteEvent );
            hSoundCompleteEvent = NULL;
        }
    sound_stopped = TRUE;
}

static __inline__ void waveout_play( void )
{
    MMRESULT result;

    /* Get the big looping waveOutWrite() rolling here, but only once at startup */
    if( sound_flushes == 1 )
    {
        lpWaveHdr->lpData = lpData;
        lpWaveHdr->dwBufferLength = soundbufsize;
        lpWaveHdr->dwFlags = WHDR_BEGINLOOP | WHDR_ENDLOOP;
        lpWaveHdr->dwLoops = 0x7FFFFFFFL;
        if( ( result = waveOutPrepareHeader( hWaveOut, lpWaveHdr, sizeof( WAVEHDR ) ) ) == MMSYSERR_NOERROR )
	{
	    if( waveOutWrite( hWaveOut, lpWaveHdr, sizeof( WAVEHDR ) ) )
	    { 
		waveOutUnprepareHeader( hWaveOut, lpWaveHdr, sizeof( WAVEHDR ) );
		write_log( "WAVEOUT: Failed to write to sound card\n" );
	    }
	}
	else
	{
	    write_log( "WAVEOUT: Failed to prepare waveOut header with error-code %d, hWaveOut = %p\n", result, hWaveOut );
	}
    }
}

static __inline__ void startsound( int force )
{
    if( force || ( sound_stopped == TRUE ) )
    {
        sound_stopped = FALSE;
            waveout_play();
    }
}

static __inline__ void stopsound( void )
{
    int i;
    HRESULT hr;

    if( sound_stopped == FALSE )
    {
	    sndptr = lpData;

	sndptrmax = sndptr + soundbufsize;    

        samplecount = 0;

            memset( lpData, soundneutral, soundbufsize );
            waveOutReset( hWaveOut );
            waveOutUnprepareHeader( hWaveOut, lpWaveHdr, sizeof( WAVEHDR ) );
        sound_stopped = TRUE;
    }
}

/* Use this to pause or stop Win32 sound output */
void pause_sound( int full_stop )
{
        if( full_stop )
        {
        }
        else
        {
            stopsound();
        }
}

/* Use this to resume Win32 sound output */
void resume_sound( void )
{
    if( sound_stopped )
    {
        if( hWaveOut == NULL )
        {
            sound_flushes = 0; /* Because flush_sound_buffer() will increment this to 1 */
        }
        else
        {
            sound_flushes = 1; /* Pretend we're starting from scratch */
            startsound(0);
        }
    }
}

void flush_sound_buffer( void )
{
    sound_flushes++;

    startsound(1);

	sndptr = lpData;
}

static int init_sound_win32(void);

static int init_sound_win32 (void)
{
    HRESULT hr;
    MMRESULT mmres;
    int i;
    DWORD dwBytes;

    if ( hWaveOut)
        return 0;

            num_sound_buffers = 1;

    wavfmt.cbSize = 0;
    wavfmt.wFormatTag = WAVE_FORMAT_PCM;
    wavfmt.nChannels = 2;
    wavfmt.nSamplesPerSec = 44100;
    wavfmt.wBitsPerSample = 16;
    wavfmt.nBlockAlign = 16 / 8 * wavfmt.nChannels;
    wavfmt.nAvgBytesPerSec = wavfmt.nBlockAlign * wavfmt.nSamplesPerSec;

    soundneutral = 0;
    bufsamples = 2048 * wavfmt.nSamplesPerSec / 11025;
    soundbufsize = bufsamples * wavfmt.nBlockAlign;

	if( !( hData = (LPSTR)GlobalAlloc( GMEM_MOVEABLE | GMEM_SHARE | GMEM_ZEROINIT, soundbufsize ) ) )
	{
		write_log( "WAVEOUT: Failed to allocate sound buffer!\n" );
		return 0;
	}

	if( !( lpData = GlobalLock(hData) ) )
	{
	    write_log( "WAVEOUT: Failed to lock sound buffer!\n" );
	    return 0;
	}

        if( !( hWaveHdr = GlobalAlloc( GMEM_MOVEABLE | GMEM_SHARE | GMEM_ZEROINIT, (DWORD)sizeof( WAVEHDR ) ) ) )
        {
            write_log( "WAVEOUT: Failed to allocate wave header!\n" );
            return 0;
        }
        if( !( lpWaveHdr = GlobalLock( hWaveHdr ) ) )
        {
            write_log( "WAVEOUT: Failed to lock wave header!\n" );
            return 0;
        }

        if( ( mmres = waveOutOpen( &hWaveOut, WAVE_MAPPER, &wavfmt, 0, 0, CALLBACK_NULL | WAVE_ALLOWSYNC | WAVE_FORMAT_DIRECT ) ) )
        {
            write_log( "WAVEOUT: Device failed to open with error code %d.\n", mmres );
            return 0;
        }
	write_log( "WAVEOUT: Opened handle 0x%p\n", hWaveOut );
	if( hWaveOut == NULL )
	    return 0;

    sndptrmax = lpData + soundbufsize;
    sndptr = lpData;
    samplecount = 0;

    return 44100;
}

static int rate;

int init_sound (void)
{
    if ((rate = init_sound_win32 ()) < 2)
	return rate;

    write_log( "WaveOut driver found and configured for 16-bits at %d Hz\n", rate );

    return 1;
}
