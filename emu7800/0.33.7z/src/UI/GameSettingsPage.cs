/*
 * GameSettingsPage.cs
 * 
 * A ConrolPanelTabPage that provides browsing of game settings, as well as the running
 * of ROMs not registered to ROMProperties.txt
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */

using System;
using System.Drawing;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace EMU7800 {
	
public class GameSettingsPage : ControlPanelTabPage {
	private ControlPanelForm ControlPanelForm;

	private Label lblTitle, lblManuf, lblYear, lblModelNo, lblRarity, lblManual;
	private TextBox txtTitle, txtManuf, txtYear, txtModelNo, txtRarity, txtManual;

	private Label lblSaveKey;
	private TextBox txtSaveKey;
	private Label lblCartType, lblMachineType, lblLController, lblRController;
	private ComboBox cmbCartType, cmbMachineType, cmbLController, cmbRController;

	private Label lblROM;
	private ComboBox cmbROM;
	private Button btnBrowse;

	private OpenFileDialog openFileDialog1;

	public override void ClearChanges() {
		GameSettings gs = ControlPanelForm.CurrGameSettings;

		txtTitle.Text = gs.Title;
		txtManuf.Text = gs.Manufacturer;
		txtYear.Text = gs.Year;
		txtModelNo.Text = gs.ModelNo;
		txtRarity.Text = gs.Rarity;
		txtManual.Text = gs.Manual;

		txtSaveKey.Text = gs.SaveKey;
		txtSaveKey.ReadOnly = true;

		cmbCartType.SelectedItem = gs.CartType.ToString();
		cmbMachineType.SelectedItem = gs.MachineType.ToString();

		cmbLController.SelectedItem = gs.LController.ToString();
		cmbRController.SelectedItem = gs.RController.ToString();

		cmbROM.Text = gs.ROMFullName;
	}

	public override void ApplyChanges() {
		GameSettings gs;
		bool newSettings = false;
		
		try {
			gs = new GameSettings(ComputeMD5(cmbROM.Text));
			gs.Title = txtTitle.Text;
			gs.Manufacturer = txtManuf.Text;
			gs.Year = txtYear.Text;
			gs.ModelNo = txtModelNo.Text;
			gs.Rarity = txtRarity.Text;
			gs.Manual = txtManual.Text;
			gs.CartType = (CartType)Enum.Parse(typeof(CartType), cmbCartType.Text);
			gs.MachineType = (MachineType)Enum.Parse(typeof(MachineType), cmbMachineType.Text);
			gs.LController = (Controller)Enum.Parse(typeof(Controller), cmbLController.Text);
			gs.RController = (Controller)Enum.Parse(typeof(Controller), cmbRController.Text);
			gs.ROMFullName = cmbROM.Text;
			ControlPanelForm.CurrGameSettings = gs;
			newSettings = true;
		} catch {
		}
		ClearChanges();

		if (newSettings) {
			gs = ControlPanelForm.CurrGameSettings;
			Cart c = Cart.New(gs);
			Machine m = Machine.New(gs, c, new InputAdapter());
			if (m != null) {
				ControlPanelForm.H.InstallMachine(m);
				ControlPanelForm.CurrGameSettings = gs;
			}
		}
	}

	public GameSettingsPage(ControlPanelForm f) {
		ControlPanelForm = f;
		Text = "Settings";

		lblTitle = new Label();
		lblTitle.AutoSize = true;
		lblTitle.Text = "Title:";
		txtTitle = new TextBox();
		txtTitle.Size = new Size(200, txtTitle.PreferredHeight);

		lblManuf = new Label();
		lblManuf.AutoSize = true;
		lblManuf.Text = "Manufacturer:";
		txtManuf = new TextBox();
		txtManuf.Size = new Size(120, txtManuf.PreferredHeight);

		lblYear = new Label();
		lblYear.AutoSize = true;
		lblYear.Text = "Year:";
		txtYear = new TextBox();
		txtYear.Size = new Size(30, txtYear.PreferredHeight);

		lblModelNo = new Label();
		lblModelNo.AutoSize = true;
		lblModelNo.Text = "Model #:";
		txtModelNo = new TextBox();
		txtModelNo.Size = new Size(150, txtModelNo.PreferredHeight);

		lblRarity = new Label();
		lblRarity.AutoSize = true;
		lblRarity.Text = "Rarity:";
		txtRarity = new TextBox();
		txtRarity.Size = new Size(100, txtRarity.PreferredHeight);

		lblManual = new Label();
		lblManual.AutoSize = true;
		lblManual.Text = "Manual:";
		txtManual = new TextBox();
		txtManual.Size = new Size(100, txtManual.PreferredHeight);

		lblSaveKey = new Label();
		lblSaveKey.AutoSize = true;
		lblSaveKey.Text = "MD5:";
		txtSaveKey = new TextBox();
		txtSaveKey.Size = new Size(200, txtSaveKey.PreferredHeight);

		lblCartType = new Label();
		lblCartType.AutoSize = true;
		lblCartType.Text = "Cartridge:";
		cmbCartType = new ComboBox();
		cmbCartType.SelectedValueChanged += new EventHandler(OnCmbChanged);
		cmbCartType.Size = new Size(100, cmbCartType.PreferredHeight);
		cmbCartType.DropDownStyle = ComboBoxStyle.DropDown;
		foreach (string nm in Enum.GetNames(typeof(CartType))) {
			cmbCartType.Items.Add(nm);
		}

		lblMachineType = new Label();
		lblMachineType.AutoSize = true;
		lblMachineType.Text = "Machine:";
		cmbMachineType = new ComboBox();
		cmbMachineType.SelectedValueChanged += new EventHandler(OnCmbChanged);
		cmbMachineType.Size = new Size(100, cmbMachineType.PreferredHeight);
		cmbMachineType.DropDownStyle = ComboBoxStyle.DropDown;
		foreach (string nm in Enum.GetNames(typeof(MachineType))) {
			cmbMachineType.Items.Add(nm);
		}

		lblLController = new Label();
		lblLController.AutoSize = true;
		lblLController.Text = "Left Controller:";
		cmbLController = new ComboBox();
		cmbLController.SelectedValueChanged += new EventHandler(OnCmbChanged);
		cmbLController.Size = new Size(100, cmbLController.PreferredHeight);
		cmbLController.DropDownStyle = ComboBoxStyle.DropDown;
		foreach (string nm in Enum.GetNames(typeof(Controller))) {
			cmbLController.Items.Add(nm);
		}

		lblRController = new Label();
		lblRController.AutoSize = true;
		lblRController.Text = "Right Controller:";
		cmbRController = new ComboBox();
		cmbRController.SelectedValueChanged += new EventHandler(OnCmbChanged);
		cmbRController.Size = new Size(100, cmbRController.PreferredHeight);
		cmbRController.DropDownStyle = ComboBoxStyle.DropDown;
		foreach (string nm in Enum.GetNames(typeof(Controller))) {
			cmbRController.Items.Add(nm);
		}

		lblROM = new Label();
		lblROM.AutoSize = true;
		lblROM.Text = "ROM File:";
		cmbROM = new ComboBox();
		cmbROM.SelectedValueChanged += new EventHandler(OnCmbROMChanged);
		btnBrowse = new Button();
		btnBrowse.Text = "Select ROM File";
		btnBrowse.Size = new Size(105, 25);
		btnBrowse.Click += new EventHandler(OnBrowseClick);

		Controls.AddRange(new Control[] {
			lblTitle, txtTitle,
			lblManuf, txtManuf,
			lblYear, txtYear,
			lblModelNo, txtModelNo,
			lblRarity, txtRarity,
			lblManual, txtManual,
			lblSaveKey, txtSaveKey,
			lblCartType, cmbCartType,
			lblMachineType, cmbMachineType,
			lblLController, cmbLController,
			lblRController, cmbRController,
			lblROM, cmbROM,
			btnBrowse});

		foreach (Control c in Controls) {
			if (c.GetType() == typeof(TextBox)) {
				((TextBox)c).BorderStyle = BorderStyle.FixedSingle;
			}
		}

		Layout += new LayoutEventHandler(OnLayout);
	}

	private void OnLayout(Object sender, LayoutEventArgs e) {
		int lx, lx2;
		int x, y;

		lx = 10;
		lx2 = lblRController.Right;

		x = lx;
		y = 30;
		lblTitle.Location = new Point(x, y);
		x = lx2;
		txtTitle.Location = new Point(x, y);

		x = lx;
		y = lblTitle.Bottom + 10;
		lblManuf.Location = new Point(x, y);
		x = lx2;
		txtManuf.Location = new Point(x, y);
		x = txtManuf.Right + 20;
		lblYear.Location = new Point(x, y);
		x = lblYear.Right;
		txtYear.Location = new Point(x, y);

		x = lx;
		y = lblManuf.Bottom + 10;
		lblModelNo.Location = new Point(x, y);
		x = lx2;
		txtModelNo.Location = new Point(x, y);

		x = lx;
		y = lblModelNo.Bottom + 10;
		lblRarity.Location = new Point(x, y);
		x = lx2;
		txtRarity.Location = new Point(x, y);

		x = lx;
		y = lblRarity.Bottom + 10;
		lblManual.Location = new Point(x, y);
		x = lx2;
		txtManual.Location = new Point(x, y);

		x = lx;
		y = lblManual.Bottom + 20;
		lblSaveKey.Location = new Point(x, y);
		x = lx2;
		txtSaveKey.Location = new Point(x, y);

		x = lx;
		y = lblSaveKey.Bottom + 10;
		lblCartType.Location = new Point(x, y);
		x = lx2;
		cmbCartType.Location = new Point(x, y);

		x = lx;
		y = lblCartType.Bottom + 10;
		lblMachineType.Location = new Point(x, y);
		x = lx2;
		cmbMachineType.Location = new Point(x, y);

		x = lx;
		y = lblMachineType.Bottom + 10;
		lblLController.Location = new Point(x, y);
		x = lx2;
		cmbLController.Location = new Point(x, y);

		x = lx;
		y = lblLController.Bottom + 10;
		lblRController.Location = new Point(x, y);
		x = lx2;
		cmbRController.Location = new Point(x, y);

		x = lx;
		y = lblRController.Bottom + 10;
		lblROM.Location = new Point(x, y);
		x = lx2;
		cmbROM.Size = new Size(Width - 110, cmbROM.PreferredHeight);
		cmbROM.Location = new Point(x, y);

		x = lx2;
		y = lblROM.Bottom + 10;
		btnBrowse.Location = new Point(x, y);
	}
	
	private void OnCmbChanged(Object sender, EventArgs e) {
		TryApplyButtonEnable();
	}

	private void OnCmbROMChanged(Object sender, EventArgs e) {
		UpdateCmbROM(cmbROM.Text);
	}

	private void OnBrowseClick(Object sender, EventArgs e) {
		openFileDialog1 = new OpenFileDialog();
		openFileDialog1.Title = "Select ROM File";
		openFileDialog1.InitialDirectory = cmbROM.Text;
		openFileDialog1.Filter = "ROM files (*.bin)|*.bin|All files (*.*)|*.*" ;
		openFileDialog1.FilterIndex = 1;

		if(openFileDialog1.ShowDialog() == DialogResult.OK) {
			UpdateCmbROM(openFileDialog1.FileName);
		}
	}

	private void UpdateCmbROM(string fn) {
		string romfn = fn.Replace(@"\", "/");
		bool found = false;
		foreach (string s in cmbROM.Items) {
			if (s == romfn) {
				found = true;
				break;
			}
		}
		if (!found) {
			cmbROM.Items.Add(romfn);
		}
		cmbROM.Text = romfn;
		TryApplyButtonEnable();
	}

	private void TryApplyButtonEnable() {
		GameSettings gs = ControlPanelForm.CurrGameSettings;
		if (cmbROM.Text.Length > 0
				&& cmbCartType.Text != CartType.Null.ToString()
				&& cmbMachineType.Text != MachineType.Null.ToString()) {
			ControlPanelForm.ApplyButtonEnabled = true;
		} else {
			ControlPanelForm.ApplyButtonEnabled = false;
		}
	}

	private string ComputeMD5(string romfullname) {
		MD5 MD5 = new MD5CryptoServiceProvider();
		FileInfo fi = new FileInfo(romfullname);
		BinaryReader br = new BinaryReader(File.OpenRead(romfullname));
		byte[] ROM = br.ReadBytes((int)fi.Length);
		br.Close();
		StringBuilder md5 = new StringBuilder();
		foreach (Byte b in MD5.ComputeHash(ROM)) {
			md5.Append(String.Format("{0:x2}", b)); 
		}
		return md5.ToString();
	}
}
}
