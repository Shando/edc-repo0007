 /*
  * UAE - The Un*x Amiga Emulator
  *
  *  Serial Line Emulation
  *
  * (c) 1996, 1997 Stefan Reinauer <stepan@linux.de>
  * (c) 1997 Christian Schmitt <schmitt@freiburg.linux.de>
  * (c) 2001 Bernd Roesch
  *
  */

#include "sysconfig.h"
#include "sysdeps.h"

#include "config.h"
#include "options.h"
#include "uae.h"
#include "memory.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "cia.h"

#define TIOCM_CAR 1
#define TIOCM_DSR 2
#include "osdep/parser.h"

#ifndef O_NONBLOCK
#define O_NONBLOCK O_NDELAY
#endif

#define SERIALDEBUG 0 /* 0, 1, 2 3 */
#define MODEMTEST   0 /* 0 or 1 */

void serial_open (void);
void serial_close (void);
void serial_init (void);
void serial_exit (void);

void serial_dtr_on (void);
void serial_dtr_off (void);

void serial_flush_buffer (void);
static int serial_read (char *buffer);

int serial_readstatus (void);
uae_u16 serial_writestatus (int, int);

uae_u16 SERDATR (void);

int  SERDATS (void);
void  SERPER (uae_u16 w);
void  SERDAT (uae_u16 w);

static char inbuf[1024], outbuf[1024];
static int inptr, inlast, outlast;

int waitqueue=0,
    carrier=0,
    serdev=0,
    dsr=0,
    dtr=0,
    isbaeh=0,
    doreadser=0,
    serstat=-1;

int sd = -1;

uae_u16 serper=0,serdat;

void SERPER (uae_u16 w)
{
    int baud=0;
    if (!currprefs.use_serial)
	return;

    if (serper == w)  /* don't set baudrate if it's already ok */
	return;
	
    serper=w;

    if (w&0x8000)
	write_log( "SERPER: 9bit transmission not implemented.\n" );

    switch (w & 0x7fff)
    {
     /* These values should be calculated by the current
      * color clock value (NTSC/PAL). But this solution is
      * easy and it works.
      */

     case 0x2e9b:
     case 0x2e14:
         baud=300;
         break;
     case 0x170a:
     case 0x0b85:
         baud=1200;
         break;
     case 0x05c2:
     case 0x05b9:
     case 0x05d0: /* CNet BBS uses this value?! */
         baud=2400;
         break;
     case 0x02e9:
     case 0x02e1:
         baud=4800;
         break;
     case 0x0174:
     case 0x0170:
         baud=9600;
         break;
     case 0x00b9:
     case 0x00b8:
         baud=19200;
         break;
     case 0x005c:
     case 0x005d:
         baud=38400;
         break;
     case 0x003d:
         baud=57600;
         break;
     case 0x001e:
         baud=115200;
         break;
     case 0x000f:
         baud=230400;
         break;
     case 0x70:
     case 0x71:
     case 0x72:
     case 0x73:
         baud = 31400;
         break;
     default:
      write_log( "SERPER: unsupported baudrate (0x%04x) %d\n",w&0x7fff,
		 (unsigned int)(3579546.471/(double)((w&0x7fff)+1)));  return;
    }
    serdat=0x3000; //so bars and octamed not hang after serialport use
    setbaud(baud);

#if SERIALDEBUG > 0
    if (serdev == 1)
    write_log( "SERPER: baudrate set to %d bit/sec\n", baud );
#endif
}

/* Not (fully) implemented yet:
 *
 *  -  Something's wrong with the Interrupts.
 *     (NComm works, TERM does not. TERM switches to a
 *     blind mode after a connect and wait's for the end
 *     of an asynchronous read before switching blind
 *     mode off again. It never gets there on UAE :-< )
 *
 *  -  RTS/CTS handshake, this is not really neccessary,
 *     because you can use RTS/CTS "outside" without
 *     passing it through to the emulated Amiga
 *
 *  -  ADCON-Register ($9e write, $10 read) Bit 11 (UARTBRK)
 *     (see "Amiga Intern", pg 246)
 */

void SERDAT (uae_u16 w)
{
    unsigned char z;

    if (!currprefs.use_serial)
	return;

    z = (unsigned char)(w&0xff);

    if (currprefs.serial_demand && !dtr) {
        write_log( "SERDAT: Baeh.. Your software needs SERIAL_ALWAYS to work properly.\n" );
        openser( currprefs.sername );
        dtr=1;
	return;
    }
    else
    {
	writeser(z);
	return;
    }

#if SERIALDEBUG > 2
    write_log( "SERDAT: wrote 0x%04x\n", w );
#endif

    serdat|=0x2000; /* Set TBE in the SERDATR ... */
    intreq|=1;      /* ... and in INTREQ register */
    return;
}

uae_u16 SERDATR (void)
{
    if (!currprefs.use_serial)
	return 0;
#if SERIALDEBUG > 2
    write_log( "SERDATR: read 0x%04x\n", serdat );
#endif
    waitqueue = 0;
    return serdat;
}

int SERDATS (void)
{
    unsigned char z;
    hsyncstuff();
    
    if (!serdev)           /* || (serdat&0x4000)) */
	return 1;
    
    if (waitqueue == 1) {
	
	
	intreq |= 0x0800;
	return 1;
    }
    //midiin start
    {
	
	extern BOOL midi_ready;
	extern long getmidibyte();
	
	if (midi_ready)
	{
	    if (!(serdat & 0x4000)){ //RBF must check
		// if it clear otherwise data can lost 
		long i=getmidibyte();
		if(i==-1)return 1;
		waitqueue = 1; 
		serdat=serdat &0xff00;
		serdat |= 0x4100;  /* RBF and STP set! */
		serdat |= ((unsigned int)i) & 0xff;
		intreq |= 0x0800; /* Set RBF flag (Receive Buffer full) */
		INTREQ(0x8000 | (0x0800));
#if SERIALDEBUG > 1
		write_log( "MIDI: received 0x%02x --> serdat==0x%04x\n",
		    (unsigned int)i, (unsigned int)serdat);
#endif
		return 1;
	    }
	    return 1;
	}
	
    }
    //midiin stop
    if (!(serdat & 0x4000)){ //RBF must check
	// if it clear otherwise data can lost 
	
	if ((serial_read ((char *)&z)) == 1) {
	    
	    waitqueue = 1;
	    serdat=serdat &0xff00;
	    serdat |= 0x4100; /* RBF and STP set! */
	    serdat |= ((unsigned int)z) & 0xff;
	    intreq |= 0x0800; /* Set RBF flag (Receive Buffer full) */
	    
	    INTREQ(0x8000 | (0x0800));
#if SERIALDEBUG > 1
	    write_log( "SERDATS: received 0x%02x --> serdat==0x%04x\n",
		(unsigned int)z, (unsigned int)serdat);
#endif
	    return 1;
	}
	return 1;
    }
    return 1;
}

void serial_dtr_on(void)
{
#if SERIALDEBUG > 0
  write_log( "SERIAL: DTR on.\n" );
#endif
    dtr=1;

    if (currprefs.serial_demand)
	serial_open ();
}

void serial_dtr_off(void)
{
#if SERIALDEBUG > 0
  write_log( "SERIAL: DTR off.\n" );
#endif
    dtr=0;
    if (currprefs.serial_demand)
	serial_close ();
}

static int serial_read (char *buffer)
{
    return readser( buffer );                 	
}

void serial_flush_buffer(void)
{
    doserout();
}

int serial_readstatus(void)
{
    int status = 0;
    getserstat( &status );
    if (status & TIOCM_CAR) {
	if (!carrier) {
	    ciabpra |= 0x20; /* Push up Carrier Detect line */
	    carrier = 1;
#if SERIALDEBUG > 0
	write_log( "SERIAL: Carrier detect.\n" );
#endif
	}
    } else {
	if (carrier) {
	    ciabpra &= ~0x20;
	    carrier = 0;
#if SERIALDEBUG > 0
	write_log( "SERIAL: Carrier lost.\n" );
#endif
	}
    }

    if (status & TIOCM_DSR) {
	if (!dsr) {
	    ciabpra |= 0x08; /* DSR ON */
	    dsr = 1;
		
	}
    } else {
	if (dsr) {
	    ciabpra &= ~0x08;
	    dsr = 0;
		
	}
    }
	ciabpra &= 0xf7;
    return status;
}

uae_u16 serial_writestatus (int old, int new)
{
    if (((old&0x80)==0x80) && ((new&0x80)==0x00))
	serial_dtr_on();
    if (((old&0x80)==0x00) && ((new&0x80)==0x80))
	serial_dtr_off();

#if SERIALDEBUG > 0
    if ((old&0x40)!=(new&0x40))
      write_log( "SERIAL: RTS %s.\n",((new&0x40)==0x40)?"set":"cleared");

    if ((old&0x10)!=(new&0x10))
      write_log( "SERIAL: CTS %s.\n",((new&0x10)==0x10)?"set":"cleared");
#endif
    return new; /* This value could also be changed here */
}

void serial_open(void)
{
    if (serdev == 1)
	return;

    if( !openser( currprefs.sername ) )
    {
        write_log( "SERIAL: Could not open Device %s\n", currprefs.sername );
        return;
    }
    serdev = 1;

}

void serial_close (void)
{
    closeser();
    serdev = 0;
}

void serial_init (void)
{
    if (!currprefs.use_serial)
	return;

    if (!currprefs.serial_demand)
	serial_open ();

    serdat = 0x2000;
    return;
}

void serial_exit (void)
{
    serial_close ();	/* serial_close can always be called because it	*/
    dtr = 0;		/* just closes *opened* filehandles which is ok	*/
    return;		/* when exiting.				*/
}
