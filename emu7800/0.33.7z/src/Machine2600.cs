/*
 * Machine2600.cs
 * 
 * A realization of a 2600 machine.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */ 

using System;
using System.Drawing;
using System.IO;
using System.Text;

namespace EMU7800 {

public class Machine2600 : Machine {
	protected M6502 _CPU;	protected AddressSpace Mem;	protected PIA PIA;	protected TIA TIA;	protected IDevice NullDevice;

	public override M6502 CPU {
		get {
			return _CPU;
		}
	}

	protected Rectangulator DisplRectangulator;

	public override Size ViewPortSize {
		set {
			DisplRectangulator.ViewPortSize = value;
		}
	}

	public override Point ClipLocation {
		get {
			return DisplRectangulator.ClipLocation;
		}
		set {
			// Keep clip location adjustments sane
			if (Math.Abs(value.X) < 50 && Math.Abs(value.Y) < 50) {
				DisplRectangulator.ClipLocation = value;
			}
		}
	}

	public override bool DrawEntireFrame {
		get {
			return DisplRectangulator.DrawEntireFrame;
		}
		set {
			DisplRectangulator.DrawEntireFrame = value;
		}
	}

	public override void DrawPauseFrame() {
		DisplRectangulator.DrawPauseFrame();
	}

	protected override void DoReset() {
		TIA.Reset();
		PIA.Reset();
		CPU.Reset();
	}

	protected override void DoRun() {		DisplRectangulator.StartFrame();		TIA.StartFrame();		CPU.RunClocks = (Scanlines + 3)*76;		while (CPU.RunClocks > 0 && !CPU.Jammed) {			CPU.Execute();			if (!CPU.EmulatorPreemptRequest) {				continue;			}			if (TIA.WSYNCDelayClocks > 0) {				CPU.Clock += (ulong)TIA.WSYNCDelayClocks/3;
				CPU.RunClocks -= TIA.WSYNCDelayClocks/3;
				TIA.WSYNCDelayClocks = 0;			}			if (TIA.EndOfFrame) {				break;			}		}		TIA.EndFrame();		DisplRectangulator.EndFrame();	}

	public override bool ExecuteTokenList(TokenList tokenList) {
		switch (tokenList.LookAhead.Symbol) {		case "fps":
			DoFPS(tokenList);
			break;		case "d":
			DMP(tokenList);
			break;
		case "m":
			DMP(tokenList);
			break;
		case "poke":
			DMP(tokenList);
			break;
		case "reset":
			Reset();
			break;
		case "r":
			Log.Msg(CPU.Disassembler.GetRegisters() + "\n");
			break;
		case "step":
			tokenList.GetNextToken();
			Token tok = tokenList.GetNextToken();
			if (!tok.EOL && tok.IsNumber) {
				Step(tok.Number);
			} else {
				Log.Msg("malformed command");
			}
			break;
		case "help":
		case "h":
		case "?":
			Log.Msg("** Machine Specific Commands **\n"			+ " fps [rate]: adj. frames per second\n"			+ " d [ataddr] [toaddr]: disassemble\n"			+ " m [ataddr] [toaddr]: memory dump\n"			+ " p [ataddr] [data]: poke\n"			+ " r: display CPU registers\n"			+ " step [#]: CPU step\n"			+ " reset: reset CPU\n");			break;
		default:
			return false;
		}
		return true;
	}

	public Machine2600(Cart c, InputAdapter ia, int slines, int fHZ) : base (ia) {
		scanlines = slines;
		frameHZ = fHZ;

		Mem = new AddressSpace(this, 13, 6);  // 2600: 13bit, 64byte pages		_CPU = new M6502(Mem);		// Configure the rectangulator
		DisplRectangulator = new Rectangulator(this,
			160,                   // # of visible horiz. pixels
			this.Scanlines,
			new Size(2, 1));       // pixel aspect ratio		TIA = new TIA(this, DisplRectangulator);		for (ushort i=0; i < 0x1000; i += 0x100) {
			Mem.Map(i, 0x0080, TIA);
		}		PIA = new PIA(this);		for (ushort i=0x0080; i < 0x1000; i += 0x100) {
			Mem.Map(i, 0x0080, PIA);
		}		Mem.Map(0x1000, 0x1000, c);
	}

	private void DMP(TokenList tokenList) {
		Token cmd = tokenList.GetNextToken();

		Token arg1 = tokenList.GetNextToken();
		if (!arg1.IsNumber) {
			goto error;
		} 
		Token arg2 = tokenList.GetNextToken();
		if (!arg2.IsNumber) {
			goto error;
		}
		
		switch (cmd.Symbol) {
		case "poke":
			Mem[(ushort)arg1.Number] = (byte)arg2.Number;
			Log.Msg("poke #${0:x2} at ${1:x4} complete\n",
				arg2.Number, arg1.Number);
			break;
		case "m":
			Log.Msg(CPU.Disassembler.MemDump(
				(ushort)arg1.Number, (ushort)arg2.Number) + "\n");
			break;
		case "d":
			Log.Msg(CPU.Disassembler.Disassemble(
				(ushort)arg1.Number, (ushort)arg2.Number) + "\n");
			break;
		}
		return;
	error:
		Log.Msg("usage: {0} [toaddr] [data]\n", cmd.Symbol);
	}

	private void Step(int steps) {
		StringBuilder sb = new StringBuilder();

		sb.Append(CPU.Disassembler.Disassemble(CPU.PC, (ushort)(CPU.PC+1)));
		sb.Append(CPU.Disassembler.GetRegisters());
		sb.Append("\n");
		for (int i=0; i < steps; i++) {
			CPU.RunClocks = 2;
			CPU.Execute();
			sb.Append(CPU.Disassembler.Disassemble(CPU.PC, (ushort)(CPU.PC+1)));
			sb.Append(CPU.Disassembler.GetRegisters());
			sb.Append("\n");
		}
		Log.Msg(sb.ToString() + "\n");
	}

	private void DoFPS(TokenList tokenList) {
		tokenList.GetNextToken();
		Token token = tokenList.GetNextToken();

		if (token.EOL) {
			Log.Msg("FPS is {0}\n", this.FrameHZ);
		} else if (!token.IsNumber) {
			Log.Msg("bad parameter\n");
		} else {
			this.FrameHZ = token.Number;
			Log.Msg("set FPS to {0}\n", this.FrameHZ);
		}
		return;
	}
}

public class Machine2600NTSC : Machine2600 {
	public override string ToString() {
		return MachineType.A2600NTSC.ToString();
	}

	public Machine2600NTSC(Cart cart, InputAdapter ia) : base(cart, ia, 262, 60) {
		soundSampleRate = TIASound.NTSC_SAMPLES_PER_SEC;
		DisplRectangulator.SetPalette(TIATables.NTSCPalette);
		Log.Msg("{0} ready\n", this);
	}
}

public class Machine2600PAL : Machine2600 {
	public override string ToString() {
		return MachineType.A2600PAL.ToString();
	}

	public Machine2600PAL(Cart cart, InputAdapter ia) : base(cart, ia, 312, 50) {
		soundSampleRate = TIASound.PAL_SAMPLES_PER_SEC;
		DisplRectangulator.SetPalette(TIATables.PALPalette);
		Log.Msg("{0} ready\n", this);
	}
}
}
