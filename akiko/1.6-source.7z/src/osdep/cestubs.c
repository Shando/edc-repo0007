 /*
  * UAE - The Un*x Amiga Emulator
  *
  * Windows CE related stubs...
  *
  * (c) 2000 Brian King
  *
  */
#include "config.h"
#include "sysconfig.h"
#if defined( _WIN32 ) && !defined( _MSC_VER )
#include <windows.h>
#include "winstuff.h"
#endif
#include "sysdeps.h"
#include "uae.h"
#include "options.h"

/* Debugger related */
int debugging = 0;

void activate_debugger (void)
{
    debugging = 0;
}

void debug (void)
{
}

/* Native2Amiga related */
void native2amiga_install( void )
{
}

void native2amiga_cleanup( void )
{
}

/* UAE Exe related */
void uaeexe_install( void )
{
}

/* BSD Socket related */
void bsdlib_install( void )
{
}

void bsdlib_reset( void )
{
}

void deinit_socket_layer( void )
{
}

/* Emulib related */
void emulib_install( void )
{
}

/* Expansion related */
void expamem_reset( void )
{
}

void expansion_init( void )
{
}

void expansion_cleanup( void )
{
}

void rtarea_init( void )
{
}

void rtarea_setup( void )
{
}

/* File-system related */
void hardfile_install( void )
{
}

void filesys_install( void )
{
}

void filesys_init( void )
{
}

void filesys_reset (void)
{
}

void filesys_prepare_reset (void)
{
}

void filesys_start_threads (void)
{
}

void free_mountinfo( struct uaedev_mount_info *mi )
{
}

struct uaedev_mount_info *alloc_mountinfo( void )
{
    return NULL;
}

/* Serial-port related */
int setbaud( long baud )
{
    return 0;
}

void getserstat( int *status )
{
}

int readser( char *buffer )
{
    return 0;
}

void writeser( char c )
{
}

int openser( char *sername )
{
    return 0;
}

void closeser( void )
{
}

void doserout( void )
{
}
