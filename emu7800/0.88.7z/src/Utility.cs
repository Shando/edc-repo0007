/*
 * Utility.cs
 * 
 * Convenient utility functions.
 * 
 * Copyright 2004-2008 (c) Mike Murphy
 * 
 */
using System;
using System.Diagnostics;
using System.IO;
using System.Security;
using System.Security.Cryptography;
using System.Text;
using System.Threading;

namespace EMU7800
{
    public static class Utility
    {
        #region MD5 Public Members

        private static readonly MD5CryptoServiceProvider md5CSP = new MD5CryptoServiceProvider();
        private static readonly StringBuilder md5SB = new StringBuilder();
        private static int offset, count;

        public static string ComputeMD5Digest(byte[] fileContents)
        {
            return fileContents != null ? StringifyMD5(md5CSP.ComputeHash(fileContents)) : null;
        }

        public static string ComputeMD5Digest(FileInfo fi)
        {
            offset = fi.Extension.Equals(".a78", StringComparison.OrdinalIgnoreCase) ? 128 : 0;
            count = (int)fi.Length - offset;
            byte[] rom = null;
            try 
            {
                using (var r = new BinaryReader(File.OpenRead(fi.FullName)))
                {
                    if (offset > 0)
                    {
                        r.ReadBytes(offset);
                    }
                    rom = r.ReadBytes(count);
                }
            }
            catch (IOException ex)
            {
                Trace.WriteLine(ex);
            }
            return rom != null ? StringifyMD5(md5CSP.ComputeHash(rom)) : null;
        }

        #endregion

        #region Misc Public Members

        public static bool IsCriticalException(Exception ex)
        {
            return ex is OutOfMemoryException
                || ex is StackOverflowException
                || ex is SecurityException
                || ex is ThreadAbortException;
        }

        #endregion

        #region Helpers

        static string StringifyMD5(byte[] bytes)
        {
            md5SB.Length = 0;
            if (bytes != null && bytes.Length >= 16)
            {
                for (var i = 0; i < 16; i++)
                {
                    md5SB.AppendFormat("{0:x2}", bytes[i]);
                }
            }
            return md5SB.ToString();
        }

        #endregion
    }
}