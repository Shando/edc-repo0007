/* $Header: /winc/emuiil/source/version.h,v 1.5 2003/08/30 10:22:29 dosius Exp $ */

/*
 * $Log: version.h,v $
 * Revision 1.5  2003/08/30 10:22:29  dosius
 * Bugfixes; work on Z80 core
 *
 * Revision 1.4  2003/08/28 10:25:50  dosius
 * A few modifications, bugfixes, a nice ASM core...
 * not to mention a nice progress bar! :D
 *
 * Revision 1.3  2003/06/30 19:28:37  dosius
 * Integrated HP's changes to all files.
 *
 * Revision 1.1  2003/06/25 18:33:08  dosius
 * Initial revision
 *
 */

/* Version information to be included in DAPPLE.C and ROM.C */

#define DappleVersion "0.32"
