
#ifndef DEVICE_H
#define DEVICE_H

#include "types.h"

//class Option;

class Device
{

    public:
/*
        Option* getOptions();
*/

};

#endif
