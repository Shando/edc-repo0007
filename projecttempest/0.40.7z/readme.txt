
		Project Tempest v0.4 (26 December 2002)
		---------------------------------------


What is Project Tempest ?
-------------------------

Project Tempest is worlds first working Atari Jaguar emulator. It currently runs several
commercial games.


What is emulated ?
------------------

MC68000:    		Completely. Using Turbo68K by Bart Trzynadlowski

GPU: 	    		All the opcodes are emulated.

DSP:	  	  	All the opcodes are emulated.

Object Processor: 	Everything is emulated, except 32-bit objects.

Blitter:		Z-Buffering and some operations missing.


System Requirements
--------------------

Pentium III/Athlon 800+ MHz
128MB RAM
DirectX 8.0 or higher
Windows 9x/ME/2000/XP

A faster processor is seriously recommended !

What's New IN Version 0.4
--------------------------

* Sound emulation in some games
* New HLE blitter for a nice speed boost
* Fixed invalid colors in some games
* Lots of other fixes


How to use the emulator
------------------------

To load commercial games, select Open ROM from File menu. To start the game, press F2 or Start from
emulation menu.

To load homebrewn games and demos, select Open BIN from File menu. Write the addresses required and
press F2 or Start from emulation menu.

To stop the emulation, press F3 or Stop from emulation menu.

Press ESC key switch between fullscreen and windowed mode.


Settings
--------

Disable DSP Emulation: 	This should usually be enabled. Only some games require DSP to be 				emulated.
		 	Doom requires DSP emulation !

Blitter:		Original Blitter is the one from earlier versions of PT.
			New Blitter is more accurate but slower.
			HLE Blitter is faster but may not work on all games.

Enable sound:		Enables sound output. You also need to enable DSP to get any sound.

DSP & GPU Speed Hack:	Removes GPU & DSP idle loops. May break some games. Gives more
			speed on some games. 


Controls
--------

Keyboard and DirectInput-compatible game controllers are supported.
Use Controller/Joypad 1/2 to configure controllers

Enable Joypad in Joypad screen enables the corresponding Jaguar joypad.

Also in Pinball Fantasies, Shifts and Ctrls are mapped as the flipper keys.


Credits
-------

Emulator programming by Ville Linde

Website and support by The Fox (emuunlim@emuunlim.com)
Website design by Malc Jennings


Contact Information
-------------------

Website:  http://pt.emuunlim.com
E-Mail:	  ptemu@emuunlim.com

