package com.blissjweb.plugin;

import java.applet.*;
import com.bliss.core.Intellivision;
import com.bliss.core.devices.*;

public class AppletPlugIn implements PlugIn
{

    public AppletPlugIn(Applet applet) {
        vod = new AppletVideoOutputDevice(applet);
        id = new AppletInputDevice(applet);
        aod = new AppletAudioOutputDevice();
        cd = new AppletClockDevice();
    }

    public void init(Intellivision inty) {
        vod.init(inty.getImageBank());
        aod.init();
        id.init();
    }

    public void release(Intellivision inty) {
        id.release();
        aod.release();
        vod.release();
    }

    public String getPlugInName() {
        return "";
    }

    public String getPlugInDescription() {
        return "";
    }

    public VideoOutputDevice getVideoOutputDevice() {
        return vod;
    }

    public AudioOutputDevice getAudioOutputDevice() {
        return aod;
    }

    public InputDevice getInputDevice() {
        return id;
    }

    public ClockDevice getClockDevice() {
        return cd;
    }

    public boolean stopRequested() {
        return false;
    }

    private AppletVideoOutputDevice vod;
    private AppletAudioOutputDevice aod;
    private AppletInputDevice id;
    private AppletClockDevice cd;

}
