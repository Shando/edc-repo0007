/*
 * SettingsPage.cs
 * 
 * A TabPage that permits major game setting changes
 * 
 * Copyright (c) 2003, 2004 Mike Murphy
 * 
 */

using System;
using System.Drawing;
using System.Windows.Forms;

namespace EMU7800 {
	
public class SettingsPage : TabPage {
	private ControlPanelForm ControlPanelForm;

	private GroupBox gbHostSelect;
	private ComboBox cmbHostSelect;

	public string[] HostSelections = {"Windows GDI", "Simple DirectMedia Layer (SDL)"};

	public SettingsPage(ControlPanelForm f) {
		ControlPanelForm = f;
		Text = "Settings";

		cmbHostSelect = new ComboBox();
		cmbHostSelect.Text = "";
		cmbHostSelect.Location = new Point(10, 15);
		cmbHostSelect.Size = new Size(180, 45);
		cmbHostSelect.Items.AddRange(HostSelections);
		cmbHostSelect.SelectedIndexChanged += new EventHandler(OnSelectedIndexChanged);
		gbHostSelect = new GroupBox();
		gbHostSelect.Text = "Host Select";
		gbHostSelect.Location = new Point(5, 10);
		gbHostSelect.Size = new Size(200, 45);
		gbHostSelect.Controls.Add(cmbHostSelect);

		Controls.AddRange(new Control[] {gbHostSelect});

		VisibleChanged += new EventHandler(OnVisibleChanged);
	}

	private void OnVisibleChanged(object sender, EventArgs e) {
		try {
			switch (Globals.HostSelect.ToUpper()) {
			case "SDL":
				cmbHostSelect.SelectedIndex = 1;
				break;
			case "GDI":
			default:
				cmbHostSelect.SelectedIndex = 0;
				break;
			}
		} catch {
			cmbHostSelect.SelectedIndex = 0;
		}
	}

	private void OnSelectedIndexChanged(object sender, EventArgs e) {
		if (sender == cmbHostSelect) {
			switch (cmbHostSelect.SelectedIndex) {
			case 1:
				Globals.HostSelect = "SDL";
				break;
			case 0:
			default:
				Globals.HostSelect = "GDI";
				break;
			}
			Globals.Save();
		}
	}
}
}