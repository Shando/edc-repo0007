/*
 * HelpPage.cs
 * 
 * A ControlPanelTabPage extension that displays the README file.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */

using System;
using System.Collections;
using System.Drawing;
using System.Windows.Forms;

namespace EMU7800 {

public class HelpPage : ControlPanelTabPage {
	private RichTextBox rtxtBox;

	public static string READMEFileName {
		get {
			return Globals.RootDir + "/README.TXT";
		}
	}
	
	public override void ClearChanges() {}
	public override void ApplyChanges() {}

	public HelpPage() {
		Text = "README";

		try {
		rtxtBox = new RichTextBox();
		rtxtBox.BackColor = Color.Beige;
		rtxtBox.Font = new Font("Verdana", 12F,
			FontStyle.Regular, GraphicsUnit.Point,
			((System.Byte)(0)));
		rtxtBox.ReadOnly = true;
		rtxtBox.WordWrap = false;
		rtxtBox.ScrollBars = RichTextBoxScrollBars.Both;
		rtxtBox.LoadFile(READMEFileName, RichTextBoxStreamType.PlainText);
		Controls.Add(rtxtBox);
		} catch {
			rtxtBox = new RichTextBox();
		}
	
		Layout += new LayoutEventHandler(OnLayout);
	}
	
	private void OnLayout(Object sender, LayoutEventArgs e) {		
		rtxtBox.Location = new Point(15, 15);
		rtxtBox.Size = new Size(Size.Width - 2*15, Size.Height - 2*15);
	}
}
}