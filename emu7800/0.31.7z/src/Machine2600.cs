/*
 * Machine2600.cs
 * 
 * A realization of a 2600 (NTSC) only machine.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */ 

using System;
using System.Drawing;
using System.IO;
using System.Text;

namespace EMU7800 {

public class Machine2600 : Machine {
	protected M6502 _CPU;	protected AddressSpace Mem;	protected PIA PIA;	protected TIA TIA;	protected TIASound TIASound;	protected IDevice NullDevice;

	public override M6502 CPU {
		get {
			return _CPU;
		}
	}

	protected Rectangulator DisplRectangulator;

	public override Size ViewPortSize {
		set {
			DisplRectangulator.ViewPortSize = value;
		}
	}

	public override Point ClipLocation {
		get {
			return DisplRectangulator.ClipLocation;
		}
		set {
			// Keep clip location adjustments sane
			if (Math.Abs(value.X) < 50 && Math.Abs(value.Y) < 50) {
				DisplRectangulator.ClipLocation = value;
			}
		}
	}

	public override bool DrawEntireFrame {
		get {
			return DisplRectangulator.DrawEntireFrame;
		}
		set {
			DisplRectangulator.DrawEntireFrame = value;
		}
	}

	public override void DrawPauseFrame() {
		DisplRectangulator.DrawPauseFrame();
	}

	public override void StopCPU() {
		CPU.Stop();
	}

	protected override void DoReset() {
		TIA.Reset();
		PIA.Reset();
		CPU.Reset();
	}

	protected override void DoRun() {		DisplRectangulator.StartFrame();		TIA.StartFrame();		if (TIASound != null) {			TIASound.StartFrame();		}		CPU.Execute(25000);		if (TIASound != null) {			TIASound.EndFrame();		}		DisplRectangulator.EndFrame();	}

	public override bool ExecuteTokenList(TokenList tokenList) {
		switch (tokenList.LookAhead.Symbol) {		case "d":
			DMP(tokenList);
			break;
		case "m":
			DMP(tokenList);
			break;
		case "poke":
			DMP(tokenList);
			break;
		case "reset":
			Reset();
			break;
		case "r":
			Log.Msg(CPU.Disassembler.GetRegisters() + "\n");
			break;
		case "step":
			tokenList.GetNextToken();
			Token tok = tokenList.GetNextToken();
			if (!tok.EOL && tok.IsNumber) {
				Step(tok.Number);
			} else {
				Log.Msg("malformed command");
			}
			break;
		case "help":
		case "h":
		case "?":
			Log.Msg("** Machine Specific Commands **\n"			+ " d [ataddr] [toaddr]: disassemble\n"			+ " m [ataddr] [toaddr]: memory dump\n"			+ " p [ataddr] [data]: poke\n"			+ " r: display CPU registers\n"			+ " step [#]: CPU step\n"			+ " reset: reset CPU\n");			break;
		default:
			return false;
		}
		return true;
	}

	public Machine2600(Cart c, InputAdapter ia) : base (ia) {
		Mem = new AddressSpace(this, 13, 6);  // 2600: 13bit, 64byte pages		_CPU = new M6502(Mem);		// Configure the rectangulator
		DisplRectangulator = new Rectangulator(this,
			new Size(160, 262),	         // Frame buffer
			new Rectangle(0, 15, 160, 240),  // Clipping rectangle
			new Size(2, 1));	         // Pixel aspect ratio		if (Globals.SoundOn) {			TIASound = new TIASound(this);		} else {			TIASound = null;		}		TIA = new TIA(DisplRectangulator, TIASound);		for (ushort i=0; i < 0x1000; i += 0x100) {
			Mem.Map(i, 0x0080, TIA);
		}		PIA = new PIA();		for (ushort i=0x0080; i < 0x1000; i += 0x100) {
			Mem.Map(i, 0x0080, PIA);
		}		Mem.Map(0x1000, 0x1000, c);
	}

	private void DMP(TokenList tokenList) {
		Token cmd = tokenList.GetNextToken();

		Token arg1 = tokenList.GetNextToken();
		if (!arg1.IsNumber) {
			goto error;
		} 
		Token arg2 = tokenList.GetNextToken();
		if (!arg2.IsNumber) {
			goto error;
		}
		
		switch (cmd.Symbol) {
		case "poke":
			Mem[(ushort)arg1.Number] = (byte)arg2.Number;
			Log.Msg("poke #${0:x2} at ${1:x4} complete\n",
				arg2.Number, arg1.Number);
			break;
		case "m":
			Log.Msg(CPU.Disassembler.MemDump(
				(ushort)arg1.Number, (ushort)arg2.Number) + "\n");
			break;
		case "d":
			Log.Msg(CPU.Disassembler.Disassemble(
				(ushort)arg1.Number, (ushort)arg2.Number) + "\n");
			break;
		}
		return;
	error:
		Log.Msg("usage: {0} [toaddr] [data]\n", cmd.Symbol);
	}

	private void Step(int steps) {
		StringBuilder sb = new StringBuilder();

		sb.Append(CPU.Disassembler.Disassemble(CPU.PC, (ushort)(CPU.PC+1)));
		sb.Append(CPU.Disassembler.GetRegisters());
		sb.Append("\n");
		for (int i=0; i < steps; i++) {
			CPU.Execute(1);
			sb.Append(CPU.Disassembler.Disassemble(CPU.PC, (ushort)(CPU.PC+1)));
			sb.Append(CPU.Disassembler.GetRegisters());
			sb.Append("\n");
		}
		Log.Msg(sb.ToString() + "\n");
	}
}

public class Machine2600NTSC : Machine2600 {
	public override string ToString() {
		return MachineType.A2600NTSC.ToString();
	}

	public Machine2600NTSC(Cart cart, InputAdapter ia) : base(cart, ia) {
		FrameHZ = 60;
		DisplRectangulator.SetPalette(TIATables.NTSCPalette);
		Log.Msg("{0} ready\n", this);
	}
}

public class Machine2600PAL : Machine2600 {
	public override string ToString() {
		return MachineType.A2600PAL.ToString();
	}

	public Machine2600PAL(Cart cart, InputAdapter ia) : base(cart, ia) {
		FrameHZ = 50;
		DisplRectangulator.SetPalette(TIATables.PALPalette);
		Log.Msg("{0} ready\n", this);
	}
}
}
