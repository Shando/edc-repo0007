/*
 * Dapple ][ Emulator  Version 0.07
 * Copyright (C) 2002, 2003 Dapple ][ Development.  All rights reserved.
 *
 * Component:  DISK: routines for emulating two disk drives
 * Revision:   (0.07) 2003.0201 (Columbia)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <stdio.h>
#include <string.h>
#include "asmlib.h"
#include "dapple.h"

/* dapple.c */
extern unsigned char exitprogram;
extern unsigned int  window;
extern unsigned char inidiskpath1[256];
extern unsigned char inidiskpath2[256];
unsigned int strright(unsigned char *string1, unsigned char *string2);
void setmessage(unsigned char *message);
unsigned int fileselectmenu(unsigned int keyboard, unsigned int window,
                            unsigned char *title,
                            unsigned char *filename, unsigned char *tail,
                            unsigned char optnew);

/* cpu.c */
void cpusetdelay(unsigned int value);
unsigned int cpugetdelay();
void cpusetlinecycle(unsigned int value);
unsigned int cpugetlinecycle();

/* video.c */
extern unsigned char    virtcopy;


const unsigned char DISKTYPENONE        = 0;
const unsigned char DISKTYPEDOS         = 1;
const unsigned char DISKTYPEPRODOS      = 2;
const unsigned char DISKTYPENIBBLE      = 3;

typedef struct {
  unsigned char path[260];
  unsigned char type;
  unsigned int track;
  unsigned int phase;
  unsigned int bytepointer;
  unsigned char access;
  unsigned char writeprotected;
  unsigned char data[233472];
} drivedisk;

static unsigned char    driveselect;
static unsigned int     drivelatch;
static unsigned int     drivelatch0ee;
drivedisk               drivedisk1;
drivedisk               drivedisk2;
static unsigned char    drivemotorflag1;
static unsigned char    drivemotorflag2;
unsigned char           drivefastmode;
unsigned char           drivefastflag;
unsigned char           drivemessageflag;
static unsigned int     driveoldlinecycle;
static unsigned int     driveolddelay;
static unsigned char    driveselectmenu;

#define false 0
#define true 1

/* Drive                */
/* - driveempty         */
/* - drivereset         */
/* - driveinit          */
/* - driveconvertsecnib */
/* - driveload          */
/* - driveread          */
/* - drivewrite         */



/*-------------------------------------*/


      void drivediskstore(FILE *file, drivedisk *disk) {
        fwrite(disk, sizeof(drivedisk), 1, file);
/*
 *      fwrite(&disk->path,             sizeof(disk->path),             1,file);
 *      fwrite(&disk->type,             sizeof(disk->type),             1,file);
 *      fwrite(&disk->phase,            sizeof(disk->phase),            1,file);
 *      fwrite(&disk->track,            sizeof(disk->track),            1,file);
 *      fwrite(&disk->bytepointer,      sizeof(disk->bytepointer),      1,file);
 *      fwrite(&disk->access,           sizeof(disk->access),           1,file);
 *      fwrite(&disk->writeprotected,   sizeof(disk->writeprotected),   1,file);
 *      fwrite(&disk->data,             sizeof(disk->data),             1,file);
 */
      } /* drivediskstore */


      void drivestore(FILE *file) {

        drivediskstore(file, &drivedisk1);
        drivediskstore(file, &drivedisk2);
        fwrite(&driveselect,            sizeof(driveselect),            1,file);
        fwrite(&drivelatch,             sizeof(drivelatch),             1,file);
        fwrite(&drivelatch0ee,          sizeof(drivelatch0ee),          1,file);
        fwrite(&drivemotorflag1,        sizeof(drivemotorflag1),        1,file);
        fwrite(&drivemotorflag2,        sizeof(drivemotorflag2),        1,file);
        fwrite(&drivefastmode,          sizeof(drivefastmode),          1,file);
        fwrite(&drivefastflag,          sizeof(drivefastflag),          1,file);
        fwrite(&drivemessageflag,       sizeof(drivemessageflag),       1,file);
        fwrite(&driveoldlinecycle,      sizeof(driveoldlinecycle),      1,file);
        fwrite(&driveolddelay,          sizeof(driveolddelay),          1,file);
        fwrite(&driveselectmenu,        sizeof(driveselectmenu),        1,file);

      } /* drivestore */


/*-------------------------------------*/


      void drivediskrestore(FILE *file, drivedisk *disk) {
        fread(disk, sizeof(drivedisk), 1, file);
/*
 *      fread(&disk->path,              sizeof(disk->path),             1,file);
 *      fread(&disk->type,              sizeof(disk->type),             1,file);
 *      fread(&disk->phase,             sizeof(disk->phase),            1,file);
 *      fread(&disk->track,             sizeof(disk->track),            1,file);
 *      fread(&disk->bytepointer,       sizeof(disk->bytepointer),      1,file);
 *      fread(&disk->access,            sizeof(disk->access),           1,file);
 *      fread(&disk->writeprotected,    sizeof(disk->writeprotected),   1,file);
 *      fread(&disk->data,              sizeof(disk->data),             1,file);
 */
      } /* drivediskrestore */


      void driverestore(FILE *file) {

        drivediskrestore(file, &drivedisk1);
        drivediskrestore(file, &drivedisk2);
        fread(&driveselect,             sizeof(driveselect),            1,file);
        fread(&drivelatch,              sizeof(drivelatch),             1,file);
        fread(&drivelatch0ee,           sizeof(drivelatch0ee),          1,file);
        fread(&drivemotorflag1,         sizeof(drivemotorflag1),        1,file);
        fread(&drivemotorflag2,         sizeof(drivemotorflag2),        1,file);
        fread(&drivefastmode,           sizeof(drivefastmode),          1,file);
        fread(&drivefastflag,           sizeof(drivefastflag),          1,file);
        fread(&drivemessageflag,        sizeof(drivemessageflag),       1,file);
        fread(&driveoldlinecycle,       sizeof(driveoldlinecycle),      1,file);
        fread(&driveolddelay,           sizeof(driveolddelay),          1,file);
        fread(&driveselectmenu,         sizeof(driveselectmenu),        1,file);

      } /* driverestore */


/*-------------------------------------*/


      /* set all bytes of emulated disk to 0xaa */
      void driveempty(drivedisk *disk) {
        register unsigned int i;

        strcpy(disk->path, "");                 /* clear filename */
        disk->type = DISKTYPENONE;              /* set type to no disk present */

        for ( i=0; i<233472; i++) {             /* no bytes */
          disk->data[i] = 0xaa;
        } /* for i */

      } /* driveempty */


/*-------------------------------------*/


      void drivereset() {

        driveselect             = true;         /* drive 1 */
        drivedisk1.access       = true;         /* read */
        drivedisk2.access       = true;         /* read */
        drivemotorflag1         = false;        /* off */
        drivemotorflag2         = false;        /* off */
        imagefillbox(window, 628, 8, 629, 9, RGBLGHTOFF);
        imagefillbox(window, 632, 8, 633, 9, RGBLGHTOFF);
        drivefastmode           = false;

      } /* drivereset */


/*-------------------------------------*/


      void driveinit() {

        driveempty(&drivedisk1);
        driveempty(&drivedisk2);
        drivelatch      = 0xaa;
        drivelatch0ee   = 0;
        drivedisk1.track        = 34;
        drivedisk2.track        = 34;
        drivedisk1.phase        = 35*2-1;
        drivedisk2.phase        = 35*2-1;
        drivedisk1.bytepointer  = 0;
        drivedisk2.bytepointer  = 0;
        drivedisk1.writeprotected = false;
        drivedisk2.writeprotected = false;
        drivefastmode   = false;
        drivefastflag   = true;
        drivemessageflag = false;
        driveselectmenu = 0;
        drivereset();

      } /* driveinit */


/*-------------------------------------*/


      void driveconvertsecnib (unsigned char source[144360], drivedisk *disk, unsigned int volume) {
        unsigned int    track;
        unsigned int    sector;
        unsigned int    sectorsit;
        unsigned int    secpointer;
        unsigned char   *nibpointer;
        unsigned int    zappointer;
        unsigned int    happointer;
        unsigned char   diskbyte;
        unsigned char   diskzap[256];
        unsigned char   diskhap[256];
        static unsigned char dossit [] = {
          0x00, 0x0d, 0x0b, 0x09, 0x07, 0x05, 0x03, 0x01,
          0x0e, 0x0c, 0x0a, 0x08, 0x06, 0x04, 0x02, 0x0f
        };
        static unsigned int dospos [] = {
          0x00, 0x0d, 0x0b, 0x09, 0x07, 0x05, 0x03, 0x01,
          0x0e, 0x0c, 0x0a, 0x08, 0x06, 0x04, 0x02, 0x0f
        };
        static unsigned int prodospos [] = {
          0x00, 0x02, 0x04, 0x06, 0x08, 0x0a, 0x0c, 0x0e,
          0x01, 0x03, 0x05, 0x07, 0x09, 0x0b, 0x0d, 0x0f
        };
        static unsigned char diskwit [] = {
          0x96, 0x97, 0x9a, 0x9b, 0x9d, 0x9e, 0x9f, 0xa6,
          0xa7, 0xab, 0xac, 0xad, 0xae, 0xaf, 0xb2, 0xb3,
          0xb4, 0xb5, 0xb6, 0xb7, 0xb9, 0xba, 0xbb, 0xbc,
          0xbd, 0xbe, 0xbf, 0xcb, 0xcd, 0xce, 0xcf, 0xd3,
          0xd6, 0xd7, 0xd9, 0xda, 0xdb, 0xdc, 0xdd, 0xde,
          0xdf, 0xe5, 0xe6, 0xe7, 0xe9, 0xea, 0xeb, 0xec,
          0xed, 0xee, 0xef, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6,
          0xf7, 0xf9, 0xfa, 0xfb, 0xfc, 0xfd, 0xfe, 0xff
        };

        secpointer      = 0;
        for ( track=0; track < 35; track++) {
          for ( sector=0; sector < 16; sector++) {
            if (disk->type == DISKTYPEDOS ) {
              sectorsit = dospos[sector];
            }
            else {
              sectorsit = prodospos[sector];
            }
            nibpointer  = &disk->data[(track * 0x1a00) + (sectorsit * 416)];
            *nibpointer++       = 0x00;         /* write header prolog */
            *nibpointer++       = 0xd5;
            *nibpointer++       = 0xaa;
            *nibpointer++       = 0x96;
            *nibpointer++       = ((volume >> 1) & 0x55) | 0xaa;
            *nibpointer++       = ( volume       & 0x55) | 0xaa;
            *nibpointer++       = ((track >> 1)  & 0x55) | 0xaa;
            *nibpointer++       = ( track        & 0x55) | 0xaa;
            *nibpointer++       = ((sectorsit >> 1) & 0x55) | 0xaa;
            *nibpointer++       = ( sectorsit       & 0x55) | 0xaa;
            *nibpointer++       = (((volume ^ track ^ sectorsit) >> 1) & 0x55) | 0xaa;
            *nibpointer++       = (( volume ^ track ^ sectorsit)       & 0x55) | 0xaa;
            *nibpointer++       = 0xde;         /* write header epilog */
            *nibpointer++       = 0xaa;
            *nibpointer++       = 0xeb;
            *nibpointer++       = 0x00;         /* gap */
            *nibpointer++       = 0x01;
            *nibpointer++       = 0x00;
            *nibpointer++       = 0x01;
            *nibpointer++       = 0x00;
            *nibpointer++       = 0xd5;         /* write data prolog */
            *nibpointer++       = 0xaa;
            *nibpointer++       = 0xad;

            for ( zappointer=0; zappointer < 256; zappointer++) {       /* clear buffers */
              diskzap[zappointer]       = 0;
              diskhap[zappointer]       = 0;
            }

            happointer  = 2;
            do {
              for ( zappointer=0; zappointer < 0x56; zappointer++) {
                happointer              = (happointer - 1) & 0xff;
                diskbyte                = source[secpointer + happointer];
                diskzap[zappointer]     = (diskzap[zappointer] << 2)
                                          | ((diskbyte & 0x1) << 1)
                                          | ((diskbyte & 0x2) >> 1);
                diskhap[happointer]     = diskbyte >> 2;
              }
            }
            while (happointer != 0);

            for ( zappointer=0x56; zappointer > 0; zappointer--) {
              *nibpointer++             = diskwit[diskzap[zappointer] ^ diskzap[zappointer-1]];
            }

            *nibpointer++               = diskwit[diskzap[0] ^ diskhap[0]];

            for (happointer=1; happointer < 256; happointer++) {
              *nibpointer++             = diskwit[diskhap[happointer] ^ diskhap[happointer-1]];
            }

            *nibpointer++               = diskwit[diskhap[255]];

            *nibpointer++       = 0xde;         /* write data epilog */
            *nibpointer++       = 0xaa;
            *nibpointer++       = 0xeb;
            *nibpointer++       = 0x00;
            *nibpointer++       = 0x01;
            *nibpointer++       = 0x00;
            for ( zappointer=0; zappointer<11; zappointer++) {  /* write gap */
              *nibpointer++     = 0x01;
              *nibpointer++     = 0x00;
              *nibpointer++     = 0x01;
              *nibpointer++     = 0x00;
            }
            secpointer  = secpointer + 256;
          } /* for sector */
        } /* for track */
      } /* driveconvertsecnib */


/*-------------------------------------*/


      /* load standard DOS image (.DSK) or Nibble image (.NIB) */
      unsigned int driveload(unsigned int keyboard, unsigned int window,
                             drivedisk *disk, unsigned char *filename) {
        FILE *file;
        unsigned int filelength;
        unsigned char diskbuffer [143360];

        stringwrite(window, "Attempting to load disk image '");
        stringwrite(window, filename);
        stringwrite(window, "'...\r");

        file = fopen(filename,"rb");
        if (!file) {
          stringwrite(window, "Disk image not found. Press a key to continue\r");
          imageupdate();
          do { }
          while ( (unsigned char)channelin(keyboard) == 0);
          return 0;
        }

        fseek(file,0,SEEK_END);         /* get filelength */
        filelength=ftell(file);
        fseek(file,0,SEEK_SET);
        stringwrite(window, "Loading disk image...\r");
        imageupdate();

        if (filelength < 232960 /*==143360*/) {
          fread(diskbuffer,143360,1,file);
          fclose(file);
          if (strright(filename, ".PO")) {
            stringwrite(window, "Converting ProDOS image...\r");
            imageupdate();
            disk->type = DISKTYPEPRODOS;
            driveconvertsecnib(diskbuffer, disk, 254);
          }
          else {
            stringwrite(window, "Converting DOS image...\r");
            imageupdate();
            disk->type = DISKTYPEDOS;
            driveconvertsecnib(diskbuffer, disk, 254);
          }
          strcpy(disk->path, filename);
/*        debugger(diskdata, 233472); */
          return 1;
        }
        else {
          if (filelength==232960) {
            fread(&disk->data, 232960, 1, file);
            fclose(file);
            disk->type = DISKTYPENIBBLE;
            strcpy(disk->path, filename);
            return 1;
          }
          else {
            fclose(file);
            stringwrite(window, "Wrong disk image format.\r");
            imageupdate();
            do { }
            while ( (unsigned char)channelin(keyboard) == 0);
            return 0;   /* wrong file size */
          }
        }
      } /* driveload */


/*-------------------------------------*/


      void drivetrackmessage () {
        unsigned char message[256];
        register unsigned int i;

        if (drivemessageflag) {
          strcpy (message, "Drive 1 Track: xx / Drive 2 Track: xx");
          i = drivedisk1.track / 10;
          if (i == 0) { message[15] = ' '; }
          else        { message[15] = i + '0'; }
          message[16] = (drivedisk1.track % 10) + '0';
          i = drivedisk2.track / 10;
          if (i == 0) { message[35] = ' '; }
          else        { message[35] = i + '0'; }
          message[36] = (drivedisk2.track % 10) + '0';
          setmessage(message);
        }
      } /* drivetrackmessage */


/*-------------------------------------*/


      unsigned char driveread (unsigned int addr) {
        unsigned int i;
        unsigned char bytebuffer;

        switch (addr & 0xf) {
          case 0x0 :                    /* --- */
          case 0x2 :
          case 0x4 :
          case 0x6 :
            return 0x0d;
          case 0x1 :                    /* set phase 0 */
          case 0x3 :                    /* set phase 1 */
          case 0x5 :                    /* set phase 2 */
          case 0x7 :                    /* set phase 3 */
            addr = (addr &0xf) >> 1;
            if (driveselect) {
              i = (drivedisk1.phase + 1) & 3;
              if (i == addr) {
                if (drivedisk1.phase < (35*2-1)) {
                  drivedisk1.phase++;
                  drivedisk1.track = drivedisk1.phase >> 1;
                  drivetrackmessage();
                }
              }
              else {
                if ( ((i+2)&3) == addr) {
                  if (drivedisk1.phase > 0) {
                    drivedisk1.phase--;
                    drivedisk1.track = drivedisk1.phase >> 1;
                    drivetrackmessage();
                  }
                }
              }
            }
            else {
              i = (drivedisk2.phase + 1) & 3;
              if (i == addr) {
                if (drivedisk2.phase < (35*2-1)) {
                  drivedisk2.phase++;
                  drivedisk2.track = drivedisk2.phase >> 1;
                  drivetrackmessage();
                }
              }
              else {
                if ( ((i+2)&3) == addr) {
                  if (drivedisk2.phase > 0) {
                    drivedisk2.phase--;
                    drivedisk2.track = drivedisk2.phase >> 1;
                    drivetrackmessage();
                  }
                }
              }
            }
            return 0xd;
          case 0x8 :    /* motor off */
            if (driveselect) {
              drivemotorflag1   = false;
              imagefillbox(window, 628, 8, 629, 9, RGBLGHTOFF);
              drivemotorflag2   = false;
              imagefillbox(window, 632, 8, 633, 9, RGBLGHTOFF);
              virtcopy = 1;
            }
            else {
              drivemotorflag1   = false;
              imagefillbox(window, 628, 8, 629, 9, RGBLGHTOFF);
              drivemotorflag2   = false;
              imagefillbox(window, 632, 8, 633, 9, RGBLGHTOFF);
              virtcopy = 1;
            }
            if (drivefastmode) {
              cpusetlinecycle(driveoldlinecycle);
              cpusetdelay(driveolddelay);
              drivefastmode     = false;
            }
            return 0xa0;
          case 0x9 :    /* motor on */
            if (driveselect) {
              drivemotorflag1   = true;
              imagefillbox(window, 628, 8, 629, 9, RGBLGHTON);
              drivemotorflag2   = false;
              imagefillbox(window, 632, 8, 633, 9, RGBLGHTOFF);
              virtcopy = 1;
            }
            else {
              drivemotorflag1   = false;
              imagefillbox(window, 628, 8, 629, 9, RGBLGHTOFF);
              drivemotorflag2   = true;
              imagefillbox(window, 632, 8, 633, 9, RGBLGHTON);
              virtcopy = 1;
            }
            if (drivefastflag) {
              if (!drivefastmode) {
                driveoldlinecycle       = cpugetlinecycle();
                driveolddelay           = cpugetdelay();
                cpusetdelay(0);
                cpusetlinecycle(65*8);
                drivefastmode   = true;
              }
            }
            return 0xa0;
          case 0xa :                    /* set drive 1 */
            driveselect = true;
            return 0xa0;
          case 0xb :                    /* set drive 2 */
            driveselect = false;
            return 0xa0;
          case 0xc :                    /* read/write byte to/from disk */
            if (driveselect) {
              if (drivedisk1.access) {
                bytebuffer = drivedisk1.data[drivedisk1.track * 0x1a00 + drivedisk1.bytepointer];
              }
              else {
                if (!drivedisk1.writeprotected) {
                  drivedisk1.data[drivedisk1.track * 0x1a00 + drivedisk1.bytepointer] = drivelatch;
                }
                bytebuffer = drivelatch;
              }
//            if (drivemotorflag1) {
                drivedisk1.bytepointer++;
                if (drivedisk1.bytepointer >= 0x1a00) {
                  drivedisk1.bytepointer = 0;
                }
//            }
              return bytebuffer;
            }
            else {
              if (drivedisk2.access) {
                bytebuffer = drivedisk2.data[drivedisk2.track * 0x1a00 + drivedisk2.bytepointer];
              }
              else {
                if (!drivedisk2.writeprotected) {
                  drivedisk2.data[drivedisk2.track * 0x1a00 + drivedisk2.bytepointer] = drivelatch;
                }
                bytebuffer      = drivelatch;
              }
//            if (drivemotorflag2) {
                drivedisk2.bytepointer++;
                if (drivedisk2.bytepointer >= 0x1a00) {
                  drivedisk2.bytepointer = 0;
                }
//            }
              return bytebuffer;
            }
          case 0xd :
            return 0xa0;
          case 0xe :                    /* set disk read */
            if (driveselect) {
              drivedisk1.access = true;
              return (((drivedisk1.writeprotected)? 0x80 : 0x00) | drivelatch0ee);
            }
            else {
              drivedisk2.access = true;
              return (((drivedisk2.writeprotected)? 0x80 : 0x00) | drivelatch0ee);
            }
          case 0xf :                    /* set disk write */
            if (driveselect) {
              drivedisk1.access = false;
              return 0;
            }
            else {
              drivedisk2.access = false;
              return 1;
            }
        } /* switch */
      } /* driveread */


/*-------------------------------------*/


      void drivewrite(unsigned int addr, unsigned int value) {

        switch (addr&0xf) {

          case 0x0 :
          case 0x1 :
          case 0x2 :
          case 0x3 :
          case 0x4 :
          case 0x5 :
          case 0x6 :
          case 0x7 :
            return;
          case 0x8 :
            if (driveselect) {
              drivemotorflag1   = false;
              imagefillbox(window, 628, 8, 629, 9, RGBLGHTOFF);
              drivemotorflag2   = false;
              imagefillbox(window, 632, 8, 633, 9, RGBLGHTOFF);
              virtcopy = 1;
            }
            else {
              drivemotorflag1   = false;
              imagefillbox(window, 628, 8, 629, 9, RGBLGHTOFF);
              drivemotorflag2   = false;
              imagefillbox(window, 632, 8, 633, 9, RGBLGHTOFF);
              virtcopy = 1;
            }
            if (drivefastmode) {
              cpusetlinecycle(driveoldlinecycle);
              cpusetdelay(driveolddelay);
              drivefastmode     = false;
            }
            return;
          case 0x9 :
            if (driveselect) {
              drivemotorflag1   = true;
              imagefillbox(window, 628, 8, 629, 9, RGBLGHTON);
              drivemotorflag2   = false;
              imagefillbox(window, 632, 8, 633, 9, RGBLGHTOFF);
              virtcopy = 1;
            }
            else {
              drivemotorflag1   = false;
              imagefillbox(window, 628, 8, 629, 9, RGBLGHTOFF);
              drivemotorflag2   = true;
              imagefillbox(window, 632, 8, 633, 9, RGBLGHTON);
              virtcopy = 1;
            }
            if (drivefastflag) {
              if (!drivefastmode) {
                driveoldlinecycle       = cpugetlinecycle();
                driveolddelay           = cpugetdelay();
                cpusetdelay(0);
                cpusetlinecycle(65*8);
                drivefastmode   = true;
              }
            }
            return;
          case 0xa :
            driveselect = true;         /* set drive 1 */
            return;
          case 0xb :
            driveselect = false;        /* set drive 2 */
            return;
          case 0xc :
            return;
          case 0xd :
            drivelatch  = value;
            return;
          case 0xe :                    /* set disk read */
            if (driveselect) {
              drivedisk1.access = true;
            }
            else {
              drivedisk2.access = true;
            }
            return;
          case 0xf :                    /* set disk write */
            drivelatch0ee       = value & 0x1f;
            if (driveselect) {
              drivedisk1.access = false;
            }
            else {
              drivedisk2.access = false;
            }
            return;
        } /* switch */

      } /* drivewrite */


/*-------------------------------------*/


      void drivemenu () {
        unsigned int screen;
        unsigned int keyboard;
        unsigned int window;
        unsigned char key;
        unsigned char update;
        unsigned char filename[260];

        screen = screenstore();
        if (!windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1, "Drive Options", &keyboard, &window)) {

          update = 1;
          do {
            if (update) {
              channelout(window, 12);           /* clear window */
              stringwrite(window, "\r[ESC] - Quit\r\r");

              stringwrite(window, "\rCurrent drive is drive ");
              channelout(window, driveselectmenu + '1');
              stringwrite(window, ".\rFilename: ");
              if (driveselectmenu) {
                if (!inidiskpath2[0]) {
                  stringwrite(window, "<empty>");
                }
                else {
                  stringwrite(window, inidiskpath2);
                }
              }
              else {
                if (!inidiskpath1[0]) {
                  stringwrite(window, "<empty>");
                }
                else {
                  stringwrite(window, inidiskpath1);
                }
              }
              channelout(window, 13);

              stringwrite(window, "\r[1] - Select Drive 1");
              stringwrite(window, "\r[2] - Select Drive 2");
              stringwrite(window, "\r[E] - Eject disk");
              stringwrite(window, "\r[L] - Load a disk image");
              stringwrite(window, "\r\r[M] - Drive Message: ");
              if (drivemessageflag) {
                stringwrite(window, "On");
              }
              else {
                stringwrite(window, "Off");
              }

              stringwrite(window, "\r[F] - Drive Fast Access: ");
              if (drivefastflag) {
                stringwrite(window, "On");
              }
              else {
                stringwrite(window, "Off");
              }

              imageupdate();
              update = 0;
            }
            do {
              key = (unsigned char)channelin(keyboard);
            }
            while ((key == 0) && (!exitprogram));
            switch (key) {
              case '1' :
                driveselectmenu = 0;
                update = 1;
                break;
              case '2' :
                driveselectmenu = 1;
                update = 1;
                break;
              case 'e' :
              case 'E' :
                if (driveselectmenu) {
                  driveempty(&drivedisk2);
                  strcpy(inidiskpath2, "");
                }
                else {
                  driveempty(&drivedisk1);
                  strcpy(inidiskpath1, "");
                }
                update = 1;
                break;
              case 'f' :
              case 'F' :
                drivefastflag = !drivefastflag;
                update = 1;
                break;
              case 'l' :
              case 'L' :
                if (driveselectmenu) {
                  if (fileselectmenu(keyboard, window, "Drive 2 (*.DSK, *.NIB, *.IIE, *.DO, *.PO, *.2MG)",
                                     filename, "._img_", 0)) {
                    channelout(window, 12);
                    if (driveload(keyboard, window, &drivedisk2, filename))
                      strcpy(inidiskpath2, filename);
                  }
                }
                else {
                  if (fileselectmenu(keyboard, window, "Drive 1 (*.DSK, *.NIB, *.IIE, *.DO, *.PO, *.2MG)",
                                     filename, "._img_", 0)) {
                    channelout(window, 12);
                    if (driveload(keyboard, window, &drivedisk1, filename))
                      strcpy(inidiskpath1, filename);
                  }
                }
                update = 1;
                break;
              case 'm' :
              case 'M' :
                drivemessageflag = !drivemessageflag;
                update = 1;
                break;
            } /* switch (key) */
          }
          while ((key != 27) && (key != 32) && (key != 13) && (!exitprogram));
          channelclose(keyboard);
          channelclose(window);
        }
        screenrestore(screen);

      } /* drivemenu */
