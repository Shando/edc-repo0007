/* 
 * UAE - The Un*x Amiga Emulator
 *
 * Not a parser, but parallel and serial emulation for Win32
 *
 * Copyright 1997 Mathias Ortmann
 * Copyright 1998-1999 Brian King
 */

#define PRTBUFSIZE 4096

int setbaud( long baud );
void getserstat( int *status );
int readser( char *buffer );
void writeser( char c );
int openser( char *sername );
void closeser( void );
void doserout( void );

extern char inbuf[1024], outbuf[1024];
extern int inptr, inlast, outlast;
