/*
 * AddressSpace.cs
 *
 * The class representing the memory map or address space of a machine.
 *
 * Copyright (c) 2003 Mike Murphy
 *
 */
using System;
using System.Diagnostics;

namespace EMU7800.Machine
{
    [Serializable]
    public sealed class AddressSpace
    {
        public MachineBase M { get; private set; }

        readonly int AddrSpaceShift;
        readonly int AddrSpaceSize;
        readonly int AddrSpaceMask;

        readonly int PageShift;
        readonly int PageSize;

        readonly IDevice[] MemoryMap;
        IDevice Snooper;

        public byte DataBusState { get; private set; }

        public override string ToString()
        {
            return "AddressSpace";
        }

        public byte this[ushort addr]
        {
            get
            {
                if (Snooper != null)
                {
                    // here DataBusState is just facilitating a dummy read to the snooper device
                    // the read operation may have important side effects within the device
                    DataBusState = Snooper[addr];
                }
                var pageno = (addr & AddrSpaceMask) >> PageShift;
                var dev = MemoryMap[pageno];
                DataBusState = dev[addr];
                return DataBusState;
            }
            set
            {
                DataBusState = value;
                if (Snooper != null)
                {
                    Snooper[addr] = DataBusState;
                }
                var pageno = (addr & AddrSpaceMask) >> PageShift;
                var dev = MemoryMap[pageno];
                dev[addr] = DataBusState;
            }
        }

        public void Map(ushort basea, ushort size, IDevice device)
        {
            if (device == null) throw new ArgumentNullException("device");
            
            for (int addr = basea; addr < basea + size; addr += PageSize)
            {
                var pageno = (addr & AddrSpaceMask) >> PageShift;
                MemoryMap[pageno] = device;
            }
            device.Map(this);

            Debug.WriteLine(string.Format("{0}: Mapped {1} to ${2:x4}:${3:x4}", this, device, basea, basea + size));
        }

        public void Map(ushort basea, ushort size, Cart cart)
        {
            if (cart == null) throw new ArgumentNullException("cart");
            
            var device = (IDevice)cart;
            if (cart.RequestSnooping)
            {
                Snooper = device;
            }
            Map(basea, size, device);
        }

        public AddressSpace(MachineBase m, int addrSpaceShift, int pageShift)
        {
            M = m;

            AddrSpaceShift = addrSpaceShift;
            AddrSpaceSize  = 1 << AddrSpaceShift;
            AddrSpaceMask = AddrSpaceSize - 1;

            PageShift = pageShift;
            PageSize = 1 << PageShift;

            MemoryMap = new IDevice[1 << addrSpaceShift >> PageShift];
            IDevice nullDev = new NullDevice();
            for (var pageno=0; pageno < MemoryMap.Length; pageno++)
            {
                MemoryMap[pageno] = nullDev;
            }
        }
    }
}