package com.bliss.core;

public class SignalLine
{

    boolean isHigh = true;

}
