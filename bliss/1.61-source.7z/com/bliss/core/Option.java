package com.bliss.core;

import java.beans.*;

public interface Option
{

    public String getDescription();

    public String getDescription(Object value);

    public Object getValue();

    public void setValue(Object value);

    public final static Option[] EMPTY_CONTROLLER_ARRAY =
            new Option[0];

}
