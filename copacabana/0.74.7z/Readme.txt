=======================================
CoPaCabana - (C)2002-2006 R�gis Nicolas
=======================================

CoPaCabana 0.7 (Alpha version) for Windows - Copyright R�gis Nicolas
CoPaCabana 0.7 (Alpha version) for PalmOS 5.0+ - Copyright R�gis Nicolas & Gilles Fabre. Thanks Gilles for the PalmOS port.

CoPaCabana is a new Amstrad CPC emulator.
CoPaCabana is freeware. You can distribute it freely as long as you distribute the original package unmodified.
CoPaCabana is provided AS IS without any warranty of any kind. There is no official support although this is work in progress and thus will evolve in the future.

This release is an Alpha version. Please report problems to <mailto:rni.dev@free.fr>

Your feedback is very welcomed.

-----------------------------------------------
IMPORTANT: SUPPORT, SPONSOR and REWARD FREEWARE
-----------------------------------------------
CoPaCabana is free. Use it, distribute it, and have fun. 
It's free for you but it still represents some work and effort for us.
If you had good time with it and want to support or encourage future versions, you can make a donation on PayPal (see URLs below).
I don't expect a lot of money but if this pays a good restaurant to people who worked on it, that would be nice.
Thanks in advance.
https://www.paypal.com/
https://www.paypal.com/fr/
Use email address: rni.dev@free.fr
-----------------------------------------------

----------
USER GUIDE
----------

****** Windows version ******

This package provides 2 versions of the emulator:
- A Release version for gamers.
- A Debug version for developers or emulator developers. It provides a powerful debugging console. Type HELP in the console as a starting point. F5 to run. See Console reference at the end.
JOYSTICK SUPPORT: Pressing F11 key toggles between Joystick mode and Keyboard mode. In Joystick mode, Space is Fire, 'O', 'P', 'Q', 'A' are joystick directions. This will probably change in the future.

If the sound does not work correctly, especially in "Best" emulation mode, please let me know your HW configuration and the status of the 2 "indicators" in the status bar (letters F and E):
Are they constantly orange? red? What is the number next to them? Thanks in advance.

****** Palm OS version ******

This package provides the Release version only for Palm OS. 
It requires a device running with an ARM processor and Palm OS 5. It does NOT work on Palm OS 6.x.
It also requires a high-density device (320x320).
It has been tested and will run on the following devices: Tungsten T, T2, T3, T5, C, E, LifeDrive, Treo 650, Zire71, 72, a number of Clie devices: UX50, TJ35, NX70, NX73, NZ90, TG50, TJ25, TH55.
On other devices, it will accept to run but no guarantee is provided that it works. It could even force a Reset. Use it at your own risk and don't forget to backup (HotSync) your data before using it.
If you see the "Unsupported Device" dialog when starting, please let me know your Device ID and whether it works on it or not.

The Settings Dialog allows you to define if the Rocker is used as Arrow Keys or Joystick.
The buttons below the CPC screen are:
  Run/Pause, Reset, Settings, Insert disk image, Swap disk images, Toggle Sound On/Off, Show CPC keyboard for Input (on 320x480 devices only).
The hard keys are used as follows:
  DateBook: Fire, Notepad/MemoPad: Break, AddressBook: Shift, ToDo: Ctrl
Disk images (standard .dsk files - zip not supported) must be on an extension card (SD, ...).

In order to be able to use the DIA on a T3, the 2 PRCs in the T3 folder must be installed on your device.
CAUTION: You should install both at the same time using HotSync. If you really want to beam them one after the other, start with StatusBarLib.prc.

CoPaCabana is provided AS-IS without any warranty. We can't be held responsible for any data loss due to installing it on your device.
It's ALWAYS a good practice to synchronize your device before installing any application.
Don't install it if you are not confident that your data are backed up.

*******************

We are working on versions for different OSes. This is NOT a commitment but simply an information.

CoPaCabana Home Page is located at <http://copacabana.emuunlim.com>
You will be able to find a great amount of CPC information/resources at <http://cpczone.emuunlim.com>
You will be able to find many disk images at <http://tacgr.emuunlim.com/downloads/downloads.php>
In order to use one, load it first, type in: cat <Return>, find out the program to run and type in: run"program" <Return>
For Sorcery.dsk: run"Sorcery <Return>
For better Sound experience, make sure to run at "Actual speed", not full speed and that speed is close to 100%.

-----------------
IMPORTANT NOTICE:
-----------------
ROM images supplied with CoPaCabana are copyrighted by Amstrad Plc and Locomotive Software. Amstrad and Locomotive have given permission to distribute these ROM images with CPC emulators, but still retain the copyright. 

----------------
REVISION HISTORY
----------------

VERSION 0.1
-----------
First public version released.

VERSION 0.2
-----------
Keyboard Handling fixed.
Better CRTC Emulation.
Better Monitor emulation (Real size now. Use the Ctrl+F8 and F9 to slide it Left/Right).
Support for 2 drives (A and B). HotSwapping. This is VERY useful for 2 sided games or demo. Load side A (F5) in drive A and side B (F6) in drive B. When asked to turn the disk, just press F7 to swap A and B...
Better "Real speed" emulation.
A couple new Z80 instructions emulated.
Z80 Instruction timings improved.
Added Menu options and accelerators.

VERSION 0.3
-----------
Better CRTC Emulation - More demos are (quite) working
Added some more Z80 instructions (I am adding them on an as-needed basis)
Added support for empty disk tracks
Fixed keyboard ',','<','>' keys
Fixed miscellaneous bugs

VERSION 0.4
-----------
Cycle-accurate CRTC emulation. This is a new, complete rewrite of CRTC (with Z80 changes to add cycles during instructions (OUT)). A menu entry allows to select which one to use: the old one (faster) or the new one (better but slower). 
  This new version enables raster split. Many demos (including Rebellion.dsk) are working closer to how they do on a real CPC now!!!
Reworked the menu hierarchy. Added several options.
Fixed miscellaneous bugs

VERSION 0.5
-----------
Improved the Cycle-accurate CRTC emulation. A number of demos are now working: Rebellion, Backtro, Croco, Prophecy.
Added new instructions emulation
Improved Console support (PageUp/PageDown) allows to scroll in the assembly pane, IL addr command to disassemble addr
ADDED SOUND SUPPORT: Envelopes not supported yet.
Changed Keyboard handling code. Some problems will be fixed in the future

VERSION 0.6
-----------
Released first PalmOS version
Improved sound support, especially in "Best" emulation mode

VERSION 0.61 (PalmOS only)
--------------------------
Allow CoPaCabana to run even on devices we did not officially test. 
There is a new Dialog making explicit that it's not been tested on the device and provides the Device ID.
Changed Icons (Thanks Renaud).

VERSION 0.62 (PalmOS only)
--------------------------
Added T|C and T|E to the list of supported devices
Added Support for Clie UX50 and limited support for Zodiac devices
Removed sound icon if sound not supported on the device.
Fix the rightmost column of pixels not being of the right color
Fix a crashing bug when accessing SD card with empty label
Improved double buffering
Improved screen size management, especially square screens, screen size detection

VERSION 0.7
-----------
General:
  Added support for Snapshots (.sna). 
  Reworked File support
  Fixed a problem with RAM banking management (CPC-Aventure now works)

PalmOS specific:
  CoPaCabana restarts where you left it and includes Quick Save/Load. 
  The red "record" button saves the current context and the Green "insert" button reloads the last saved context. 
  Very convenient to pass difficult parts of games.
  LifeDrive support added (but 5way does not work due to a bug in its driver)
  Disk icon, speed and buttons area design changed
  Added more error dialogs
  Fixed a memory leak when loading disks
  Better management (pausing emulator) of intrusive PalmOS events showing dialogs (Low battery, Incoming beam, Find, ...)

VERSION 0.71 (PalmOS only)
--------------------------
General (will be in next windows version too):
  PPI management improved

PalmOS specific:
  LifeDrive 5way support fixed to support diagonal moves
  Disk reloading at launch fixed
  Fixed version information
  
VERSION 0.72 (PalmOS only)
--------------------------
General (will be in next windows version too):
  Fixed a bug in Floppy emulation in Multi sector reads (Laser Squad now works)

Windows specific:
  Added 2 new console commands: IT and SNA SAVE (see below)
  
PalmOS specific:
  Switched compilation to ARM mode (as opposed to Thumb) which increased speed by 30%
  Added support for T|X
  Menu key (Treo 650) or Menu icon now enqueues the '|' for easy access (|cpm, ...)
  Fixed a bug on Treo 650 when entering in Sleep mode on inactivity
  Fixed a memory leak

VERSION 0.73
------------
General (will be in next windows version too):
  Fixed a bug in emulation of ADC HL,ss (P flag was not set correctly)
  Added support for opcode ED 54 (NEG)
  Fix a bug in prefix emulation handling (FD FD or DD DD)
  
PalmOS specific:
  Boot text now shows correct version
  Changed DIA support to not use an external 68K PRC (which was created at launch time and deleted at shutdown). 
    All is done internally now.
  Correctly disable rotation trigger
  Reduced flickering when pausing/resuming or opening/closing DIA
  Fix the crash when reloading a previously saved snapshot (using the 2 SNA buttons)

Windows specific:
  Put sound back in. I removed it by mistake in the previous version.

VERSION 0.74
------------
Windows specific:
  New Sound menu that includes the ability to "record" sound to an AY file in text format.
    I'm separately providing AY tools: AYPlay and AYCompress to work with these files.
    AYPlay allows to replay an AY file or to create a wav file from it.
    AYCompress generates a compressed binary AY file that AYPlay is also able to play.
    See http://copacabana.emuunlim.com.

VERSION 0.75
------------
PalmOS specific:
  Modified palette management to use system palette: lower part of the screen looks normal now.
  
  
----------
TODO LIST:
----------
- Small Icon
Of course, I'm very open to any suggestion as to which feature to add to CoPaCabana so feel free to mail me.
Here is a list of features I'm considering adding in the near future:
- Improved CRTC emulation
- Better debugger window for CoPaCabana for Windows
- Keyboard mapping
- Support for French ROMs
- Writing to disk support (as well as saving modified disk images)
- Sound settings window (including volume)
- ROM settings window (to allow loading external ROMs)

For a longer term, I would (probably) add:
- Other platforms (MacOS, Windows CE, Linux, ...)
- Tape support and Tape files
- Printing to a bitmap or file
- Screen snapshots

------------------
CONSOLE REFERENCE:
------------------
Where values are expected, you can also use a register name to use the value of this register (e.g.: IL PC, DM loram HL, ...)

HELP: Help - Useless - Read this
F10: Step Over (works only for CALL, LDIR)
F11: Step Into. You should always use F11 and use F10 to step over a call or LDIR
F5: Run
RT aaaa: Run until PC reaches address aaaa and then breaks (e.g.: RT 589)
REG r vv: Set 8bit register r to value vv (e.g.: REG A 3F)
REG rr vvvv: Set 16bit register rr to value vvvv (e.g.: REG HL 12AB)
PC aaaa: Set PC to value aaaa (e.g.: PC 12F0)
BR aaaa: Set a Breakpoint at address aaaa (e.g.: BR 12AB)
BRC aaaa: Remove a Breakpoint set at address aaaa (e.g.: BRC 12AB)
BRD: Display all currently set Breakpoints
BRNOW: Break immediately
IL aaaa: Display instructions at address aaaa (e.g.: IL 589, IL PC)
RB (ram|rom): Reboot in ram or rom: Normally should only be RB rom.
DM [loram | hiram | lorom | hirom] aaaa: Display memory content at address aaaa. Specify which memory if not default (e.g.: DM loram 0400)
FB aaaa (vv* | "str"): Find Bytes starting at address aaaa. You can specify bytes or string (e.g.: FB 1000 CD 00 04 or FB 1000 "EMU")
SB aaaa vv*: Store bytes at address aaaa (e.g.: SB 1200 21 00 40 11 00 C0 01 00 40 ED B0)
SW aaaa vvvv*: Store words at address aaaa (e.g.: SW 12AB 0021 3400)
FILL aaaa n vv: Fill n bytes of memory starting at address aaaa with byte vv (e.g.: FILL C000 4000 0)
PCLOG (on|off): Starts or stops tracing all addresses executed into a PCLog.txt file. This is useful to understand what's executed BUT BE CAREFUL: This slows the emulator down a lot and creates a HUGE file...
MEM hiram | hirom | loram | lorom: Selects the memory to use. Should not be used. Same as forcing an OUT 7FXX,vv.
SAMPLER: Not in use. Allows to track instructions frequency.
LD DriveNum, filename: Load a Disk image in drive DriveNum. You should rather use the menu option.
ED DriveNum: Eject disk in DriveNum: Not implemented.
LOAD filename[,aaaa]: Load a binary file at address aaaa. The file MUST start with a valid 256 bytes header. If aaaa is provided, it takes precedence on the value in the header. If the start address is provided in the header, PC is automatically set to it.
PLAY filename: filename must be a script: a list of console commands. Commands are read from the script and executed. Lines starting with '#' are ignored (comments).
DR b0 b1 b2 b3 b4: Display the real number represented by bytes b0..b4 in memory (Basic help) (e.g.: DR 00 00 00 00 81 displays 1)
VID: Displays current Video registers.
IT aaaa bbbb: Disassemble code between aaaa and bbbb and sends to Reporter
SNA SAVE filename: Saves a snapshot to filename
