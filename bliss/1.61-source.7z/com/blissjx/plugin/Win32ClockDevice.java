package com.blissjx.plugin;

import com.bliss.core.devices.*;
import com.bliss.core.*;

public class Win32ClockDevice implements ClockDevice
{

    public Option[] getOptions() {
        return Option.EMPTY_CONTROLLER_ARRAY;
    }

    public void init() { }
    public void release() { }

    public native long getTickFrequency();

    public native long getTick();

}
