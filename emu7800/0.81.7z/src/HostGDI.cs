/*
 * HostGDI
 *
 * A GDI-based Host. 
 *
 * Copyright (c) 2003-2007 Mike Murphy
 *
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Text;
using System.Reflection;
using System.Windows.Forms;

namespace EMU7800
{
	public class HostGdiForm : Form
	{
		Machine M;

		Rectangulator _Rectangulator;
		byte[] _AudioBuffer;
		bool _ReqRefresh;

		Font _TextFont;
		SolidBrush _TextBrush;
		Graphics _RGraphics;
		SolidBrush _SBrush = new SolidBrush(Color.Black);

		Dictionary<Keys, HostInput> _KeyBindings;

		Stopwatch _Stopwatch;
		const int FRAME_SAMPLES = 120;
		long _startOfCycleTick, _endOfCycleTick;
		long _frameBudgetTicks, _sleepableTicks;
		long _ticksPerMillisec = Stopwatch.Frequency / 1000;
		int _FrameRectangleCount;
		int[] _RunMachineTicks = new int[FRAME_SAMPLES];
		int[] _WaitTicks = new int[FRAME_SAMPLES];
		int[] _Rectangles = new int[FRAME_SAMPLES];

		public void Run(Machine m)
		{
			Trace.WriteLine("GDI Host startup");

			M = m;

			Text = EMU7800App.Title;
			Icon = new Icon(Assembly.GetExecutingAssembly().GetManifestResourceStream("EMU7800.Icon1.ico"));

			Rectangulator r = new Rectangulator(M.VisiblePitch, M.Scanlines);
			r.UpdateRect += new UpdateRectHandler(OnUpdateRect);
			r.Palette = M.Palette;
			r.PixelAspectXRatio = 320 / M.VisiblePitch;
			r.OffsetLeft = 0;
			r.ClipTop = M.FirstScanline;
			r.ClipHeight = 240;
			r.UpdateTransformationParameters();
			_Rectangulator = r;

			ShowInTaskbar = true;
			FormBorderStyle = FormBorderStyle.Sizable;
			CenterToScreen();

			ClientSize = new Size(640, 480);
			MinimumSize = new Size(320 + 8, 240 + 27);
		
			// Enable double-buffering to avoid flicker
			SetStyle(ControlStyles.UserPaint, true);
			SetStyle(ControlStyles.AllPaintingInWmPaint, true);
			SetStyle(ControlStyles.DoubleBuffer, true);

			_TextFont = new Font("Courier New", 18);
			_TextBrush = new SolidBrush(Color.White);

			InitializeKeyBindings();

			Paint += OnPaint;
			Layout += OnLayout;
			Closing += OnClosing;

			MouseDown += delegate(object sender, MouseEventArgs e) { OnMouseClick(e, true); };
			MouseUp += delegate(object sender, MouseEventArgs e) { OnMouseClick(e, false); };
			MouseMove += delegate(object sender, MouseEventArgs e) { OnMouseMove_(e); };
		
			KeyDown += delegate(object sender, KeyEventArgs e) { OnKeyPress(e, true); };
			KeyUp += delegate(object sender, KeyEventArgs e) { OnKeyPress(e, false); };
			KeyPreview = true;

			Show();

			_ReqRefresh = true;

			Run();

			Trace.WriteLine("GDI Host shutdown");

			Close();
		}

		void Run()
		{
			_Stopwatch = new Stopwatch();
			_frameBudgetTicks = Stopwatch.Frequency / M.FrameHZ;
			_sleepableTicks = _frameBudgetTicks - EMU7800App.Instance.Settings.CpuSpin * _ticksPerMillisec;
			_Stopwatch.Start();
			_endOfCycleTick = _Stopwatch.ElapsedTicks;

			while (true)
			{
				_startOfCycleTick = _endOfCycleTick;

				_FrameRectangleCount = 0;

				Application.DoEvents();

				if (M.H.Ended || !Created)
				{
					break;
				}

				if (_ReqRefresh)
				{
					_RGraphics.Clear(Color.Black);
					_Rectangulator.DrawEntireFrame(M.H.Paused);
					_ReqRefresh = false;
				}

				if (!M.H.Paused && !M.MachineHalt)
				{
					_Rectangulator.StartFrame();
					M.Run();
					_Rectangulator.EndFrame();
				}

				ShowPostedMsg();

				long endOfRunMachineTick = _Stopwatch.ElapsedTicks;

				while (M.H.EnqueueAudio(_AudioBuffer) == 1)
				{
				}

				_endOfCycleTick = _Stopwatch.ElapsedTicks;

				int statIndex = (int)M.FrameNumber % FRAME_SAMPLES;
				_RunMachineTicks[statIndex] = (int)(endOfRunMachineTick - _startOfCycleTick);
				_WaitTicks[statIndex] = (int)(_endOfCycleTick - endOfRunMachineTick);
				if (_FrameRectangleCount != 0)
				{
					_Rectangles[statIndex] = _FrameRectangleCount;
				}
			}

			M.H.CloseAudio();
		}

		void InitializeKeyBindings()
		{
			_KeyBindings = new Dictionary<Keys, HostInput>();
			_KeyBindings.Add(Keys.Escape, HostInput.End);
			_KeyBindings.Add(Keys.P, HostInput.Pause);
			_KeyBindings.Add(Keys.ControlKey, HostInput.Fire);
			_KeyBindings.Add(Keys.Menu, HostInput.Fire2);
			_KeyBindings.Add(Keys.Left, HostInput.Left);
			_KeyBindings.Add(Keys.Up, HostInput.Up);
			_KeyBindings.Add(Keys.Right, HostInput.Right);
			_KeyBindings.Add(Keys.Down, HostInput.Down);
			_KeyBindings.Add(Keys.NumPad7, HostInput.NumPad7);
			_KeyBindings.Add(Keys.NumPad8, HostInput.NumPad8);
			_KeyBindings.Add(Keys.NumPad9, HostInput.NumPad9);
			_KeyBindings.Add(Keys.NumPad4, HostInput.NumPad4);
			_KeyBindings.Add(Keys.NumPad5, HostInput.NumPad5);
			_KeyBindings.Add(Keys.NumPad6, HostInput.NumPad6);
			_KeyBindings.Add(Keys.NumPad1, HostInput.NumPad1);
			_KeyBindings.Add(Keys.NumPad2, HostInput.NumPad2);
			_KeyBindings.Add(Keys.NumPad3, HostInput.NumPad3);
			_KeyBindings.Add(Keys.Multiply, HostInput.NumPadMult);
			_KeyBindings.Add(Keys.NumPad0, HostInput.NumPad0);
			_KeyBindings.Add(Keys.Divide, HostInput.NumPadDiv);
			_KeyBindings.Add(Keys.D1, HostInput.LeftDifficulty);
			_KeyBindings.Add(Keys.D2, HostInput.RightDifficulty);
			_KeyBindings.Add(Keys.F1, HostInput.SetKeyboardToPlayer1);
			_KeyBindings.Add(Keys.F2, HostInput.SetKeyboardToPlayer2);
			_KeyBindings.Add(Keys.F3, HostInput.SetKeyboardToPlayer3);
			_KeyBindings.Add(Keys.F4, HostInput.SetKeyboardToPlayer4);
			_KeyBindings.Add(Keys.F5, HostInput.PanLeft);
			_KeyBindings.Add(Keys.F6, HostInput.PanRight);
			_KeyBindings.Add(Keys.F7, HostInput.PanUp);
			_KeyBindings.Add(Keys.F8, HostInput.PanDown);
			_KeyBindings.Add(Keys.F11, HostInput.SaveMachine);
			_KeyBindings.Add(Keys.F12, HostInput.Unknown);
			_KeyBindings.Add(Keys.C, HostInput.Color);
			_KeyBindings.Add(Keys.F, HostInput.Unknown);
			_KeyBindings.Add(Keys.M, HostInput.Mute);
			_KeyBindings.Add(Keys.R, HostInput.Reset);
			_KeyBindings.Add(Keys.S, HostInput.Select);
		}

		void OnMouseClick(MouseEventArgs e, bool down)
		{
			if (!M.H.Paused && e.Button == MouseButtons.Left)
			{
				M.H.RaiseInput(HostInput.Fire, down);
			}
		}

		void OnMouseMove_(MouseEventArgs e)
		{
			M.H.RaiseLightGunInput(Width, e.X, e.Y);
			M.H.RaisePaddleInput(Width, e.X);
		}

		void OnKeyPress(KeyEventArgs e, bool down)
		{
			if (_KeyBindings.ContainsKey(e.KeyCode))
			{
				switch (e.KeyCode)
				{
					case Keys.F:
						if (down)
						{
							double rmTicks = 0.0, wTicks = 0.0, avgRectPerFrame = 0.0;
							for (int i=0; i < FRAME_SAMPLES; i++)
							{
								rmTicks += _RunMachineTicks[i];
								wTicks += _WaitTicks[i];
								avgRectPerFrame += _Rectangles[i];
							}
							rmTicks = rmTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
							wTicks = wTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
							avgRectPerFrame /= FRAME_SAMPLES;
							double fps = 1000.0 / (rmTicks + wTicks);
							M.H.PostedMsg = string.Format("{0}/{1} FPS {2:0.0}+{3:0.0}={4:0.0}/{5:0.0} ms {6:0.0} RPF", Math.Round(fps, 0), M.H.EffectiveFPS, rmTicks, wTicks, rmTicks + wTicks, 1000.0 / M.H.EffectiveFPS, avgRectPerFrame);
						}
						break;
					case Keys.F5:
						if (down)
						{
							_Rectangulator.OffsetLeft++;
							_Rectangulator.UpdateTransformationParameters();
							_ReqRefresh = true;
						}
						break;
					case Keys.F6:
						if (down)
						{
							_Rectangulator.OffsetLeft--;
							_Rectangulator.UpdateTransformationParameters();
							_ReqRefresh = true;
						}
						break;
					case Keys.F7:
						if (down)
						{
							_Rectangulator.ClipTop++;
							_Rectangulator.UpdateTransformationParameters();
							_ReqRefresh = true;
						}
						break;
					case Keys.F8:
						if (down)
						{
							_Rectangulator.ClipTop--;
							_Rectangulator.UpdateTransformationParameters();
							_ReqRefresh = true;
						}
						break;
					case Keys.F12:
						if (down)
						{
							M.H.PostedMsg = "Screenshot not supported";
						}
						break;
					default:
						M.H.RaiseInput(_KeyBindings[e.KeyCode], down);
						break;
				}
			}
			else
			{
				M.H.RaiseInput(HostInput.Unknown, down);
			}

			e.Handled = true;
		}

		bool _RenderedTextMsg = false;

		void ShowPostedMsg()
		{
			if (M.H.PostedMsg.Length > 0)
			{
				ClearTextMsg();
				ShowTextMsg();
				_RenderedTextMsg = true;
			}
			else if (_RenderedTextMsg)
			{
				ClearTextMsg();
			}
		}

		void ShowTextMsg()
		{
			_TextBrush.Color = Color.White;
			_RGraphics = CreateGraphics();
			_RGraphics.TextRenderingHint = TextRenderingHint.SystemDefault;
			_RGraphics.DrawString(M.H.PostedMsg, _TextFont, _TextBrush, 0, 0);
			_RenderedTextMsg = true;
		}

		void ClearTextMsg()
		{
			_TextBrush.Color = Color.Black;
			_RGraphics.FillRectangle(_TextBrush, 0, 0, ClientSize.Width, 30);
			_RenderedTextMsg = false;
		}

		void OnLayout(object sender, LayoutEventArgs e)
		{
			_RGraphics = CreateGraphics();
			_RGraphics.CompositingMode = CompositingMode.SourceCopy;
			_RGraphics.CompositingQuality = CompositingQuality.Invalid;
			_RGraphics.SmoothingMode = SmoothingMode.None;
			_RGraphics.InterpolationMode = InterpolationMode.NearestNeighbor;

			_Rectangulator.ViewPortSize = ClientSize;
			_Rectangulator.UpdateTransformationParameters();

			_ReqRefresh = true;
		}

		void OnClosing(object sender,  CancelEventArgs e)
		{
			if (!M.H.Ended)
			{
				// if game is running, veto close request while arranging for game loop termination
				// this facilitates cleaning things up nicely
				M.H.RaiseInput(HostInput.End, true);
				e.Cancel = true;
			}
		}

		void OnPaint(object sender, PaintEventArgs e)
		{
			_ReqRefresh = true;
		}

		public void UpdateDisplay(byte[] buf, int scanline, int xstart, int len)
		{
			if (M.H.PostedMsg.Length > 0 && scanline <= M.H.ClipStart + 12)
			{
				// do not overwrite the rendered text of the posted message
			}
			else
			{
				_Rectangulator.InputScanline(buf, scanline, xstart, len);
			} 
		}

		void OnUpdateRect(DisplRect r)
		{
			_SBrush.Color = Color.FromArgb(r.Argb);
			_RGraphics.FillRectangle(_SBrush, r.Rectangle);
			_FrameRectangleCount++;
		}

		public void UpdateSound(byte[] buf)
		{
			if (M.H.Muted)
			{
				for (int i=0; i < buf.Length; i++)
				{
					buf[i] = 0;
				}
			}

			_AudioBuffer = buf;
		}
	}

	public class HostGdi : Host
	{
		HostGdiForm F;

		public static readonly HostGdi Instance = new HostGdi();
		private HostGdi() { }

		public override void Run(Machine m)
		{
			InitializeInputSystem(m);
			F = new HostGdiForm();
			F.Run(m);
		}
		public override void UpdateDisplay(byte[] buf, int scanline, int start, int len)
		{
			F.UpdateDisplay(buf, scanline, start, len);
		}
		public override void UpdateSound(byte[] buf)
		{
			F.UpdateSound(buf);
		}
	}
}