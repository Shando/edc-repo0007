/*
 * Log.cs
 * 
 * Logger for the entire application.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */ 
using System;
using System.Text;

namespace EMU7800 {

public delegate void LogUpdatedHandler();

public class Log {
	public static bool LoggerStarted = false;
	public static event LogUpdatedHandler LogUpdated;

	private static StringBuilder MessageSpool = new StringBuilder();	public static void Msg(String fmt, params Object[] objs) {		MessageSpool.AppendFormat(fmt, objs);		if (LogUpdated != null && LoggerStarted) {			LogUpdated();		}	}	public static string GetMsgs() {		string msgs = "";		if (MessageSpool.Length > 0) {			msgs = MessageSpool.ToString();			MessageSpool = new StringBuilder();		}		return msgs.Replace("\n", Environment.NewLine);	}}
}
