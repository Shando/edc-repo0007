/*
 * Dapple ][ Emulator  Version 0.06
 * Copyright (C) 2002, 2003 Dapple ][ Development.  All rights reserved.
 *
 * Component:  CPU65C02: CPU emulation
 * Revision:   (0.06) 2003.0129
 * ADC and SBC instructions contributed by Scott Hemphill.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <stdio.h>
#include <string.h>
#include "asmlib.h"
#include "dapple.h"

/* extern declarations */

/* dapple.c */
extern unsigned int inicpudelay;
extern unsigned int window;
extern unsigned int messagecount;
extern unsigned char messageflag;
void setmessage(unsigned char *message);
void applereset();
void keyconvert();

/* memory.c */
extern unsigned char memram[0x28000];
unsigned char memoryread(unsigned int addr);
void memorywrite(unsigned int addr, unsigned int value);

/* video.c */
extern unsigned char virtcopy;
extern unsigned int virtflashmode;
void virtpaletteset(unsigned int index, unsigned int r,
                    unsigned int b,     unsigned int g);
void virtline(unsigned int rastline);
void virtscreencopy();

/* disk.c */
extern unsigned char drivefastmode;

/* intern declarations */

/* type of CPU */
typedef enum {CPU6502, CPU65C02, CPU65SC02} CPUTYPE;
CPUTYPE cputype;

static unsigned char areg;		/* Accumulator          */
static unsigned char xreg;		/* X-Register           */
static unsigned char yreg;		/* Y-Register           */
static unsigned char stack;		/* Stack-Register       */
static unsigned short pc;		/* Program counter      */

static unsigned char nflag;             /* N-Flag               */
static unsigned char vflag;             /* Overflow-Flag        */
static unsigned char iflag;             /* Interrupt-Flag       */
static unsigned char bflag;             /* Break-Flag           */
static unsigned char dflag;             /* Decimal-Flag         */
static unsigned char zflag;             /* Zero-Flag            */
static unsigned char cflag;             /* Carry-Flag           */

static unsigned char bytebuffer;
static unsigned int address;		/* 16-bit address       */
unsigned int cycle;			/* Number of cycles     */
static unsigned int lastcycle;
static unsigned int linecycles;
static unsigned char traceflag;		/* set tracemode        */
static unsigned char breakflag;		/* allow breakpoint     */
static unsigned short breakpoint;
static unsigned int flashloop;
static unsigned int cpudelay;
unsigned char cpuwriteregsflag;
unsigned int rasterline;

/* state of the processor */
static unsigned char stateflags;


/*-------------------------------------*/

/* CPU */
/* - cpusetbreakpoint   */
/* - cpugetbreakpoint   */
/* - cpuclearbreakpoint */
/* - cpusettracemode    */
/* - cpugettracemode    */
/* - cpusetpc           */
/* - cpugetpc           */
/* - cpugeta            */
/* - cpugetx            */
/* - cpugety            */
/* - cpusetlinecycle	*/
/* - cpugetlinecycle	*/
/* - cpusetdelay	*/
/* - cpugetdelay	*/
/* - cpusettype		*/
/* - cpugettype		*/
/* - cpuinuse		*/
/* - cpureset           */
/* - cpuinit            */
/* - cpustore           */
/* - cpurestore         */
/* - cpuline            */
/* - cpurun		*/

/*-------------------------------------*/

/* flags		*/
/* - flagssetnz		*/
/* - flagsgen		*/
/* - flagsget		*/
/* - flagstostring	*/

      void flagssetnz(unsigned char value) {

        zflag = (value == 0) ? 1 : 0;
        nflag = (value > 0x7f) ? 1 : 0;

      } /* flagssetnz */


/*-------------------------------------*/


      unsigned char cpuflagsgen() {
        register unsigned char f;

        f = 0x20;
        if ( nflag != 0 ) { f = f | 0x80; }
        if ( vflag != 0 ) { f = f | 0x40; }
        if ( bflag != 0 ) { f = f | 0x10; }
        if ( dflag != 0 ) { f = f | 0x08; }
        if ( iflag != 0 ) { f = f | 0x04; }
        if ( zflag != 0 ) { f = f | 0x02; }
        if ( cflag != 0 ) { f = f | 0x01; }
        return(f);
      } /* flagsgen */


/*-------------------------------------*/


      void cpuflagsget(unsigned char value) {

        nflag = ((value & 0x80) == 0) ? 0 : 1;
        vflag = ((value & 0x40) == 0) ? 0 : 1;
        bflag = ((value & 0x10) == 0) ? 0 : 1;
        dflag = ((value & 0x08) == 0) ? 0 : 1;
        iflag = ((value & 0x04) == 0) ? 0 : 1;
        zflag = ((value & 0x02) == 0) ? 0 : 1;
        cflag = ((value & 0x01) == 0) ? 0 : 1;
      } /* flagsget */


/*-------------------------------------*/


      void cpuflagstostring(unsigned char value, unsigned char *stringptr) {

	if (value & 0x80) { *stringptr++ = '-'; }
	else		  { *stringptr++ = 'N'; }
	if (value & 0x40) { *stringptr++ = '-'; }
	else		  { *stringptr++ = 'V'; }
	if (value & 0x20) { *stringptr++ = '-'; }
	else		  { *stringptr++ = '1'; }
	if (value & 0x10) { *stringptr++ = '-'; }
	else		  { *stringptr++ = 'B'; }
	if (value & 0x08) { *stringptr++ = '-'; }
	else		  { *stringptr++ = 'D'; }
	if (value & 0x04) { *stringptr++ = '-'; }
	else		  { *stringptr++ = 'I'; }
	if (value & 0x02) { *stringptr++ = '-'; }
	else		  { *stringptr++ = 'Z'; }
	if (value & 0x01) { *stringptr   = '-'; }
	else		  { *stringptr   = 'C'; }

      } /* flagsstring */


/*-------------------------------------*/


      void cpusetbreakpoint(unsigned int value) {

        breakpoint = value;
        breakflag  = 1;

      } /* cpusetbreakpoint */


/*-------------------------------------*/


      unsigned int cpugetbreakpoint() {

        if (breakflag) {
          return breakpoint;
        }
        else {
          return 0xffff;
        }

      } /* cpugetbreakpoint */


/*-------------------------------------*/


      void cpuclearbreakpoint() {

        breakflag = 0;

      } /* cpuclearbreakpoint */


/*-------------------------------------*/


      void cpusettracemode(unsigned char mode) {

        if (mode) {
          traceflag = 1;
        }
        else {
          traceflag = 0;
        }
      } /* cpusettracemode */


/*-------------------------------------*/


      unsigned char cpugettracemode() {

        return traceflag;

      } /* cougettracemode */


/*-------------------------------------*/


      void cpusetpc(unsigned int address) {

        pc = address & 0xffff;

      } /* cpusetpc */



/*-------------------------------------*/


      unsigned short cpugetpc() {

        return pc;

      } /* cpugetpc */


/*-------------------------------------*/


      unsigned int cpugetsp() {

        return (stack | 0x100);

      } /* cpugetsp */


/*-------------------------------------*/


      unsigned char cpugeta() {

        return areg;

      } /* cpugeta */


/*-------------------------------------*/


      unsigned char cpugetx() {

        return xreg;

      } /* cpugetx */


/*-------------------------------------*/


      unsigned char cpugety() {

        return yreg;

      } /* cpugety */


/*-------------------------------------*/


      void cpusetlinecycle(unsigned int value) {

	linecycles = value;

      } /* cpugetlinecycle */


/*-------------------------------------*/


      unsigned int cpugetlinecycle() {

	return linecycles;

      } /* cpugetlinecycle */


/*-------------------------------------*/


      void cpusetdelay(unsigned int value) {

	cpudelay = value;

      } /* cpugetlinecycle */


/*-------------------------------------*/


      unsigned int cpugetdelay() {

	return cpudelay;

      } /* cpugetlinecycle */


/*-------------------------------------*/


      void cpusettype (CPUTYPE value) {

	if (value <= CPU65SC02) {
	  cputype = value;
	}

      } /* cpugettype */


/*-------------------------------------*/


      CPUTYPE cpugettype () {

	return cputype;

      } /* cpugettype */


/*-------------------------------------*/


      void cpusetstate(unsigned int value) {

	value = value & (STATEHALT | STATERESET | STATETRACE | STATEIRQ | STATENMI) & (!stateflags);

	if (value & STATEIRQ) {
	  setmessage("CPU IRQ triggered");
	}
	if (value & STATENMI) {
	  setmessage("CPU NMI triggered");
	}
	if (value & STATERESET) {
	  setmessage("CPU Reset triggered");
	}
	if (value & STATEHALT) {
	  setmessage("CPU halted");
	  imagefillbox(window, 628, 388, 629,389, RGBLGHTOFF);
	}
	if (value & STATETRACE) {
	  setmessage("CPU trace mode set");
	}
	  
	stateflags = stateflags | (unsigned char)value;

      } /* cpusetflag */


/*-------------------------------------*/


      void cpuclearstate(unsigned int value) {

	value = value
		& (STATEHALT | STATERESET | STATETRACE | STATEIRQ | STATENMI | STATEBPT | STATEGURU)
		& (stateflags);

	if (value & STATEIRQ) {
	  setmessage("CPU IRQ cleared");
	}
	if (value & STATENMI) {
	  setmessage("CPU NMI cleared");
	}
	if (value & STATERESET) {
	  setmessage("CPU Reset cleared");
	}
	if (value & STATEHALT) {
	  setmessage("CPU started");
	  if (stateflags & STATEGURU) {	/* if it was an illegal opcode ==> reset whole machine */
	    applereset();
	  }
	  imagefillbox(window, 628, 388, 629,389, RGBLGHTON);
	}
	if (value & STATETRACE) {
	  setmessage("CPU trace mode cleared");
	}
	if (value & STATEGURU) {	/* if it was an illegal opcode ==> reset whole machine */
	  applereset();
	}
	stateflags = stateflags & (!((unsigned char)value));

      } /* cpuclearstate */


/*-------------------------------------*/


      unsigned char cpugetstate() {

	return stateflags;

      } /* cpugetstate */


/*-------------------------------------*/


      unsigned char cpuinuse() {

	return ((stateflags & STATEHALT)
	      ||(stateflags & STATEBPT)
	      ||(stateflags & STATEGURU)) ? 0 : -1;

      } /* cpuinuse */


/*-------------------------------------*/


      void cpureset() {

        stateflags = STATERESET;
        cpusetdelay(inicpudelay);
        cpusetlinecycle(65);
	imagefillbox(window, 628, 388, 629,389, RGBLGHTON);
	virtcopy = 1;

      } /* cpureset */


/*-------------------------------------*/


      void cpuinit() {

	cpusettype(CPU65C02);

        areg    = 0;                    /* clear register */
        xreg    = 0;
        yreg    = 0;
        zflag   = 0;                    /* clear flags */
        nflag   = 0;
        cflag   = 0;
        vflag   = 0;
        iflag   = 0;
        dflag   = 0;
        bflag   = 0;
        stack   = 0xff;                 /* + 0x100 ! ==> pullstack/pushstack */

        cycle   = 0;                    /* clear cycle count */
        lastcycle = 0;
        linecycles = 65 * 1;

        cpusettracemode(0);             /* trace mode off */
        cpuclearbreakpoint();           /* no breakpoint */

	cpudelay = 0x00;
	rasterline = 0;
	flashloop = 0;
	cpuwriteregsflag = 0;
        cpureset();

      } /* cpuinit */


/*-------------------------------------*/


      void cpustore(FILE *file) {

        unsigned char flags;

        fwrite(&areg,sizeof(areg),1,file);
        fwrite(&xreg,sizeof(xreg),1,file);
        fwrite(&yreg,sizeof(yreg),1,file);
        fwrite(&pc,sizeof(pc),1,file);
        fwrite(&stack,sizeof(stack),1,file);
        flags = cpuflagsgen();
        fwrite(&flags,sizeof(flags),1,file);
        fwrite(&stateflags,sizeof(stateflags),1,file);
        fwrite(&cycle,sizeof(cycle),1,file);
        fwrite(&lastcycle,sizeof(lastcycle),1,file);
        fwrite(&linecycles,sizeof(linecycles),1,file);
        fwrite(&cpudelay,sizeof(cpudelay),1,file);
        fwrite(&traceflag,sizeof(traceflag),1,file);
        fwrite(&breakflag,sizeof(breakflag),1,file);
        fwrite(&breakpoint,sizeof(breakpoint),1,file);
        fwrite(&flashloop,sizeof(flashloop),1,file);
        fwrite(&rasterline,sizeof(rasterline),1,file);

      } /* cpustore */


/*-------------------------------------*/


      void cpurestore(FILE *file) {

        unsigned char flags;

        fread(&areg,		sizeof(areg),		1,file);
        fread(&xreg,		sizeof(xreg),		1,file);
        fread(&yreg,		sizeof(yreg),		1,file);
        fread(&pc,		sizeof(pc),		1,file);
        fread(&stack,		sizeof(stack),		1,file);
        fread(&flags,		sizeof(flags),		1,file);
        cpuflagsget(flags);
        fread(&stateflags,	sizeof(stateflags),	1,file);
        fread(&cycle,		sizeof(cycle),		1,file);
        fread(&lastcycle,	sizeof(lastcycle),	1,file);
        fread(&linecycles,	sizeof(linecycles),	1,file);
        fread(&cpudelay,	sizeof(cpudelay),	1,file);
        fread(&traceflag,	sizeof(traceflag),	1,file);
        fread(&breakflag,	sizeof(breakflag),	1,file);
        fread(&breakpoint,	sizeof(breakpoint),	1,file);
        fread(&flashloop,	sizeof(flashloop),	1,file);
        fread(&rasterline,	sizeof(rasterline),	1,file);

      } /* cpurestore */


/*-------------------------------------*/

/* addressing modes */

#define incpc pc++

/* standard read zero page instruction */
      unsigned char readzp() {
        address = memoryread(pc);
        incpc;
        return memoryread(address);
      } /* readzp */

/* save address for read-and-modify instructions */
      unsigned char readzpm() {
        address = memoryread(pc);
        incpc;
        return memoryread(address);
      } /* readzp */

/* standard read zero page,x instruction */
      unsigned char readzpx() {
        address = (memoryread(pc) + xreg) & 0xff;
        incpc;
        return memoryread(address);
      } /* readzpx */


/* save address for read-and-modify instructions */
      unsigned char readzpxm() {
        address = (memoryread(pc) + xreg) & 0xff;
        incpc;
        return memoryread(address);
      } /* readzpx */

/* standard read zero page,y instruction */
      unsigned char readzpy() {
        address = (memoryread(pc) + yreg) & 0xff;
        incpc;
        return memoryread(address);
      } /* readzpy */


/* standard read abs instruction */
      unsigned char readabs() {
        address = memoryread(pc);
        incpc;
        address = address + ( memoryread(pc) << 8 );
        incpc;
        return memoryread(address);
      } /* readabs */

/* save address for read-and-modify instructions */
      unsigned char readabsm() {
        address = memoryread(pc);
        incpc;
        address = address + ( memoryread(pc) << 8 );
        incpc;
        return memoryread(address);
      } /* readabs */

/* standard read abs,x instruction */
      unsigned char readabsx() {
        address = memoryread(pc);
        incpc;
        address = (address + ( memoryread(pc) << 8 ) + xreg) & 0xffff;
        incpc;
        return memoryread(address);
      } /* readabsx */

/* save address for read-and-modify instructions */
      unsigned char readabsxm() {
        address = memoryread(pc);
        incpc;
        address = (address + ( memoryread(pc) << 8 ) + xreg) & 0xffff;
        incpc;
        return memoryread(address);
      } /* readabsx */

/* standard read abs,y instruction */
      unsigned char readabsy() {
        address = memoryread(pc);
        incpc;
        address = (address + ( memoryread(pc) << 8 ) + yreg) & 0xffff;
        incpc;
        return memoryread(address);
      } /* readabsy */


      unsigned char readindzp() {
        address = memoryread(pc);
        incpc;
        address = memoryread(address) + ( memoryread((address + 1) & 0xff) << 8);
        return memoryread(address);
      } /* readindzp */


      unsigned char readindzpx() {
        address = ( memoryread(pc) + xreg ) & 0xff;
        incpc;
        address = memoryread(address) + ( memoryread((address + 1) & 0xff) << 8);
        return memoryread(address);
      } /* readindzpx */


      unsigned char readindzpy() {
        address = memoryread(pc);
        incpc;
        address = ( memoryread(address) + ( memoryread((address + 1) & 0xff) << 8) + yreg) & 0xffff;
        return memoryread(address);
      } /* readindzpy */



/* standard write zero page instruction */
      void writezp (unsigned int value) {
        address = memoryread(pc);
        incpc;
        memorywrite(address, value);
      } /* writezp */


/* standard write zero page,x instruction */
      void writezpx (unsigned int value) {
        address = ( memoryread(pc) + xreg ) & 0xff;
        incpc;
        memorywrite(address, value);
      } /* writezpx */


/* standard write zero page,y instruction */
      void writezpy (unsigned int value) {
        address = ( memoryread(pc) + yreg ) & 0xff;
        incpc;
        memorywrite(address, value);
      } /* writezpy */


/* standard write abs instruction */
      void writeabs (unsigned int value) {
        address = memoryread(pc);
        incpc;
        address = address + ( memoryread(pc) << 8 );
        incpc;
        memorywrite(address, value);
      } /* writeabs */


/* standard write abs,x instruction */
      void writeabsx (unsigned int value) {
        address = memoryread(pc);
        incpc;
        address = (address + ( memoryread(pc) << 8 ) + xreg) & 0xffff;
        incpc;
        memorywrite(address, value);
      } /* writeabsx */


/* standard write abs,x instruction */
      void writeabsy (unsigned int value) {
        address = memoryread(pc);
        incpc;
        address = (address + ( memoryread(pc) << 8 ) + yreg) & 0xffff;
        incpc;
        memorywrite(address, value);
      } /* writeabsy */

      void writeindzp (unsigned int value) {
        address = memoryread(pc);
        incpc;
        address = memoryread(address) + ( memoryread((address + 1) & 0xff) << 8);
        memorywrite(address, value);
      } /* writeindzp */


      void writeindzpx (unsigned int value) {
        address = ( memoryread(pc) + xreg ) & 0xff;
        incpc;
        address = memoryread(address) + ( memoryread((address + 1) & 0xff) << 8);
        memorywrite(address, value);
      } /* writeindzpx */


/* standard write (zp),y instruction */
      void writeindzpy (unsigned int value) {
        address = memoryread(pc);
        incpc;
        address = ( memoryread(address) + ( memoryread((address + 1) & 0xff) << 8 ) + yreg) & 0xffff;
        memorywrite(address, value);
      } /* writeindzpy */



/*-------------------------------------*/



/* Stack */

        unsigned char pullstack() {
          stack = (stack + 1) & 0xff;
          return memoryread(stack | 0x100);
        } /* pullstack */


        void pushstack (register unsigned char value) {
          memorywrite(stack | 0x100, value);
          stack = (stack - 1) & 0xff;
        } /* pushstack */



/*-------------------------------------*/



/* Adc */

/* The following code was provided by Mr. Scott Hemphill. */
/* Thanks a lot! */

      void adc(unsigned int value) {

        register unsigned int w;

        if ((areg ^ value) & 0x80) {
          vflag = 0;
        }
        else {
          vflag = 1;
        }

        if (dflag) {
          w = (areg & 0xf) + (value & 0xf) + cflag;
          if (w >= 10) {
            w = 0x10 | ((w+6)&0xf);
          }
          w += (areg & 0xf0) + (value & 0xf0);
          if (w >= 160) {
            cflag = 1;
            if (vflag && w >= 0x180) vflag = 0;
            w += 0x60;
          }
          else {
            cflag = 0;
            if (vflag && w < 0x80) vflag = 0;
          }
        }
        else {
          w = areg + value + cflag;
          if (w >= 0x100) {
            cflag = 1;
            if (vflag && w >= 0x180) vflag = 0;
          }
          else {
            cflag = 0;
            if (vflag && w < 0x80) vflag = 0;
          }
        }
        areg = (unsigned char)w;
        nflag = (areg >= 0x80) ? 1 : 0;
        zflag = (areg == 0)    ? 1 : 0;
      } /* adc */


/* Sbc */

/* The following code was provided by Mr. Scott Hemphill. */
/* Thanks a lot again! */

      void sbc(unsigned int value) {

        register unsigned int w;
        register unsigned char temp;

        if ((areg ^ value) & 0x80) {
          vflag = 1;
        }
        else {
          vflag = 0;
        }

        if (dflag) {            /* decimal subtraction */
          temp = 0xf + (areg & 0xf) - (value & 0xf) + (cflag);
          if (temp < 0x10) {
            w = 0;
            temp -= 6;
          }
          else {
            w = 0x10;
            temp -= 0x10;
          }
          w += 0xf0 + (areg & 0xf0) - (value & 0xf0);
          if (w < 0x100) {
            cflag = 0;
            if (vflag && w < 0x80) vflag = 0;
            w -= 0x60;
          }
          else {
            cflag = 1;
            if ((vflag) && w >= 0x180) vflag = 0;
          }
          w += temp;
        }
        else {                  /* standard binary subtraction */
          w = 0xff + areg - value + cflag;
          if (w < 0x100) {
            cflag = 0;
            if (vflag && w < 0x80) vflag = 0;
          }
          else {
            cflag = 1;
            if (vflag && w >= 0x180) vflag = 0;
          }
        }
        areg = (unsigned char)w;
        nflag = (areg >= 0x80) ? 1 : 0;
        zflag = (areg == 0)    ? 1 : 0;
      } /* sbc */


/*-------------------------------------*/


/* Cmp */

      void cmp(unsigned char value) {

        cflag = (areg >= value) ? 1 : 0;
        nflag = (((areg - value) & 0x80) == 0) ? 0 : 1;
        zflag = (areg == value) ? 1 : 0;

      } /* cmp */

/* Cpx */

      void cpx(unsigned char value) {

        cflag = (xreg >= value) ? 1 : 0;
        nflag = (((xreg - value) & 0x80) == 0) ? 0 : 1;
        zflag = (xreg == value) ? 1 : 0;

      } /* cpx */

/* Cpy */

      void cpy(unsigned char value) {

        cflag = (yreg >= value) ? 1 : 0;
        nflag = (((yreg - value) & 0x80) == 0) ? 0 : 1;
        zflag = (yreg == value) ? 1 : 0;

      } /* cpy */


/*-------------------------------------*/

      void hex8tostringf(unsigned int value, unsigned char *stringpointer) {
        register unsigned char c;

	c = (unsigned char)value >> 4;
	if (c > 9) { c = c + 'A' - 10; }
	else { c = c + '0'; }
	*stringpointer = c;
	c = (unsigned char)value & 0xf;
	if (c > 9) { c = c + 'A' - 10; }
	else { c = c + '0'; }
	*(stringpointer+1) = c;

      }

      void cpuwriteregs(unsigned int window) {
	unsigned char message[80];

	strcpy(message, "A: $xx, X: $xx, Y: $xx, PC: $xxxx, SP: $01xx, Flags: NV1BDIZC");
	hex8tostringf(areg, &message[4]);
	hex8tostringf(xreg, &message[12]);
	hex8tostringf(yreg, &message[20]);
	hex8tostringf(pc >> 8,   &message[29]);
	hex8tostringf(pc & 0xff, &message[31]);
	hex8tostringf(stack &0xff, &message[42]);
	cpuflagstostring( cpuflagsgen(), &message[53]);
	stringwrite(window, message);

      } /* cpuwriteregs */

      void cpubrk() {
        unsigned char message[80];

	strcpy(message, "BRK instruction hit at address $xxxx");
	hex8tostringf((pc - 1) >> 8,   &message[32]);
	hex8tostringf((pc - 1) & 0xff, &message[34]);
	setmessage(message);
	stateflags = stateflags | STATEBRK;	/* give the surrounding environment     */
	incpc;					/* the chance to respond to a BRK       */
	pushstack(pc >> 8);			/* e.g. with a debugger                 */
	pushstack(pc & 0xff);
	pc    = address + ( memoryread(pc) << 8 );
	pushstack( cpuflagsgen() | 0x10 );
	if (cputype == CPU65C02) {
	  dflag = 0;                            /* The 65c02 clears the D-flag. */
	}
	iflag = 1;
	bflag = 1;

      } /* cpubrk */

      void cpuillegal(unsigned int opcode) {
        unsigned char message[80];

	pc = (pc - 1) & 0xffff;
	stateflags = stateflags | STATEGURU | STATEHALT;
	imagefillbox(window, 628, 388, 629,389, RGBLGHTOFF);

	strcpy(message, "Illegal instruction $xx hit at address $xxxx");
	hex8tostringf(opcode,    &message[21]);
	hex8tostringf(pc >> 8,   &message[40]);
	hex8tostringf(pc & 0xff, &message[42]);
	setmessage(message);

      } /* cpuillegal */


/*-------------------------------------*/


      void cpuline() {


            do { /* ... while (!tracemode) */

              while (stateflags) {
                if (stateflags & STATERESET) {
                  stateflags = stateflags & ~(STATEHALT | STATERESET);
                  dflag = 0;            /* on a 65c02 the dflag gets cleared on reset */
                  pc = memoryread(0xfffc) | (memoryread(0xfffd) << 8);
                  cycle = cycle + 5;
                }
                if (stateflags & STATEHALT) {   /* processor still halted? */
                  virtcopy = 1;
		  virtscreencopy();
                  return;
                }
                if (stateflags & STATENMI) {
                  stateflags = stateflags & ~STATENMI;
                  pushstack(pc >> 8);
                  pushstack(pc & 0xff);
                  pushstack( cpuflagsgen() );
                  pc    = memoryread(0xfffa) | (memoryread(0xfffb) << 8);
                  cycle = cycle + 6;
                }
                if (stateflags & STATEIRQ) {
                  stateflags = stateflags & ~STATEIRQ;
                  pushstack(pc >> 8);
                  pushstack(pc & 0xff);
                  pushstack( cpuflagsgen() );
                  iflag = 1;
                  pc    = memoryread(0xfffe) | (memoryread(0xffff) << 8);
                  cycle = cycle + 6;
                }
                if (stateflags & STATEBRK) {
                  stateflags = stateflags & ~STATEBRK;
                  pc    = memoryread(0xfffe) | (memoryread(0xffff) << 8);
                  cycle = cycle + 7;
                }
                stateflags = stateflags &  ~(STATETRACE | STATEGURU | STATEBPT);        /* remove these */
               } /* while (stateflags) */


              if (pc == breakpoint) {
                if (breakflag) {        /* breakpoint allowed? */
                  stateflags = stateflags | STATEBPT;
		  setmessage("CPU stopped because breakpoint was reached");
		  imagefillbox(window, 628, 388, 629,389, RGBLGHTOFF);
		  virtcopy = 1;
		  virtscreencopy();
                  return;
                }
              }
              if ((cycle - lastcycle) >= linecycles) {
                lastcycle = lastcycle + linecycles;
                if (rasterline > 265) {
                  rasterline = 0;
                  flashloop++;
#define cachetext40	0x000100
#define cachetext40f	0x000200
                  if ((flashloop&0x3f)==0x00) {
                    virtflashmode = cachetext40;	/* text40 */
//                    virtpaletteset(COL_TXT_WHT2,0x00,0x00,0x00);
//                    virtpaletteset(COL_TXT_WHT3,0xFF,0xFF,0xFF);
//                    virtpaletteset(COL_TXT_AMB2,0x00,0x00,0x00);
//                    virtpaletteset(COL_TXT_AMB3,0xbf,0x5f,0x00);
//                    virtpaletteset(COL_TXT_GRN2,0x00,0x00,0x00);
//                    virtpaletteset(COL_TXT_GRN3,0x00,0xAF,0x00);
//                    virtcopy = 1;
                  }
                  else {
                    if ((flashloop&0x3f)==0x20) {
                      virtflashmode = cachetext40f;	/* text40f */
//                      virtpaletteset(COL_TXT_WHT2,0xFF,0xFF,0xFF);
//                      virtpaletteset(COL_TXT_WHT3,0x00,0x00,0x00);
//                      virtpaletteset(COL_TXT_AMB2,0xbf,0x5f,0x00);
//                      virtpaletteset(COL_TXT_AMB3,0x00,0x00,0x00);
//                      virtpaletteset(COL_TXT_GRN2,0x00,0xAF,0x00);
//                      virtpaletteset(COL_TXT_GRN3,0x00,0x00,0x00);
//                      virtcopy = 1;
                    }
                  }
                  if (cpuwriteregsflag) {
                    imagesettextcolor(window, RGBBLACK, RGBWHITE);
                    imagesetcursor(window, 0, 7);
                    cpuwriteregs(window);
                    virtcopy = 1;
                  }
		  virtscreencopy();
                  return;
                } /* rasterline > 265 */
                else {
                  if (rasterline <= 191) {
                    virtline(rasterline);
                  }
                }
                rasterline++;
              } /* cycle >= 65 */

              /* interpret next opcode */
              bytebuffer        = memoryread(pc);
	      incpc;
              switch (bytebuffer) {
                case 0x00 :                             /* BRK */
                  cpubrk();
                  return;
                case 0x01 :                             /* ORA (zp,x) */
                  areg  = areg | readindzpx();
                  flagssetnz(areg);
                  cycle = cycle + 6;
                  break;
                case 0x02 :
                  if (cputype == CPU6502) {
                    cpuillegal(0x2);
                  }
                  else {				/* NOP2 65C02 */
                    pc    = (pc + 1) & 0xffff;
                    cycle = cycle + 2;
                  }
                  break;
                case 0x03 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x04 :
                  if (cputype == CPU6502) {
                    cpuillegal(0x4);
                  }
                  else {
                    bytebuffer    = readzpm();		/* TSB zp 65C02 */
                    zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                    memorywrite(address, areg | bytebuffer);
                    cycle = cycle + 5;
                  }
                  break;
                case 0x05 :                             /* ORA zp */
                  areg  = areg | readzp();
                  flagssetnz(areg);
                  cycle = cycle + 3;
                  break;
                case 0x06 :                             /* ASL zp */
                  bytebuffer    = readzpm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = (bytebuffer << 1) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = bytebuffer << 1;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x07 :                             /* RMB0 zp */
                  bytebuffer    = readzpm() & 0xfe;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x08 :                             /* PHP */
                  pushstack( cpuflagsgen() );
                  cycle = cycle + 3;
                  break;
                case 0x09 :                             /* ORA # */
                  areg  = areg | memoryread(pc);
		  incpc;
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x0a :                             /* ASL */
                  if ( areg > 0x7f ) {
                    areg        = (areg << 1) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    areg        = areg << 1;
                    cflag       = 0;
                  }
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x0b :                             /* NOP 65C02 */
                  cycle = cycle + 1;
                  break;
                case 0x0c :                             /* TSB abs */
                  bytebuffer    = readabsm();
                  zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                  memorywrite(address, areg | bytebuffer);
                  cycle = cycle + 6;
                  break;
                case 0x0d :                             /* ORA abs */
                  areg  = areg | readabs();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x0e :                             /* ASL abs */
                  bytebuffer    = readabsm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = (bytebuffer << 1) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = bytebuffer << 1;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 6;
                  break;
                case 0x0f :
                  if (cputype == CPU65SC02) {
                    if (!(readzp() & 0x01)) {           /* BBR0 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0x10 :                             /* BPL */
                  if ( nflag == 0) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                    pc          = (pc + 1) & 0xffff;
                    cycle       = cycle + 2;
                  }
                  break;
                case 0x11 :                             /* ORA (zp),y */
                  areg  = areg | readindzpy();
                  flagssetnz(areg);
                  cycle = cycle + 5;
                  break;
                case 0x12 :                             /* ORA (zp) */
                  areg  = areg | readindzp();
                  flagssetnz(areg);
                  cycle = cycle + 5;
                  break;
                case 0x13 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x14 :                             /* TRB zp */
                  bytebuffer    = readzpm();
                  zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                  memorywrite(address, (~areg) & bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x15 :                             /* ORA zp,x */
                  areg  = areg | readzpx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x16 :                             /* ASL zp,x */
                  bytebuffer    = readzpxm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = (bytebuffer << 1) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = bytebuffer << 1;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 6;
                  break;
                case 0x17 :                             /* RMB1 zp */
                  bytebuffer    = readzpm() & 0xfd;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x18 :                             /* CLC */
                  cflag = 0;
                  cycle = cycle + 2;
                  break;
                case 0x19 :                             /* ORA abs,y */
                  areg  = areg | readabsy();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x1a :                             /* INA */
                  areg  = (areg + 1) & 0xff;
                  flagssetnz(xreg);
                  cycle = cycle + 2;
                  break;
                case 0x1b :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x1c :                             /* TRB abs */
                  bytebuffer    = readabsm();
                  zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                  memorywrite(address, (~areg) & bytebuffer);
                  cycle = cycle + 6;
                  break;
                case 0x1d :                             /* ORA abs,x */
                  areg  = areg | readabsx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x1e :                             /* ASL abs,x */
                  bytebuffer    = readabsxm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = (bytebuffer << 1) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = bytebuffer << 1;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 7;
                  break;
                case 0x1f :
                  if (cputype == CPU65SC02) {
                    if (!(readzp() & 0x02)) {           /* BBR1 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    cycle = cycle + 3;
                    break;
                  }
                case 0x20 :                             /* JSR abs */
                  address       = memoryread(pc);
		  incpc;
                  pushstack(pc >> 8);
                  pushstack(pc & 0xff);
                  pc            = address + ( memoryread(pc) << 8 );
                  cycle = cycle + 6;
                  break;
                case 0x21 :                             /* AND (zp,x) */
                  areg  = areg & readindzpx();
                  flagssetnz(areg);
                  cycle = cycle + 6;
                  break;
                case 0x22 :                             /* NOP2 65C02 */
                  pc    = (pc + 1) & 0xffff;
                  cycle = cycle + 2;
                  break;
                case 0x23 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x24 :                             /* BIT zp */
                  bytebuffer    = readzp();
                  vflag = ((bytebuffer & 0x40) == 0) ? 0 : 1;
                  nflag = ((bytebuffer & 0x80) == 0) ? 0 : 1;
                  zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                  cycle = cycle + 3;
                  break;
                case 0x25 :                             /* AND zp */
                  areg  = areg & readzp();
                  flagssetnz(areg);
                  cycle = cycle + 3;
                  break;
                case 0x26 :                             /* ROL zp */
                  bytebuffer    = readzpm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = ((bytebuffer << 1) | cflag) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = (bytebuffer << 1) | cflag;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x27 :                             /* RMB2 zp */
                  bytebuffer    = readzpm() & 0xfb;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x28 :                             /* PLP */
                  cpuflagsget( pullstack() );
                  cycle = cycle + 4;
                  break;
                case 0x29 :                             /* AND # */
                  areg  = areg & memoryread(pc);
		  incpc;
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x2a :                             /* ROL */
                  if (areg > 0x7f) {
                    areg        = ((areg << 1) | cflag) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    areg        = (areg << 1) | cflag;
                    cflag       = 0;
                  }
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x2b :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x2c :                             /* BIT abs */
                  bytebuffer    = readabs();
                  vflag = ((bytebuffer & 0x40) == 0) ? 0 : 1;
                  nflag = ((bytebuffer & 0x80) == 0) ? 0 : 1;
                  zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                  cycle = cycle + 4;
                  break;
                case 0x2d :                             /* AND abs */
                  areg  = areg & readabs();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x2e :                             /* ROL abs */
                  bytebuffer    = readabsm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = ((bytebuffer << 1) | cflag) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = (bytebuffer << 1) | cflag;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 6;
                  break;
                case 0x2f :
                  if (cputype == CPU65SC02) {
                    if (!(readzp() & 0x04)) {           /* BBR2 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0x30 :                             /* BMI */
                  if ( nflag != 0 ) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f ) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                    pc          = (pc + 1) & 0xffff;
                    cycle       = cycle + 2;
                  }
                  break;
                case 0x31 :                             /* AND (zp),y */
                  areg  = areg & readindzpy();
                  flagssetnz(areg);
                  cycle = cycle + 5;
                  break;
                case 0x32 :                             /* AND (zp) */
                  areg  = areg & readindzp();
                  flagssetnz(areg);
                  cycle = cycle + 5;
                  break;
                case 0x33 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x34 :                             /* BIT zp,x */
                  bytebuffer    = readzpx();
                  vflag = ((bytebuffer & 0x40) == 0) ? 0 : 1;
                  nflag = ((bytebuffer & 0x80) == 0) ? 0 : 1;
                  zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                  cycle = cycle + 4;
                  break;
                case 0x35 :                             /* AND zp,x */
                  areg  = areg & readzpx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x36 :                             /* ROL zp,x */
                  bytebuffer    = readzpxm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = ((bytebuffer << 1) | cflag) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = (bytebuffer << 1) | cflag;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 6;
                  break;
                case 0x37 :                             /* RMB3 zp */
                  bytebuffer    = readzpm() & 0xf7;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x38 :                             /* SEC */
                  cflag = 1;
                  cycle = cycle + 2;
                  break;
                case 0x39 :                             /* AND abs,y */
                  areg  = areg & readabsy();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x3a :                             /* DEA */
                  areg  = (areg - 1) & 0xff;
                  flagssetnz(xreg);
                  cycle = cycle + 2;
                  break;
                case 0x3b :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x3c :                             /* BIT abs,x */
                  bytebuffer    = readabsx();
                  vflag = ((bytebuffer & 0x40) == 0) ? 0 : 1;
                  nflag = ((bytebuffer & 0x80) == 0) ? 0 : 1;
                  zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                  cycle = cycle + 4;
                  break;
                case 0x3d :                             /* AND abs,x */
                  areg  = areg & readabsx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x3e :                             /* ROL abs,x */
                  bytebuffer    = readabsxm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = ((bytebuffer << 1) | cflag) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = (bytebuffer << 1) | cflag;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x3f :
                  if (cputype == CPU65SC02) {
                    if (!(readzp() & 0x08)) {           /* BBR3 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0x40 :                             /* RTI */
                  cpuflagsget( pullstack() );
                  pc    = pullstack() + (pullstack() << 8);
                  cycle = cycle + 6;
                  break;
                case 0x41 :                             /* EOR (zp,x) */
                  areg  = areg ^ readindzpx();
                  flagssetnz(areg);
                  cycle = cycle + 6;
                  break;
                case 0x42 :                             /* NOP2 65C02 */
                  pc    = (pc + 1) & 0xffff;
                  cycle = cycle + 2;
                  break;
                case 0x43 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x44 :                             /* NOP3 65C02 */
                  pc    = (pc + 1) & 0xffff;
                  cycle = cycle + 3;
                  break;
                case 0x45 :                             /* EOR zp */
                  areg  = areg ^ readzp();
                  flagssetnz(areg);
                  cycle = cycle + 3;
                  break;
                case 0x46 :                             /* LSR zp */
                  bytebuffer    = readzpm();
                  cflag         = ((bytebuffer & 1) == 0) ? 0 : 1;
                  bytebuffer    = bytebuffer >> 1;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 5;
                  break;
                case 0x47 :                             /* RMB4 zp */
                  bytebuffer    = readzpm() & 0xef;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x48 :                             /* PHA */
                  pushstack(areg);
                  cycle = cycle + 3;
                  break;
                case 0x49 :                             /* EOR # */
                  areg  = areg ^ memoryread(pc);
		  incpc;
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x4a :                             /* LSR */
                  cflag = ((areg & 1) == 0) ? 0 : 1;
                  areg  = areg >> 1;
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x4b :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x4c :                             /* JMP abs */
                  pc    = memoryread(pc) + ( memoryread( (pc + 1) & 0xffff) << 8 );
                  cycle = cycle + 3;
                  break;
                case 0x4d :                             /* EOR abs */
                  areg  = areg ^ readabs();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x4e :                             /* LSR abs */
                  bytebuffer    = readabsm();
                  cflag         = ((bytebuffer & 1) == 0) ? 0 : 1;
                  bytebuffer    = bytebuffer >> 1;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 6;
                  break;
                case 0x4f :
                  if (cputype == CPU65SC02) {
                    if (!(readzp() & 0x10)) {           /* BBR4 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0x50 :                             /* BVC */
                  if ( vflag == 0) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                    pc          = (pc + 1) & 0xffff;
                    cycle       = cycle + 2;
                  }
                  break;
                case 0x51 :                             /* EOR (zp),y */
                  areg  = areg ^ readindzpy();
                  flagssetnz(areg);
                  cycle = cycle + 5;
                  break;
                case 0x52 :                             /* EOR (zp) */
                  areg  = areg ^ readindzp();
                  flagssetnz(areg);
                  cycle = cycle + 5;
                  break;
                case 0x53 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x54 :                             /* NOP4 65C02 */
                  pc    = (pc + 1) & 0xffff;
                  cycle = cycle + 4;
                  break;
                case 0x55 :                             /* EOR zp,x */
                  areg  = areg ^ readzpx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x56 :                             /* LSR zp,x */
                  bytebuffer    = readzpxm();
                  cflag         = ((bytebuffer & 1) == 0) ? 0 : 1;
                  bytebuffer    = bytebuffer >> 1;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 6;
                  break;
                case 0x57 :                             /* RMB5 zp */
                  bytebuffer    = readzpm() & 0xdf;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x58 :                             /* CLI */
                  iflag = 0;
                  cycle = cycle + 2;
                  break;
                case 0x59 :                             /* EOR abs,y */
                  areg  = areg ^ readabsy();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x5a :                             /* PHY */
                  pushstack(yreg);
                  cycle = cycle + 3;
                  break;
                case 0x5b :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x5c :                             /* NOP8 65C02 */
                  pc    = (pc + 2) & 0xffff;
                  cycle = cycle + 8;
                  break;
                case 0x5d :                             /* EOR abs,x */
                  areg  = areg ^ readabsx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x5e :                             /* LSR abs,x */
                  bytebuffer    = readabsxm();
                  cflag         = ((bytebuffer & 1) == 0) ? 0 : 1;
                  bytebuffer    = bytebuffer >> 1;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 7;
                  break;
                case 0x5f :
                  if (cputype == CPU65SC02) {
                    if (!(readzp() & 0x20)) {           /* BBR5 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0x60 :                             /* RTS */
                  pc    = ((pullstack() + (pullstack() << 8)) + 1) & 0xffff;
                  cycle = cycle + 6;
                  break;
                case 0x61 :                             /* ADC (zp,x) */
                  adc(readindzpx());
                  cycle = cycle + 6;
                  break;
                case 0x62 :                             /* NOP2 65C02 */
                  pc    = (pc + 1) & 0xffff;
                  cycle = cycle + 2;
                  break;
                case 0x63 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x64 :                             /* STZ zp */
                  writezp(0);
                  cycle = cycle + 3;
                  break;
                case 0x65 :                             /* ADC zp */
                  adc(readzp());
                  cycle = cycle + 3;
                  break;
                case 0x66 :                             /* ROR zp */
                  bytebuffer    = readzpm();
                  if (cflag) {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = (bytebuffer >> 1) | 0x80;
                  }
                  else {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = bytebuffer >> 1;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x67 :                             /* RMB6 zp */
                  bytebuffer    = readzpm() & 0xbf;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x68 :                             /* PLA */
                  areg  = pullstack();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x69 :                             /* ADC # */
                  adc(memoryread(pc));
		  incpc;
                  cycle = cycle + 2;
                  break;
                case 0x6a :                             /* ROR */
                  if (cflag) {
                    cflag       = (areg & 1) ? 1 : 0;
                    areg        = (areg >> 1) | 0x80;
                  }
                  else {
                    cflag       = (areg & 1) ? 1 : 0;
                    areg        = areg >> 1;
                  }
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x6b :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x6c :                             /* JMP (abs) */
                  address       = memoryread(pc) + ( memoryread((pc + 1) & 0xffff) << 8 );
                  pc            = memoryread(address)
                                  + ( memoryread((address + 1) & 0xffff) << 8 );
                  cycle = cycle + 5;
                  break;
                case 0x6d :                             /* ADC abs */
                  adc(readabs());
                  cycle = cycle + 4;
                  break;
                case 0x6e :                             /* ROR abs */
                  bytebuffer    = readabsm();
                  if (cflag) {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = (bytebuffer >> 1) | 0x80;
                  }
                  else {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = bytebuffer >> 1;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 6;
                  break;
                case 0x6f :
                  if (cputype == CPU65SC02) {
                    if (!(readzp() & 0x40)) {           /* BBR6 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0x70 :                             /* BVS */
                  if ( vflag != 0) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                    pc          = (pc + 1) & 0xffff;
                    cycle       = cycle + 2;
                  }
                  break;
                case 0x71 :                             /* ADC (zp),y */
                  adc(readindzpy());
                  cycle = cycle + 5;
                  break;
                case 0x72 :                             /* ADC (zp) */
                  adc(readindzp());
                  cycle = cycle + 5;
                  break;
                case 0x73 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x74 :                             /* STZ zp,x */
                  writezpx(0);
                  cycle = cycle + 4;
                  break;
                case 0x75 :                             /* ADC zp,x */
                  adc(readzpx());
                  cycle = cycle + 4;
                  break;
                case 0x76 :                             /* ROR zp,x */
                  bytebuffer    = readzpxm();
                  if (cflag) {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = (bytebuffer >> 1) | 0x80;
                  }
                  else {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = bytebuffer >> 1;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 6;
                  break;
                case 0x77 :                             /* RMB7 zp */
                  bytebuffer    = readzpm() & 0x7f;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x78 :                             /* SEI */
                  iflag = 1;
                  cycle = cycle + 2;
                  break;
                case 0x79 :                             /* ADC abs,y */
                  adc(readabsy());
                  cycle = cycle + 4;
                  break;
                case 0x7a :                             /* PLY */
                  yreg  = pullstack();
                  flagssetnz(yreg);
                  cycle = cycle + 4;
                  break;
                case 0x7b :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x7c :                             /* JMP (abs,x) */
                  address       = (memoryread(pc) + ( memoryread((pc + 1) & 0xffff) << 8 )
                                  + xreg) & 0xffff;
                  pc            = memoryread(address)
                                  + ( memoryread((address + 1) & 0xffff) << 8 );
                  cycle = cycle + 5;
                  break;
                case 0x7d :                             /* ADC abs,x */
                  adc(readabsx());
                  cycle = cycle + 4;
                  break;
                case 0x7e :                             /* ROR abs,x */
                  bytebuffer    = readabsxm();
                  if (cflag) {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = (bytebuffer >> 1) | 0x80;
                  }
                  else {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = bytebuffer >> 1;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 7;
                  break;
                case 0x7f :
                  if (cputype == CPU65SC02) {
                    if (!(readzp() & 0x80)) {           /* BBR7 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0x80 :                             /* BRA */
                  bytebuffer= memoryread(pc);
                  if ( bytebuffer > 0x7f) {
                    pc  = (pc - 255 + bytebuffer) & 0xffff;
                  }
                  else {
                    pc  = (pc + 1 + bytebuffer) & 0xffff;
                  }
                  cycle = cycle + 3;
                  break;
                case 0x81 :                             /* STA (zp,x) */
                  writeindzpx(areg);
                  cycle = cycle + 6;
                  break;
                case 0x82 :                             /* NOP2 65C02 */
                  pc    = (pc + 1) & 0xffff;
                  cycle = cycle + 2;
                  break;
                case 0x83 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x84 :                             /* STY zp */
                  writezp(yreg);
                  cycle = cycle + 3;
                  break;
                case 0x85 :                             /* STA zp */
                  writezp(areg);
                  cycle = cycle + 3;
                  break;
                case 0x86 :                             /* STX zp */
                  writezp(xreg);
                  cycle = cycle + 3;
                  break;
                case 0x87 :                             /* SMB0 zp */
                  bytebuffer    = readzpm() | 0x01;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x88 :                             /* DEY */
                  yreg  = (yreg - 1) & 0xff;
                  flagssetnz(yreg);
                  cycle = cycle + 2;
                  break;
                case 0x89 :                             /* BIT # */
                  bytebuffer    = memoryread(pc);
                  incpc;
                  vflag = ((bytebuffer & 0x40) == 0) ? 0 : 1;
                  nflag = ((bytebuffer & 0x80) == 0) ? 0 : 1;
                  zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                  cycle = cycle + 2;
                  break;
                case 0x8a :                             /* TXA */
                  areg  = xreg;
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x8b :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x8c :                             /* STY abs */
                  writeabs(yreg);
                  cycle = cycle + 4;
                  break;
                case 0x8d :                             /* STA abs */
                  writeabs(areg);
                  cycle = cycle + 4;
                  break;
                case 0x8e :                             /* STX abs */
                  writeabs(xreg);
                  cycle = cycle + 4;
                  break;
                case 0x8f :
                  if (cputype == CPU65SC02) {
                    if (readzp() & 0x01) {              /* BBS0 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0x90 :                             /* BCC */
                  if ( cflag == 0) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                   pc           = (pc + 1) & 0xffff;
                   cycle        = cycle + 2;
                  }
                  break;
                case 0x91 :                             /* STA (zp),y */
                  writeindzpy(areg);
                  cycle = cycle + 6;
                  break;
                case 0x92 :                             /* STA (zp) */
                  writeindzp(areg);
                  cycle = cycle + 6;
                  break;
                case 0x93 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x94 :                             /* STY zp,x */
                  writezpx(yreg);
                  cycle = cycle + 4;
                  break;
                case 0x95 :                             /* STA zp,x */
                  writezpx(areg);
                  cycle = cycle + 4;
                  break;
                case 0x96 :                             /* STX zp,y */
                  writezpy(xreg);
                  cycle = cycle + 4;
                  break;
                case 0x97 :                             /* SMB1 zp */
                  bytebuffer    = readzpm() | 0x02;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x98 :                             /* TYA */
                  areg  = yreg;
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x99 :                             /* STA abs,y */
                  writeabsy(areg);
                  cycle = cycle + 5;
                  break;
                case 0x9a :                             /* TXS */
                  stack = xreg;
                  cycle = cycle + 2;
                  break;
                case 0x9b :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x9c :                             /* STZ abs */
                  writeabs(0);
                  cycle = cycle + 4;
                  break;
                case 0x9d :                             /* STA abs,x */
                  writeabsx(areg);
                  cycle = cycle + 5;
                  break;
                case 0x9e :                             /* STZ abs,x */
                  writeabsx(0);
                  cycle = cycle + 5;
                  break;
                case 0x9f :
                  if (cputype == CPU65SC02) {
                    if (readzp() & 0x02) {              /* BBS1 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0xa0 :                             /* LDY # */
                  yreg  = memoryread(pc);
		  incpc;
                  flagssetnz(yreg);
                  cycle = cycle + 2;
                  break;
                case 0xa1 :                             /* LDA (zp,x) */
                  areg  = readindzpx();
                  flagssetnz(areg);
                  cycle = cycle + 6;
                  break;
                case 0xa2 :                             /* LDX # */
                  xreg  = memoryread(pc);
		  incpc;
                  flagssetnz(xreg);
                  cycle = cycle + 2;
                  break;
                case 0xa3 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0xa4 :                             /* LDY zp */
                  yreg  = readzp();
                  flagssetnz(yreg);
                  cycle = cycle + 3;
                  break;
                case 0xa5 :                             /* LDA zp */
                  areg  = readzp();
                  flagssetnz(areg);
                  cycle = cycle + 3;
                  break;
                case 0xa6 :                             /* LDX zp */
                  xreg  = readzp();
                  flagssetnz(xreg);
                  cycle = cycle + 3;
                  break;
                case 0xa7 :                             /* SMB2 zp */
                  bytebuffer    = readzpm() | 0x04;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0xa8 :                             /* TAY */
                  yreg  = areg;
                  flagssetnz(yreg);
                  cycle = cycle + 2;
                  break;
                case 0xa9 :                             /* LDA # */
                  areg  = memoryread(pc);
		  incpc;
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0xaa :                             /* TAX */
                  xreg  = areg;
                  flagssetnz(xreg);
                  cycle = cycle + 2;
                  break;
                case 0xab :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0xac :                             /* LDY abs */
                  yreg  = readabs();
                  flagssetnz(yreg);
                  cycle = cycle + 4;
                  break;
                case 0xad :                             /* LDA abs */
                  areg  = readabs();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0xae :                             /* LDX abs */
                  xreg  = readabs();
                  flagssetnz(xreg);
                  cycle = cycle + 4;
                  break;
                case 0xaf :
                  if (cputype == CPU65SC02) {
                    if (readzp() & 0x04) {              /* BBS2 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0xb0 :                             /* BCS */
                  if ( cflag != 0) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                    pc          = (pc + 1) & 0xffff;
                    cycle       = cycle + 2;
                  }
                  break;
                case 0xb1 :                             /* LDA (zp),y */
                  areg  = readindzpy();
                  flagssetnz(areg);
                  cycle = cycle + 5;
                  break;
                case 0xb2 :                             /* LDA (zp) */
                  areg  = readindzp();
                  flagssetnz(areg);
                  cycle = cycle + 5;
                  break;
                case 0xb3 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0xb4 :                             /* LDY zp,x */
                  yreg  = readzpx();
                  flagssetnz(yreg);
                  cycle = cycle + 4;
                  break;
                case 0xb5 :                             /* LDA zp,x */
                  areg  = readzpx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0xb6 :                             /* LDX zp,y */
                  xreg  = readzpy();
                  flagssetnz(xreg);
                  cycle = cycle + 4;
                  break;
                case 0xb7 :                             /* SMB3 zp */
                  bytebuffer    = readzpm() | 0x08;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0xb8 :                             /* CLV */
                  vflag = 0;
                  cycle = cycle + 2;
                  break;
                case 0xb9 :                             /* LDA abs,y */
                  areg  = readabsy();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0xba :                             /* TSX */
                  xreg  = stack;
                  flagssetnz(xreg);
                  cycle = cycle + 2;
                  break;
                case 0xbb :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0xbc :                             /* LDY abs,x */
                  yreg  = readabsx();
                  flagssetnz(yreg);
                  cycle = cycle + 4;
                  break;
                case 0xbd :                             /* LDA abs,x */
                  areg  = readabsx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0xbe :                             /* LDX abs,y */
                  xreg  = readabsy();
                  flagssetnz(xreg);
                  cycle = cycle + 4;
                  break;
                case 0xbf :
                  if (cputype == CPU65SC02) {
                    if (readzp() & 0x08) {              /* BBS3 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0xc0 :                             /* CPY # */
                  cpy(memoryread(pc));
		  incpc;
                  cycle = cycle + 2;
                  break;
                case 0xc1 :                             /* CMP (zp,x) */
                  cmp(readindzpx());
                  cycle = cycle + 6;
                  break;
                case 0xc2 :                             /* NOP2 65C02 */
                  pc    = (pc + 1) & 0xffff;
                  cycle = cycle + 2;
                  break;
                case 0xc3 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0xc4 :                             /* CPY zp */
                  cpy(readzp());
                  cycle = cycle + 3;
                  break;
                case 0xc5 :                             /* CMP zp */
                  cmp(readzp());
                  cycle = cycle + 3;
                  break;
                case 0xc6 :                             /* DEC zp */
                  bytebuffer    = (readzpm() - 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 5;
                  break;
                case 0xc7 :                             /* SMB4 zp */
                  bytebuffer    = readzpm() | 0x10;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0xc8 :                             /* INY */
                  yreg  = (yreg + 1) & 0xff;
                  flagssetnz(yreg);
                  cycle = cycle + 2;
                  break;
                case 0xc9 :                             /* CMP # */
                  cmp(memoryread(pc));
		  incpc;
                  cycle = cycle + 2;
                  break;
                case 0xca :                             /* DEX */
                  xreg  = (xreg - 1) & 0xff;
                  flagssetnz(xreg);
                  cycle = cycle + 2;
                  break;
                case 0xcb :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0xcc :                             /* CPY abs */
                  cpy(readabs());
                  cycle = cycle + 4;
                  break;
                case 0xcd :                             /* CMP abs */
                  cmp(readabs());
                  cycle = cycle + 4;
                  break;
                case 0xce :                             /* DEC abs */
                  bytebuffer    = (readabsm() - 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 6;
                  break;
                case 0xcf :
                  if (cputype == CPU65SC02) {
                    if (readzp() & 0x10) {              /* BBS4 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0xd0 :                             /* BNE */
                  if ( zflag == 0) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                    pc          = (pc + 1) & 0xffff;
                    cycle       = cycle + 2;
                  }
                  break;
                case 0xd1 :                             /* CMP (zp),y */
                  cmp(readindzpy());
                  cycle = cycle + 5;
                  break;
                case 0xd2 :                             /* CMP (zp) */
                  cmp(readindzp());
                  cycle = cycle + 5;
                  break;
                case 0xd3 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0xd4 :                             /* NOP4 65C02 */
                  pc    = (pc + 1) & 0xffff;
                  cycle = cycle + 4;
                  break;
                case 0xd5 :                             /* CMP zp,x */
                  cmp(readzpx());
                  cycle = cycle + 4;
                  break;
                case 0xd6 :                             /* DEC zp,x */
                  bytebuffer    = (readzpxm() - 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 6;
                  break;
                case 0xd7 :                             /* SMB5 zp */
                  bytebuffer    = readzpm() | 0x20;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0xd8 :                             /* CLD */
                  dflag = 0;
                  cycle = cycle + 2;
                  break;
                case 0xd9 :                             /* CMP abs,y */
                  cmp(readabsy());
                  cycle = cycle + 4;
                  break;
                case 0xda :                             /* PHX */
                  pushstack(xreg);
                  cycle = cycle + 3;
                  break;
                case 0xdb :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0xdc :                             /* NOP4 65C02 */
                  pc    = (pc + 2) & 0xffff;
                  cycle = cycle + 4;
                  break;
                case 0xdd :                             /* CMP abs,x */
                  cmp(readabsx());
                  cycle = cycle + 4;
                  break;
                case 0xde :                             /* DEC abs,x */
                  bytebuffer    = (readabsxm() - 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 7;
                  break;
                case 0xdf :
                  if (cputype == CPU65SC02) {
                    if (readzp() & 0x20) {              /* BBS5 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0xe0 :                             /* CPX # */
                  cpx(memoryread(pc));
		  incpc;
                  cycle = cycle + 2;
                  break;
                case 0xe1 :                             /* SBC (zp,x) */
                  sbc(readindzpx());
                  cycle = cycle + 5;
                  break;
                case 0xe2 :                             /* NOP2 65C02 */
                  pc    = (pc + 1) & 0xffff;
                  cycle = cycle + 2;
                  break;
                case 0xe3 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0xe4 :                             /* CPX zp */
                  cpx(readzp());
                  cycle = cycle + 3;
                  break;
                case 0xe5 :                             /* SBC zp */
                  sbc(readzp());
                  cycle = cycle + 3;
                  break;
                case 0xe6 :                             /* INC zp */
                  bytebuffer    = (readzpm() + 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 5;
                  break;
                case 0xe7 :                             /* SMB6 zp */
                  bytebuffer    = readzpm() | 0x40;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0xe8 :                             /* INX */
                  xreg  = (xreg + 1) & 0xff;
                  flagssetnz(xreg);
                  cycle = cycle + 2;
                  break;
                case 0xe9 :                             /* SBC # */
                  sbc(memoryread(pc));
                  pc    = (pc + 1) & 0xffff;
                  cycle = cycle + 2;
                  break;
                case 0xea :                             /* NOP */
                  cycle = cycle + 2;
                  break;
                case 0xeb :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0xec :                             /* CPX abs */
                  cpx(readabs());
                  cycle = cycle + 4;
                  break;
                case 0xed :                             /* SBC abs */
                  sbc(readabs());
                  cycle = cycle + 4;
                  break;
                case 0xee :                             /* INC abs */
                  bytebuffer    = (readabsm() + 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 6;
                  break;
                case 0xef :
                  if (cputype == CPU65SC02) {
                    if (readzp() & 0x40) {              /* BBS6 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0xf0 :                             /* BEQ */
                  if ( zflag != 0 ) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f ) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                    pc          = (pc + 1) & 0xffff;
                    cycle       = cycle + 2;
                  }
                  break;
                case 0xf1 :                             /* SBC (zp),y */
                  sbc(readindzpy());
                  cycle = cycle + 5;
                  break;
                case 0xf2 :                             /* SBC (zp) */
                  sbc(readindzp());
                  cycle = cycle + 5;
                  break;
                case 0xf3 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0xf4 :                             /* NOP4 65C02 */
                  pc    = (pc + 1) & 0xffff;
                  cycle = cycle + 4;
                  break;
                case 0xf5 :                             /* SBC zp,x */
                  sbc(readzpx());
                  cycle = cycle + 4;
                  break;
                case 0xf6 :                             /* INC zp,x */
                  bytebuffer    = (readzpxm() + 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 6;
                  break;
                case 0xf7 :                             /* SMB7 zp */
                  bytebuffer    = readzpm() | 0x80;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0xf8 :                             /* SED */
                  dflag = 1;
                  cycle = cycle + 2;
                  break;
                case 0xf9 :                             /* SBC abs,y */
                  sbc(readabsy());
                  cycle = cycle + 4;
                  break;
                case 0xfa :                             /* PLX */
                  xreg  = pullstack();
                  flagssetnz(xreg);
                  cycle = cycle + 4;
                  break;
                case 0xfb :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0xfc :                             /* NOP4 65C02 */
                  pc    = (pc + 2) & 0xffff;
                  cycle = cycle + 4;
                  break;
                case 0xfd :                             /* SBC abs,x */
                  sbc(readabsx());
                  cycle = cycle + 4;
                  break;
                case 0xfe :                             /* INC abs,x */
                  bytebuffer    = (readabsxm() + 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 7;
                  break;
                case 0xff :
                  if (cputype == CPU65SC02) {
                    if (readzp() & 0x80) {              /* BBS7 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                default :
                  stateflags = stateflags | STATEHALT | STATEGURU;
                  pc    = (pc - 1) % 0xffff;            /* go back to last instruction */
		  setmessage("CPU stopped because of an illegal instruction");
		  imagefillbox(window, 628, 388, 629,389, RGBLGHTOFF);
		  virtcopy = 1;
		  virtscreencopy();
                  return;
              } /* switch */
              {
                register unsigned int delay;
                for (delay=cpudelay; delay; delay--);
              }
            } /* do */
            while (!traceflag);
            stateflags = stateflags | STATETRACE;

	    setmessage("CPU stopped because of trace mode");
	    imagefillbox(window, 628, 388, 629,389, RGBLGHTOFF);
	    virtcopy = 1;

      } /* cpuline */


/*-------------------------------------*/


      void cpurun() {

        do {
          cpuline();
          if ((stateflags & STATETRACE) | (stateflags & STATEGURU) | (stateflags & STATEBPT)
              /*| (stateflags & STATEBRK) */ ) {
	    debugger(memram, sizeof(memram));
	    if (stateflags & STATEBPT)   { stateflags = stateflags & !STATEBPT;   }
	    if (stateflags & STATETRACE) { stateflags = stateflags & !STATETRACE; }
	    if (stateflags & STATEGURU) {
	      stateflags = stateflags & !STATEGURU;
	      applereset();
	    }
          }
          keyconvert();
          if (messagecount != 0) {
            messagecount--;
            if (messagecount == 0) {
              imagefillbox(window, 0, 392, 639, 399, 0x000000);
              virtcopy = 1;
            }
          }
        }
        while (!exitprogram);
      } /* cpurun */


/*-------------------------------------*/


     void cpumenu() {
	unsigned int screen;
	unsigned int menukeyboard;
	unsigned int menuwindow;
	unsigned char key;
	unsigned char update;
	unsigned char waitstates[32];

	screen = screenstore();
	if (!windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1, "CPU Options", &menukeyboard, &menuwindow)) {

	  messageflag = 0;
	  update = 1;
	  do {
	    if (update) {
	      channelout(menuwindow, 12);		/* clear window */
	      stringwrite(menuwindow, "\r[ESC] - Quit\r\r");

	      stringwrite(menuwindow, "\r[1] - CPU 6502:   ");
	      channelout(menuwindow, cputype==CPU6502 ?   '*':' ');
	      stringwrite(menuwindow, "\r[2] - CPU 65C02:  ");
	      channelout(menuwindow, cputype==CPU65C02 ?  '*':' ');
	      stringwrite(menuwindow, "\r[3] - CPU 65SC02: ");
	      channelout(menuwindow, cputype==CPU65SC02 ? '*':' ');
	      stringwrite(menuwindow, "\rPlease note: Processors are not\rfully implemented yet.");

	      stringwrite(menuwindow, "\r\r[P] - Pause ");
	      if (stateflags & STATEHALT) {
	        stringwrite(menuwindow, "(CPU paused)");
	      }
	      else {
	        stringwrite(menuwindow, "(CPU running)");
	      }

	      stringwrite(menuwindow, "\r[S] - Show CPU registers: ");
	      if (cpuwriteregsflag) {
	        stringwrite(menuwindow, "Yes");
	      }
	      else {
	        stringwrite(menuwindow, "No");
	      }
	      stringwrite(menuwindow, "\r[W] - Wait states (");
	      hex32tostringd(inicpudelay, waitstates);
	      stringwrite(menuwindow, waitstates);
	      stringwrite(menuwindow, ")");

	      imageupdate();
	      update = 0;
	    }
	    do {
	      key = (unsigned char)channelin(menukeyboard);
	    }
	    while ((key == 0) && (!exitprogram));
	    switch (key) {
	      case '1' :
	        cpusettype(CPU6502);
	        update = 1;
	        break;
	      case '2' :
	        cpusettype(CPU65C02);
	        update = 1;
	        break;
	      case '3' :
	        cpusettype(CPU65SC02);
	        update = 1;
	        break;
	      case 'p' :
	      case 'P' :
	        if (stateflags & STATEHALT) {
	          cpuclearstate(STATEHALT);
	        }
	        else {
	          cpusetstate(STATEHALT);
	        }
	        update = 1;
	        break;
	      case 's' :
	      case 'S' :
		cpuwriteregsflag = !cpuwriteregsflag;
		if (!cpuwriteregsflag) {
		  imagefillbox(window, 0, 0, 639, 7, RGBBLACK);
		}
		else {
		  imagesetcursor(window, 0, 7);
		  cpuwriteregs(window);
		}
		update = 1;
		break;
	      case 'w' :
	      case 'W' :
	        stringwrite(menuwindow, "\r\rEnter delay (Enter keeps current value):\r");
	        if (imagestringread(menuwindow, menukeyboard, waitstates, 9)) {
	          inicpudelay = stringtoint(waitstates);
		  cpusetdelay(inicpudelay);
		  cpusetlinecycle(65);
		  drivefastmode = 0;
	        }
	        update = 1;
	        break;
	    } /* switch (key) */
	  }
	  while ((key != 27) && (key != 32) && (key != 13) && (!exitprogram));
	  channelclose(menukeyboard);
	  channelclose(menuwindow);
	  messageflag = 1;
	}
	screenrestore(screen);
	if (stateflags & STATEHALT) {
	  imagefillbox(window, 628, 388, 629,389, RGBLGHTOFF);
	}
	else {
	  imagefillbox(window, 628, 388, 629,389, RGBLGHTON);
	}
	if (!cpuwriteregsflag) {
	  imagefillbox(window, 0, 0, 639, 7, RGBBLACK);
	}

} /* cpumenu */
