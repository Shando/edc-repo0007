package com.blissj.app.util;

import java.io.*;
import java.util.*;
import java.util.zip.*;

public class ResourceArchiveStream extends ArchiveStream
{

    public ResourceArchiveStream(InputStream is) throws IOException {
        this.is = is;

        //read the header off of the stream first
        int stringLength = is.read();
        readFully(header);
        String headerName = new String(header, 0, stringLength);
        if (!headerName.equals("Resource"))
            throw new IOException("Not a valid resource file format");

        discard(2);
        resourceCounter = readWord();
        discard(32);
    }

    public ArchiveEntry getNextEntry() throws IOException {
        if (resourceCounter == 0)
            return null;

        discard(dataCounter);

        crc = new CRC32();

        //read the next record header and return the name
        int stringLength = is.read();
        readFully(header);
        String resourceName = new String(header, 0, stringLength);
        int resourceType = readWord();
        dataCounter = readLong();
        discard(12);
        return new ResourceArchiveEntry(resourceName);
    }

    public int available() {
        return (int)dataCounter;
    }

    public int read() throws IOException {
        if (dataCounter == 0)
            return -1;

        dataCounter--;
        int read = is.read();
        crc.update(read);
        return read;
    }

    public void close() throws IOException {
        is.close();
    }

    private void discard(long length) throws IOException {
        for (long i = 0; i < length; i++)
            is.read();
    }

    private void readFully(int[] array) throws IOException {
        for (int i = 0; i < array.length; i++)
            array[i] = is.read();
    }

    private void readFully(byte[] array) throws IOException {
        int readCount = 0;
        while ((readCount = is.read(array, readCount, array.length-readCount))
                < array.length);
    }

    private int readWord() throws IOException {
        int loByte = is.read();
        int hiByte = is.read();
        return ((hiByte << 8) | loByte);
    }

    private long readLong() throws IOException {
        long loByte0 = is.read();
        long loByte1 = is.read();
        long hiByte0 = is.read();
        long hiByte1 = is.read();
        return ((hiByte1 << 24) | (hiByte0 << 16) | (loByte1 << 8) | loByte0);
    }

    private InputStream is;
    private byte[] header = new byte[12];
    private int resourceCounter;
    private long dataCounter;
    private CRC32 crc;

    private class ResourceArchiveEntry implements ArchiveEntry
    {
        private ResourceArchiveEntry(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }

        public long getCrc() {
            return crc.getValue();
        }

        private String name;

    }

}
