/* faux1 terminal Apple 1 emulator
 * Portions Copyright (C) 2012 James M. Reneau (renejm@users.sourceforge.net)
 *
 * napple1 ncurses Apple 1 emulator
 * Copyright (C) 2008 Nobu Hatano
 *
 * Pom1 Apple 1 Emulator
 * Copyright (C) 2000 Verhille Arnaud
 * Copyright (C) 2006 John D. Corrado
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, 
 * USA.
 */
/** screen.c
 * Screen is a vitrual display of Apple I 
 */
#define _XOPEN_SOURCE 500
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>

#include "strings.h"
#include "screen.h"
#include "memory.h"

void resetScreen(void)
{
	printf(SCREEN_HELLO, VERSION, memMode());
}

static void synchronizeOutput(void)
{
	// the apple1 ran at 2400 baud for output
	// 2400 bits/sec / 10 bits/byte = 240 bytes per second
	// 1000/240 = ms per byte
	// 1000000/240 = us per character
	// 4166 us delay
	usleep(4166);
}

static void newLine(void)
{
	printf("\n");
	fflush(stdout); 
}

void outputDsp(unsigned char dsp)
{
	switch (dsp)
	{
	case 0x5F:
		break;
	case 0x0A:
	case 0x0D:
		newLine();
		break;
	case 0x00:
	case 0x7F:
		break;
	default:
		printf("%c",dsp);
		fflush(stdout); 
		break;
	}

	synchronizeOutput();
}

void select_screen(void)
{
}
