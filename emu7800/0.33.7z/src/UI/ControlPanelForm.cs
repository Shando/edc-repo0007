/*
 * ControlPanelForm.cs
 * 
 * The main user interface form.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */

using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace EMU7800 {

public abstract class ControlPanelTabPage : TabPage {
	public abstract void ClearChanges();
	public abstract void ApplyChanges();
}

public class ControlPanelForm : Form {
	public IHost H;
	public GameSettings CurrGameSettings;
	public bool ApplyButtonEnabled {
		get {
			return btnApply.Enabled;
		}
		set {
			btnCancel.Enabled = value;
			btnApply.Enabled = value;
		}
	}

	private TabControl tabControl;
	private Panel panel1, panel2;
	private Button btnOK, btnCancel, btnApply;

	public ControlPanelForm(IHost h) {
		// Try to set the icon for the form, but don't bomb the application over it
		try {
			Icon = new Icon(Assembly.GetExecutingAssembly().GetManifestResourceStream("EMU7800.Icon1.ico"));
		} catch {}

		H = h;
		CurrGameSettings = new GameSettings(null);

		Text = Globals.Title + " v" + Globals.Version + " Control Panel";
		ClientSize = Globals.ControlPanelFormClientSize;
		MinimumSize = new Size(340, 320);
		MinimizeBox = false;
		MaximizeBox = false;
		ShowInTaskbar = false;
		TopMost = true;
		StartPosition = FormStartPosition.CenterScreen;
		AcceptButton = btnOK;
		SizeGripStyle = SizeGripStyle.Show;
		Opacity = Globals.Opacity;

		panel1 = new Panel();
		panel2 = new Panel();
		Controls.Add(panel1);
		Controls.Add(panel2);

		tabControl = new TabControl();
		panel1.Controls.Add(tabControl);
   
 		Size button_size = new Size(74, 24);
		btnOK = new Button();
		btnOK.Size = button_size;
		btnOK.TabIndex = 0;
		btnOK.Text = "OK";
		btnOK.Click += new EventHandler(OnClickOK);

		btnCancel = new Button();
		btnCancel.Size = button_size;
		btnCancel.TabIndex = 1;
		btnCancel.Text = "Cancel";
		btnCancel.Click += new EventHandler(OnClickCancel);
		
		btnApply = new Button();
		btnApply.Size = button_size;
		btnApply.TabIndex = 2;
		btnApply.Text = "Apply";
		btnApply.Enabled = false;
		btnApply.Click += new EventHandler(OnClickApply);
		
		panel2.Controls.Add(btnOK);
		panel2.Controls.Add(btnCancel);
		panel2.Controls.Add(btnApply);
				
		Layout += new LayoutEventHandler(OnLayout);
		Closing += new CancelEventHandler(OnClosing);

		AddControlPanelTabPage(new GameSelectPage(this));
		if (Directory.Exists(ManualViewingPage.ManualDir)) {
			AddControlPanelTabPage(new ManualViewingPage(this));
		}
		AddControlPanelTabPage(new GreenScreenPage(this));
		AddControlPanelTabPage(new GameSettingsPage(this));
		if (File.Exists(HelpPage.READMEFileName)) {
			AddControlPanelTabPage(new HelpPage());
		}
	}

	private void AddControlPanelTabPage(ControlPanelTabPage tabpage) {
		tabControl.Controls.Add(tabpage);
		tabpage.VisibleChanged += new EventHandler(OnVisibleChanged);
	}

	private void OnClosing(Object sender, CancelEventArgs e) {
		e.Cancel = true;
		Hide();
		Globals.ControlPanelFormClientSize = ClientSize;
	}

	private void OnClickOK(Object sender, EventArgs e) {
		Apply();
		Hide();
		Globals.ControlPanelFormClientSize = ClientSize;
	}
	
	private void OnClickCancel(Object sender, EventArgs e) {
		Cancel();
	}
	
	private void OnClickApply(Object sender, EventArgs e) {
		Apply();
	}

	private void OnVisibleChanged(Object sender, EventArgs e) {
		Cancel();
	}

	private void Apply() {
		if (!ApplyButtonEnabled) {
			return;
		}
		((ControlPanelTabPage)tabControl.SelectedTab).ApplyChanges();
		ApplyButtonEnabled = false;
	}

	private void Cancel() {
		((ControlPanelTabPage)tabControl.SelectedTab).ClearChanges();
		ApplyButtonEnabled = false;
	}

	private void OnLayout(Object sender, LayoutEventArgs e) {
		panel1.Location = new Point(0, 0);
		panel1.Size = new Size(Size.Width - 10, Size.Height - 60);

		tabControl.Location = new Point(0, 0);
		tabControl.Size = panel1.Size;

		panel2.Location = new Point(0, Size.Height - 55);
		panel2.Size = new Size(Size.Width - 25, 55);

		int x = 0;
		btnOK.Location = new Point(x, 0);
		x += btnOK.Size.Width + 5;
		btnCancel.Location = new Point(x, 0);
		x += btnCancel.Size.Width + 5;
		btnApply.Location = new Point(x, 0);
	}
}
}