using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using EMU7800.Machine;

namespace EMU7800.UI
{
    partial class ControlPanelForm
    {
        #region Event Handlers

        void textboxOutput_VisibleChanged(object sender, EventArgs e)
        {
            if (textboxOutput.Visible) textboxOutput.AppendText(EMUTraceListener.Instance.GetMsgs());
            textboxInput.Text = string.Empty;
        }

        void textboxInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)13)
            {
                e.Handled = true;
                IssueCommandFromInputTextbox();
            }
        }

        #endregion

        #region CommandLine Members

        public void ExecuteCommandLine(CommandLine cl)
        {
            if (cl.IsHelp)
            {
                Trace.WriteLine("\n** General Commands **");
            }
            if (cl.CommandEquals("clear"))
            {
                ClClear(cl);
            }
            if (cl.CommandEquals("cpunop"))
            {
                ClCpuNop(cl);
            }
            if (cl.CommandEquals("disablemouse"))
            {
                ClDisableMouse(cl);
            }
            if (cl.CommandEquals("dumpromprops"))
            {
                ClDumpRomProps(cl);
            }
            if (cl.CommandEquals("gs"))
            {
                ClGs(cl);
            }
            if (cl.CommandEquals("ls"))
            {
                ClLs(cl);
            }
            if (cl.CommandEquals("rec"))
            {
                ClRec(cl);
            }
            if (cl.CommandEquals("pb"))
            {
                ClPb(cl);
            }
            if (cl.CommandEquals("run"))
            {
                ClRun(cl);
            }
            if (cl.CommandEquals("opacity"))
            {
                ClOpacity(cl);
            }
            if (cl.CommandEquals("joybuttons"))
            {
                ClJoyButtons(cl);
            }
            if (cl.CommandEquals("fps"))
            {
                ClFps(cl);
            }
            if (cl.CommandEquals("cpuspin"))
            {
                ClCpuSpin(cl);
            }
            if (cl.CommandEquals("save"))
            {
                ClSave(cl);
            }
            if (cl.CommandEquals("restore"))
            {
                ClRestore(cl);
            }

            if (M != null)
            {
                M.ExecuteCommandLine(cl);
            }

            if (!cl.HasMatched && !cl.IsHelp)
            {
                Trace.WriteLine("unrecognized command");
            }
        }

        void ClClear(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" clear: clear log messages (64k limit)");
                return;
            }
            textboxOutput.Clear();
            Trace.WriteLine("log cleared");
        }

        static void ClCpuNop(CommandLine cl)
        {
            if (cl.IsCommandHelp || cl.Parms.Count > 2)
            {
                Trace.WriteLine(" cpunop [on]|[off]: turn on/off cpu NOP register dumping");
                return;
            }
            if (cl.Parms.Count.Equals(2))
            {
                GlobalSettings.Instance.NOPRegisterDumping = cl.Parms[0].Equals("ON");
            }
            Trace.Write("CPU NOP register dumping: ");
            Trace.WriteLine(GlobalSettings.Instance.NOPRegisterDumping ? "ON" : "OFF");
        }

        static void ClDisableMouse(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" disablemouse [on]|[off]: disable mouse input");
                return;
            }
            if (!cl.CheckParms("ss"))
            {
                Trace.WriteLine("need on/off parm");
            }
            else
            {
                GlobalSettings.Instance.DeactivateMouseInput = cl.Parms[1].Equals("ON");
            }
            Trace.Write("Disable mouse: ");
            Trace.WriteLine(GlobalSettings.Instance.DeactivateMouseInput ? "ON" : "OFF");
        }

        void ClDumpRomProps(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" dumpromprops: dump rom properties");
                return;
            }
            ROMProperties.Dump();
        }

        void ClGs(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" gs <attribute> <newvalue>: show/set game settings");
                return;
            }

            var gs = CurrGameSettings;
            if (cl.Parms.Count <= 1)
            {
                Trace.WriteLine(gs);
                return;
            }

            var var = cl.Parms[1];
            var val = cl.Parms.Count == 2 ? new CommandLineParameter("?") : cl.Parms[2];
            if (var.Equals("title"))
            {
                gs.Title = val.StrValue;
            }
            else if (var.Equals("manufacturer"))
            {
                gs.Manufacturer = val.StrValue;
            }
            else if (var.Equals("year"))
            {
                gs.Year = val.StrValue;
            }
            else if (var.Equals("modelno"))
            {
                gs.ModelNo = val.StrValue;
            }
            else if (var.Equals("rarity"))
            {
                gs.Rarity = val.StrValue;
            }
            else if (var.Equals("carttype"))
            {
                try
                {
                    gs.CartType = (CartType)Enum.Parse(typeof(CartType), val.StrValue, true);
                }
                catch (ArgumentException)
                {
                    Trace.WriteLine("Valid CartTypes:");
                    foreach (var typ in Enum.GetNames(typeof(CartType)))
                    {
                        Trace.Write(typ + " ");
                    }
                    Trace.WriteLine(string.Empty);
                }
                return;
            }
            else if (var.Equals("machinetype"))
            {
                try
                {
                    gs.MachineType = (MachineType)Enum.Parse(typeof(MachineType), val.StrValue, true);
                }
                catch (ArgumentException)
                {
                    Trace.WriteLine("Valid MachineTypes:");
                    foreach (var typ in Enum.GetNames(typeof(MachineType)))
                    {
                        Trace.Write(typ + " ");
                    }
                    Trace.WriteLine(string.Empty);
                    return;
                }
            }
            else if (var.Equals("lcontroller") || var.Equals("rcontroller"))
            {
                var c = Controller.None;
                try
                {
                    c = (Controller)Enum.Parse(typeof(Controller), val.StrValue, true);
                }
                catch (ArgumentException)
                {
                }
                if (c != Controller.None)
                {
                    if (var.StrValue.Substring(0, 1).Equals("l", StringComparison.OrdinalIgnoreCase))
                    {
                        gs.LController = c;
                    }
                    else
                    {
                        gs.RController = c;
                    }
                }
                else
                {
                    Trace.WriteLine("Valid Controllers:");
                    foreach (var typ in Enum.GetNames(typeof(Controller)))
                    {
                        Trace.Write(typ + " ");
                    }
                    Trace.WriteLine(string.Empty);
                    return;
                }
            }
            else if (var.Equals("helpuri"))
            {
                gs.HelpUri = val.StrValue;
            }
            else
            {
                Trace.WriteLine("bad parms");
                return;
            }

            CurrGameSettings = gs;
            Trace.WriteLine(CurrGameSettings);
        }

        static void ClLs(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" ls: show files in outdir");
                return;
            }
            Trace.WriteLine("files in outdir:");
            Trace.WriteLine(GlobalSettings.Instance.OutputDirectory);
            try
            {
                var files = new DirectoryInfo(GlobalSettings.Instance.OutputDirectory).GetFiles();
                Trace.Write("FileName".PadRight(40, ' '));
                Trace.WriteLine(" Size");
                Trace.WriteLine(string.Empty.PadRight(45, '-'));
                foreach (var fi in files)
                {
                    if (fi.Extension.Equals(".bmp", StringComparison.OrdinalIgnoreCase)
                        || fi.Extension.Equals(".emu", StringComparison.OrdinalIgnoreCase)
                        || fi.Extension.Equals(".emurec", StringComparison.OrdinalIgnoreCase))
                    {
                        Trace.Write(fi.Name.PadRight(40, ' '));
                        Trace.Write(" ");
                        Trace.Write(fi.Length/1024);
                        Trace.WriteLine("k");
                    }
                }
            }
            catch (DirectoryNotFoundException)
            {
                Trace.Write("directory does not exist: ");
                Trace.WriteLine(GlobalSettings.Instance.OutputDirectory);
            }
        }

        void ClRec(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" rec: start recording input");
                return;
            }
            if (!cl.CheckParms("ss"))
            {
                Trace.WriteLine("need filename");
                return;
            }
            if (CurrGameSettings == null)
            {
                Trace.WriteLine("no game selected");
                return;
            }
            var fn = GenerateOutFileName(Path.Combine(GlobalSettings.Instance.OutputDirectory, cl.Parms[1].StrValue), ".emurec");
            Record(fn);
        }

        void ClPb(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" pb <filenm> [loop]: replay recording");
                return;
            }
            if (!cl.CheckParms("ss"))
            {
                Trace.WriteLine("need filename");
                return;
            }
            if (cl.Parms.Count >= 3 && !cl.Parms[2].Equals("loop"))
            {
                Trace.WriteLine("bad optional parameter");
                return;
            }
            var fn = Path.Combine(GlobalSettings.Instance.OutputDirectory, cl.Parms[1].StrValue);
            Playback(fn, cl.Parms.Count >= 3);
        }

        void ClRun(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" run: run ROM specified in GameSettings");
                return;
            }
            if (CurrGameSettings.FileInfo == null)
            {
                Trace.WriteLine("GameSettings incomplete");
                return;
            }
            textboxOutput_VisibleChanged(this, null);
            buttonStart_Click(this, null);
        }

        void ClOpacity(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" opacity [25-100]");
                return;
            }
            if (cl.Parms.Count <= 1)
            {
                Trace.WriteLine("opacity " + Opacity * 100 + "%");
                return;
            }
            if (!cl.CheckParms("si"))
            {
                Trace.WriteLine("bad parm");
                return;
            }
            var op = cl.Parms[1].IntValue;
            if (op > 100)
            {
                op = 100;
            }
            else if (op < 25)
            {
                op = 25;
            }
            Opacity = op / 100.0;
            Trace.WriteLine("opacity set to " + Opacity * 100 + "%");
        }

        static void ClJoyButtons(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" joybuttons <trigger#> <booster#>");
                return;
            }
            if (cl.Parms.Count <= 1)
            {
                Trace.WriteLine(string.Format("joybuttons: trigger:{0} booster:{1}\n", GlobalSettings.Instance.JoyBTrigger, GlobalSettings.Instance.JoyBBooster));
                return;
            }
            if (!cl.CheckParms("sii"))
            {
                Trace.WriteLine("bad parms");
                Trace.WriteLine("usage: joybuttons [trigger#] [booster#] [select#] [reset#] [swap#]");
                return;
            }
            GlobalSettings.Instance.JoyBTrigger = cl.Parms[1].IntValue;
            GlobalSettings.Instance.JoyBBooster = cl.Parms[2].IntValue;
            Trace.WriteLine("joystick button bindings set");
        }

        static void ClFps(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" fps [ratedelta]: adj. frames per second");
                return;
            }
            if (cl.Parms.Count <= 1)
            {
                Trace.WriteLine(GlobalSettings.Instance.FrameRateAdjust);
                return;
            }
            if (!cl.CheckParms("si") || cl.Parms.Count > 2)
            {
                Trace.WriteLine("bad parm");
                return;
            }
            GlobalSettings.Instance.FrameRateAdjust = cl.Parms[1].IntValue;
            Trace.WriteLine("ok");
        }

        static void ClCpuSpin(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" cpuspin [millisecs]: per frame time cpu will spin wait for next frame");
                return;
            }
            if (cl.Parms.Count <= 1)
            {
                Trace.WriteLine(GlobalSettings.Instance.CpuSpin);
                return;
            }
            if (!cl.CheckParms("si"))
            {
                Trace.WriteLine("bad parm");
                return;
            }
            GlobalSettings.Instance.CpuSpin = cl.Parms[1].IntValue;
            Trace.WriteLine("ok");
        }

        void ClSave(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" save <filenm>: save machine state");
                return;
            }
            if (M == null)
            {
                Trace.WriteLine("no machine");
                return;
            }
            if (!cl.CheckParms("ss"))
            {
                Trace.WriteLine("bad parm");
                return;
            }
            var fn = GenerateOutFileName(Path.Combine(GlobalSettings.Instance.OutputDirectory, cl.Parms[1].StrValue), ".emu");
            try
            {
                M.Serialize(fn);
            }
            catch (Exception ex)
            {
                if (Utility.IsCriticalException(ex)) throw;
                Trace.WriteLine("error saving machine state: ");
                Trace.WriteLine(ex);
                return;
            }
            Trace.Write("machine state saved to ");
            Trace.WriteLine(Path.GetFileName(fn));
        }

        void ClRestore(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" restore <filenm>: restore machine state");
                return;
            }
            if (!cl.CheckParms("ss"))
            {
                Trace.WriteLine("bad parm");
                return;
            }
            CurrGameSettings = null;
            var fn = Path.Combine(GlobalSettings.Instance.OutputDirectory, cl.Parms[1].StrValue);
            try
            {
                M = MachineBase.Deserialize(fn);
            }
            catch (Exception ex)
            {
                if (Utility.IsCriticalException(ex)) throw;
                StartButtonEnabled = false;
                ResumeButtonEnabled = false;
                Trace.WriteLine(ex);
                return;
            }
            StartButtonEnabled = false;
            ResumeButtonEnabled = true;
            ResetGameTitleLabel();
            Trace.WriteLine("machine state restored");
        }

        #endregion

        #region Helpers

        void IssueCommandFromInputTextbox()
        {
            var commandline = textboxInput.Text;
            textboxInput.Text = string.Empty;
            Trace.WriteLine(string.Format(">{0}", commandline));
            ExecuteCommandLine(new CommandLine(commandline));
            textboxOutput.AppendText(EMUTraceListener.Instance.GetMsgs());
            textboxInput.Focus();
        }

        static string GenerateOutFileName(string fn, string ext)
        {
            var stem = Path.Combine(Path.GetDirectoryName(fn),Path.GetFileNameWithoutExtension(fn));
            var i = 0;
            var u = string.Empty;
            string outFileName;
            while (true)
            {
                outFileName = stem + u + ext;
                if (!File.Exists(outFileName))
                {
                    break;
                }
                u = (++i).ToString();
            }
            return outFileName;
        }

        void Record(string fn)
        {
            GlobalSettings.Instance.Skip7800BIOS = true;
            checkboxSkip7800Bios.Checked = true;
            Trace.Write("recording to ");
            Trace.WriteLine(Path.GetFileName(fn));
            textboxOutput_VisibleChanged(this, null);
            var ria = new RecordInputAdapter(fn, CurrGameSettings.MD5);
            Start(ria);
            ria.StopRecording();
        }

        void Playback(string fn, bool doLooping)
        {
            bool playbackLoopingEofSeen;
            GlobalSettings.Instance.Skip7800BIOS = true;
            checkboxSkip7800Bios.Checked = true;
            while (true)
            {
                var pia = new PlaybackInputAdapter(fn);
                playbackLoopingEofSeen = false;
                if (doLooping)
                {
                    pia.EofListeners += delegate
                    {
                        M.MachineHalt = true;
                        playbackLoopingEofSeen = true;
                    };
                }
                if (pia.CartMD5 == null)
                {
                    Trace.WriteLine("error starting playback");
                }
                else
                {
                    var gs = ROMProperties.GetGameSettings(pia.CartMD5);
                    if (gs == null || gs.FileInfo == null)
                    {
                        Trace.WriteLine("rom not found in current rom directory");
                    }
                    else
                    {
                        textboxOutput_VisibleChanged(this, null);
                        ResetGameTitleLabel();
                        CurrGameSettings = gs;
                        Start(pia);
                        pia.StopPlayback();
                    }
                }

                if (!doLooping || !playbackLoopingEofSeen)
                {
                    break;
                }
            }
        }

        #endregion
    }
}