/*
 * SettingsPage.cs
 * 
 * A TabPage that permits major game setting changes
 * 
 * Copyright (c) 2003, 2004 Mike Murphy
 * 
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace EMU7800 {
	
public class SettingsPage : TabPage {
	private ControlPanelForm ControlPanelForm;

	private Label lblHostSelect;
	private ComboBox cmbHostSelect;

	private Label lblFrameRateAdjust;
	private NumericUpDown nudFrameRateAdjust;

	private Label lblNumSoundBuffers;
	private NumericUpDown nudNumSoundBuffers;

	private Label lblSoundVolume;
	private NumericUpDown nudSoundVolume;

	private Label lblSkip7800BIOS;
	private CheckBox cbxSkip7800BIOS;

	public SettingsPage(ControlPanelForm f) {
		ControlPanelForm = f;
		Text = "Settings";

		lblHostSelect = new Label();
		lblHostSelect.Text = "Host Select:";
		lblHostSelect.Location = new Point(15, 15);
		lblHostSelect.Size = new Size(210, 15);

		cmbHostSelect = new ComboBox();
		cmbHostSelect.Text = "";
		cmbHostSelect.Location = new Point(15, 30);
		cmbHostSelect.Size = new Size(210, 15);
		cmbHostSelect.Items.Add("Windows GDI");
		cmbHostSelect.Items.Add("Simple DirectMedia Layer (SDL)");
		try {
			switch (Globals.HostSelect.ToUpper()) {
			case "GDI":
				cmbHostSelect.SelectedIndex = 0;
				break;
			default:
			case "SDL":
				cmbHostSelect.SelectedIndex = 1;
				break;
			}
		} catch {
			cmbHostSelect.SelectedIndex = 0;
		}
		cmbHostSelect.SelectedIndexChanged += new EventHandler(OnSelectedIndexChanged);

		lblFrameRateAdjust = new Label();
		lblFrameRateAdjust.Text = "Frame Rate Adjust (+/-):";
		lblFrameRateAdjust.Location = new Point(15, 60);
		lblFrameRateAdjust.Size = new Size(150, 15);

		nudFrameRateAdjust = new NumericUpDown();
		nudFrameRateAdjust.Location = new Point(170, 60);
		nudFrameRateAdjust.Size = new Size(55, 15);
		nudFrameRateAdjust.ReadOnly = true;
		nudFrameRateAdjust.Increment = 1;
		nudFrameRateAdjust.Minimum = -40;
		nudFrameRateAdjust.Maximum = 40;
		try {
			nudFrameRateAdjust.Value = Globals.FrameRateAdjust;
		} catch {
			Globals.FrameRateAdjust = 0;
			nudFrameRateAdjust.Value = 0;
		}
		nudFrameRateAdjust.ValueChanged += new EventHandler(OnValueChanged);

		lblNumSoundBuffers = new Label();
		lblNumSoundBuffers.Text = "Sound Queue Length:";
		lblNumSoundBuffers.Location = new Point(15, 90);
		lblNumSoundBuffers.Size = new Size(150, 15);

		nudNumSoundBuffers = new NumericUpDown();
		nudNumSoundBuffers.Location = new Point(170, 90);
		nudNumSoundBuffers.Size = new Size(55, 15);
		nudNumSoundBuffers.ReadOnly = true;
		nudNumSoundBuffers.Increment = 1;
		nudNumSoundBuffers.Minimum = 2;
		nudNumSoundBuffers.Maximum = 30;
		try {
			nudNumSoundBuffers.Value = Globals.NumSoundBuffers;
		} catch {
			nudNumSoundBuffers.Value = 10;
			Globals.NumSoundBuffers = 10;
		}
		nudNumSoundBuffers.ValueChanged += new EventHandler(OnValueChanged);

		lblSoundVolume = new Label();
		lblSoundVolume.Text = "Sound Volume:";
		lblSoundVolume.Location = new Point(15, 120);
		lblSoundVolume.Size = new Size(150, 15);

		nudSoundVolume = new NumericUpDown();
		nudSoundVolume.Location = new Point(170, 120);
		nudSoundVolume.Size = new Size(55, 15);
		nudSoundVolume.ReadOnly = true;
		nudSoundVolume.Increment = 1;
		nudSoundVolume.Minimum = 1;
		nudSoundVolume.Maximum = 16;
		try {
			nudSoundVolume.Value = Globals.SoundVolume;
		} catch {
			nudSoundVolume.Value = 8;
			Globals.SoundVolume = 8;
		}
		nudSoundVolume.ValueChanged += new EventHandler(OnValueChanged);

		lblSkip7800BIOS = new Label();
		lblSkip7800BIOS.Text = "Skip BIOS (7800 Emulation):";
		lblSkip7800BIOS.Location = new Point(15, 150);
		lblSkip7800BIOS.Size = new Size(150, 15);

		cbxSkip7800BIOS = new CheckBox();
		cbxSkip7800BIOS.Location = new Point(170, 150);
		cbxSkip7800BIOS.Checked = Globals.Skip7800BIOS;
		cbxSkip7800BIOS.CheckedChanged += new EventHandler(OnValueChanged);

		Controls.Add(lblHostSelect);
		Controls.Add(cmbHostSelect);
		Controls.Add(lblFrameRateAdjust);
		Controls.Add(nudFrameRateAdjust);
		Controls.Add(lblNumSoundBuffers);
		Controls.Add(nudNumSoundBuffers);
		Controls.Add(lblSoundVolume);
		Controls.Add(nudSoundVolume);
		Controls.Add(lblSkip7800BIOS);
		Controls.Add(cbxSkip7800BIOS);
	}

	private void OnValueChanged(object sender, EventArgs e) {
		if (sender == nudFrameRateAdjust) {
			Globals.FrameRateAdjust = (int)nudFrameRateAdjust.Value;
			ControlPanelForm.StartButtonEnabled = true;
			ControlPanelForm.ResumeButtonEnabled = false;
		}
		if (sender == nudNumSoundBuffers) {
			Globals.NumSoundBuffers = (int)nudNumSoundBuffers.Value;
			ControlPanelForm.StartButtonEnabled = true;
			ControlPanelForm.ResumeButtonEnabled = false;
		}
		if (sender == nudSoundVolume) {
			Globals.SoundVolume = (int)nudSoundVolume.Value;
		}
		if (sender == cbxSkip7800BIOS) {
			Globals.Skip7800BIOS = cbxSkip7800BIOS.Checked;
		}
	}

	private void OnSelectedIndexChanged(object sender, EventArgs e) {
		if (sender == cmbHostSelect) {
			switch (cmbHostSelect.SelectedIndex) {
			case 0:

				Globals.HostSelect = "GDI";
				break;
			default:
			case 1:
				Globals.HostSelect = "SDL";
				break;
			}
		}
	}
}
}