export CVSROOT=$USERNAME@cvs.blissemu.sourceforge.net:/cvsroot/blissemu
export CVSIGNORE="*.class *.obj *.jar *.dll *.exp *.lib *.res com_*.h"
export JAVA_HOME="c:\\dev\\jdk1.3.1"
export MSSDKFORJAVA_HOME="c:\\Program Files\\Microsoft SDK for Java 4.0\\bin"
export DX_HOME="c:\\dev\\DXVCSDK"
export VC_HOME="c:\\dev\\msvc6.0"
export VC_HOME_BASH="/dev/msvc6.0"
export SRC_ROOT="c:\\dev\\bliss\\blissj\\src"
export SRC_ROOT_BASH="/dev/bliss/blissj/src"

export CLASSPATH="$SRC_ROOT;$JAVA_HOME\\jre\\lib\\rt.jar"
export INCLUDE="$DX_HOME\\include;$VC_HOME\\include;$JAVA_HOME\\include;$JAVA_HOME\\include\\win32;$SRC_ROOT\\kaillera;$SRC_ROOT\\corenative;$SRC_ROOT\\bliss32"
export LIB="$DX_HOME\\lib;$VC_HOME\\lib;$JAVA_HOME\\lib;$SRC_ROOT\\kaillera"
export PATH="$PATH:/dev/jikes-1.14:$VC_HOME_BASH/bin:$VC_HOME_BASH/common/MSDev98/bin:$MSSDKFORJAVA_HOME/bin"

