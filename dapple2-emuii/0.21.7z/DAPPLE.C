/*
 * Dapple ][ Emulator  Version 0.21
 * Copyright (C) 2002, 2003 Dapple ][ Development.  All rights reserved.
 *
 * Component:  DAPPLE: main menu, global functions, keyboard emulation
 * Revision:   (0.21) 2003.0211
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <dir.h>
#include <dos.h>
#include <go32.h>		/* _go32_want_ctrl_break() */
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <sys/exceptn.h>	/* __djgpp_set_ctrl_c() */
#include <unistd.h>
#include "dapple.h"
#include "asmlib.h"

/* video.c */
extern unsigned char virtcopy;
void virtinit();
void virtreset();
void virtline(unsigned int rasterline);
void virtscreencopy();
void virtsethresmode(unsigned char mode);
unsigned char virtgethresmode();
void virtsetmonochrome(unsigned char mode);
unsigned char virtgetmonochrome();
void virtsetpalette(unsigned char mode);
unsigned char virtgetpalette();
void virtmenu();
unsigned int virtstore(unsigned int window, FILE *file);
unsigned int virtrestore(unsigned int window, FILE *file);

/* cpu65c02.c */
unsigned char cpuinuse();
void cpuinit();
void cpureset();
void cpusetlinecycle(unsigned int value);
unsigned int cpugetlinecycle();
void cpusetdelay(unsigned int value);
void cpusetstate(unsigned int value);
void cpuclearstate(unsigned int value);
unsigned char cpugetstate();
void cpuline();
void cpurun();
void cpumenu();
unsigned int cpustore(unsigned int window, FILE *file);
unsigned int cpurestore(unsigned int window, FILE *file);

/* memory.c */
extern unsigned char memkey;
extern unsigned int memjoyx;
extern unsigned int memjoyy;
extern unsigned char memjoybutton0;
extern unsigned char memjoybutton1;
extern unsigned char memram[0x28000];
void soundinit();
void soundmenu();
void memoryinit();
void memoryreset();
unsigned int memoryautoloadrom(unsigned int keyboard, unsigned int window);
void memorymenu();
unsigned int memorystore(unsigned int window, FILE *file);
unsigned int memoryrestore(unsigned int window, FILE *file);

int find_ramworks (void);

/* disk.c */
typedef struct {
  unsigned char slot;
  unsigned char drive;
  unsigned char path[260];
  unsigned char type;
  unsigned int phase;
  unsigned int track;
  unsigned int bytepointer;
  unsigned char access;
  unsigned char changed;
  unsigned char writeprotected;
  unsigned char data[233472];
} drivedisk;
extern drivedisk drivedisk1;
extern drivedisk drivedisk2;
extern unsigned char drivefastmode;
void driveinit();
void drivereset();
unsigned int driveeject(drivedisk *disk);
unsigned int driveload(drivedisk *disk, unsigned char *filename);
void drivemenu();
unsigned int drivestore(unsigned int window, FILE *file);
unsigned int driverestore(unsigned int window, FILE *file);

/* lldisk.c */
void llinit();

/* ini.c */
void readini();
void writeini();


void mainmenu();
void keyboardmenu();
unsigned int keyboardstore(unsigned int window, FILE *file);
unsigned int keyboardrestore(unsigned int window, FILE *file);
unsigned int  keyboard;		/* keyboard handle		*/
unsigned int  window;		/* window handle		*/
unsigned char appletype;	/* II+/IIe/IIc */
unsigned char key;
unsigned char keyspec;
unsigned int  messagecount;
unsigned char messageflag;
unsigned int  i;
unsigned int  inicpudelay;
unsigned char inidiskpath1[256];
unsigned char inidiskpath2[256];
unsigned char inidebugflag;	/* debugger on? */
unsigned char inidrivemessageflag; /* display current drive track? */
unsigned char inidrivefastflag;
unsigned char keycapslock;	/* capslock mode on? */
unsigned char keygerman;	/* switch 'Y' and 'Z' on German keyboards? */
unsigned char keyjoystick;	/* emulate joystick via numbpad or real joystick */
unsigned char callingpath[260];

/* dummy declarations to let other modules compile successfully */

unsigned char HDDROM[256];
unsigned char *shiftstate;
unsigned char dqhdv;
unsigned char dqshift;

/*-------------------------------------*/

      unsigned char ReadMassStorIO(unsigned int addr) {

	return 0xff;

      }

/*-------------------------------------*/

      void WriteMassStorIO(unsigned int addr, unsigned int value) {

	return;

      }

/*-------------------------------------*/


      void stringwritecenterx(unsigned int window, unsigned char *stringpointer) {

	imagesetcursor(window, (WINDOWXSIZE - (strlen(stringpointer) << 3)) / 2, imagegetcursory(window) );
	stringwrite(window, stringpointer);

      } /* stringwritecenterx */


/*-------------------------------------*/


      unsigned int windowprotocol(unsigned int *keyboard, unsigned int *window, unsigned char *title) {
        const unsigned int XSIZE = 480;
        const unsigned int YSIZE = 128;
	register unsigned int error;

	error = windowaddio(-1, -1, XSIZE, YSIZE, 0, 0, NULL, keyboard, window);
	if (!error) {
	  imagedrawbox(*window, 0,	0,	XSIZE-1,YSIZE-1,0x000000);
	  imagefillbox(*window, 1,	YSIZE-2,XSIZE-2,YSIZE-2,0x404040);
	  imagefillbox(*window, XSIZE-2,1,	XSIZE-2,YSIZE-2,0x404040);
	  imagefillbox(*window, 1,	1,	XSIZE-2,1,	0xffffff);
	  imagefillbox(*window, 1,	1,	1,	YSIZE-2,0xffffff);
	  imagesetview(*window, 2,	2,	XSIZE-3,YSIZE-3);
	  imagesettextcolor(*window,	0x808080,	0xffffff);
	  imagesettextattribute(*window, IMAGEBOLD);
	  channelout(*window, 12);
	  stringwrite(*window, title);
	  imagesettextattribute(*window, 0);
	  imagefillbox(*window, 2, imagegetcursory(*window)+2, XSIZE-3, imagegetcursory(*window)+2, 0x404040);
	  imagefillbox(*window, 2, imagegetcursory(*window)+3, XSIZE-3, imagegetcursory(*window)+3, 0xffffff);
	  imagesetview(*window, 2,	imagegetcursory(*window)+6, XSIZE-3, YSIZE-3);
	  imagesettextcolor(*window,	0x808080,	0xffff00);
	  channelout(*window, 16);
	}
	return error;

      } /* windowprotocol */


/*-------------------------------------*/


      void imagetickbox(unsigned int window, unsigned int value) {

	register unsigned int cursorx;
	register unsigned int cursory;

	cursorx = imagegetcursorx(window);
	cursory = imagegetcursory(window);

	imagefillbox(window, cursorx, cursory-7, cursorx+7, cursory, RGBLIGHT);
	imagefillbox(window, cursorx, cursory-6, cursorx+6, cursory, RGBDARK);
	imagefillbox(window, cursorx+1, cursory-6, cursorx+6, cursory-1, RGBWHITE);

	if (value) {
	  imageline(window, cursorx+2, cursory-4, cursorx+3, cursory-2, RGBBLACK);
	  imageline(window, cursorx+3, cursory-2, cursorx+6, cursory-5, RGBBLACK);
	}
	imagesetcursor(window, cursorx+8, cursory);

      } /* stringwritecenterx */


/*-------------------------------------*/


     void setmessage(unsigned char *message) {

	if (messageflag) {
	  imagesetcursor	(window, 0, 399);
	  imagefillbox	(window, 0, 392, 639, 399, 0xff8000);
	  imagesettextcolor(window, 0xff8000, 0x000000);
	  stringwrite	(window, message);
	  messagecount = 50 * 4;
	  virtcopy = 1;
	}

     } /* setmessage */


/*-------------------------------------*/


      void applereset() {

	cpureset();
#ifdef EMUZ80
	Z80_Reset();
#endif
	memoryreset();
	virtreset();
	drivereset();

	setmessage("Reset Apple");

      } /* applereset */


/*-------------------------------------*/


      unsigned int applestore(unsigned char *filename) {
        unsigned int screen;
        unsigned int keyboard;
        unsigned int window;
	unsigned char header[16];
	unsigned char oldcwd[260];
	FILE *file;
	register unsigned int error;
	register unsigned char key;


	screen = screenstore();

	error = windowprotocol(&keyboard, &window, "Save emulation state");
	if (!error) {

	  getcwd(oldcwd, 256);
	  chdir(callingpath);

	  file = fopen(filename, "wb");
	  if (!(file)) {
	    stringwrite(window, "Sorry, I could not open the file \"");
	    stringwrite(window, filename);
	    stringwrite(window, "DAPPLE2.DAT\".\r");
	    error = 1;
 	  }
	  else {

	    strcpy(header, "DAPPLE2 STATE");
	    fwrite(header,	sizeof(header),	1, file);

	    error = keyboardstore(window, file);
	    if (!error) {
	      imageupdate();
	      error = memorystore(window, file);
	      if (!error) {
	        imageupdate();
	        error = cpustore(window, file);
	        if (!error) {
	          imageupdate();
	          error = virtstore(window, file);
	          if (!error) {
	            imageupdate();
	            error = drivestore(window, file);
	            if (!error) {
	  	      stringwrite(window, "Emulator state stored.\r");
	              imageupdate();
	  	    }
	  	  }
	        }
	      }
	    }

	    fclose(file);
	  }

	  chdir(oldcwd);

	  if (error) {
	    stringwrite(window, "Press a key to continue.");
	    do {
	      imageupdate();
	      key = (unsigned char)channelin(keyboard);
	    }
	    while ((key == 0) && (!exitprogram));
	  }

	  channelclose(keyboard);
	  channelclose(window);
	}

	screenrestore(screen);

	return error;

      } /* applestore */


/*-------------------------------------*/


      unsigned int applerestore(unsigned char *filename) {
        unsigned int screen;
        unsigned int keyboard;
        unsigned int window;
	unsigned char header[16];
	unsigned char oldcwd[260];
	FILE *file;
	register unsigned int error;
	register unsigned char key;


	screen = screenstore();

	error = windowprotocol(&keyboard, &window, "Load emulation state");
	if (!error) {

	  stringwrite(window, "Restoring emulator state...\r");
	  imageupdate();

	  getcwd(oldcwd, 256);
	  chdir(callingpath);

	  file = fopen(filename, "rb");
	  if (!(file)) {
	    stringwrite(window, "Sorry, I could not open the file \"");
	    stringwrite(window, filename);
	    stringwrite(window, "DAPPLE2.DAT\".\r");
	    error = 1;
 	  }
	  else {

	    fread(header, sizeof(header), 1, file);
	    if (strcmp(header, "DAPPLE2 STATE")) {
	      stringwrite(window, "File is not a Dapple Emulator State file.\r");
	      error = 1;
	    }
	    else {
	      error = keyboardrestore(window, file);
	      if (!error) {
	        imageupdate();
	        error = memoryrestore(window, file);
	        if (!error) {
	          imageupdate();
	          error = cpurestore(window, file);
	          if (!error) {
	            imageupdate();
	            error = virtrestore(window, file);
	            if (!error) {
	              imageupdate();
	              error = driverestore(window, file);
	              if (!error) {
	   	        stringwrite(window, "Emulator state restored.\r");
	                imageupdate();
	  	      }
	  	    }
	          }
	        }
	      }
	    }

	    fclose(file);
	  }

	  chdir(oldcwd);

	  if (error) {
	    stringwrite(window, "Press a key to continue.");
	    do {
	      imageupdate();
	      key = (unsigned char)channelin(keyboard);
	    }
	    while ((key == 0) && (!exitprogram));
	  }

	  channelclose(keyboard);
	  channelclose(window);
	}

	screenrestore(screen);

	return error;

      } /* applerestore */


/*-------------------------------------*/


      unsigned int keyboardstore(unsigned int window, FILE *file) {

	fwrite(&keygerman,	sizeof(keygerman),	1, file);
	fwrite(&keycapslock,	sizeof(keycapslock),	1, file);
	fwrite(&keyjoystick,	sizeof(keyjoystick),	1, file);

	stringwrite(window, "Keyboard stored.\r");
	return 0;

      } /* keyboardstore */


/*-------------------------------------*/


      unsigned int keyboardrestore(unsigned int window, FILE *file) {

	fread(&keygerman,	sizeof(keygerman),	1, file);
	fread(&keycapslock,	sizeof(keycapslock),	1, file);
	fread(&keyjoystick,	sizeof(keyjoystick),	1, file);

	stringwrite(window, "Keyboard restored.\r");

	return 0;

      } /* keyboardstore */


/*-------------------------------------*/


static int joya(void) {
  union REGS regs;

  regs.h.ah=0x84;
  regs.x.dx=0;
  int86(0x15,&regs,&regs); /* al */
  if ((regs.h.al&0x10)==0) return 255; else return 0;
}

static int joyb(void) {
  union REGS regs;

  regs.h.ah=0x84;
  regs.x.dx=0;
  int86(0x15,&regs,&regs); /* al */
  if ((regs.h.al&0x20)==0) return 255; else return 0;
}


/*-------------------------------------*/


      void keyconvert() {
	register unsigned int i;

	memjoybutton0 = 0x00;
	memjoybutton1 = 0x00;

	if (keyjoystick) {		/* read PC joystick? */
	  union REGS regs;
	   regs.h.ah=0x84;		/* Get the current position of the game controller */
	   regs.x.dx=0x0001;
	   int86(0x15,&regs,&regs);
	   memjoyx=(27*(regs.x.ax&0xFFFF));
	   memjoyy=(27*(regs.x.bx&0xFFFF));
	}
	else {				/* joystick emulation via numeric keypad */
	  i = keyboardjoyx();
	  if (i > 0x7fffffff) { memjoyx = 0x008; }
	  else {
	    if (i == 0)	{ memjoyx = 0x575; }
	    else	{ memjoyx = 0xb7c; }
	  }
	  i = keyboardjoyy();
	  if (i > 0x7fffffff) { memjoyy = 0x008; }
	  else {
	    if (i == 0)	{ memjoyy = 0x575; }
	    else	{ memjoyy = 0xb7c; }
	  }
	}

	i = keyboardjoyb();	/* open and close apple button will always work, even on an Apple][+ */
	if (i & 0xff00)		{ memjoybutton0 = memjoybutton0 | 0x80; }
	if (i & 0xff)		{ memjoybutton1 = memjoybutton1 | 0x80; }

	i = channelin(keyboard) & 0xffff;
	key	= (unsigned char)i;
	keyspec	= (unsigned char)(i >> 8);

	switch (key) {
	  case 0  :		/* no key pressed */
	    break;
	  case 28 :		/* function keys */
	    switch (keyspec) {
	      case 0x90 :	/* <Arrow-Left> */
		memkey = 0x88;
		break;
	      case 0x91 :	/* <Arrow-Right> */
		memkey = 0x95;
		break;
	      case 0x92 :	/* <Arrow-Up> */
		memkey = 0x8b;
		break;
	      case 0x93 :	/* <Arrow-Down> */
		memkey = 0x8a;
		break;
	      case 0xc2 :	/* <F2> */
		keyboardmenu();
		imageupdate();
		break;
	      case 0xc3 :	/* <F3> */
		virtmenu();
		imageupdate();
		break;
	      case 0xc4 :	/* <F4> */
		cpumenu();
		imageupdate();
		break;
	      case 0xc6 :	/* <F6> */
	        drivemenu();
	        imageupdate();
	        break;
	      case 0xc8 :	/* <F8> */
	        memorymenu();
	        if (appletype == 0) {
	          mainmenu();
	        }
	        imageupdate();
	        break;
		/* if (!nof8) prtsc(); */
		break;
	      case 0xc9 :	/* <F9> */
	        inidebugflag = 1;
		debugger(memram, sizeof(memram));
	        inidebugflag = 0;
		break;
	      case 0xca :	/* <F10> */
	        mainmenu();
	        imageupdate();
		break;
	    } /* switch (keyspec) */
	    break;
	  case 29 :		/* shift function keys */
	    switch (keyspec) {
	      case 0xc3 :	/* <Shift-F3> */
		virtsetmonochrome((virtgetmonochrome() + 1) & 0x3);
		break;
	      case 0xc4 :	/* <Shift-F4> */
		if (memjoybutton0 || memjoybutton1) { exitprogram = -1; }
		else {
		  if (cpugetlinecycle() == 65) {
		    cpusetlinecycle(65 * 8);
		    cpusetdelay(0);
		    drivefastmode = 0;
		    setmessage("Set CPU to fast mode");
		  }
		  else {
		    cpusetlinecycle(65);
		    cpusetdelay(inicpudelay);
		    drivefastmode = 0;
                    setmessage("Set CPU to 1 MHz");
		  }
		}
		break;
	      case 0xc8 :	/* <Shift-F8> */
		if (!(applestore("DAPPLE2.DAT"))) {
		  setmessage("Emulation state stored");
		}
	        break;
	    } /* switch (keyspec) */
	    break;
	  case 30 :		/* control function keys */
	    switch (keyspec) {
	      case 0xc3 :	/* <Ctrl-F3> */
		i = virtgetpalette();
		i++;
		if (i > 3) { i = 0; }
		virtsetpalette(i);
		break;
	      case 0xc4 :	/* <Ctrl-F4> */
		if (memjoybutton0 || memjoybutton1) { exitprogram = -1; }
		else {
		  if (cpugetstate() & STATEHALT) {
		    cpuclearstate(STATEHALT);
		  }
		  else {
		    cpusetstate(STATEHALT);
		  }
		}
		break;
	      case 0xc8 :	/* <Ctrl-F8> */
		if (!(applerestore("DAPPLE2.DAT"))) {
		  setmessage("Emulation state restored");
		}
		break;
	      case 0xca :	/* <Ctrl-F10> */
	      case 0xcc :	/* <Ctrl-F12> */
	        applereset();
		break;
	    } /* switch (keyspec) */
	    break;
	  case 31 :		/* shift control function keys */
	    switch (keyspec) {
	      case 0xc3 :	/* <Shift-Ctrl-F3> */
		virtsethresmode((virtgethresmode() + 1) & 0x1);
		break;
	    } /* switch (keyspec) */
	    break;
	  default :
	    if (key <= 0x7f) {
	      if (keycapslock) {
		if ( ((key >= 'A') && (key <= 'Z')) || ((key >= 'a') && (key <= 'z')) ) {
		  key = key ^ 0x20;
		}
	      }
	      if (keygerman) {
		if (key == 'Y') { key = 'Z'; }
		else {
		  if (key == 'y') { key = 'z'; }
		  else {
		    if (key == 'Z') { key = 'Y'; }
		    else {
		      if (key == 'z') { key = 'y'; }
		    }
		  }
		}
	      }
	      memkey = key | 0x80;
	    }
	} /* switch (key) */

      } /* keyconvert */


/*-------------------------------------*/


      void keyboardinit () {

	keycapslock = 1;
	keygerman   = 0;
	keyjoystick = 0;
	keyboardsetlayout(0);	/* USA */

      } /* keyboardinit */


/*-------------------------------------*/


      void keyboardmenu () {
	unsigned int screen;
	unsigned int keyboard;
	unsigned int window;
	unsigned char key;
	unsigned char update;

	screen = screenstore();
	if (!windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1, "Keyboard Options", &keyboard, &window)) {

	  update = 1;
	  do {
	    if (update) {
	      channelout(window, 12);		/* clear window */
	      stringwrite(window, "\r[ESC] - Quit\r\r");

	      stringwrite(window, "\r[C] - ");
//	      imagetickbox(window, keycapslock);
	      stringwrite(window, "Reverse Caps Lock: ");
	      if (keycapslock) {
	        stringwrite(window, "Yes");
	      }
	      else {
	        stringwrite(window, "No");
	      }

	      stringwrite(window, "\r[S] - Switch keys 'Y' and 'Z': ");
	      if (keygerman) {
	        stringwrite(window, "Yes");
	      }
	      else {
	        stringwrite(window, "No");
	      }
	      stringwrite(window, "\r\r      Keyboard Layout:");
	      stringwrite(window, "\r[U] - USA:     ");
	      channelout(window, keyboardgetlayout()==0 ? '*':' ');
	      stringwrite(window, "\r[G] - Germany: ");
	      channelout(window, keyboardgetlayout()==1 ? '*':' ');

	      stringwrite(window, "\r\r[J] - Joystick emulation: ");
	      if (keyjoystick) {
		stringwrite(window, "PC joystick");
	      }
	      else {
		stringwrite(window, "Numeric keypad");
	      }
	      update = 0;
	    }
	    do {
	      imageupdate();
	      key = (unsigned char)channelin(keyboard);
	    }
	    while ((key == 0) && (!exitprogram));
	    switch (key) {
	      case 'c' :
	      case 'C' :
	        keycapslock = !keycapslock;
	        update = 1;
	        break;
	      case 'g' :
	      case 'G' :
	        keyboardsetlayout(1);
	        update = 1;
	        break;
	      case 'j' :
	      case 'J' :
	        keyjoystick = !keyjoystick;
	        update = 1;
	        break;
	      case 's' :
	      case 'S' :
	        keygerman = !keygerman;
	        update = 1;
	        break;
	      case 'u' :
	      case 'U' :
	        keyboardsetlayout(0);
	        update = 1;
	        break;
	    } /* switch (key) */
	  }
	  while ((key != 27) && (key != 32) && (key != 13) && (!exitprogram));
	  channelclose(keyboard);
	  channelclose(window);
	}
	screenrestore(screen);

      } /* keyboardmenu */


/*-------------------------------------*/


      int strright (char *tgt, char *src) {
	int x = strlen(src);

	return !stringcomparec(&(tgt[strlen(tgt)-x]), src);
      } /* strright */


      void cwdxchgslash(unsigned char *stringptr, unsigned int value) {

	getcwd(stringptr, value);

	while (*stringptr) {
	  if (*stringptr == '/') {
	    *stringptr = '\\';
	  }
	  stringptr++;
	} /* while */
      } /* cwdxchgslash */


/* maximum number of filenames for fdialog(), 256+16 bytes each */
#define MFN 512
#define MAXROWS 24

typedef struct {char name[260]; int attr;} fnam;


      void filesort(fnam *fnames, unsigned int *fnamesptr, int attribute,
      		    unsigned int min, unsigned int max) {

	register int i;
	register int j;
	unsigned int temp;

/* stupid bubblesort algorithm */
	for (i=min+1; i <= max; i++) {
	  for (j=max; j >= i; j--) {
	    if (fnames[fnamesptr[j-1]].attr == attribute) {
	      if (fnames[fnamesptr[j]].attr == attribute) {
		if (stringcomparec( fnames[fnamesptr[j-1]].name, fnames[fnamesptr[j]].name) > 0) {
		  temp = fnamesptr[j-1];
		  fnamesptr[j-1] = fnamesptr[j];
		  fnamesptr[j] = temp;
		}
	      }
	      else {
		temp = fnamesptr[j-1];
		fnamesptr[j-1] = fnamesptr[j];
		fnamesptr[j] = temp;
	      }
	    }
	  } /* for j */
	} /* for i */

      } /* filesort */


      unsigned int fileselectmenu (unsigned int keyboard, unsigned int window,
			   unsigned char *title,
			   unsigned char *filename, unsigned char *tail,
			   unsigned char optnew) {

	unsigned char path[260];
	unsigned char oldpath[260];
	unsigned char filestring[260];
	unsigned int fileminnumber;
	unsigned int filenumber = 0;
	int cursor;
	int cursorx;
	int cursory;
	int columnstart = 0;
	int i;
	struct ffblk ffblk;

	fnam fnames[MFN];
	unsigned int fnamesptr[MFN];

	unsigned char key;
	unsigned char keyspec;
	unsigned char update;
	unsigned char reload;


	cwdxchgslash(oldpath, MAXPATH);
	cursor = 0;
	update = 1;
	reload = 1;

	do {
	  if (reload) {		/* do we have to load the filename array? */
	    cwdxchgslash(path, MAXPATH);			/* get current directory */

	    filenumber = 0;					/* add fix elements to array */
	    fileminnumber = 0;
	    if (optnew) {
	      strcpy(fnames[0].name,"(New File)");
	      fnames[0].attr = -1;
	      fnamesptr[0] = 0;
	      filenumber++;
	      fileminnumber++;
	    }
	    strcpy(fnames[filenumber].name,"(Select Drive)");
	    fnames[filenumber].attr = -1;
	    fnamesptr[filenumber] = filenumber;
	    filenumber++;
	    fileminnumber++;

	    i = findfirst("*.*", &ffblk, FA_DIREC);		/* put all filenames into array */
	    while ( (!i) && (filenumber < MFN) ) {
	      strcpy(fnames[filenumber].name, ffblk.ff_name);
	      fnames[filenumber].attr = (ffblk.ff_attrib & FA_DIREC) ? FA_DIREC : 0;	/* directory? */

	      if (!stringcomparec(tail,"._img_")) {		/* Custom mode for tail "._img_" */
		if ((fnames[filenumber].attr) || (strright(fnames[filenumber].name,".DSK"))
					      || (strright(fnames[filenumber].name,".IIE"))
					      || (strright(fnames[filenumber].name,".2MG"))
					      || (strright(fnames[filenumber].name,".DO"))
					      || (strright(fnames[filenumber].name,".PO"))
					      || (strright(fnames[filenumber].name,".NIB"))) {
					        fnamesptr[filenumber] = filenumber;
					        filenumber++;
		}
	      }
	      else {
	        if (!stringcomparec(tail,".*")) {
	          fnamesptr[filenumber] = filenumber;
	          filenumber++;
	        }
	        else {
		  if ((fnames[filenumber].attr) || (strright(fnames[filenumber].name, tail))) {
		    fnamesptr[filenumber] = filenumber;
		    filenumber++;
		  }
		}
	      }
	      i = findnext(&ffblk);
	    } /* while */

	    filesort(fnames, fnamesptr, FA_DIREC, fileminnumber, filenumber-1);
	    filesort(fnames, fnamesptr, 0, fileminnumber, filenumber-1);

	    cursor	= 0;			/* set to first entry in array */
	    columnstart	= 0;
	    reload	= 0;
	  }

	  if (update) {
	    channelout(window, 12);		/* clear window */

	    if (strlen(path) > ((WINDOWXSIZE/8)-4)) {		/* print current directory path */
	      path[(WINDOWXSIZE/8)-4] = 0;
	      imagesetcursor(window, 8, 22);
	    }
	    else {
	      imagesetcursor(window, (WINDOWXSIZE - (strlen(path) << 3)) >> 1, 22);
	    }
	    stringwrite(window, path);

	    imagefillbox(window, 0, 24, WINDOWXSIZE, 25, 0xffff00);
	    imagefillbox(window, 0, WINDOWYSIZE - 34, WINDOWXSIZE, WINDOWYSIZE - 35, 0xffff00);
	    imagefillbox(window, 0, WINDOWYSIZE - 23, WINDOWXSIZE, WINDOWYSIZE - 24, 0xffff00);

	    imagesetcursor(window, 12, WINDOWYSIZE-25);
	    stringwrite(window, title);
	    imagesetcursor(window, 4, WINDOWYSIZE-13);			/* print bottom message */
	    stringwrite(window, " Arrows move, <ENTER> selects, <ESC> exits\r");
	    stringwrite(window, " Folder names end in \"\\\". ");

	    i = columnstart;
	    cursorx = 8;
	    cursory = 35;
	    while ((i < filenumber) & (cursorx < WINDOWXSIZE)) {
	      imagesetcursor(window, cursorx, cursory);
	      if (i == cursor) {
	        imagesettextcolor(window, 0xffffff, 0x03050ff);
	        imagefillbox(window, cursorx, cursory-7, cursorx+(WINDOWXSIZE/3)-1, cursory, 0xffffff);
	      }
	      strcpy(filestring, fnames[fnamesptr[i]].name);
	      if (strlen(filestring) > ((WINDOWXSIZE/24))-1) {
	        filestring[(WINDOWXSIZE/24)-4] = ' ';
	        filestring[(WINDOWXSIZE/24)-3] = '.';
	        filestring[(WINDOWXSIZE/24)-2] = '.';
	        filestring[(WINDOWXSIZE/24)-1] = 0;
	      }
	      stringwrite(window, filestring);
	      if (fnames[fnamesptr[i]].attr == FA_DIREC) {	/* directory? */
	        channelout(window, '\\');
	      }
	      if (i == cursor) {
	        imagesettextcolor(window, 0x03050ff, 0xffffff);
	      }
	      cursory = cursory + 8;
	      if (cursory >= (MAXROWS*8) + 35) {
	        cursory = 35;
	        cursorx = cursorx + (WINDOWXSIZE/3);
	      }
	      i++;
	    } /* while */

	    update = 0;
	  } /* if (update) */

	  do {
	    imageupdate();
	    i = channelin(keyboard);
	    key = (unsigned char)(i & 0xff);
	    keyspec = (unsigned char) ((i >> 8) & 0xff);
	  }
	  while ((key ==0) && (!exitprogram));
	  switch (key) {
	    case 13 :
	      if (!stringcomparec(fnames[fnamesptr[cursor]].name, "(Select Drive)")) {
		imagesetcursor(window, 12, WINDOWYSIZE-25);
		imagefillbox(window, 0, WINDOWYSIZE-32, WINDOWXSIZE, WINDOWYSIZE-25, 0x03050ff);
		stringwrite(window, "Enter drive or <ENTER> to cancel: _");
		imageupdate();
		do {
		  key = (unsigned char)channelin(keyboard);
		}
		while ((key == 0) && (!exitprogram));
		if ((key >= 'a') && (key <= 'z')) {
		  setdisk(key - 'a');
		  reload = 1;
		}
		else {
		  if ((key >= 'A') && (key <= 'Z')) {
		    setdisk(key - 'A');
		    reload = 1;
		  }
		}
		key = 0;
		update = 1;
	      }
	      else {
		if (fnames[fnamesptr[cursor]].attr) {
		  chdir(fnames[fnamesptr[cursor]].name);
		  reload = 1;
		  update = 1;
		  key    = 0;
		}
		else {
		  strcpy(filename, path);
		  if (filename[strlen(filename)-1]!='\\')
		    { strcat(filename,"\\"); }
		  strcat(filename, fnames[fnamesptr[cursor]].name);
		}
	      }
	      break;
	    case 27 :
	    case 32 :
	      chdir(oldpath);
	      break;
	    case 28 :
	      switch (keyspec) {
		case 0x90 :		/* <Arrow-Left> */
		  if (cursor >= MAXROWS) {
		    cursor = cursor - MAXROWS;
		    if (cursor < columnstart) {
		      columnstart = columnstart - MAXROWS;
		      if (columnstart < 0) { columnstart = 0; }
		    }
		  }
		  update = 1;
		  break;
		case 0x91 :		/* <Arrow-Right> */
		  if ((cursor + MAXROWS) < filenumber) {
		    cursor = cursor + MAXROWS;
		    if (cursor >= (columnstart+3*MAXROWS)) {
		      columnstart = columnstart + MAXROWS;
		    }
		  }
		  update = 1;
		  break;
		case 0x92 :		/* <Arrow-Up> */
		  if (cursor > 0) {
		    cursor--;
		    if (cursor < columnstart) {
		      columnstart = columnstart - MAXROWS;
		      if (columnstart < 0) { columnstart = 0; }
		    }
		  }
		  update = 1;
		  break;
		case 0x93 :		/* <Arrow-Down> */
		  if (cursor < (filenumber-1)) {
		    cursor++;
		    if (cursor >= (columnstart+3*MAXROWS)) {
		      columnstart = columnstart + MAXROWS;
		    }
		  }
		  update = 1;
		  break;
	      } /* switch (keyspec) */
	  } /* switch (key) */

	}
	while ((key != 13) && (key != 27) && (key != 32) && (!exitprogram));
	return (key == 13);
      } /* fileselectmenu */


/*-------------------------------------*/


      void aboutmenu () {
	unsigned int screen;
	unsigned int keyboard;
	unsigned int window;
	unsigned char key;
	unsigned char update;

	screen = screenstore();
	if (!windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1, "About Dapple][ v" DappleVersion,
			  &keyboard, &window)) {

	  update = 1;
	  do {
	    if (update) {
	      channelout(window, 12);		/* clear window */
	      stringwrite(window, "\r[ESC] - Quit\r\r");

	      stringwrite(window, "Dapple ][ v" DappleVersion);
	      stringwrite(window, " was written by Steve Nickolas\r");
	      stringwrite(window, "with some small portions by Holger Picker.\r");
	      stringwrite(window, "Please send any comments, suggestions, bug reports to\r");
	      stringwrite(window, "<steve@dosius.zzn.com>. For latest updates visit\r");
/* I'd like to say dapple.sourceforge.net, but I can't update it right now
   since I don't have access to an "ssh" program and can't log in to the
   server any other way. -uso. */
              stringwrite(window, "the homepage at <http://sourceforge.net/projects/dapple/>\r\r");
	      stringwrite(window, "Thanks to (in alphabetical order):\r");
              stringwrite(window, "Scott Alfter, David Empson, Andrew Gregory,\r");
              stringwrite(window, "Scott Hemphill, Robert Munafo, Paul R. Santa-Maria.\r");
	      stringwrite(window, "\rDuring emulation you can use the following function keys:\r\r");
              stringwrite(window, "<F2>       : Keyboard options\r");
              stringwrite(window, "<F3>       : Video options\r");
              stringwrite(window, "<Shift-F3> : Toggle color/monochrome mode\r");
              stringwrite(window, "<Ctrl-F3>  : Toggle color palette\r");
              stringwrite(window, "<F4>       : CPU options\r");
              stringwrite(window, "<Shift-F4> : Toggle CPU fast/1 Mhz mode\r");
              stringwrite(window, "<Ctrl-F4>  : Toggle pause on/off\r");
              stringwrite(window, "<F6>       : Disk options\r");
              stringwrite(window, "<F8>       : Memory options\r");
              stringwrite(window, "<Shift-F8> : Quicksave emulation state\r");
              stringwrite(window, "<Ctrl-F8>  : Quickload emulation state\r");
              stringwrite(window, "<F9>       : Debugger\r");
              stringwrite(window, "<F10>      : Main menu\r");
              stringwrite(window, "<Ctrl-F10> : Reset\r");

	      update = 0;
	    }
	    do {
	      imageupdate();
	      key = (unsigned char)channelin(keyboard);
	    }
	    while ((key == 0) && (!exitprogram));
	  }
	  while ((key != 27) && (key != 32) && (key != 13) && (!exitprogram));
	  channelclose(keyboard);
	  channelclose(window);
	}
	screenrestore(screen);

      } /* keyboardmenu */


/*-------------------------------------*/


      void mainmenu () {
	unsigned int screen;
	unsigned int keyboard;
	unsigned int window;
	unsigned char key;
	unsigned char update;
	unsigned char menu;

	do {
	  screen = screenstore();
	  if (windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1, "Dapple ][ Menu", &keyboard, &window)) {
	    menu = 1;
	    exitprogram = 1;
	  }
	  else {
	    menu   = 0;
	    update = 1;
	    do {
	      if (update) {
	        channelout(window, 12);		/* clear window */
	        imagesettextattribute(window, IMAGEBOLD);
	        channelout(window, 13);
		stringwritecenterx(window, "Dapple ][ v" DappleVersion);
		channelout(window, 13);
	        stringwritecenterx(window, "(C) 2002, 2003 Dapple ][ Development Team");
	        channelout(window, 13);
	        imagesettextattribute(window, 0);

	        stringwrite(window, "\r\r[ESC] - Resume emulation\r");

		stringwrite(window, "\r[A] - About Dapple ][");
		stringwrite(window, "\r[C] - CPU options");
	        stringwrite(window, "\r[D] - Drive options");
	        stringwrite(window, "\r[K] - Keyboard Options");
	        stringwrite(window, "\r[M] - Memory Options");
	        stringwrite(window, "\r[N] - Sound Options");
	        stringwrite(window, "\r[V] - Video Options");
	        stringwrite(window, "\r[Q] - Quit to DOS");
	        update = 0;
	      }
	      do {
	        imageupdate();
	        key = (unsigned char)channelin(keyboard);
	      }
	      while (key == 0);
	      switch (key) {
	        case 13 :
	        case 27 :
	        case 32 :
	          if (appletype == 0) {
                    stringwrite(window, "\r\rSorry, no Apple ROMs have been loaded yet.");
	            stringwrite(window, "\rPress a key to continue.");
	            do {
	              imageupdate();
	              key = (unsigned char)channelin(keyboard);
	            }
	            while ((key == 0) && (!exitprogram));
	            update = 1;
	          }
	          else {
	            menu = 1;
	          }
	          break;
	        case 'a' :
	        case 'A' :
	          menu = 2;
	          break;
	        case 'c' :
	        case 'C' :
	          menu = 3;
	          break;
	        case 'd' :
	        case 'D' :
	          menu = 4;
	          break;
	        case 'k' :
	        case 'K' :
	          menu = 5;
	          break;
	        case 'm' :
	        case 'M' :
	          menu = 6;
	          break;
	        case 'n' :
	        case 'N' :
	          menu = 7;
	          break;
	        case 'v' :
	        case 'V' :
	          menu = 8;
	          break;
	        case 'q' :
	        case 'Q' :
	          stringwrite(window, "\r\rQuit to DOS: Are you sure? (y/n)");
		  do {
	            imageupdate();
		    key = (unsigned char)channelin(keyboard);
		  }
		  while ((key == 0) && (!exitprogram));
		  if ((key == 'y') || (key == 'Y') || (exitprogram)) {
		    menu = 1;
		    exitprogram = 1;
		  }
		  else {
		    update = 1;
		  }
		  key = 0;
	          break;
	      } /* switch (key) */
	    }
	    while (menu == 0);
	    channelclose(keyboard);
	    channelclose(window);
	  }
	  screenrestore(screen);
	  switch (menu) {
	    case 2 :
	      aboutmenu();
	      break;
	    case 3 :
	      cpumenu();
	      break;
	    case 4 :
	      drivemenu();
	      break;
	    case 5 :
	      keyboardmenu();
	      break;
	    case 6 :
	      memorymenu();
	      break;
	    case 7 :
	      soundmenu();
	      break;
	    case 8 :
	      virtmenu();
	      break;
	  } /* switch (menu) */
	} while (menu != 1);

      } /* mainmenu */


/*-------------------------------------*/


      int main () {
	unsigned int keyprotocol;
	unsigned int winprotocol;

/* prevent ^C from killing us -uso. (2002.0130) */
//      signal (SIGINT, SIG_IGN); (sometimes GPFs? -uso.)
#ifndef NOGRABBREAK
	_go32_want_ctrl_break(0);
	 __djgpp_set_ctrl_c(0);
#endif

/* initialize global variables */
	keyboard	= 0;
	window		= 0;
	cwdxchgslash(callingpath, 260);		/* store original directory at calling Dapple */

/* initialize asm library */
	asmopen();

/* set resolution */
	if (screensetresolution(640,400,8)) {
	  if (screensetresolution(640,480,8)) {
	    if (screensetresolution(800,600,8)) {
	      if (screensetresolution(1024,768,8)) {
	        goto endofprogram2;
	      }
	    }
	  }
	}

/* open emulation window */
	if (windowaddio( -1, -1, 640, 400, 0, 0, NULL, &keyboard, &window)) { goto endofprogram2; }
	imagefillbox(window, 0, 0, 640, 400, 0x000000);

	if (windowaddio( -1, -1, 544, 304, -1, 1, "Protocol", &keyprotocol, &winprotocol)) { goto endofprogram; }

	stringwrite(winprotocol, "Welcome to Dapple ][ v" DappleVersion "\r");
	stringwrite(winprotocol, "==========================\r\r");
        if (find_ramworks())
         stringwrite(winprotocol, "This version features 3MB RAM emulation\r");
	imageupdate();

	messagecount = 0;
	messageflag = 0;

/* initialize default values */

	strcpy(inidiskpath1, "");
	strcpy(inidiskpath2, "");
	inicpudelay	= 0x120;
	inidebugflag	= 0;

/* initialize emulator */

	cpuinit();
	memoryinit();
	keyboardinit();
	soundinit();
	virtinit();
	driveinit();
	llinit();

/* get default values from file */

	readini();

/* automatic search for rom file */

	memoryautoloadrom(keyprotocol, winprotocol);

	if (inidiskpath1[0]) {
	  driveload(&drivedisk1, inidiskpath1);
	}
	if (inidiskpath2[0]) {
	  driveload(&drivedisk2, inidiskpath2);
	}
	channelclose(keyprotocol);
	channelclose(winprotocol);

	imagefillbox(window, 40, 8, 559 + 40, 391, 0x000000);
	messageflag = 1;	/* allow messages */
        if (find_ramworks())
         setmessage("Welcome to Dapple ][ (with RAM Works emulation)");
        else
         setmessage("Welcome to Dapple ][");
	cpusetdelay(inicpudelay);
	mainmenu();
	if (!exitprogram) {
	  cpurun();
	}

	exitprogram = 0;
	strcpy(inidiskpath1, drivedisk1.path);
	strcpy(inidiskpath2, drivedisk2.path);
	driveeject(&drivedisk1);
	driveeject(&drivedisk2);

	chdir(callingpath);			/* restore original directory at calling Dapple */
	writeini();

endofprogram:
	channelclose(window);
	channelclose(keyboard);

endofprogram2:
	asmclose();

	return 0;

      } /* main */
