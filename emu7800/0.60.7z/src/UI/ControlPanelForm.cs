/*
 * ControlPanelForm.cs
 * 
 * The main user interface form.
 * 
 * Copyright (c) 2003, 2004 Mike Murphy
 * 
 */
using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace EMU7800 {

public class ControlPanelForm : Form {
	private GameSettings currGameSettings;
	public GameSettings CurrGameSettings {
		get {
			if (currGameSettings == null) {
				currGameSettings = new GameSettings(null);
			}
			return currGameSettings;
		}
		set {
			if (value == null) {
				return;
			}

			StringBuilder s = new StringBuilder();
			GameSettings gs = value;
			if (gs.Title != null && gs.Title.Trim().Length > 0) {
				s.AppendFormat("{0}, {1}", gs.Title, gs.MachineType);
				if (gs.Manufacturer != null && gs.Manufacturer.Trim().Length > 0) {
					s.AppendFormat(", {0}", gs.Manufacturer);
				}
				if (gs.Year != null && gs.Year.Trim().Length > 0) {
					s.AppendFormat(", {0}", gs.Year);
				}
			}
			tpGameSelect.SetGameTitleLabel(s.ToString());
			currGameSettings = gs;
		}
	}

	public bool StartButtonEnabled {
		set {
			btnStart.Enabled = value && CurrGameSettings != null;
		}
	}

	public bool ResumeButtonEnabled {
		set {
			btnResume.Enabled = value && EMU7800App.Instance.M != null;
		}
	}

	private TabControl tabControl;
	private GameSelectPage tpGameSelect;
	private SettingsPage tpSettings;
	private GreenScreenPage tpGreenScreen;
	private Panel panel1, panel2;
	private Button btnStart, btnResume, btnQuit;
	
	public ControlPanelForm() {
		Icon = new Icon(Assembly.GetExecutingAssembly()
				.GetManifestResourceStream("EMU7800.Icon1.ico"));
		Text = EMU7800App.Title + " v" + EMU7800App.Version + " Control Panel";
		MinimumSize = new Size(340, 440);
		ClientSize = EMU7800App.Instance.Settings.ControlPanelFormSize;
		MinimizeBox = true;
		MaximizeBox = false;
		ShowInTaskbar = false;
		TopMost = true;
		StartPosition = FormStartPosition.CenterScreen;
		SizeGripStyle = SizeGripStyle.Show;

		panel1 = new Panel();
		panel2 = new Panel();
		Controls.Add(panel1);
		Controls.Add(panel2);

		tabControl = new TabControl();
		panel1.Controls.Add(tabControl);
   
 		Size button_size = new Size(70, 25);

		btnStart = new Button();
		int x = 0;
		btnStart.Location = new Point(x, 0);
		btnStart.Size = button_size;
		btnStart.TabIndex = 0;
		btnStart.Text = "Start";
		btnStart.Enabled = false;
		btnStart.Click += new EventHandler(OnClickStart);
		btnStart.Click += new EventHandler(SaveGlobalSettings);

		btnResume = new Button();
		x += btnStart.Size.Width + 5;
		btnResume.Location = new Point(x, 0);
		btnResume.Size = button_size;
		btnResume.TabIndex = 1;
		btnResume.Text = "Resume";
		btnResume.Enabled = false;
		btnResume.Click += new EventHandler(OnClickResume);
		btnResume.Click += new EventHandler(SaveGlobalSettings);

		btnQuit = new Button();
		x += btnResume.Size.Width + 5;
		btnQuit.Location = new Point(x, 0);
		btnQuit.Size = button_size;
		btnQuit.TabIndex = 2;
		btnQuit.Text = "Quit";
		btnQuit.Click += new EventHandler(OnClickQuit);
		btnQuit.Click += new EventHandler(SaveGlobalSettings);
		
		panel2.Controls.AddRange(new Control[] {btnStart, btnResume, btnQuit});
		
		tpGameSelect = new GameSelectPage(this);
		tpSettings = new SettingsPage(this);
		tpGreenScreen = new GreenScreenPage(this);
		
		tabControl.Controls.AddRange(new Control[] {tpGameSelect, tpSettings, tpGreenScreen});
		tabControl.SelectedIndexChanged += new EventHandler(SaveGlobalSettings);

		Layout += new LayoutEventHandler(OnLayout);
		Closing += new CancelEventHandler(OnClosing);
	}

	private void OnClosing(object sender, CancelEventArgs e) {
		EMU7800App.Instance.Settings.Serialize();
		e.Cancel = true;
		Hide();
	}

	public void OnClickStart(object sender, EventArgs e) {
		StartButtonEnabled = false;
		Hide();
		try {
			EMU7800App.Instance.RunMachine(CurrGameSettings);
		} catch (Exception ex) {
			MessageBox.Show(ex.Message, "Machine Error",
				MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			Log.Msg("{0}\n{1}\n", ex.Message, ex.StackTrace);
		}
		Show();
		StartButtonEnabled = true;
		ResumeButtonEnabled = true;
	}

	public void OnClickResume(object sender, EventArgs e) {
		ResumeButtonEnabled = false;
		Hide();
		try {
			EMU7800App.Instance.RunMachine();
		} catch (Exception ex) {
			MessageBox.Show(ex.Message, "Host Error",
				MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			Log.Msg("{0}\n{1}\n", ex.Message, ex.StackTrace);
		}
		Show();
		StartButtonEnabled = true;
		ResumeButtonEnabled = true;
	}
	
	public void OnClickQuit(object sender, EventArgs e) {
		Application.Exit();
	}

	private void SaveGlobalSettings(object sender, EventArgs e) {
		EMU7800App.Instance.Settings.Serialize();
	}

	private void OnLayout(object sender, LayoutEventArgs e) {
		panel1.Location = new Point(0, 0);
		panel1.Size = new Size(Size.Width - 10, Size.Height - 70);

		tabControl.Location = new Point(0, 0);
		tabControl.Size = panel1.Size;

		panel2.Location = new Point(0, Size.Height - 65);
		panel2.Size = new Size(Size.Width - 25, 55);

		EMU7800App.Instance.Settings.ControlPanelFormSize = ClientSize;
	}
}
}