
#include <stdio.h>
#include "DirectXVideoOutputDevice.h"
#include "DirectInputDevice.h"
#include "DirectInputSignal.h"

extern DirectXVideoOutputDevice* currentDevice;

const INT32 DirectInputDevice::PLAYER_ONE_ID_START       = 1000;
const INT32 DirectInputDevice::PLAYER_ONE_NORTH          = PLAYER_ONE_ID_START + 0;
const INT32 DirectInputDevice::PLAYER_ONE_NORTHEAST      = PLAYER_ONE_ID_START + 1;
const INT32 DirectInputDevice::PLAYER_ONE_EAST           = PLAYER_ONE_ID_START + 2;
const INT32 DirectInputDevice::PLAYER_ONE_SOUTHEAST      = PLAYER_ONE_ID_START + 3;
const INT32 DirectInputDevice::PLAYER_ONE_SOUTH          = PLAYER_ONE_ID_START + 4;
const INT32 DirectInputDevice::PLAYER_ONE_SOUTHWEST      = PLAYER_ONE_ID_START + 5;
const INT32 DirectInputDevice::PLAYER_ONE_WEST           = PLAYER_ONE_ID_START + 6;
const INT32 DirectInputDevice::PLAYER_ONE_NORTHWEST      = PLAYER_ONE_ID_START + 7;
const INT32 DirectInputDevice::PLAYER_ONE_BUTTON_ONE     = PLAYER_ONE_ID_START + 8;
const INT32 DirectInputDevice::PLAYER_ONE_BUTTON_TWO     = PLAYER_ONE_ID_START + 9;
const INT32 DirectInputDevice::PLAYER_ONE_BUTTON_THREE   = PLAYER_ONE_ID_START + 10;
const INT32 DirectInputDevice::PLAYER_ONE_BUTTON_FOUR    = PLAYER_ONE_ID_START + 11;
const INT32 DirectInputDevice::PLAYER_ONE_BUTTON_FIVE    = PLAYER_ONE_ID_START + 12;
const INT32 DirectInputDevice::PLAYER_ONE_BUTTON_SIX     = PLAYER_ONE_ID_START + 13;
const INT32 DirectInputDevice::PLAYER_ONE_KEYPAD_ONE     = PLAYER_ONE_ID_START + 14;
const INT32 DirectInputDevice::PLAYER_ONE_KEYPAD_TWO     = PLAYER_ONE_ID_START + 15;
const INT32 DirectInputDevice::PLAYER_ONE_KEYPAD_THREE   = PLAYER_ONE_ID_START + 16;
const INT32 DirectInputDevice::PLAYER_ONE_KEYPAD_FOUR    = PLAYER_ONE_ID_START + 17;
const INT32 DirectInputDevice::PLAYER_ONE_KEYPAD_FIVE    = PLAYER_ONE_ID_START + 18;
const INT32 DirectInputDevice::PLAYER_ONE_KEYPAD_SIX     = PLAYER_ONE_ID_START + 19;
const INT32 DirectInputDevice::PLAYER_ONE_KEYPAD_SEVEN   = PLAYER_ONE_ID_START + 20;
const INT32 DirectInputDevice::PLAYER_ONE_KEYPAD_EIGHT   = PLAYER_ONE_ID_START + 21;
const INT32 DirectInputDevice::PLAYER_ONE_KEYPAD_NINE    = PLAYER_ONE_ID_START + 22;
const INT32 DirectInputDevice::PLAYER_ONE_KEYPAD_ZERO    = PLAYER_ONE_ID_START + 23;
const INT32 DirectInputDevice::PLAYER_ONE_KEYPAD_DELETE  = PLAYER_ONE_ID_START + 24;
const INT32 DirectInputDevice::PLAYER_ONE_KEYPAD_ENTER   = PLAYER_ONE_ID_START + 25;
const INT32 DirectInputDevice::PLAYER_ONE_KEYPAD_ASTERIX = PLAYER_ONE_ID_START + 26;
const INT32 DirectInputDevice::PLAYER_ONE_KEYPAD_POUND   = PLAYER_ONE_ID_START + 27;
const INT32 DirectInputDevice::PLAYER_ONE_ID_END         = PLAYER_ONE_KEYPAD_POUND;

const INT32 DirectInputDevice::PLAYER_TWO_ID_START       = 2000;
const INT32 DirectInputDevice::PLAYER_TWO_NORTH          = PLAYER_TWO_ID_START + 0;
const INT32 DirectInputDevice::PLAYER_TWO_NORTHEAST      = PLAYER_TWO_ID_START + 1;
const INT32 DirectInputDevice::PLAYER_TWO_EAST           = PLAYER_TWO_ID_START + 2;
const INT32 DirectInputDevice::PLAYER_TWO_SOUTHEAST      = PLAYER_TWO_ID_START + 3;
const INT32 DirectInputDevice::PLAYER_TWO_SOUTH          = PLAYER_TWO_ID_START + 4;
const INT32 DirectInputDevice::PLAYER_TWO_SOUTHWEST      = PLAYER_TWO_ID_START + 5;
const INT32 DirectInputDevice::PLAYER_TWO_WEST           = PLAYER_TWO_ID_START + 6;
const INT32 DirectInputDevice::PLAYER_TWO_NORTHWEST      = PLAYER_TWO_ID_START + 7;
const INT32 DirectInputDevice::PLAYER_TWO_BUTTON_ONE     = PLAYER_TWO_ID_START + 8;
const INT32 DirectInputDevice::PLAYER_TWO_BUTTON_TWO     = PLAYER_TWO_ID_START + 9;
const INT32 DirectInputDevice::PLAYER_TWO_BUTTON_THREE   = PLAYER_TWO_ID_START + 10;
const INT32 DirectInputDevice::PLAYER_TWO_BUTTON_FOUR    = PLAYER_TWO_ID_START + 11;
const INT32 DirectInputDevice::PLAYER_TWO_BUTTON_FIVE    = PLAYER_TWO_ID_START + 12;
const INT32 DirectInputDevice::PLAYER_TWO_BUTTON_SIX     = PLAYER_TWO_ID_START + 13;
const INT32 DirectInputDevice::PLAYER_TWO_KEYPAD_ONE     = PLAYER_TWO_ID_START + 14;
const INT32 DirectInputDevice::PLAYER_TWO_KEYPAD_TWO     = PLAYER_TWO_ID_START + 15;
const INT32 DirectInputDevice::PLAYER_TWO_KEYPAD_THREE   = PLAYER_TWO_ID_START + 16;
const INT32 DirectInputDevice::PLAYER_TWO_KEYPAD_FOUR    = PLAYER_TWO_ID_START + 17;
const INT32 DirectInputDevice::PLAYER_TWO_KEYPAD_FIVE    = PLAYER_TWO_ID_START + 18;
const INT32 DirectInputDevice::PLAYER_TWO_KEYPAD_SIX     = PLAYER_TWO_ID_START + 19;
const INT32 DirectInputDevice::PLAYER_TWO_KEYPAD_SEVEN   = PLAYER_TWO_ID_START + 20;
const INT32 DirectInputDevice::PLAYER_TWO_KEYPAD_EIGHT   = PLAYER_TWO_ID_START + 21;
const INT32 DirectInputDevice::PLAYER_TWO_KEYPAD_NINE    = PLAYER_TWO_ID_START + 22;
const INT32 DirectInputDevice::PLAYER_TWO_KEYPAD_ZERO    = PLAYER_TWO_ID_START + 23;
const INT32 DirectInputDevice::PLAYER_TWO_KEYPAD_DELETE  = PLAYER_TWO_ID_START + 24;
const INT32 DirectInputDevice::PLAYER_TWO_KEYPAD_ENTER   = PLAYER_TWO_ID_START + 25;
const INT32 DirectInputDevice::PLAYER_TWO_KEYPAD_ASTERIX = PLAYER_TWO_ID_START + 26;
const INT32 DirectInputDevice::PLAYER_TWO_KEYPAD_POUND   = PLAYER_TWO_ID_START + 27;
const INT32 DirectInputDevice::PLAYER_TWO_ID_END         = PLAYER_TWO_KEYPAD_POUND;

const INT32 DirectInputDevice::KEYBOARD_ID_START = 5000;
const INT32 DirectInputDevice::KEYBOARD_A = KEYBOARD_ID_START + 0;
const INT32 DirectInputDevice::KEYBOARD_B = KEYBOARD_ID_START + 1;
const INT32 DirectInputDevice::KEYBOARD_C = KEYBOARD_ID_START + 2;
const INT32 DirectInputDevice::KEYBOARD_D = KEYBOARD_ID_START + 3;
const INT32 DirectInputDevice::KEYBOARD_E = KEYBOARD_ID_START + 4;
const INT32 DirectInputDevice::KEYBOARD_F = KEYBOARD_ID_START + 5;
const INT32 DirectInputDevice::KEYBOARD_G = KEYBOARD_ID_START + 6;
const INT32 DirectInputDevice::KEYBOARD_H = KEYBOARD_ID_START + 7;
const INT32 DirectInputDevice::KEYBOARD_I = KEYBOARD_ID_START + 8;
const INT32 DirectInputDevice::KEYBOARD_J = KEYBOARD_ID_START + 9;
const INT32 DirectInputDevice::KEYBOARD_K = KEYBOARD_ID_START + 10;
const INT32 DirectInputDevice::KEYBOARD_L = KEYBOARD_ID_START + 11;
const INT32 DirectInputDevice::KEYBOARD_M = KEYBOARD_ID_START + 12;
const INT32 DirectInputDevice::KEYBOARD_N = KEYBOARD_ID_START + 13;
const INT32 DirectInputDevice::KEYBOARD_O = KEYBOARD_ID_START + 14;
const INT32 DirectInputDevice::KEYBOARD_P = KEYBOARD_ID_START + 15;
const INT32 DirectInputDevice::KEYBOARD_Q = KEYBOARD_ID_START + 16;
const INT32 DirectInputDevice::KEYBOARD_R = KEYBOARD_ID_START + 17;
const INT32 DirectInputDevice::KEYBOARD_S = KEYBOARD_ID_START + 18;
const INT32 DirectInputDevice::KEYBOARD_T = KEYBOARD_ID_START + 19;
const INT32 DirectInputDevice::KEYBOARD_U = KEYBOARD_ID_START + 20;
const INT32 DirectInputDevice::KEYBOARD_V = KEYBOARD_ID_START + 21;
const INT32 DirectInputDevice::KEYBOARD_W = KEYBOARD_ID_START + 22;
const INT32 DirectInputDevice::KEYBOARD_X = KEYBOARD_ID_START + 23;
const INT32 DirectInputDevice::KEYBOARD_Y = KEYBOARD_ID_START + 24;
const INT32 DirectInputDevice::KEYBOARD_Z = KEYBOARD_ID_START + 25;

const INT32 DirectInputDevice::KEYBOARD_0 = KEYBOARD_ID_START + 26;
const INT32 DirectInputDevice::KEYBOARD_1 = KEYBOARD_ID_START + 27;
const INT32 DirectInputDevice::KEYBOARD_2 = KEYBOARD_ID_START + 28;
const INT32 DirectInputDevice::KEYBOARD_3 = KEYBOARD_ID_START + 29;
const INT32 DirectInputDevice::KEYBOARD_4 = KEYBOARD_ID_START + 30;
const INT32 DirectInputDevice::KEYBOARD_5 = KEYBOARD_ID_START + 31;
const INT32 DirectInputDevice::KEYBOARD_6 = KEYBOARD_ID_START + 32;
const INT32 DirectInputDevice::KEYBOARD_7 = KEYBOARD_ID_START + 33;
const INT32 DirectInputDevice::KEYBOARD_8 = KEYBOARD_ID_START + 34;
const INT32 DirectInputDevice::KEYBOARD_9 = KEYBOARD_ID_START + 35;

const INT32 DirectInputDevice::KEYBOARD_UP        = KEYBOARD_ID_START + 36;
const INT32 DirectInputDevice::KEYBOARD_DOWN      = KEYBOARD_ID_START + 37;
const INT32 DirectInputDevice::KEYBOARD_LEFT      = KEYBOARD_ID_START + 38;
const INT32 DirectInputDevice::KEYBOARD_RIGHT     = KEYBOARD_ID_START + 39;

const INT32 DirectInputDevice::KEYBOARD_COMMA     = KEYBOARD_ID_START + 40;
const INT32 DirectInputDevice::KEYBOARD_PERIOD    = KEYBOARD_ID_START + 41;
const INT32 DirectInputDevice::KEYBOARD_SPACE     = KEYBOARD_ID_START + 42;
const INT32 DirectInputDevice::KEYBOARD_SEMICOLON = KEYBOARD_ID_START + 43;
const INT32 DirectInputDevice::KEYBOARD_COLON     = KEYBOARD_ID_START + 44;
const INT32 DirectInputDevice::KEYBOARD_ESCAPE    = KEYBOARD_ID_START + 45;
const INT32 DirectInputDevice::KEYBOARD_ENTER     = KEYBOARD_ID_START + 46;
const INT32 DirectInputDevice::KEYBOARD_CONTROL   = KEYBOARD_ID_START + 47;
const INT32 DirectInputDevice::KEYBOARD_SHIFT     = KEYBOARD_ID_START + 48;
const INT32 DirectInputDevice::KEYBOARD_ID_END    = KEYBOARD_SHIFT;

const INT32 DirectInputDevice::MENU_ID_START = 6000;
const INT32 DirectInputDevice::MENU_DISPLAY  = MENU_ID_START + 0;
const INT32 DirectInputDevice::MENU_UP       = MENU_ID_START + 1;
const INT32 DirectInputDevice::MENU_DOWN     = MENU_ID_START + 2;
const INT32 DirectInputDevice::MENU_SELECT   = MENU_ID_START + 3;
const INT32 DirectInputDevice::MENU_ID_END   = MENU_SELECT;

const INT32 DirectInputDevice::EMULATOR_ID_START   = 7000;
const INT32 DirectInputDevice::EMULATOR_PAUSE      = EMULATOR_ID_START + 0;
const INT32 DirectInputDevice::EMULATOR_SAVE       = EMULATOR_ID_START + 1;
const INT32 DirectInputDevice::EMULATOR_LOAD       = EMULATOR_ID_START + 2;
const INT32 DirectInputDevice::EMULATOR_RESET      = EMULATOR_ID_START + 3;
const INT32 DirectInputDevice::EMULATOR_SCREENSHOT = EMULATOR_ID_START + 4;
const INT32 DirectInputDevice::EMULATOR_ID_END     = EMULATOR_SCREENSHOT;

const CHAR* inputErrorMessages[3] = {
    "Failed to create a DirectInput object",
    "Failed to create the DirectInput keyboard object",
    "Failed to set the keyboard format",
};


char* g_lpszPOVDescriptions[4] = {
    "Up", "Right", "Down", "Left"
};

ULONG DEFAULT_KEYS_PLAYER_ONE[28] = {
        DIK_UP, 0, DIK_RIGHT, 0, DIK_DOWN, 0, DIK_LEFT, 0,
        DIK_LCONTROL, DIK_Z, DIK_X, 0, 0, 0,
        DIK_1, DIK_2, DIK_3, DIK_4, DIK_5, DIK_6, DIK_7, DIK_8, DIK_9,
        DIK_0, DIK_DELETE, DIK_RETURN, DIK_MULTIPLY, DIK_ADD
};

ULONG DEFAULT_KEYS_PLAYER_TWO[28] = {
    DIK_LBRACKET, 0, DIK_RBRACKET, 0, DIK_BACKSLASH, 0,
    DIK_APOSTROPHE, 0, DIK_RCONTROL, DIK_PERIOD, DIK_BACKSLASH, 0, 0,
    0,
    DIK_Q, DIK_W, DIK_E, DIK_R, DIK_T, DIK_Y, DIK_U, DIK_I, DIK_O, DIK_P,
    DIK_K, DIK_L, DIK_COMMA, DIK_M,
};

ULONG DEFAULT_KEYS_KEYBOARD[49] = {
    DIK_A, DIK_B, DIK_C, DIK_D, DIK_E, DIK_F, DIK_G, DIK_H, DIK_I, DIK_J,
    DIK_K, DIK_L, DIK_M, DIK_N, DIK_O, DIK_P, DIK_Q, DIK_R, DIK_S, DIK_T,
    DIK_U, DIK_V, DIK_W, DIK_X, DIK_Y, DIK_Z, DIK_0, DIK_1, DIK_2, DIK_3,
    DIK_4, DIK_5, DIK_6, DIK_7, DIK_8, DIK_9, DIK_UP, DIK_DOWN, DIK_LEFT,
    DIK_RIGHT, DIK_COMMA, DIK_PERIOD, DIK_SPACE, DIK_SEMICOLON, DIK_COLON,
    DIK_GRAVE, DIK_RETURN, DIK_LCONTROL, DIK_LSHIFT,
};

ULONG DEFAULT_KEYS_EMULATOR[5] = {
    DIK_F1, DIK_F5, DIK_F6, DIK_F9, DIK_F12
};

DirectInputSignal* DEFAULT_INPUT_SIGNALS_PLAYER_ONE[28];
DirectInputSignal* DEFAULT_INPUT_SIGNALS_PLAYER_TWO[28];
DirectInputSignal* DEFAULT_INPUT_SIGNALS_KEYBOARD[49];
DirectInputSignal* DEFAULT_INPUT_SIGNALS_EMULATOR[5];

DirectInputDevice::DirectInputDevice()
{
    m_pDI = NULL;
    m_pdiKeyboard = NULL;
    m_iJoystickCount = 0;
    for(int x=0; x<10; x++)
		m_pdiJoysticks[x] = NULL;

    m_bLastPollSuccessful = FALSE;

    if(!initDirectInput())  // If no problems
    {
        //initialize the default player one input signals
		for (INT32 i = 0; i < 28; i++) {
			if (DEFAULT_KEYS_PLAYER_ONE[i] == 0) {
				DEFAULT_INPUT_SIGNALS_PLAYER_ONE[i] = NULL;
				continue;
			}
    
			DEFAULT_INPUT_SIGNALS_PLAYER_ONE[i] = createKeyboardSignal(
			        DEFAULT_KEYS_PLAYER_ONE[i]);
		}

        //initialize the player two input signals
        for (i = 0; i < 28; i++) {
            if (DEFAULT_KEYS_PLAYER_TWO[i] == 0) {
                DEFAULT_INPUT_SIGNALS_PLAYER_TWO[i] = NULL;
                continue;
            }

			DEFAULT_INPUT_SIGNALS_PLAYER_TWO[i] = createKeyboardSignal(
			        DEFAULT_KEYS_PLAYER_TWO[i]);
        }

        //initialize the ecs keyboard input signals
        for (i = 0; i < 49; i++) {
            if (DEFAULT_KEYS_KEYBOARD[i] == 0) {
                DEFAULT_INPUT_SIGNALS_KEYBOARD[i] = NULL;
                continue;
            }

			DEFAULT_INPUT_SIGNALS_KEYBOARD[i] = createKeyboardSignal(
			        DEFAULT_KEYS_KEYBOARD[i]);
        }

        //initialize the control input signals
        for (i = 0; i < 5; i++) {
            if (DEFAULT_KEYS_EMULATOR[i] == 0) {
                DEFAULT_INPUT_SIGNALS_EMULATOR[i] = NULL;
                continue;
            }

			DEFAULT_INPUT_SIGNALS_EMULATOR[i] = createKeyboardSignal(
			        DEFAULT_KEYS_EMULATOR[i]);
        }
    }


	releaseDirectInput();
}

DirectInputDevice::~DirectInputDevice()
{}

DirectInputSignal* DirectInputDevice::createKeyboardSignal(ULONG keyID)
{
    DIPROPSTRING propString;
    propString.diph.dwSize = sizeof(DIPROPSTRING);
    propString.diph.dwHeaderSize = sizeof(DIPROPHEADER);
    propString.diph.dwHow = DIPH_BYOFFSET;
    propString.diph.dwObj = (ULONG)keyID;
    m_pdiKeyboard->GetProperty(DIPROP_KEYNAME, &propString.diph);
    INT32 len = WideCharToMultiByte(CP_ACP, 0, propString.wsz,
            -1, NULL, 0, NULL, NULL);
    CHAR* desc = new CHAR[len];
    WideCharToMultiByte(CP_ACP, 0, propString.wsz, -1, desc, len, NULL,
            NULL);
    DirectInputSignal* s = new DirectInputSignal(0, keyID, desc);
    delete[] desc;
    return s;
}

DirectInputSignal* DirectInputDevice::createInputSignal(const CHAR* configKey)
{
    CHAR* tmp = new CHAR[strlen(configKey)];
    strcpy(tmp, configKey);
    CHAR* didPtr = tmp;
    CHAR* cidPtr = strchr(didPtr, ':');
    if (cidPtr == NULL)
        return NULL;

    (*cidPtr) = NULL;
    cidPtr++;
    CHAR* descPtr = strchr(cidPtr, ':');
    if (descPtr == NULL)
        return NULL;

    (*descPtr) = NULL;
    descPtr++;
    DirectInputSignal* signal = new DirectInputSignal(atoi(didPtr), atoi(cidPtr),
            descPtr);
    delete[] tmp;
    return signal;
}

void DirectInputDevice::poll()
{
    //update the keyboard buffer
    if (FAILED(m_pdiKeyboard->GetDeviceState(
            sizeof(m_KeyboardBuffer),
            (LPVOID)&m_KeyboardBuffer)))
    {
        //try to reacquire the device before giving up on the keyboard
        if (FAILED(m_pdiKeyboard->Acquire())) {
            m_bLastPollSuccessful = FALSE;
            return;
        }

        if (FAILED(m_pdiKeyboard->GetDeviceState(
                    sizeof(m_KeyboardBuffer),
                    (LPVOID)&m_KeyboardBuffer)))
        {
            m_bLastPollSuccessful = FALSE;
            return;
        }
    }

    //check to see if the user pressed ESCAPE
    if (m_KeyboardBuffer[DIK_ESCAPE] & 0x80)
        stop = TRUE;

    //update the joystick states
    for (INT32 i = 0; i < m_iJoystickCount; i++) {
        if (FAILED(m_pdiJoysticks[i]->Poll()))
        {
            if (FAILED(m_pdiJoysticks[i]->Acquire())) {
                m_bLastPollSuccessful = FALSE;
                return;
            }
    
            if (FAILED(m_pdiJoysticks[i]->Poll())) {
                m_bLastPollSuccessful = FALSE;
                return;
            }
        }

        if (FAILED(m_pdiJoysticks[i]->GetDeviceState(
                sizeof(DIJOYSTATE2), &m_JoystickStates[i])))
        {
            m_bLastPollSuccessful = FALSE;
            return;
        }
    }

    m_bLastPollSuccessful = TRUE;
}

BOOL CALLBACK EnumJoysticksCallback(const DIDEVICEINSTANCE*     
                                       pdidInstance, VOID* pContext)
{
    DirectInputDevice* did = (DirectInputDevice*)pContext;
    //obtain an interface to the enumerated joystick
    HRESULT hr = did->m_pDI->CreateDevice(pdidInstance->guidInstance,  
            &did->m_pdiJoysticks[did->m_iJoystickCount],
            NULL);

    if(FAILED(hr)) 
        return DIENUM_CONTINUE;

    //increment our joystick counter
    did->m_iJoystickCount++;
    if (did->m_iJoystickCount < 10)
        return DIENUM_CONTINUE;

    return DIENUM_STOP;
}

INT32 DirectInputDevice::initDirectInput()
{
    if (FAILED(DirectInput8Create(GetModuleHandle(NULL), DIRECTINPUT_VERSION, 
            IID_IDirectInput8, (void**)&m_pDI, NULL)))
    { 
        return ERR_UNABLE_TO_CREATE_INPUT;
    }

    //create the keyboard device
    if (FAILED(m_pDI->CreateDevice(GUID_SysKeyboard,
            &(m_pdiKeyboard), NULL)))
    { 
        return ERR_UNABLE_TO_CREATE_KEYBOARD; 
    } 

    //set the keyboard data format
    if (FAILED(m_pdiKeyboard->SetDataFormat(&c_dfDIKeyboard))) {
        return ERR_UNABLE_TO_SET_KEYBOARD; 
    }

    //enumerate and initialize the joysticks
    m_iJoystickCount = 0;
    m_pDI->EnumDevices(DI8DEVCLASS_GAMECTRL, EnumJoysticksCallback, this,
            DIEDFL_ATTACHEDONLY);
 
    for (INT32 i = 0; i < m_iJoystickCount; i++) {
        if (FAILED(m_pdiJoysticks[i]->SetDataFormat(&c_dfDIJoystick2)))
            return ERR_UNABLE_TO_CREATE_INPUT;
    }

    return 0;
}

INT32 DirectInputDevice::initDirectInputDevices(HWND hWnd)
{

    //set the keyboard cooperative level
    if (FAILED(m_pdiKeyboard->SetCooperativeLevel(
            hWnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE)))
        return ERR_UNABLE_TO_CREATE_INPUT;

    INT32 j;
    for (INT32 i = 0; i < m_iJoystickCount; i++) {
        if (FAILED(m_pdiJoysticks[i]->SetCooperativeLevel(
                hWnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE)))
            return ERR_UNABLE_TO_CREATE_INPUT;

        //set up the dead zone for the axes
        DIPROPDWORD wordProp;
        wordProp.diph.dwSize = sizeof(DIPROPDWORD);
        wordProp.diph.dwHeaderSize = sizeof(DIPROPHEADER);
        wordProp.diph.dwObj = 0;
        wordProp.diph.dwHow = DIPH_DEVICE;
        wordProp.dwData = 1000;
        m_pdiJoysticks[i]->SetProperty(DIPROP_DEADZONE,
                &wordProp.diph);

        //poll the joysticks once so we can determine the center positions
        if (FAILED(m_pdiJoysticks[i]->Acquire()))
            return ERR_UNABLE_TO_CREATE_INPUT;
    
        if (FAILED(m_pdiJoysticks[i]->Poll()))
            return ERR_UNABLE_TO_CREATE_INPUT;

        if (FAILED(m_pdiJoysticks[i]->GetDeviceState(
                sizeof(DIJOYSTATE2), &m_JoystickStates[i])))
            return ERR_UNABLE_TO_CREATE_INPUT;
        
        //get the ranges and centering info for the axes
        DIPROPRANGE rangeProp;
        rangeProp.diph.dwSize = sizeof(DIPROPRANGE);
        rangeProp.diph.dwHeaderSize = sizeof(DIPROPHEADER);
        rangeProp.diph.dwHow = DIPH_BYOFFSET;
        for (j = 0; j < 3; j++) {
            rangeProp.diph.dwObj = (j == 0 ? DIJOFS_X :
                    (j == 1 ? DIJOFS_Y : DIJOFS_Z));
            if (SUCCEEDED(m_pdiJoysticks[i]->GetProperty(
                        DIPROP_RANGE, &rangeProp.diph)))
            {
                LONG center = ((LONG*)&m_JoystickStates[i])[j];
                ((LONG*)&m_JoystickAxes[i])[j<<1] = (rangeProp.lMax - center);
                ((LONG*)&m_JoystickAxes[i])[(j<<1)+1] = center;
            }
            else {
                ((LONG*)&m_JoystickAxes[i])[j<<1] = 0;
                ((LONG*)&m_JoystickAxes[i])[(j<<1)+1] = 0;
            }
        }
    }

    return 0;
}

void DirectInputDevice::releaseDirectInput() {
    for (INT32 i = 0; i < m_iJoystickCount; i++) {
        if (m_pdiJoysticks[i] != NULL) {
            m_pdiJoysticks[i]->Unacquire();
            m_pdiJoysticks[i]->Release();
            m_pdiJoysticks[i] = NULL;
        }
    }
    if (m_pdiKeyboard != NULL) {
        m_pdiKeyboard->Unacquire();
        m_pdiKeyboard->Release();
        m_pdiKeyboard = NULL;
    }
    if (m_pDI != NULL) {
        m_pDI->Release();
        m_pDI = NULL;
    }
}

void DirectInputDevice::release()
{
    releaseDirectInput();
}

DirectInputSignal* DirectInputDevice::getDefaultSignal(INT32 controlID)
{
    DirectInputSignal* dsignal = NULL;
    if (controlID >= PLAYER_ONE_ID_START &&
            controlID <= PLAYER_ONE_ID_END)
    {
        dsignal = DEFAULT_INPUT_SIGNALS_PLAYER_ONE[controlID-PLAYER_ONE_ID_START];
    }
    else if (controlID >= PLAYER_TWO_ID_START &&
            controlID <= PLAYER_TWO_ID_END)
    {
        dsignal = DEFAULT_INPUT_SIGNALS_PLAYER_TWO[controlID-PLAYER_TWO_ID_START];
    }
    else if (controlID >= KEYBOARD_ID_START &&
            controlID <= KEYBOARD_ID_END)
    {
        dsignal = DEFAULT_INPUT_SIGNALS_KEYBOARD[controlID-KEYBOARD_ID_START];
    }
    else if (controlID >= EMULATOR_ID_START &&
            controlID <= EMULATOR_ID_END)
    {
        dsignal = DEFAULT_INPUT_SIGNALS_EMULATOR[controlID-EMULATOR_ID_START];
    }

    if (dsignal != NULL)
        return new DirectInputSignal(*dsignal);
    else
        return NULL;
}

INT32 DirectInputDevice::initConfigMode()
{
    INT32 result;
    if (result = initDirectInput())
        return result;

    if (result = initDirectInputDevices(GetForegroundWindow())) {
        releaseDirectInput();
        return result;
    }

    //get the names of the joysticks for config mode
    for (INT32 i = 0; i < m_iJoystickCount; i++) {
        DIPROPSTRING stringProp;
        stringProp.diph.dwSize = sizeof(DIPROPSTRING);
        stringProp.diph.dwHeaderSize = sizeof(DIPROPHEADER);
        stringProp.diph.dwObj = 0;
        stringProp.diph.dwHow = DIPH_DEVICE;
        if (SUCCEEDED(m_pdiJoysticks[i]->
                GetProperty(DIPROP_INSTANCENAME, &stringProp.diph)))
        {
            WideCharToMultiByte(CP_ACP, 0, stringProp.wsz, -1,
                    m_JoystickNames[i], MAX_PATH, NULL, NULL);
        }
        else
            m_JoystickNames[i][0] = 0;
    }

    return 0;
}

DirectInputSignal* DirectInputDevice::pollForInputSignal()
{
    poll();

    if (!m_bLastPollSuccessful)
        return NULL;

    DirectInputSignal* returnValue = checkKeyboardForInputSignal();
    if (returnValue != NULL)
        return returnValue;

    for (INT32 i = 0; i < m_iJoystickCount; i++) {
        returnValue = checkJoystickForInputSignal(i);
        if (returnValue != NULL)
            return returnValue;
    }

    return NULL;
}

DirectInputSignal* DirectInputDevice::checkKeyboardForInputSignal()
{
//    DirectInputSignal* retVal;
    //check for key presses on the keyboard
    for (INT32 i = 0; i < 256; i++) {
        if (m_KeyboardBuffer[i] & 0x80) {
            DIPROPSTRING propString;
            propString.diph.dwSize = sizeof(DIPROPSTRING);
            propString.diph.dwHeaderSize = sizeof(DIPROPHEADER);
            propString.diph.dwObj = i;
            propString.diph.dwHow = DIPH_BYOFFSET;

            CHAR description[256];
            if (SUCCEEDED(m_pdiKeyboard->GetProperty(
                    DIPROP_KEYNAME, &propString.diph)))
            {
                WideCharToMultiByte(CP_ACP, 0, propString.wsz, -1, description,
                        256, NULL, NULL);
            }
            else
                strcpy(description, "<???>");
            return new DirectInputSignal(0, i, description);
        }
    }

    return NULL;
}

DirectInputSignal* DirectInputDevice::checkJoystickForInputSignal(INT32 joystickNum)
{
    if (joystickNum >= m_iJoystickCount)
        return NULL;

    DIJOYSTATE2* joyState = &m_JoystickStates[joystickNum];
    //poll the axes
    if (joyState->lX < m_JoystickAxes[joystickNum].lCenterX) {
        CHAR description[256];
        DIDEVICEOBJECTINSTANCE deviceInfo;
        deviceInfo.dwSize = sizeof(DIDEVICEOBJECTINSTANCE);
        if (SUCCEEDED(m_pdiJoysticks[joystickNum]->
                GetObjectInfo(&deviceInfo, DIJOFS_X, DIPH_BYOFFSET)))
        {
            sprintf(description, "-%s (%s)", deviceInfo.tszName,
                    m_JoystickNames[joystickNum]);
        }
        else
            strcpy(description, "<???>");
        return new DirectInputSignal(joystickNum+1, 0, description);
    }

    if (joyState->lY < m_JoystickAxes[joystickNum].lCenterY) {
        CHAR description[256];
        DIDEVICEOBJECTINSTANCE deviceInfo;
        deviceInfo.dwSize = sizeof(DIDEVICEOBJECTINSTANCE);
        if (SUCCEEDED(m_pdiJoysticks[joystickNum]->
                GetObjectInfo(&deviceInfo, DIJOFS_Y, DIPH_BYOFFSET)))
        {
            sprintf(description, "-%s (%s)", deviceInfo.tszName,
                    m_JoystickNames[joystickNum]);
        }
        else
            strcpy(description, "<???>");
        return new DirectInputSignal(joystickNum+1, 1, description);
    }

    if (joyState->lZ < m_JoystickAxes[joystickNum].lCenterZ) {
        CHAR description[256];
        DIDEVICEOBJECTINSTANCE deviceInfo;
        deviceInfo.dwSize = sizeof(DIDEVICEOBJECTINSTANCE);
        if (SUCCEEDED(m_pdiJoysticks[joystickNum]->
                GetObjectInfo(&deviceInfo, DIJOFS_Z, DIPH_BYOFFSET)))
        {
            sprintf(description, "-%s (%s)", deviceInfo.tszName,
                    m_JoystickNames[joystickNum]);
        }
        else
            strcpy(description, "<???>");
        return new DirectInputSignal(joystickNum+1, 2, description);
    }

    if (joyState->lX > m_JoystickAxes[joystickNum].lCenterX) {
        CHAR description[256];
        DIDEVICEOBJECTINSTANCE deviceInfo;
        deviceInfo.dwSize = sizeof(DIDEVICEOBJECTINSTANCE);
        if (SUCCEEDED(m_pdiJoysticks[joystickNum]->
                GetObjectInfo(&deviceInfo, DIJOFS_X, DIPH_BYOFFSET)))
        {
            sprintf(description, "+%s (%s)", deviceInfo.tszName,
                    m_JoystickNames[joystickNum]);
        }
        else
            strcpy(description, "<???>");
        return new DirectInputSignal(joystickNum+1, 3, description);
    }

    if (joyState->lY > m_JoystickAxes[joystickNum].lCenterY) {
        CHAR description[256];
        DIDEVICEOBJECTINSTANCE deviceInfo;
        deviceInfo.dwSize = sizeof(DIDEVICEOBJECTINSTANCE);
        if (SUCCEEDED(m_pdiJoysticks[joystickNum]->
                GetObjectInfo(&deviceInfo, DIJOFS_Y, DIPH_BYOFFSET)))
        {
            sprintf(description, "+%s (%s)", deviceInfo.tszName,
                    m_JoystickNames[joystickNum]);
        }
        else
            strcpy(description, "<???>");
        return new DirectInputSignal(joystickNum+1, 4, description);
    }

    if (joyState->lZ > m_JoystickAxes[joystickNum].lCenterZ) {
        CHAR description[256];
        DIDEVICEOBJECTINSTANCE deviceInfo;
        deviceInfo.dwSize = sizeof(DIDEVICEOBJECTINSTANCE);
        if (SUCCEEDED(m_pdiJoysticks[joystickNum]->
                GetObjectInfo(&deviceInfo, DIJOFS_Z, DIPH_BYOFFSET)))
        {
            sprintf(description, "+%s (%s)", deviceInfo.tszName,
                    m_JoystickNames[joystickNum]);
        }
        else
            strcpy(description, "<???>");
        return new DirectInputSignal(joystickNum+1, 5, description);
    }

    //poll the joystick buttons
    for (INT32 i = 0; i < 128; i++) {
        if (joyState->rgbButtons[i] & 0x80) {
            CHAR description[256];
            DIDEVICEOBJECTINSTANCE deviceInfo;
            deviceInfo.dwSize = sizeof(DIDEVICEOBJECTINSTANCE);
            if (SUCCEEDED(m_pdiJoysticks[joystickNum]->
                    GetObjectInfo(&deviceInfo, DIJOFS_BUTTON(i),
                        DIPH_BYOFFSET)))
            {
                sprintf(description, "%s (%s)", deviceInfo.tszName,
                        m_JoystickNames[joystickNum]);
            }
            else
                strcpy(description, "<???>");
            return new DirectInputSignal(joystickNum+1, i+6, description);
        }
    }

    //poll the POVs
    for (i = 0; i < 4; i++) {
        if (LOWORD(m_JoystickStates[joystickNum].rgdwPOV[i]) ==
                0xFFFF)
            continue;

        //determine the direction the user moved the POV
        INT32 povValue = m_JoystickStates[joystickNum].rgdwPOV[i];
        INT32 direction = ((povValue + 4500) / 9000) & 0x03;

        CHAR description[256];
        DIDEVICEOBJECTINSTANCE deviceInfo;
        deviceInfo.dwSize = sizeof(DIDEVICEOBJECTINSTANCE);
        if (SUCCEEDED(m_pdiJoysticks[joystickNum]->
                GetObjectInfo(&deviceInfo, DIJOFS_POV(i),
                    DIPH_BYOFFSET)))
        {
            sprintf(description, "%s %s (%s)", deviceInfo.tszName,
                    g_lpszPOVDescriptions[direction],
                    m_JoystickNames[joystickNum]);
        }
        else
            strcpy(description, "<???>");
        return new DirectInputSignal(joystickNum+1, 262+(i*4)+direction,
                description);
    }

    return NULL;
}

void DirectInputDevice::releaseConfigMode()
{
    releaseDirectInput();
}

INT32 DirectInputDevice::init()
{
    stop = FALSE;
    INT32 result;
    if (result = initDirectInput()) {
        return result;
    }

    if (result = initDirectInputDevices(currentDevice->m_hWnd)) {
        releaseDirectInput();
        return result;
    }

    return 0;
}

const CHAR* DirectInputDevice::getErrorDescription(INT32 errorCode)
{
    return inputErrorMessages[errorCode-1];
}

float DirectInputDevice::getJoystickSignalValue(INT32 joystickNum,
        INT32 inputCode)
{
    if (joystickNum >= m_iJoystickCount)
        return 0.0f;

    if (inputCode < 6) {
        LONG inputValue = 0;
        LONG maxValue = 0;
        switch (inputCode) {
            case 0:
                inputValue = -(m_JoystickStates[joystickNum].lX -
                        m_JoystickAxes[joystickNum].lCenterX);
                maxValue = m_JoystickAxes[joystickNum].lMaxDeltaX;
                break;
            case 1:
                inputValue = -(m_JoystickStates[joystickNum].lY -
                        m_JoystickAxes[joystickNum].lCenterY);
                maxValue = m_JoystickAxes[joystickNum].lMaxDeltaY;
                break;
            case 2:
                inputValue = -(m_JoystickStates[joystickNum].lZ -
                        m_JoystickAxes[joystickNum].lCenterZ);
                maxValue = m_JoystickAxes[joystickNum].lMaxDeltaZ;
                break;
            case 3:
                inputValue = m_JoystickStates[joystickNum].lX -
                        m_JoystickAxes[joystickNum].lCenterX;
                maxValue = m_JoystickAxes[joystickNum].lMaxDeltaX;
                break;
            case 4:
                inputValue = m_JoystickStates[joystickNum].lY -
                        m_JoystickAxes[joystickNum].lCenterY;
                maxValue = m_JoystickAxes[joystickNum].lMaxDeltaY;
                break;
            case 5:
                inputValue = m_JoystickStates[joystickNum].lZ -
                        m_JoystickAxes[joystickNum].lCenterZ;
                maxValue = m_JoystickAxes[joystickNum].lMaxDeltaZ;
                break;
        }

        if (inputValue <= 0)
            return 0.0f;

        return (float)((float)inputValue)/((float)maxValue);
    }
    else if (inputCode < 262) {
        return (m_JoystickStates[joystickNum].
                rgbButtons[inputCode-6] & 0x80 ? 1.0f : 0.0f);
    }
    else if (inputCode < 278) {
        INT32 directionToCheck = (inputCode-262) & 0x03;
        DWORD povValue = m_JoystickStates[joystickNum].
                rgdwPOV[((inputCode-262) & 0x0C) >> 2];
        if (LOWORD(povValue) == 0xFFFF)
            return 0.0f;

        INT32 direction = ((povValue + 4500) / 9000) & 0x03;
        return (direction == directionToCheck ? 1.0f : 0.0f);
    }
    return 0.0f;
}

float DirectInputDevice::getSignalValue(DirectInputSignal* inputSignal)
{
    if (!m_bLastPollSuccessful || inputSignal == NULL)
        return 0.0f;

    DirectInputSignal* dinputSignal = (DirectInputSignal*)inputSignal;
    if (dinputSignal->deviceID == 0)
        return (m_KeyboardBuffer[dinputSignal->controlID] & 0x80
                ? 1.0f : 0.0f);
    else
        return getJoystickSignalValue((int)dinputSignal->deviceID-1,
                (int)dinputSignal->controlID);
}

