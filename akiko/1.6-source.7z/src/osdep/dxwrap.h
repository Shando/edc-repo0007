#ifndef __DXWRAP_H__
#define __DXWRAP_H__

typedef enum
{
    red_mask,
    green_mask,
    blue_mask
} DirectDraw_Mask_e;

typedef enum
{
    invalid_surface,
    primary_surface,
    secondary_surface,
    overlay_surface,
    lockable_surface
} surface_type_e;

struct DirectDrawSurfaceMapper
{
    int initialized;
    int fullscreen;
    int isoverlay;
    int flipping;
    int locked;
    HWND window;
    struct
    {
        LPDIRECTDRAW dd;
        LPDIRECTDRAW4 dd_dx6;
    } directdraw;
    struct
    {
        LPDIRECTDRAWSURFACE surface;
        LPDIRECTDRAWSURFACE4 surface_dx6;
        DDSURFACEDESC desc;
        DDSURFACEDESC2 desc_dx6;
    } primary;
    struct
    {
        LPDIRECTDRAWSURFACE surface;
        LPDIRECTDRAWSURFACE4 surface_dx6;
        DDSURFACEDESC desc;
        DDSURFACEDESC2 desc_dx6;
    } secondary;
    struct
    {
        LPDIRECTDRAWSURFACE surface;
        LPDIRECTDRAWSURFACE4 surface_dx6;
        DDSURFACEDESC desc;
        DDSURFACEDESC2 desc_dx6;
    } overlay;
    struct
    {
        DDSURFACEDESC desc;
        DDSURFACEDESC2 desc_dx6;
    } current;
    struct
    {
        LPDIRECTDRAWSURFACE surface;
        LPDIRECTDRAWSURFACE4 surface_dx6;
        LPDDSURFACEDESC lpdesc;
        LPDDSURFACEDESC2 lpdesc_dx6;
    } lockable;
    LPDIRECTDRAWCLIPPER lpDDC;
    LPDIRECTDRAWPALETTE lpDDP;
    LPDIRECTDRAWPALETTE lpOverlayDDP;
    surface_type_e surface_type;
};
HRESULT DirectDraw_CreateOverlaySurface( int width, int height, int bits );
int DirectDraw_Start( void );
void DirectDraw_Release( void );
HRESULT DirectDraw_SetCooperativeLevel( HWND window, int want_fullscreen );
BOOL DirectDraw_GetCooperativeLevel( HWND *window, int *fullscreen );
HRESULT DirectDraw_SetDisplayMode( int width, int height, int bits, int freq );
HRESULT DirectDraw_GetDisplayMode( void );
HRESULT DirectDraw_CreateClipper( void );
HRESULT DirectDraw_GetCaps( DDCAPS *driver_caps, DDCAPS *hel_caps );
HRESULT DirectDraw_CreateSurface( int width, int height );
void    DirectDraw_ClearSurfaces( void );
HRESULT DirectDraw_SetClipper( HWND hWnd );
HRESULT DirectDraw_GetClipList( LPRGNDATA cliplist, LPDWORD size );
HRESULT DirectDraw_CreatePalette( LPPALETTEENTRY pal );
HRESULT DirectDraw_SetPalette( int remove );
HRESULT DirectDraw_SetPaletteEntries( int start, int count, PALETTEENTRY *palette );
HRESULT DirectDraw_WaitForVerticalBlank( DWORD flags );
HRESULT DirectDraw_EnumDisplayModes( DWORD flags, LPDDENUMMODESCALLBACK2 callback );
HRESULT DirectDraw_FlipToGDISurface( void );
HRESULT DirectDraw_GetDC( HDC *hdc, surface_type_e surface );
HRESULT DirectDraw_ReleaseDC( HDC hdc, surface_type_e surface );
int DirectDraw_Flip( void );
HRESULT DirectDraw_UpdateOverlay(RECT sr, RECT dr);
int DirectDraw_Blt( surface_type_e dsttype, LPRECT dstrect, surface_type_e srctype, LPRECT srcrect, DWORD flags, LPDDBLTFX fx );
int DirectDraw_BltFast( surface_type_e dsttype, DWORD left, DWORD top, surface_type_e srctype, LPRECT srcrect );
DWORD DirectDraw_GetPixelFormatBitMask( DirectDraw_Mask_e mask );
RGBFTYPE DirectDraw_GetPixelFormat( void );
DWORD DirectDraw_GetPixelFormatFlags( void );
DWORD DirectDraw_GetSurfaceFlags( void );
DWORD DirectDraw_GetSurfaceBitCount( void );
DWORD DirectDraw_GetPrimaryBitCount( void );
int DirectDraw_DetermineLocking( int wantfull );
BYTE DirectDraw_GetBytesPerPixel( void );
char *DirectDraw_ErrorString( HRESULT ddrval );
RGBFTYPE DirectDraw_GetSurfacePixelFormat( LPVOID surface );
surface_type_e DirectDraw_GetLockableType( void );
int DirectDraw_SurfaceLock( surface_type_e surface_type );
BOOL DirectDraw_IsLocked( void );
char *DirectDraw_GetSurfacePointer( void );
LONG DirectDraw_GetSurfacePitch( void );
DWORD DirectDraw_CurrentWidth( void );
DWORD DirectDraw_CurrentHeight( void );

extern void unlockscr (void);
#define DirectDraw_SurfaceUnlock() unlockscr()

#endif
