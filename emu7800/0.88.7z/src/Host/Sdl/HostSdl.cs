/*
 * HostSdl
 * 
 * An Sdl-based host
 * 
 * Copyright (c) 2004-2006 Mike Murphy
 * 
 */
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;
using EMU7800.Machine;

namespace EMU7800.Host.Sdl
{
    public class HostSdl : HostBase
    {
        const int WIDTH = 320, HEIGHT = 240;
        const bool FULLSCREEN = true;

        FontRenderer _FontRenderer;
        int[] _Palette;

        bool SdlJoysticksSwapped;

        int MouseX, MouseY;
        bool ShowMouseCursor;   // For lightgun emulation

        Dictionary<SdlKey, HostInput> _KeyBindings;

        Stopwatch _Stopwatch;
        const int FRAME_SAMPLES = 120;
        long _startOfCycleTick, _endOfCycleTick;
        long _frameBudgetTicks, _sleepableTicks;
        readonly long _ticksPerMillisec = Stopwatch.Frequency / 1000;
        readonly int[] _RunMachineTicks = new int[FRAME_SAMPLES];
        readonly int[] _WaitTicks = new int[FRAME_SAMPLES];

        #region HostBase Overrides

        public override void Run(MachineBase m)
        {
            base.Run(m);
            InitializeKeyBindings();
            try
            {
                Trace.WriteLine("Simple DirectMedia Layer " + SdlNativeMethods.Version + " detected");
                _FontRenderer = new FontRenderer(M.VideoFrameBuffer, M.VisiblePitch);
                _Palette = M.GetPalette();
                SdlNativeMethods.Open(WIDTH, HEIGHT, FULLSCREEN, EMU7800App.Title);
                Run();
            }
            finally
            {
                SdlNativeMethods.Close();
                CloseAudio();
                Trace.WriteLine("SDL host shutdown");
            }
        }

        #endregion

        void Run()
        {
            SdlJoysticksSwapped = false;

            SdlNativeMethods.Keyboard += OnKeyboard;
            SdlNativeMethods.JoyButton += OnJoyButton;
            SdlNativeMethods.JoyAxis += OnJoyAxis;
            SdlNativeMethods.MouseButton += OnMouseButton;
            SdlNativeMethods.MouseMotion += OnMouseMotion;

            foreach (var dev in SdlNativeMethods.Joysticks)
            {
                if (dev.Name != null && dev.Name.Contains("Stelladaptor"))
                {
                    Trace.WriteLine("Stelladaptor detected: disabling mouse input");
                    DeactivateMouseInput = true;
                }
            }

            ShowMouseCursor = M.InputAdapter.GetController(0) == Controller.Lightgun;

            _Stopwatch = new Stopwatch();
            _frameBudgetTicks = Stopwatch.Frequency / M.FrameHZ;
            _sleepableTicks = _frameBudgetTicks - GlobalSettings.Instance.CpuSpin * _ticksPerMillisec;
            _Stopwatch.Start();
            _endOfCycleTick = _Stopwatch.ElapsedTicks;

            while (!Ended && !M.MachineHalt)
            {
                _startOfCycleTick = _endOfCycleTick;

                SdlNativeMethods.PollAndDelegate();

                if (Paused)
                {
                    for (var i = 0; i < M.SoundFrameBuffer.Length; i++)
                    {
                        M.SoundFrameBuffer[i] = 0;
                    }
                }
                else
                {
                    M.RunFrame();
                }

                var endOfRunMachineTick = _Stopwatch.ElapsedTicks;

                var sleepTicks = (int)((_sleepableTicks - (endOfRunMachineTick - _startOfCycleTick)) / _ticksPerMillisec);
                if (sleepTicks > 0)
                {
                    Thread.Sleep(sleepTicks);
                }

                PullFrame();

                while (EnqueueAudio(M.SoundFrameBuffer) == 1)
                {
                }

                _endOfCycleTick = _Stopwatch.ElapsedTicks;

                int statIndex = (int)M.FrameNumber % FRAME_SAMPLES;
                _RunMachineTicks[statIndex] = (int)(endOfRunMachineTick - _startOfCycleTick);
                _WaitTicks[statIndex] = (int)(_endOfCycleTick - endOfRunMachineTick);
            }
        }

        unsafe void PullFrame()
        {
            if (PostedMsg.Length > 0)
            {
                _FontRenderer.DrawText(PostedMsg, 2, ClipStart + 4, 10, 0);
            }

            SdlNativeMethods.Lock();
            var tptr = (uint*)SdlNativeMethods.Pixels.ToPointer();
            var si = ClipStart * M.VisiblePitch + LeftOffset;
            if (tptr != null)
            {
                var xptr = tptr;
                for (var i = 0; i < HEIGHT; i++)
                {
                    while (si < 0)
                    {
                        si += M.VideoFrameBuffer.Length;
                    }
                    var yptr = xptr;
                    for (var j = 0; j < M.VisiblePitch; j++)
                    {
                        while (si >= M.VideoFrameBuffer.Length)
                        {
                            si -= M.VideoFrameBuffer.Length;
                        }
                        var pixel = (uint)_Palette[M.VideoFrameBuffer[si++]];
                        *yptr++ = pixel;
                        if (M.VisiblePitch == (WIDTH >> 1))
                        {
                            *yptr++ = pixel;
                        }
                    }
                    xptr += (SdlNativeMethods.Pitch >> 2);
                }

                if (ShowMouseCursor)
                {
                    tptr[MouseY * WIDTH + MouseX] = 0xffffff;
                }
            }
            SdlNativeMethods.Unlock();
            SdlNativeMethods.Flip();
        }

        void OnJoyButton(int deviceno, int button, bool down)
        {
            var ia = M.InputAdapter;
            var playerno = deviceno ^ (SdlJoysticksSwapped ? 1 : 0);

            if (Paused)
            {
            }
            else if (ia.GetController(playerno) == Controller.Paddles)
            {
                if (DeactivateMouseInput && button <= 1)
                {
                    // Map Stelladaptor joystick button events to paddle triggers when necessary
                    button ^= (SdlNativeMethods.Joysticks[deviceno].PaddlesSwapped ? 1 : 0);
                    playerno = (playerno << 1) | button;
                    ia[playerno, ControllerAction.Trigger] = down;
                }
            }
            else if (button == GlobalSettings.Instance.JoyBTrigger)
            {
                ia[playerno, ControllerAction.Trigger] = down;
            }
            else if (button == GlobalSettings.Instance.JoyBBooster)
            {
                ia[playerno, ControllerAction.Trigger2] = down;
            }
        }

        void OnJoyAxis(int deviceno, int axis, int val)
        {
            var ia = M.InputAdapter;
            var playerno = deviceno ^ (SdlJoysticksSwapped ? 1 : 0);

            if (Paused)
            {
            }
            else if (ia.GetController(playerno) == Controller.Paddles)
            {
                if (DeactivateMouseInput && axis <= 1)
                {
                    // Map Stelladaptor joystick axis events to paddle knobs when necessary
                    axis ^= (SdlNativeMethods.Joysticks[deviceno].PaddlesSwapped ? 1 : 0);
                    playerno = 2 * playerno + axis;
                    RaisePaddleInput(playerno, 0xfeff, 0x8000 + val);
                }
            }
            else if (axis == 0)
            {
                RaiseInput(HostInput.Left, val < -8192);
                RaiseInput(HostInput.Right, val > 8192);
            }
            else if (axis == 1)
            {
                RaiseInput(HostInput.Up, val < -8192);
                RaiseInput(HostInput.Down, val > 8192);
            }
        }

        private void InitializeKeyBindings()
        {
            _KeyBindings = new Dictionary<SdlKey, HostInput>
            {
                {SdlKey.K_ESCAPE,       HostInput.End},
                {SdlKey.K_LCTRL,        HostInput.Fire},
                {SdlKey.K_RCTRL,        HostInput.Fire},
                {SdlKey.K_LALT,         HostInput.Fire2},
                {SdlKey.K_RALT,         HostInput.Fire2},
                {SdlKey.K_LEFT,         HostInput.Left},
                {SdlKey.K_UP,           HostInput.Up},
                {SdlKey.K_RIGHT,        HostInput.Right},
                {SdlKey.K_DOWN,         HostInput.Down},
                {SdlKey.K_KP7,          HostInput.NumPad7},
                {SdlKey.K_KP8,          HostInput.NumPad8},
                {SdlKey.K_KP9,          HostInput.NumPad9},
                {SdlKey.K_KP4,          HostInput.NumPad4},
                {SdlKey.K_KP5,          HostInput.NumPad5},
                {SdlKey.K_KP6,          HostInput.NumPad6},
                {SdlKey.K_KP1,          HostInput.NumPad1},
                {SdlKey.K_KP2,          HostInput.NumPad2},
                {SdlKey.K_KP3,          HostInput.NumPad3},
                {SdlKey.K_KP_MULTIPLY,  HostInput.NumPadMult},
                {SdlKey.K_KP0,          HostInput.NumPad0},
                {SdlKey.K_KP_DIVIDE,    HostInput.NumPadDiv},
                {SdlKey.K_1,            HostInput.LeftDifficulty},
                {SdlKey.K_2,            HostInput.RightDifficulty},
                {SdlKey.K_F1,           HostInput.SetKeyboardToPlayer1},
                {SdlKey.K_F2,           HostInput.SetKeyboardToPlayer2},
                {SdlKey.K_F3,           HostInput.SetKeyboardToPlayer3},
                {SdlKey.K_F4,           HostInput.SetKeyboardToPlayer4},
                {SdlKey.K_F5,           HostInput.PanLeft},
                {SdlKey.K_F6,           HostInput.PanRight},
                {SdlKey.K_F7,           HostInput.PanUp},
                {SdlKey.K_F8,           HostInput.PanDown},
                {SdlKey.K_F11,          HostInput.SaveMachine},
                {SdlKey.K_F12,          HostInput.Unknown},
                {SdlKey.K_c,            HostInput.Color},
                {SdlKey.K_f,            HostInput.Unknown},
                {SdlKey.K_m,            HostInput.Mute},
                {SdlKey.K_p,            HostInput.Pause},
                {SdlKey.K_r,            HostInput.Reset},
                {SdlKey.K_s,            HostInput.Select},
                {SdlKey.K_q,            HostInput.Unknown},
                {SdlKey.K_w,            HostInput.Unknown},
                {SdlKey.K_e,            HostInput.Unknown}
            };
        }

        void OnKeyboard(int deviceno, bool down, int scancode, SdlKey key, SdlMod mod)
        {
            if (_KeyBindings.ContainsKey(key))
            {
                switch (key)
                {
                    case SdlKey.K_f:
                        if (down)
                        {
                            double rmTicks = 0.0, wTicks = 0.0;
                            for (var i = 0; i < FRAME_SAMPLES; i++)
                            {
                                rmTicks += _RunMachineTicks[i];
                                wTicks += _WaitTicks[i];
                            }
                            rmTicks = rmTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
                            wTicks = wTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
                            var fps = 1000.0 / (rmTicks + wTicks);
                            PostedMsg = string.Format("{0}/{1} FPS {2:0.0}+{3:0.0}={4:0.0}/{5:0.0} ms", Math.Round(fps, 0), EffectiveFPS, rmTicks, wTicks, rmTicks + wTicks, 1000.0 / EffectiveFPS);
                        }
                        break;
                    case SdlKey.K_q:
                        if (down)
                        {
                            SwapPaddles(0);
                        }
                        break;
                    case SdlKey.K_w:
                        if (down)
                        {
                            SdlJoysticksSwapped = !SdlJoysticksSwapped;
                            PostedMsg = String.Format("P1/P2 Game Controllrs {0}wapped", SdlJoysticksSwapped ? "S" : "Uns");
                        }
                        break;
                    case SdlKey.K_e:
                        if (down)
                        {
                            SwapPaddles(1);
                        }
                        break;
                    case SdlKey.K_F12:
                        if (down)
                        {
                            var fn = String.Format("emu7800 screenshot {0:yyyy} {0:MM}-{0:dd} {0:HH}{0:mm}{0:ss}.bmp", DateTime.Now);
                            var rv = SdlNativeMethods.SaveBMP(Path.Combine(GlobalSettings.Instance.OutputDirectory, fn));
                            if (rv.Length.Equals(0))
                            {
                                Trace.WriteLine("Screenshot taken: " + fn);
                                PostedMsg = "Screenshot taken";
                            }
                            else
                            {
                                Trace.WriteLine("Error while taking screenshot: " + rv);
                                PostedMsg = "Screenshot failed";
                            }
                        }
                        break;
                    default:
                        RaiseInput(_KeyBindings[key], down);
                        break;
                }
            }
            else
            {
                RaiseInput(HostInput.Unknown, down);
            }
        }

        void OnMouseButton(int deviceno, bool down, SdlMouseButton button, int x, int y)
        {
            if (Paused || DeactivateMouseInput)
            {
            }
            else
            {
                RaiseInput(HostInput.Fire, down);
            }
        }

        void OnMouseMotion(bool down, int x, int y, int xrel, int yrel)
        {
            // Record last known mouse position for drawing things
            // like possible mouse cursors
            MouseX = x;
            MouseY = y;

            if (!DeactivateMouseInput)
            {
                RaiseLightGunInput(WIDTH, x, y);
                RaisePaddleInput(WIDTH, MouseX);
            }
        }
 
        void SwapPaddles(int deviceno)
        {
            if (SdlNativeMethods.Joysticks[deviceno].Opened)
            {
                SdlNativeMethods.Joysticks[deviceno].PaddlesSwapped = !SdlNativeMethods.Joysticks[deviceno].PaddlesSwapped;
                PostedMsg = String.Format("P{0} Stelladptr Paddles {1}wapped",
                    deviceno + 1, SdlNativeMethods.Joysticks[deviceno].PaddlesSwapped ? "A" : "Uns");
            }
        }
    }
}