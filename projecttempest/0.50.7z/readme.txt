
		Project Tempest v0.5 (03 March 2003)
		---------------------------------------


What is Project Tempest ?
-------------------------

Project Tempest is worlds first working Atari Jaguar emulator. It currently runs several
commercial games.


System Requirements
--------------------

Pentium III/Athlon 800+ MHz
128MB RAM
DirectX 8.0 or higher
Windows 9x/ME/2000/XP

A faster processor is seriously recommended !
For sound emulation, you probably need a 2+ GHz processor.


What's new in version 0.5 ?
--------------------------

* Improved blitter emulation. 3D games work better now.
* Even more optimizations to the video system
* Improved sound emulation

How to use the emulator
------------------------

To load commercial games, select Open ROM from File menu. To start the game, press F2 or Start from
emulation menu.

To load homebrewn games and demos, select Open BIN from File menu. Write the addresses required and
press F2 or Start from emulation menu.

To stop the emulation, press F3 or Stop from emulation menu.


Settings
--------

Disable DSP Emulation: 	This should usually be enabled.

Blitter			HLE Blitter is fast and quite compatible. Use it.
			New Blitter is slower but more compatible. Most 3D games currently only work with it.

Enable sound:		Enables sound output. You also need to enable DSP to get any sound.

DSP Speed Hack:		Removes DSP idle loops. May break some games. Gives more
			speed on some games when sound is enabled. 


Controls
--------

Keyboard and DirectInput-compatible game controllers are supported.
Use Controller/Joypad 1/2 to configure controllers

Also in Pinball Fantasies, Shifts and Ctrls are mapped as the flipper keys.


Credits
-------

Emulator programming by Ville Linde

Website and support by The Fox (emuunlim@emuunlim.com)
Website design by Malc Jennings


Contact Information
-------------------

Website:  http://pt.emuunlim.com
E-Mail:	  ptemu@emuunlim.com

