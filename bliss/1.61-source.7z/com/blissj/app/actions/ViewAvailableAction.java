package com.blissj.app.actions;

import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.blissj.app.*;

public class ViewAvailableAction extends AbstractAction
{

    public ViewAvailableAction(JTable table) {
        this.table = table;
        this.tableModel = (CartridgeTableModel)table.getModel();
        putValue(NAME, Bliss.RESOURCES.getString(
                "ActionViewAvailable"));
    }

    public void actionPerformed(ActionEvent ae) {
        table.clearSelection();
        tableModel.setView(CartridgeTableModel.VIEW_AVAILABLE);
    }

    private JTable              table;
    private CartridgeTableModel tableModel;

}
