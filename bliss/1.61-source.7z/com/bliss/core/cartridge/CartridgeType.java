package com.bliss.core.cartridge;

import java.io.*;

public class CartridgeType
{

    public CartridgeType(String name, String producer, String year,
            long crc, int size, boolean requiresECS, boolean usesIntellivoice,
            MemoryMap map)
    {
        this.name = name;
        this.producer = producer;
        this.year = year;
        this.crc = crc;
        this.size = size;
        this.requiresECS = requiresECS;
        this.usesIntellivoice = usesIntellivoice;
        this.map = map;
    }

    public String getName() {
        return name;
    }

    public String getProducer() {
        return producer;
    }

    public String getYear() {
        return year;
    }

    public long getCrc() {
        return crc;
    }

    public int getSize() {
        return size;
    }

    public boolean requiresECS() {
        return requiresECS;
    }

    public boolean usesIntellivoice() {
        return usesIntellivoice;
    }

    public MemoryMap getMemoryMap() {
        return map;
    }

    private String          name;
    private String          producer;
    private String          year;
    private long            crc;
    private int             size;
    private MemoryMap       map;
    private boolean         requiresECS;
    private boolean         usesIntellivoice;

    public static class MemoryMap
    {
        public MemoryMap(int[][] config) {
            this.config = config;
        }

        public int getSegmentCount() {
            return config.length;
        }

        public int getSegmentStart(int i) {
            return config[i][0];
        }

        public int getSegmentEnd(int i) {
            return config[i][1];
        }

        public int getSegmentSize(int i) {
            return config[i][1] - config[i][0] + 1;
        }

        public int getSegmentLocation(int i) {
            return config[i][2];
        }

        public int getSegmentBank(int i) {
            return config[i][3];
        }

        private int[][]       config;

    }

}
