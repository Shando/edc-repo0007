package com.bliss.core.devices;

import java.awt.image.*;

public interface AudioOutputDevice extends Device
{

    public int getSampleRate();

    public void playSamples(int[] samples, int numSamples);

    public void playSample(int sample);

}
