package com.bliss.core;

import java.io.*;

public class SaveOutputStream extends OutputStream
{

    SaveOutputStream(OutputStream os) {
        this.os = os;
    }

    public void write(int i) throws IOException {
        os.write(i);
    }

    public void flush() throws IOException {
        os.flush();
    }

    public void close() throws IOException {
        os.close();
    }

    public void writeLong(long i) throws IOException {
        os.write((int)((i & 0xFF00000000000000L) >> 56));
        os.write((int)((i & 0x00FF000000000000L) >> 48));
        os.write((int)((i & 0x0000FF0000000000L) >> 40));
        os.write((int)((i & 0x000000FF00000000L) >> 32));
        os.write((int)((i & 0x00000000FF000000L) >> 24));
        os.write((int)((i & 0x0000000000FF0000L) >> 16));
        os.write((int)((i & 0x000000000000FF00L) >> 8));
        os.write((int)(i & 0x00000000000000FFL));
    }

    public void writeInt(int i) throws IOException {
        os.write((i & 0xFF000000) >> 24);
        os.write((i & 0x00FF0000) >> 16);
        os.write((i & 0x0000FF00) >> 8);
        os.write(i & 0x000000FF);
    }

    public void writeBoolean(boolean b) throws IOException {
        os.write(b ? 1 : 0);
    }

    private OutputStream os;
}
