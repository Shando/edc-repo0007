/*
 * BIOS7800.cs
 * 
 * The BIOS of the Atari 7800.
 * 
 * Copyright (c) 2004 Mike Murphy
 * 
 */
using System;
using System.IO;

namespace EMU7800 {

[Serializable]
public sealed class BIOS7800 : IDevice {
	public  ushort Size;
	private ushort Mask;

	private byte[] ROM;

	public void Reset() {}

	public void Map(AddressSpace mem) {}

	public byte this[ushort addr] {
		get {
			return ROM[addr & Mask];
		}
		set {}
	}

	public BIOS7800(MachineType MachineType) {
		switch (MachineType) {
		case MachineType.A7800NTSC:
			// Try loading the newer, correct BIOS
			// If unsuccessful, try the old BIOS for now
			try {
				LoadBIOS("0763f1ffb006ddbe32e52d497ee848ae");
			} catch {
				LoadBIOS("b32526ea179dc9ab9b2e5f8a2662b298");
				Log.Msg("WARNING: Using incorrect, but widely used, 7800 NTSC BIOS\n");
			}
			break;
		case MachineType.A7800PAL:
			LoadBIOS("397bb566584be7b9764e7a68974c4263");
			break;
		default:
			throw new Exception("Can't construct BIOS for non-7800 machine type");
		}
	}

	private void LoadBIOS(string md5sum) {
		ROM = null;

		foreach (FileInfo fi in new DirectoryInfo(EMU7800App.Instance.Settings.ROMDirectory).GetFiles()) {
			if (fi.Length != 4096 && fi.Length != 16384) {
				continue;
			}
			try {
				BinaryReader r = new BinaryReader(File.OpenRead(fi.FullName));
				ROM = r.ReadBytes((int)fi.Length);
				r.Close();
				if (md5sum != MD5.ComputeMD5Digest(ROM)) {
					ROM = null;
				}
			} catch {}
			if (ROM != null) {
				break;
			}
		}

		if (ROM == null) {
			throw new Exception(String.Format("7800 BIOS not found in ROM directory: {0}", EMU7800App.Instance.Settings.ROMDirectory));
		}

		Size = Mask = (ushort)ROM.Length;
		Mask--;
	}
}
}