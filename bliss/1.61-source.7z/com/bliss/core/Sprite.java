package com.bliss.core;

import java.awt.Rectangle;
import java.io.*;

public class Sprite
{

    void save(SaveOutputStream os) throws IOException {
        os.writeInt(xLocation);
        os.writeInt(yLocation);
        os.writeInt(foregroundColor);
        os.writeInt(cardNumber);
        os.writeBoolean(isGrom);
        os.writeBoolean(isVisible);
        os.writeBoolean(doubleWidth);
        os.writeBoolean(doubleYResolution);
        os.writeBoolean(doubleHeight);
        os.writeBoolean(quadHeight);
        os.writeBoolean(flagCollisions);
        os.writeBoolean(horizontalMirror);
        os.writeBoolean(verticalMirror);
        os.writeBoolean(behindForeground);
    }

    void load(LoadInputStream is) throws IOException {
        xLocation = is.readInt(0x00, 0xFF);
        yLocation = is.readInt(0x00, 0x7F);
        foregroundColor = is.readInt(0x0, 0xF);
        cardNumber = is.readInt(0x00, 0xFF);
        isGrom = is.readBoolean();
        isVisible = is.readBoolean();
        doubleWidth = is.readBoolean();
        doubleYResolution = is.readBoolean();
        doubleHeight = is.readBoolean();
        quadHeight = is.readBoolean();
        flagCollisions = is.readBoolean();
        horizontalMirror = is.readBoolean();
        verticalMirror = is.readBoolean();
        behindForeground = is.readBoolean();

        //now we're dirty
        changed = true;
        boundsChanged = true;
    }

    protected void reset() {
        xLocation         = 0;
        yLocation         = 0;
        foregroundColor   = 0;
        cardNumber        = 0;
        collisionRegister = 0;
        isGrom            = false;
        isVisible         = false;
        doubleWidth       = false;
        doubleYResolution = false;
        doubleHeight      = false;
        quadHeight        = false;
        flagCollisions    = false;
        horizontalMirror  = false;
        verticalMirror    = false;
        behindForeground  = false;
        boundingRectangle.x = 0;
        boundingRectangle.y = 0;
        boundingRectangle.width = 0;
        boundingRectangle.height = 0;
        changed           = true;
        boundsChanged     = true;
    }

    protected void setXLocation(int xLocation) {
        if (xLocation == this.xLocation)
            return;

        this.xLocation = xLocation;
        boundsChanged = true;
        changed = true;
    }

    protected void setYLocation(int yLocation) {
        if (yLocation == this.yLocation)
            return;

        this.yLocation = yLocation;
        boundsChanged = true;
        changed = true;
    }

/*
    protected int getYLocation() {
        return yLocation;
    }
*/

    protected void setForegroundColor(int foregroundColor) {
        if (foregroundColor == this.foregroundColor)
            return;

        this.foregroundColor = foregroundColor;
        changed = true;
    }

/*
    protected int getForegroundColor() {
        return foregroundColor;
    }
*/

    protected void setCardNumber(int cardNumber) {
        if (cardNumber == this.cardNumber)
            return;

        this.cardNumber = cardNumber;
        changed = true;
    }

/*
    protected int getCardNumber() {
        return cardNumber;
    }
*/

    protected void setVisible(boolean isVisible) {
        if (isVisible == this.isVisible)
            return;

        this.isVisible = isVisible;
        changed = true;
    }

/*
    protected boolean isVisible() {
        return isVisible;
    }
*/

    protected void setDoubleWidth(boolean doubleWidth) {
        if (doubleWidth == this.doubleWidth)
            return;

        this.doubleWidth = doubleWidth;
        boundsChanged = true;
        changed = true;
    }

/*
    protected boolean isDoubleWidth() {
        return doubleWidth;
    }
*/

    protected void setDoubleYResolution(boolean doubleYResolution) {
        if (doubleYResolution == this.doubleYResolution)
            return;

        this.doubleYResolution = doubleYResolution;
        boundsChanged = true;
        changed = true;
    }

/*
    protected boolean isDoubleYResolution() {
        return doubleYResolution;
    }
*/

    protected void setDoubleHeight(boolean doubleHeight) {
        if (doubleHeight == this.doubleHeight)
            return;

        this.doubleHeight = doubleHeight;
        boundsChanged = true;
        changed = true;
    }

/*
    protected boolean isDoubleHeight() {
        return doubleHeight;
    }
*/

    protected void setQuadHeight(boolean quadHeight) {
        if (quadHeight == this.quadHeight)
            return;

        this.quadHeight = quadHeight;
        boundsChanged = true;
        changed = true;
    }

/*
    protected boolean isQuadHeight() {
        return quadHeight;
    }
*/

    protected void setFlagCollisions(boolean flagCollisions) {
        if (flagCollisions == this.flagCollisions)
            return;

        this.flagCollisions = flagCollisions;
        changed = true;
    }

/*
    protected boolean isFlagCollisions() {
        return flagCollisions;
    }
*/

    protected void setHorizontalMirror(boolean horizontalMirror) {
        if (horizontalMirror == this.horizontalMirror)
            return;

        this.horizontalMirror = horizontalMirror;
        changed = true;
    }

/*
    protected boolean isHorizontalMirror() {
        return horizontalMirror;
    }
*/

    protected void setVerticalMirror(boolean verticalMirror) {
        if (verticalMirror == this.verticalMirror)
            return;

        this.verticalMirror = verticalMirror;
        changed = true;
    }

/*
    protected boolean isVerticalMirror() {
        return verticalMirror;
    }
*/

    protected void setBehindForeground(boolean behindForeground) {
        if (behindForeground == this.behindForeground)
            return;

        this.behindForeground = behindForeground;
        changed = true;
    }

    protected void setGROM(boolean grom) {
        if (grom == this.isGrom)
            return;

        this.isGrom = grom;
        changed = true;
    }

    protected void markClean() {
        changed = false;
    }

    protected Rectangle getBounds() {
        if (boundsChanged) {
            boundingRectangle.x = xLocation-8;
            boundingRectangle.y = yLocation-8;
            boundingRectangle.width = 8 * (doubleWidth ? 2 : 1);
            boundingRectangle.height = 4 * (quadHeight ? 4 : 1) *
                    (doubleHeight ? 2 : 1) * (doubleYResolution ? 2 : 1);
            boundsChanged = false;
        }
        return boundingRectangle;
    }

    //other classes should always use the accessor to get this variable
    private Rectangle boundingRectangle = new Rectangle();

    //these variables are made package-accessible so to offer a speed boost
    //to read them
    int     xLocation         = 0;
    int     yLocation         = 0;
    int     foregroundColor   = 0;
    int     cardNumber        = 0;
    int     collisionRegister = 0;
    boolean isGrom            = false;
    boolean isVisible         = false;
    boolean doubleWidth       = false;
    boolean doubleYResolution = false;
    boolean doubleHeight      = false;
    boolean quadHeight        = false;
    boolean flagCollisions    = false;
    boolean horizontalMirror  = false;
    boolean verticalMirror    = false;
    boolean behindForeground  = false;
    boolean boundsChanged     = true;
    boolean changed           = true;

}

