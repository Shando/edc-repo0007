/*
 * ControlPanelForm.cs
 * 
 * The main user interface form.
 * 
 * Copyright (c) 2003, 2004 Mike Murphy
 * 
 */

using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace EMU7800 {

public class ControlPanelForm : Form {
	public GameSettings CurrGameSettings;
	public bool HostRunning;
	public IHost H;
	public Machine M;
	public InputAdapter IA;
	public int FPSDelta, NumSoundBuffers;

	public bool StartButtonEnabled {
		set {
			btnStart.Enabled = value && !HostRunning;
		}
	}

	public bool ResumeButtonEnabled {
		set {
			btnResume.Enabled = value && M != null && !HostRunning;
		}
	}

	private TabControl tabControl;
	private Panel panel1, panel2;
	private Button btnStart, btnResume, btnQuit;

	public ControlPanelForm() {
		// Try to set the icon for the form, but don't bomb the application over it
		try {
			Icon = new Icon(Assembly.GetExecutingAssembly()
				.GetManifestResourceStream("EMU7800.Icon1.ico"));
		} catch {}

		Text = Globals.Title + " v" + Globals.Version + " Control Panel";
		ClientSize = new Size(340, 320);
		MinimumSize = ClientSize;
		MinimizeBox = false;
		MaximizeBox = false;
		ShowInTaskbar = false;
		TopMost = true;
		StartPosition = FormStartPosition.CenterScreen;
		SizeGripStyle = SizeGripStyle.Show;
		Opacity = Globals.Opacity;

		panel1 = new Panel();
		panel2 = new Panel();
		Controls.Add(panel1);
		Controls.Add(panel2);

		tabControl = new TabControl();
		panel1.Controls.Add(tabControl);
   
 		Size button_size = new Size(70, 25);

		btnStart = new Button();
		int x = 0;
		btnStart.Location = new Point(x, 0);
		btnStart.Size = button_size;
		btnStart.TabIndex = 0;
		btnStart.Text = "Start";
		btnStart.Enabled = false;
		btnStart.Click += new EventHandler(OnClickStart);

		btnResume = new Button();
		x += btnStart.Size.Width + 5;
		btnResume.Location = new Point(x, 0);
		btnResume.Size = button_size;
		btnResume.TabIndex = 1;
		btnResume.Text = "Resume";
		btnResume.Enabled = false;
		btnResume.Click += new EventHandler(OnClickResume);

		btnQuit = new Button();
		x += btnResume.Size.Width + 5;
		btnQuit.Location = new Point(x, 0);
		btnQuit.Size = button_size;
		btnQuit.TabIndex = 2;
		btnQuit.Text = "Quit";
		btnQuit.Click += new EventHandler(OnClickQuit);
		
		panel2.Controls.AddRange(new Control[] {btnStart, btnResume, btnQuit});
		
		tabControl.Controls.Add(new GameSelectPage(this));
		tabControl.Controls.Add(new SettingsPage(this));
		tabControl.Controls.Add(new GreenScreenPage(this));
				
		Layout += new LayoutEventHandler(OnLayout);
		Closing += new CancelEventHandler(OnClosing);

		IA = new InputAdapter();
		HostRunning = false;
		FPSDelta = 0;
		NumSoundBuffers = 10;
	}

	private void OnClosing(object sender, CancelEventArgs e) {
		if (HostRunning) {
			e.Cancel = true;
			Hide();
		}
	}

	private void OnClickStart(object sender, EventArgs e) {
		StartButtonEnabled = false;
		RunMachine();
		ResumeButtonEnabled = true;
	}

	private void OnClickResume(object sender, EventArgs e) {
		ResumeButtonEnabled = false;
		RunHost();
		ResumeButtonEnabled = true;
	}
	
	private void OnClickQuit(object sender, EventArgs e) {
		Application.Exit();
	}

	public void RunMachine() {
		if (HostRunning) {
			MessageBox.Show("Host Already Running", "Host Busy",
				MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		} else {
			GameSettings gs = CurrGameSettings;

			M = Machine.New(gs, Cart.New(gs), IA);
			M.Reset();

			RunHost();
		}
	}

	private void RunHost() {
		Hide();
		HostRunning = true;

		switch (Globals.HostSelect.ToUpper()) {
		case "SDL":
			H = new HostSDL(M, 160, NumSoundBuffers, FPSDelta, true);
			break;
		case "GDI":
			H = new HostGDI(this, M, 160, NumSoundBuffers, FPSDelta, false);
			break;
		default:
			Globals.HostSelect = "GDI";
			Globals.Save();
			H = new HostGDI(this, M, 160, NumSoundBuffers, FPSDelta, false);
			break;
		}

		try {
			H.Run();
		} catch (Exception e) {
			 MessageBox.Show(e.Message, "Host Exception",
				MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
		}

		H = null;
		HostRunning = false;

		IA = new InputAdapter();
		Show();
	}

	private void OnLayout(object sender, LayoutEventArgs e) {
		panel1.Location = new Point(0, 0);
		panel1.Size = new Size(Size.Width - 10, Size.Height - 60);

		tabControl.Location = new Point(0, 0);
		tabControl.Size = panel1.Size;

		panel2.Location = new Point(0, Size.Height - 55);
		panel2.Size = new Size(Size.Width - 25, 55);
	}
}
}