 /*
  * UAE - The Un*x Amiga Emulator
  *
  * Library of functions to make emulated filesystem as independent as
  * possible of the host filesystem's capabilities.
  * This is the Win32 version.
  *
  * Copyright 1997 Mathias Ortmann
  * Copyright 1999 Bernd Schmidt
  */

#include "sysconfig.h"
#include "sysdeps.h"

#include "fsdb.h"
#include "posixemu.h"

/* #define TRACING_ENABLED */
#ifdef TRACING_ENABLED
#define TRACE(x)	do { write_log x; } while(0)
#else
#define TRACE(x)
#endif

/* these are deadly (but I think allowed on the Amiga): */
#define NUM_EVILCHARS 8
char evilchars[NUM_EVILCHARS] = { '\\', '*', '?', '\"', '<', '>', '|', '~' };

/* Return nonzero for any name we can't create on the native filesystem.  */
int fsdb_name_invalid (const char *n)
{
    int i;
    char a = n[0];
    char b = (a == '\0' ? a : n[1]);
    char c = (b == '\0' ? b : n[2]);
    char d = (c == '\0' ? c : n[3]);

    // Convert the first three chars to uppercase, if necessary.
    if (a >= 'a' && a <= 'z')
        a -= 32;
    if (b >= 'a' && b <= 'z')
        b -= 32;
    if (c >= 'a' && c <= 'z')
        c -= 32;

    /* reserved dos devices */
    if( ( strcmp( n, "AUX" ) == 0 ) ||
	( strcmp( n, "CON" ) == 0 ) ||
	( strcmp( n, "PRN" ) == 0 ) ||
	( strcmp( n, "NUL" ) == 0 ) )
	return 1;

    if ((a == 'L' && b == 'P' && c == 'T'  && (d >= '0' && d <= '9'))    /* LPT# */
        || (a == 'C' && b == 'O' && c == 'M'  && (d >= '0' && d <= '9')))   /* COM# */
	return 1;

#if 1 /* Brian King, March 28, 2001 - There is nothing wrong in Windows for a ' ' or '.' at the
	 beginning of a filename, as long as its followed by something */
    if( ( (n[0] == '.' ) || ( n[0] == ' ' ) ) &&
	( n[1] == '\0' ) )
	return 1;
#else
    /* spaces and periods at the beginning or the end are a no-no */
    if (n[0] == '.' || n[0] == ' ')
	return 1;
#endif
    i = strlen(n) - 1;
    if (n[i] == '.' || n[i] == ' ')
	return 1;

    /* these characters are *never* allowed */
    for (i = 0; i < NUM_EVILCHARS; i++) {
        if (strchr (n, evilchars[i]) != 0)
            return 1;
    }

    /* the reserved fsdb filename */
    if (strcmp (n, FSDB_FILE) == 0)
	return 1;

    return 0; /* the filename passed all checks, now it should be ok */
}

/* For an a_inode we have newly created based on a filename we found on the
 * native fs, fill in information about this file/directory.  */
void fsdb_fill_file_attrs (a_inode *aino)
{
    struct stat statbuf;

    TRACE(("fsdb_fill_file_attrs for %s: ", aino->nname ));

    /* This really shouldn't happen...  */
    if (stat (aino->nname, &statbuf) != -1)
    {
	aino->dir = S_ISDIR (statbuf.st_mode) ? 1 : 0;
	aino->amigaos_mode = ((S_ISARC ( statbuf.st_mode ) ? 0 : A_FIBF_ARCHIVE)
			      | (S_IWUSR & statbuf.st_mode ? 0 : A_FIBF_WRITE)
			      | (S_IRUSR & statbuf.st_mode ? 0 : A_FIBF_READ));
	TRACE(("0x%x\n", aino->amigaos_mode));
    }
    else
    {
	TRACE(("failed!\n"));
    }
}

int fsdb_set_file_attrs (a_inode *aino, uae_u32 mask)
{
    struct stat statbuf;
    int result = 0;

    TRACE(("fsdb_set_file_attrs for %s: ", aino->nname ));

    if (stat (aino->nname, &statbuf) == -1)
    {
	result = ERROR_OBJECT_NOT_AROUND;
	TRACE(("stat failed!\n"));
    }
    else
    {
	if( !posixemu_chmod( aino->nname, mask ) )
	{
	    result = dos_errno();
	    TRACE(("chmod failed!\n"));
	}
	else
	{
	    aino->amigaos_mode = mask;
	    aino->dirty = 1;
	    TRACE(("success!\n"));
	}
    }
    return result;
}

/* Return nonzero if we can represent the amigaos_mode of AINO within the
 * native FS.  Return zero if that is not possible.  */
int fsdb_mode_representable_p (const a_inode *aino)
{
    if (aino->dir)
	return aino->amigaos_mode == 0;
    return (aino->amigaos_mode & (A_FIBF_DELETE | A_FIBF_SCRIPT | A_FIBF_PURE)) == 0;
}

char *fsdb_create_unique_nname (a_inode *base, const char *suggestion)
{
    char tmp[256];
    fname_atow(suggestion,tmp,sizeof tmp);

    for (;;) 
    {
	char *p = build_nname (base->nname, tmp);
	if (access (p, R_OK) < 0 && errno == ENOENT) 
	{
	    TRACE(("fsdb_create_unique_name for %s/%s: %s\n", base->nname, suggestion, p));
	    return p;
	}
	free (p);
    }
}
