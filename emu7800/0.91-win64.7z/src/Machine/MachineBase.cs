/*
 * MachineBase.cs
 * 
 * Abstraction of an emulated machine.
 * 
 * Copyright (c) 2003, 2004 Mike Murphy
 * 
 */
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using EMU7800.Host;

namespace EMU7800.Machine
{
    public enum MachineType
    {
        A2600NTSC,
        A2600PAL,
        A7800NTSC,
        A7800PAL
    };

    [Serializable]
    public abstract class MachineBase : IDisposable
    {
        #region Fields

        [NonSerialized]
        HostBase _H;

        [NonSerialized]
        byte[] _VideoFrameBuffer;

        [NonSerialized]
        byte[] _SoundFrameBuffer;

        int[] _Palette;
        bool _MachineHalt;
        int _FrameHZ;

        #endregion

        #region Public Properties

        public HostBase H { get { return _H; } protected set { _H = value; }}
        public M6502 CPU { get; protected set; }
        public AddressSpace Mem { get; protected set; }
        public PIA PIA { get; protected set; }

        public bool MachineHalt
        {
            get { return _MachineHalt; }
            set
            {
                if (value)
                {
                    _MachineHalt = true;
                }
            }
        }

        public InputAdapter InputAdapter { get; private set; }

        // Current frame number
        public long FrameNumber { get; private set; }

        // Number of scanlines on the display
        public int Scanlines { get; private set; }

        // Default starting scanline
        public int FirstScanline { get; private set; }

        // Frame rate
        public int FrameHZ
        {
            get { return _FrameHZ < 1 ? 1 : _FrameHZ; }
            set { _FrameHZ = value < 1 ? 1 : value; }
        }

        // ...in units of samples/sec
        public int SoundSampleRate { get; private set; }

        // Number of visible pixels on a single horizontal line
        public int VisiblePitch { get; private set; }

        // Returns byte array reference containing rendered pixels for the current frame
        // (x, y) indexed by [y * VisiblePitch + x]
        public byte[] VideoFrameBuffer
        {
            get
            {
                if (_VideoFrameBuffer == null)
                {
                    _VideoFrameBuffer = new byte[VisiblePitch*Scanlines];
                }
                return _VideoFrameBuffer;
            }
        }

        // Returns byte array reference containing rendered audio data for the current frame
        public byte[] SoundFrameBuffer
        {
            get
            {
                if (_SoundFrameBuffer == null)
                {
                    // two samples per scanline are generated
                    _SoundFrameBuffer = new byte[2*Scanlines];
                }
                return _SoundFrameBuffer;
            }
        }

        #endregion

        #region Public Methods

        public static MachineBase New(GameSettings gameSettings, Cart cart, InputAdapter ia)
        {
            if (gameSettings == null) throw new ArgumentNullException("gameSettings");
            if (cart == null) throw new ArgumentNullException("cart");
            if (ia == null) throw new ArgumentNullException("ia");

            MachineBase m;
            switch (gameSettings.MachineType)
            {
                case MachineType.A2600NTSC:
                    m = new Machine2600NTSC(cart, ia);
                    break;
                case MachineType.A2600PAL:
                    m = new Machine2600PAL(cart, ia);
                    break;
                case MachineType.A7800NTSC:
                    m = new Machine7800NTSC(cart, ia);
                    break;
                case MachineType.A7800PAL:
                    m = new Machine7800PAL(cart, ia);
                    break;
                default:
                    throw new ApplicationException("Unexpected machine type: " + gameSettings.MachineType);
            }

            m.InputAdapter.SetController(0, gameSettings.LController);
            m.InputAdapter.SetController(1, gameSettings.RController);

            m.Reset();

            return m;
        }

        public void Serialize(string fn)
        {
            using (var s = new FileStream(fn, FileMode.Create))
            {
                var f = new BinaryFormatter();
                f.Serialize(s, this);
            }
        }

        public static MachineBase Deserialize(string fn)
        {
            MachineBase m;
            using (var s = new FileStream(fn, FileMode.Open))
            {
                var f = new BinaryFormatter();
                m = (MachineBase)f.Deserialize(s);
            }
            return m;
        }

        public void AssignToHost(HostBase host)
        {
            if (host == null) throw new ArgumentNullException("host");
            H = host;
        }

        public void Reset()
        {
            FrameNumber = 0;
            _MachineHalt = false;
            InputAdapter.Reset();
            DoReset();
            Trace.Write("Machine ");
            Trace.Write(this);
            Trace.Write(" reset complete (");
            Trace.Write(FrameHZ);
            Trace.Write(" HZ  ");
            Trace.Write(Scanlines);
            Trace.WriteLine(" scanlines)");
        }

        public void RunFrame()
        {
            if (!MachineHalt)
            {
                InputAdapter.Checkpoint(FrameNumber);
                DoRunFrame();
                FrameNumber++;
            }
        }

        public int[] GetPalette()
        {
            return _Palette;
        }

        public void SetPalette(int[] palette)
        {
            _Palette = palette;
        }

        #endregion

        #region Abstract Members

        protected abstract void DoReset();
        protected abstract void DoRunFrame();

        #endregion

        #region Constructors

        private MachineBase()
        {
        }

        protected MachineBase(InputAdapter ia, int scanLines, int firstScanline, int fHZ, int soundSampleRate, int[] p, int vPitch) : this()
        {
            InputAdapter = ia;
            Scanlines = scanLines;
            FirstScanline = firstScanline;
            FrameHZ = fHZ;
            SoundSampleRate = soundSampleRate;
            SetPalette(p);
            VisiblePitch = vPitch;
        }

        #endregion

        public virtual void Dispose() { }

        #region CommandLine Members

        public virtual void ExecuteCommandLine(CommandLine cl)
        {
            if (cl.IsHelp)
            {
                Trace.WriteLine("\n** Machine Specific Commands **");
            }
            if (cl.CommandEquals("d"))
            {
                ClDisassemble(cl);
            }
            if (cl.CommandEquals("m"))
            {
                ClMemDump(cl);
            }
            if (cl.CommandEquals("poke"))
            {
                ClPokeMem(cl);
            }
            if (cl.CommandEquals("reset"))
            {
                ClReset(cl);
            }
            if (cl.CommandEquals("pc"))
            {
                ClSetProgramCounter(cl);
            }
            if (cl.CommandEquals("r"))
            {
                ClDumpRegisters(cl);
            }
            if (cl.CommandEquals("s"))
            {
                ClStepExecution(cl);
            }
        }

        void ClDisassemble(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" d <[$]fromaddr> [[$]toaddr]: disassemble memory");
                return;
            }
            if (cl.Parms.Count >= 3 && cl.CheckParms("sii"))
            {
                Trace.WriteLine(M6502DASM.Disassemble(Mem, (ushort)cl.Parms[1].IntValue, (ushort)cl.Parms[2].IntValue));
            }
            else if (cl.Parms.Count >= 2 && cl.CheckParms("si"))
            {
                Trace.WriteLine(M6502DASM.Disassemble(Mem, (ushort)cl.Parms[1].IntValue, (ushort)(cl.Parms[1].IntValue + 48)));
            }
            else
            {
                Trace.WriteLine("bad parms");
            }
        }

        void ClMemDump(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" m <[$]fromaddr> [[$]toaddr]: dump memory");
                return;
            }
            if (cl.Parms.Count >= 3 && cl.CheckParms("sii"))
            {
                Trace.WriteLine(M6502DASM.MemDump(Mem, (ushort)cl.Parms[1].IntValue, (ushort)cl.Parms[2].IntValue));
            }
            else if (cl.Parms.Count >= 2 && cl.CheckParms("si"))
            {
                Trace.WriteLine(M6502DASM.MemDump(Mem, (ushort)cl.Parms[1].IntValue, (ushort)cl.Parms[1].IntValue));
            }
            else
            {
                Trace.WriteLine("bad parms");
            }
        }

        void ClPokeMem(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" poke <[$]ataddr> <[$]dataval>: poke dataval to ataddr");
                return;
            }
            if (cl.Parms.Count < 3 || !cl.CheckParms("sii"))
            {
                Trace.WriteLine("bad parms");
                return;
            }
            Mem[(ushort)cl.Parms[1].IntValue] = (byte)cl.Parms[2].IntValue;
            Trace.WriteLine(string.Format("poke #${1:x2} at ${0:x4} complete", cl.Parms[1].IntValue, cl.Parms[2].IntValue));
        }

        void ClReset(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" reset: reset machine");
                return;
            }
            Reset();
        }

        void ClDumpRegisters(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" r: display CPU registers");
                return;
            }
            Trace.WriteLine(M6502DASM.GetRegisters(CPU));
        }

        void ClSetProgramCounter(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" pc <addr>: change CPU program counter");
                return;
            }
            if (cl.Parms.Count <= 1)
            {
                Trace.WriteLine(M6502DASM.GetRegisters(CPU));
            }
            else if (cl.CheckParms("si"))
            {
                CPU.PC = (ushort)cl.Parms[1].IntValue;
                Trace.WriteLine(String.Format("PC changed to {0:x4}", CPU.PC));
            }
            else
            {
                Trace.WriteLine("bad parm");
            }
        }

        void ClStepExecution(CommandLine cl)
        {
            if (cl.IsCommandHelp)
            {
                Trace.WriteLine(" s [#steps] [stop PC]: step CPU execution");
                return;
            }
            if (cl.CheckParms("si"))
            {
                _ClStepExecution(cl.Parms[1].IntValue, 0);
            }
            else if (cl.CheckParms("sii"))
            {
                _ClStepExecution(cl.Parms[1].IntValue, (ushort)cl.Parms[2].IntValue);
            }
            else
            {
                _ClStepExecution(1, 0);
            }
        }

        void _ClStepExecution(int steps, ushort stopPC)
        {
            var sb = new StringBuilder();
            sb.Append(M6502DASM.Disassemble(Mem, CPU.PC, (ushort)(CPU.PC+1)));
            sb.Append(M6502DASM.GetRegisters(CPU));
            sb.Append("\n");
            for (var i=0; i < steps && CPU.PC != stopPC; i++) 
            {
                CPU.RunClocks = 2;
                CPU.Execute();
                sb.Append(M6502DASM.Disassemble(Mem, CPU.PC, (ushort)(CPU.PC+1)));
                sb.Append(M6502DASM.GetRegisters(CPU));
                sb.Append("\n");
            }
            Trace.WriteLine(sb);
        }

        #endregion
    }
}
