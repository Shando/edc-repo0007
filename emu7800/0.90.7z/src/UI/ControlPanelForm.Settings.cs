﻿
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.Serialization;
using System.Windows.Forms;
using EMU7800.Machine;

namespace EMU7800.UI
{
    partial class ControlPanelForm
    {
        #region Event Handlers

        void buttonLoadMachineState_Click(object sender, EventArgs e)
        {
            var openfiledialogFileSelect = new OpenFileDialog
            {
                Title = "Select EMU Machine State",
                Filter = "Machine States (*.emu)|*.emu",
                FilterIndex = 1,
                InitialDirectory = GlobalSettings.Instance.OutputDirectory
            };

            if (openfiledialogFileSelect.ShowDialog() != DialogResult.OK) return;

            StartButtonEnabled = false;
            ResumeButtonEnabled = false;
            CurrGameSettings = null;
            try
            {
                M = MachineBase.Deserialize(openfiledialogFileSelect.FileName);
            }
            catch (SerializationException ex)
            {
                Trace.WriteLine("error restoring machine state: " + ex);
                return;
            }
            catch (IOException ex)
            {
                Trace.WriteLine("error restoring machine state: " + ex);
                return;
            }

            ResumeButtonEnabled = true;
            ResetGameTitleLabel();
            Trace.WriteLine("machine state restored");
        }

        void comboboxHostSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            GlobalSettings.Instance.HostSelect = comboboxHostSelect.SelectedItem as string;
        }

        void tabpageSettings_Selected(object sender, TabControlEventArgs e)
        {
            // databinding doesn't appear to work in reverse
            if (numericupdownFrameRateAdjust.Value != GlobalSettings.Instance.FrameRateAdjust)
            {
                numericupdownFrameRateAdjust.Value = GlobalSettings.Instance.FrameRateAdjust;
            }
        }

        #endregion
    }
}
