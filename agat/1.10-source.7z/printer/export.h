
int  export_raw_init(struct EPSON_EXPORT*exp, unsigned flags, HWND wnd);
int  export_text_init(struct EPSON_EXPORT*exp, unsigned flags, HWND wnd);
#define EXPORT_TIFF_COMPRESS_RLE	1
int  export_tiff_init(struct EPSON_EXPORT*exp, unsigned flags, HWND wnd);
int  export_print_init(struct EPSON_EXPORT*exp, unsigned flags, HWND wnd);
