/*
 * HostSDL
 * 
 * An SDL-based host
 * 
 * Copyright (c) 2004 Mike Murphy
 * 
 */

using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Security;

namespace EMU7800 {

public class HostSDL : IHost {
	private const int WIDTH = 320, HEIGHT = 240;
	private Machine M;

	private uint[] FrameBuffer;
	private SDLSurface BackSurface, FrontSurface;
	private int EffectiveFPS, SoundSampleRate;
	private int VisiblePitch, NumSoundBuffers;
	private bool Fullscreen;
	private int ClipStart, LeftOffset;
	private int PanX, PanY;

	private int KeyboardPlayerNo;
	private int[] JoystickPlayerNo = new int[4];
	private IntPtr[] Joystick = new IntPtr[4];
	private int[] PaddleOhms = new int[4];
	private int[] PaddleVels = new int[4];

	private FontRenderer FontRenderer;
	private string textMsg;
	private string TextMsg {
		get {
			return textMsg;
		}
		set {
			textMsg = value;
			if (textMsg != null) {
				TextExpireFrameCount = M.FrameNumber + 3*M.FrameHZ;
			}
		}
	}
	private long TextExpireFrameCount;
	private bool JoyEventShow;

	private bool Quit, Paused, Mute;

	private double FPS;
	private uint FrameStartTicks;
	private const uint FrameSamples = 120;

	public HostSDL(Machine m, int visiblePitch, int numSoundBuffers, int fpsDelta, bool fullscreen) {
		M = m;
		M.H = this;

		VisiblePitch = visiblePitch;
		NumSoundBuffers = numSoundBuffers;
		EffectiveFPS = M.FrameHZ + fpsDelta;
		SoundSampleRate = M.SoundSampleRate*EffectiveFPS/M.FrameHZ;
		Fullscreen = fullscreen;

		ClipStart = M.FirstScanline;
		LeftOffset = 0;

		FrameBuffer = new uint[VisiblePitch*M.Scanlines];
		FontRenderer = new FontRenderer(FrameBuffer, VisiblePitch, M.Palette, 0);

		for (int i=0; i < 4; i++) {
			JoystickPlayerNo[i] = i;
			PaddleOhms[i] = InputAdapter.PADDLEOHM_MIN;
			PaddleVels[0] = 0;
		}

		SDLNatives.SDL_version v = SDLVersion.Version;
		Log.Msg("Simple DirectMedia Layer v{0}.{1}.{2} detected\n",
			v.major, v.minor, v.patch);
	}

	public void Run() {
		if (SDLNatives.SDL_Init(0) == -1) {
			goto error;
		}

		if (SDLNatives.SDL_InitSubSystem((int)SDLNatives.Init.Video) != 0) {
			goto error;
		}
		FrontSurface = SDLVideo.SetVideoMode(WIDTH, HEIGHT, Fullscreen);
		if (FrontSurface == null) {
			goto error;
		}

		BackSurface = FrontSurface.CreateCompatibleSDLSurface(WIDTH, HEIGHT, true);
		if (BackSurface == null) {
			goto error;
		} 
		BackSurface.FillRect(Color.Black);

		SDLNatives.SDL_WM_SetCaption(Globals.Title + " v" + Globals.Version, "");
		SDLNatives.SDL_ShowCursor((int)SDLNatives.Enable.Disable);

		if (SDLNatives.SDL_InitSubSystem((int)SDLNatives.Init.Joystick) != 0) {
			goto error;
		}
		int noJoysticks = SDLNatives.SDL_NumJoysticks();
		if (noJoysticks > 0) {
			Log.Msg("{0} joystick{1} found:\n",
				noJoysticks, (noJoysticks != 1 ? "s" : ""));
			for (int i=0; i < noJoysticks; i++) {
				Log.Msg("{0}: {1}\n", i, SDLNatives.SDL_JoystickName(i));
			}
			OpenJoystick(0);
			if (noJoysticks > 1) {
				OpenJoystick(1);
			}
			if (noJoysticks > 2) {
				OpenJoystick(2);
			}
			if (noJoysticks > 3) {
				OpenJoystick(3);
			}
		}

		SDLEvents.Quit += new QuitEventHandler(OnQuit);
		SDLEvents.Keyboard += new KeyboardEventHandler(OnKeyboard);
		SDLEvents.JoyButton += new JoyButtonEventHandler(OnJoyButton);
		SDLEvents.JoyAxis += new JoyAxisEventHandler(OnJoyAxis);
		SDLEvents.MouseButton += new MouseButtonEventHandler(OnMouseButton);
		SDLEvents.MouseMotion += new MouseMotionEventHandler(OnMouseMotion);

Audio.winmmOpen(SoundSampleRate, M.Scanlines << 1, NumSoundBuffers);
//Audio.sdlOpen(SoundSampleRate, M.Scanlines << 1, NumSoundBuffers);

		while (true) {
			while (SDLEvents.PollAndDelegate() > 0) {}

			if (Quit) {
				goto exit;
			}

			if (M.FrameNumber % FrameSamples == 0) {
				uint sdlticks = SDLNatives.SDL_GetTicks();
				double avgticks = (sdlticks - FrameStartTicks);
				avgticks /= FrameSamples;
				FPS = 1000.0/avgticks;
				FrameStartTicks = sdlticks;
			}

			UpdatePaddles();
			M.Run();
			if (RenderFrame() < 0) {
				goto error;
			}

			if (Paused) {
				if (SDLEvents.PauseWait() < 0) {
					goto error;
				}
				TextMsg = "Resumed";
				Paused = false;
			}
		}

error:
		Log.Msg("SDLHost: ERROR: {0}\n", SDLNatives.SDL_GetError());
exit:
Audio.winmmClose();
//Audio.sdlClose();
		for (int i=0; i < 4; i++) {
			SDLNatives.SDL_JoystickClose(Joystick[i]);
		}
		if (BackSurface != null) {
			BackSurface.Dispose();
		}
		if (FrontSurface != null) {
			FrontSurface.Dispose();
		}
		SDLNatives.SDL_Quit();
	}

	private void OpenJoystick(int device) {
		Joystick[device] = SDLNatives.SDL_JoystickOpen(device);
		Log.Msg("Joystick {0} assigned to player {1} ({2} axes {3} buttons)\n",
			device, JoystickPlayerNo[device] + 1,
			SDLNatives.SDL_JoystickNumAxes(Joystick[device]),
			SDLNatives.SDL_JoystickNumButtons(Joystick[device]));
	}

	private void UpdatePaddles() {
		for (int i=0; i < 4; i++) {
			int ohms = PaddleOhms[i];
			ohms += 16384*PaddleVels[i];
			if (ohms < InputAdapter.PADDLEOHM_MIN)
				ohms = InputAdapter.PADDLEOHM_MIN;
			if (ohms > InputAdapter.PADDLEOHM_MAX)
				ohms = InputAdapter.PADDLEOHM_MAX;
			PaddleOhms[i] = ohms;
			M.InputAdapter.SetOhms(i, ohms);
		}
	}

	private unsafe int RenderFrame() {
		if (PanX < 0) {
			LeftOffset++;
			BackSurface.FillRect(Color.Black);
			if (LeftOffset > 300) {
				LeftOffset = 300;
			}
		}
		if (PanX > 0) {
			LeftOffset--;
			BackSurface.FillRect(Color.Black);
			if (LeftOffset < -300) {
				LeftOffset = -300;
			}
		}
		if (PanY < 0) {
			ClipStart++;
			BackSurface.FillRect(Color.Black);
			if (ClipStart > 300) {
				ClipStart = 300;
			}
		}
		if (PanY > 0) {
			ClipStart--;
			BackSurface.FillRect(Color.Black);
			if (ClipStart < -300) {
				ClipStart = -300;
			}
		}

		if (TextExpireFrameCount > M.FrameNumber) {
			FontRenderer.DrawText(TextMsg, 5, ClipStart + 4, 10, 0);
		}

		BackSurface.Lock();
		uint *tptr = (uint *)BackSurface.Pixels.ToPointer();
		int si = ClipStart*VisiblePitch + LeftOffset;
		if (tptr != null) {
			uint *yptr;
			for (int i=0; i < HEIGHT; i++) {
				while (si < 0) {
					si += FrameBuffer.Length;
				}
				yptr = tptr;
				for (int j=0; j < VisiblePitch; j++) {
					while (si >= FrameBuffer.Length) {
						si -= FrameBuffer.Length;
					}
					*yptr++ = *yptr++ = FrameBuffer[si++];
				}
				tptr += (BackSurface.Pitch >> 2);
			}
		}
		BackSurface.Unlock();

		if (BackSurface.Blit(FrontSurface) < 0) {
			return -1;
		}
		if (FrontSurface.Flip() < 0) {
			return -1;
		}
		return 0;
	}

	private void OnQuit() {
		Quit = true;
	}

	private void OnJoyButton(int device, int button, bool down) {
		InputAdapter ia = M.InputAdapter;

		if (button == Globals.JoyBTrigger) {
			ia[JoystickPlayerNo[device], ControllerAction.Trigger] = down;
		} else if (button == Globals.JoyBBooster) {
			ia[JoystickPlayerNo[device], ControllerAction.Booster] = down;
		} else if (device > 0) {
			;
		} else if (button == Globals.JoyBSwap && down) {
			ClearPlayerInput(0);
			ClearPlayerInput(1);
			int tmp = JoystickPlayerNo[0];
			JoystickPlayerNo[0] = JoystickPlayerNo[1];
			JoystickPlayerNo[1] = tmp;
			TextMsg = "P1/P2 Joysticks Swapped";
		} else if (button == Globals.JoyBReset) {
			ia[ConsoleSwitch.GameReset] = down;
		} else if (button == Globals.JoyBSelect) {
			ia[ConsoleSwitch.GameSelect] = down;
		}

		if (JoyEventShow && down) {
			TextMsg = String.Format("Joy:{0} Button:{1}", device, button);
			JoyEventShow = false;
		}
	}

	private void OnJoyAxis(int device, int axis, int val) {
		InputAdapter ia = M.InputAdapter;

		if (axis == 0) {
			ia[JoystickPlayerNo[device], ControllerAction.Left] = val < -8192;
			ia[JoystickPlayerNo[device], ControllerAction.Right] = val > 8192;
			if (val >= -8192 && val <= 8192) {
				PaddleVels[device] = 0;
			} else if (val < -8192) {
				PaddleVels[device] = 1;
			} else {
				PaddleVels[device] = -1;
			}
		}

		if (axis == 1) {
			ia[JoystickPlayerNo[device], ControllerAction.Up] = val < -8192;
			ia[JoystickPlayerNo[device], ControllerAction.Down] = val > 8192;
		}

		if (JoyEventShow) {
			TextMsg = String.Format("Joy:{0} Axis:{1} Val:{2}", device, axis, val);
			JoyEventShow = false;
		}
	}

	private void OnKeyboard(int device, bool down, int scancode, SDLKey key, SDLMod mod) {
		InputAdapter ia = M.InputAdapter;

		switch(key) {
		case SDLKey.K_ESCAPE:
			Quit = true;
			break;
		case SDLKey.K_LCTRL:
		case SDLKey.K_RCTRL:
			ia[KeyboardPlayerNo, ControllerAction.Trigger] = down;
			break;
		case SDLKey.K_LALT:
		case SDLKey.K_RALT:
			ia[KeyboardPlayerNo, ControllerAction.Booster] = down;
			break;
		case SDLKey.K_LEFT:
			ia[KeyboardPlayerNo, ControllerAction.Left] = down;
			PaddleVels[device] += down ? 1 : -1;
			break;
		case SDLKey.K_UP:
			ia[KeyboardPlayerNo, ControllerAction.Up] = down;
			break;
		case SDLKey.K_RIGHT:
			ia[KeyboardPlayerNo, ControllerAction.Right] = down;
			PaddleVels[device] += down ? -1 : 1;
			break;
		case SDLKey.K_DOWN:
			ia[KeyboardPlayerNo, ControllerAction.Down] = down;
			break;
		case SDLKey.K_KP7:
			ia[KeyboardPlayerNo, ControllerAction.Keypad7] = down;
			break;
		case SDLKey.K_KP8:
			ia[KeyboardPlayerNo, ControllerAction.Keypad8] = down;
			break;
		case SDLKey.K_KP9:
			ia[KeyboardPlayerNo, ControllerAction.Keypad9] = down;
			break;
		case SDLKey.K_KP4:
			ia[KeyboardPlayerNo, ControllerAction.Keypad4] = down;
			break;
		case SDLKey.K_KP5:
			ia[KeyboardPlayerNo, ControllerAction.Keypad5] = down;
			break;
		case SDLKey.K_KP6:
			ia[KeyboardPlayerNo, ControllerAction.Keypad6] = down;
			break;
		case SDLKey.K_KP1:
			ia[KeyboardPlayerNo, ControllerAction.Keypad1] = down;
			break;
		case SDLKey.K_KP2:
			ia[KeyboardPlayerNo, ControllerAction.Keypad2] = down;
			break;
		case SDLKey.K_KP3:
			ia[KeyboardPlayerNo, ControllerAction.Keypad3] = down;
			break;
		case SDLKey.K_KP_MULTIPLY:
			ia[KeyboardPlayerNo, ControllerAction.KeypadA] = down;
			break;
		case SDLKey.K_KP0:
			ia[KeyboardPlayerNo, ControllerAction.Keypad0] = down;
			break;
		case SDLKey.K_KP_DIVIDE:
			ia[KeyboardPlayerNo, ControllerAction.KeypadP] = down;
			break;
		case SDLKey.K_1:
			if (down) {
				ia[ConsoleSwitch.LDifficultyA] = !ia[ConsoleSwitch.LDifficultyA];
				TextMsg = "Left Difficulty: "
				+ (ia[ConsoleSwitch.LDifficultyA] ? "A (Pro)" : "B (Novice)");
			}
			break;
		case SDLKey.K_2:
			if (down) {
				ia[ConsoleSwitch.RDifficultyA] = !ia[ConsoleSwitch.RDifficultyA];
				TextMsg = "Right Difficulty: "
				+ (ia[ConsoleSwitch.RDifficultyA] ? "A (Pro)" : "B (Novice)");
			}
			break;
		case SDLKey.K_p:
			if (down) {
				Paused = true;
				TextMsg = "Paused";
			}
			break;
		case SDLKey.K_F1:
			if (down) {
				ClearPlayerInput(KeyboardPlayerNo);
				KeyboardPlayerNo = 0;
				TextMsg = "Keyboard Switched to Player 1";
			}
			break;
		case SDLKey.K_F2:
			if (down) {
				ClearPlayerInput(KeyboardPlayerNo);
				KeyboardPlayerNo = 1;
				TextMsg = "Keyboard Switched to Player 2";
			}
			break;
		case SDLKey.K_F3:
			if (down) {
				ClearPlayerInput(KeyboardPlayerNo);
				KeyboardPlayerNo = 2;
				TextMsg = "Keyboard Switched to Player 3";
			}
			break;
		case SDLKey.K_F4:
			if (down) {
				ClearPlayerInput(KeyboardPlayerNo);
				KeyboardPlayerNo = 3;
				TextMsg = "Keyboard Switched to Player 4";
			}
			break;
		case SDLKey.K_F5:
			PanX = down ? -1 : 0;
			break;
		case SDLKey.K_F6:
			PanX = down ? 1 : 0;
			break;
		case SDLKey.K_F7:
			PanY = down ? -1 : 0;
			break;
		case SDLKey.K_F8:
			PanY = down ? 1 : 0;
			break;
		case SDLKey.K_F12:
			if (down) {
				string fn = String.Format("{0}\\screenshot-{1:yyyy}{1:MM}{1:dd}-{1:HH}{1:mm}{1:ss}.bmp",
					Globals.OutputDirectory, DateTime.Now);
				if (FrontSurface.SaveBMP(fn) < 0) {
					Log.Msg("screenshot save failure: {0}\n", SDLNatives.SDL_GetError());
				} else {
					Log.Msg("screenshot saved to {0}\n", fn);
					TextMsg = "Screenshot Saved";
				}
			}
			break;
		case SDLKey.K_c:
			if (down) {
				ia[ConsoleSwitch.GameBW] = !ia[ConsoleSwitch.GameBW];
				TextMsg = ia[ConsoleSwitch.GameBW] ? "B/W" : "Color";
			}
			break;
		case SDLKey.K_f:
			if (down) {
				TextMsg = String.Format("{0:#.0}/{1} FPS\n",
					FPS, EffectiveFPS);
			}
			break;
		case SDLKey.K_j:
			if (down) {
				TextMsg = "Showing Next Joystick Event...";
				JoyEventShow = true;
			}
			break;
		case SDLKey.K_m:
			if (down) {
				Mute = !Mute;
				TextMsg = Mute ? "Mute On" : "Mute Off";
			}
			break;
		case SDLKey.K_r:
			ia[ConsoleSwitch.GameReset] = down;
			break;
		case SDLKey.K_s:
			ia[ConsoleSwitch.GameSelect] = down;
			break;
		case SDLKey.K_w:
			if (down) {
				ClearPlayerInput(0);
				ClearPlayerInput(1);
				int tmp = JoystickPlayerNo[0];
				JoystickPlayerNo[0] = JoystickPlayerNo[1];
				JoystickPlayerNo[1] = tmp;
				TextMsg = "P1/P2 Joysticks Swapped";
			}
			break;
		}
	}

	private void OnMouseButton(int device, bool down, SDLMouseButton button, int x, int y) {
		M.InputAdapter[KeyboardPlayerNo, ControllerAction.Trigger] = down;
	}

	private void OnMouseMotion(bool down, int x, int y, int xrel, int yrel) {
		int ohms = InputAdapter.PADDLEOHM_MAX
			- (InputAdapter.PADDLEOHM_MAX - InputAdapter.PADDLEOHM_MIN)
			/ WIDTH * x;
		PaddleOhms[KeyboardPlayerNo] = ohms;
		M.InputAdapter.SetOhms(KeyboardPlayerNo, ohms);
	}

	private void ClearPlayerInput(int playerno) {
		InputAdapter ia = M.InputAdapter;

		PaddleVels[playerno] = 0;
		ia[playerno, ControllerAction.Trigger] = false;
		ia[playerno, ControllerAction.Booster] = false;
		ia[playerno, ControllerAction.Left] = false;
		ia[playerno, ControllerAction.Up] = false;
		ia[playerno, ControllerAction.Right] = false;
		ia[playerno, ControllerAction.Down] = false;
		ia[playerno, ControllerAction.Keypad7] = false;
		ia[playerno, ControllerAction.Keypad8] = false;
		ia[playerno, ControllerAction.Keypad9] = false;
		ia[playerno, ControllerAction.Keypad4] = false;
		ia[playerno, ControllerAction.Keypad5] = false;
		ia[playerno, ControllerAction.Keypad6] = false;
		ia[playerno, ControllerAction.Keypad1] = false;
		ia[playerno, ControllerAction.Keypad2] = false;
		ia[playerno, ControllerAction.Keypad3] = false;
		ia[playerno, ControllerAction.KeypadA] = false;
		ia[playerno, ControllerAction.Keypad0] = false;
		ia[playerno, ControllerAction.KeypadP] = false;
	}

	public void UpdateDisplay(byte[] buf, int scanline, int xstart, int len) {
		int i = scanline*VisiblePitch + xstart;
		int x = xstart;
		while (len-- > 0) {
			FrameBuffer[i++] = (uint)M.Palette[buf[x++]] | (uint)0xff000000;
		}
	}

	public void UpdateSound(byte[] buf) {
		if (Mute) {
			for (int i=0; i < buf.Length; i++) {
				buf[i] = 0;
			}
		}
Audio.winmmEnqueueAndWait(buf);
//Audio.sdlEnqueueAndWait(buf);
	}
}

/*
 * Most of these enumerations, structures, and DLL imports
 * have been taken from SDL.NET by Will Weisser (ogl@9mm.com)
 */
public enum SDLKey {
	K_UNKNOWN	= 0,
	K_FIRST		= 0,
	K_BACKSPACE	= 8,
	K_TAB		= 9,
	K_CLEAR		= 12,
	K_RETURN	= 13,
	K_PAUSE		= 19,
	K_ESCAPE	= 27,
	K_SPACE		= 32,
	K_EXCLAIM	= 33,
	K_QUOTEDBL	= 34,
	K_HASH		= 35,
	K_DOLLAR	= 36,
	K_AMPERSAND	= 38,
	K_QUOTE		= 39,
	K_LEFTPAREN	= 40,
	K_RIGHTPAREN    = 41,
	K_ASTERISK	= 42,
	K_PLUS		= 43,
	K_COMMA		= 44,
	K_MINUS		= 45,
	K_PERIOD	= 46,
	K_SLASH		= 47,
	K_0		= 48,
	K_1		= 49,
	K_2		= 50,
	K_3		= 51,
	K_4		= 52,
	K_5		= 53,
	K_6		= 54,
	K_7		= 55,
	K_8		= 56,
	K_9		= 57,
	K_COLON		= 58,
	K_SEMICOLON	= 59,
	K_LESS		= 60,
	K_EQUALS	= 61,
	K_GREATER	= 62,
	K_QUESTION	= 63,
	K_AT		= 64,
	K_LEFTBRACKET	= 91,
	K_BACKSLASH	= 92,
	K_RIGHTBRACKET	= 93,
	K_CARET		= 94,
	K_UNDERSCORE	= 95,
	K_BACKQUOTE	= 96,
	K_a		= 97,
	K_b		= 98,
	K_c		= 99,
	K_d		= 100,
	K_e		= 101,
	K_f		= 102,
	K_g		= 103,
	K_h		= 104,
	K_i		= 105,
	K_j		= 106,
	K_k		= 107,
	K_l		= 108,
	K_m		= 109,
	K_n		= 110,
	K_o		= 111,
	K_p		= 112,
	K_q		= 113,
	K_r		= 114,
	K_s		= 115,
	K_t		= 116,
	K_u		= 117,
	K_v		= 118,
	K_w		= 119,
	K_x		= 120,
	K_y		= 121,
	K_z		= 122,
	K_DELETE	= 127,
	K_KP0		= 256,
	K_KP1		= 257,
	K_KP2		= 258,
	K_KP3		= 259,
	K_KP4		= 260,
	K_KP5		= 261,
	K_KP6		= 262,
	K_KP7		= 263,
	K_KP8		= 264,
	K_KP9		= 265,
	K_KP_PERIOD	= 266,
	K_KP_DIVIDE	= 267,
	K_KP_MULTIPLY	= 268,
	K_KP_MINUS	= 269,
	K_KP_PLUS	= 270,
	K_KP_ENTER	= 271,
	K_KP_EQUALS	= 272,
	K_UP		= 273,
	K_DOWN		= 274,
	K_RIGHT		= 275,
	K_LEFT		= 276,
	K_INSERT	= 277,
	K_HOME		= 278,
	K_END		= 279,
	K_PAGEUP	= 280,
	K_PAGEDOWN	= 281,
	K_F1		= 282,
	K_F2		= 283,
	K_F3		= 284,
	K_F4		= 285,
	K_F5		= 286,
	K_F6		= 287,
	K_F7		= 288,
	K_F8		= 289,
	K_F9		= 290,
	K_F10		= 291,
	K_F11		= 292,
	K_F12		= 293,
	K_F13		= 294,
	K_F14		= 295,
	K_F15		= 296,
	K_NUMLOCK	= 300,
	K_CAPSLOCK	= 301,
	K_SCROLLOCK	= 302,
	K_RSHIFT	= 303,
	K_LSHIFT	= 304,
	K_RCTRL		= 305,
	K_LCTRL		= 306,
	K_RALT		= 307,
	K_LALT		= 308,
	K_RMETA		= 309,
	K_LMETA		= 310,
	K_LSUPER	= 311,
	K_RSUPER	= 312,
	K_MODE		= 313,
	K_COMPOSE	= 314,
	K_HELP		= 315,
	K_PRINT		= 316,
	K_SYSREQ	= 317,
	K_BREAK		= 318,
	K_MENU		= 319,
	K_POWER		= 320,
	K_EURO		= 321,
	K_UNDO		= 322
}

public enum SDLMod {
	None		= 0x0000,
	LShift		= 0x0001,
	RShift		= 0x0002,
	LCtrl		= 0x0040,
	RCtrl		= 0x0080,
	LAlt		= 0x0100,
	RAlt		= 0x0200,
	LMeta		= 0x0400,
	RMeta		= 0x0800,
	Num		= 0x1000,
	Caps		= 0x2000,
	Mode		= 0x4000
}

public enum SDLMouseButton {
	Left		= 1,
	Middle		= 2,
	Right		= 3,
	WheelUp		= 4,
	WheelDown	= 5
}

public enum SDLHatPos {
	Center		= 0,
	Up		= 1,
	UpRight		= 3,
	Right		= 2,
	DownRight	= 6,
	Down		= 4,
	DownLeft	= 12,
	Left		= 8,
	UpLeft		= 9
}

unsafe class SDLNatives {
	public enum Init {
		Timer = 0x00000001,
		Audio = 0x00000010,
		Video = 0x00000020,
		Cdrom = 0x00000100,
		Joystick = 0x00000200
	}
	public enum Video {
		SWSurface = 0x00000000,
		HWSurface = 0x00000001,
		AsyncBlit = 0x00000004,
		AnyFormat = 0x10000000,
		HWPallete = 0x20000000,
		DoubleBuf = 0x40000000,
		FullScreen = -0x7FFFFFFF,
		OpenGL = 0x00000002,
		OpenGLBlit = 0x0000000A,
		Resizable = 0x00000010,
		NoFrame = 0x00000020,
		RLEAccel = 0x00004000
	}
	public enum AudioFormat {
		AUDIO_U8 = 0x0008,	 // Unsigned 8-bit samples
		AUDIO_S8 = 0x8008,	 // Signed 8-bit samples
		AUDIO_U16LSB = 0x0010,	 // Unsigned 16-bit samples
		AUDIO_S16LSB = 0x8010,	 // Signed 16-bit samples
		AUDIO_U16MSB = 0x1010,	 // As above, but big-endian byte order
		AUDIO_S16MSB = 0x9010,	 // As above, but big-endian byte order
		AUDIO_U16 = AUDIO_U16LSB,
		AUDIO_S16 = AUDIO_S16LSB
	}
	public enum Event {
		NOEVENT = 0,
		ACTIVEEVENT,
		KEYDOWN,
		KEYUP,
		MOUSEMOTION,
		MOUSEBUTTONDOWN,
		MOUSEBUTTONUP,
		JOYAXISMOTION,
		JOYBALLMOTION,
		JOYHATMOTION,
		JOYBUTTONDOWN,
		JOYBUTTONUP,
		QUIT,
		SYSWMEVENT,
		EVENT_RESERVEDA,
		EVENT_RESERVEDB,
		VIDEORESIZE,
		VIDEOEXPOSE,
		EVENT_RESERVED2,
		EVENT_RESERVED3,
		EVENT_RESERVED4,
		EVENT_RESERVED5,
		EVENT_RESERVED6,
		EVENT_RESERVED7,
		USEREVENT = 24,
		NUMEVENTS = 32
	}
	public enum Enable {
		Query = -1,
		Ignore = 0,
		Disable = 0,
		Enable = 1
	}
	public enum ColorKey {
		SrcColorKey = 0x00001000,
		RLEAccelOK = 0x00002000
	}
	public enum State {
		Pressed = 1,
		Released = 0
	}
	public enum Focus {
		MouseFocus = 1,
		InputFocus = 2,
		AppActive = 4
	}
	public enum GrabInput {
		Query = -1,
		Off = 0,
		On = 1
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_Rect {
		public SDL_Rect(System.Drawing.Rectangle r) {
			x = (short)r.X;
			y = (short)r.Y;
			w = (ushort)r.Width;
			h = (ushort)r.Height;
		}
		public short x, y;
		public ushort w, h;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_PixelFormat {
		public IntPtr palette;
		public byte BitsPerPixel;
		public byte BytesPerPixel;
		public byte Rloss;
		public byte Gloss;
		public byte Bloss;
		public byte Aloss;
		public byte Rshift;
		public byte Gshift;
		public byte Bshift;
		public byte Ashift;
		public uint Rmask;
		public uint Gmask;
		public uint Bmask;
		public uint Amask;
		public uint colorkey;
		public byte alpha;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_Surface {
		public uint flags;
		public SDL_PixelFormat *format;
		public int w, h;
		public ushort pitch;
		public IntPtr pixels;
		public int offset;
		public IntPtr hwdata;
		public SDL_Rect clip_rect;
		public uint unused1;
		public uint locked;
		public IntPtr map;
		public uint format_version;
		public int refcount;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_keysym {
		public byte scancode;
		public int sym;
		public int mod;
		public ushort unicode;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_Event {
		public byte type;
		public IntPtr d1;
		public IntPtr d2;
		public IntPtr d3;
		public IntPtr d4;
		public IntPtr d5;
		public IntPtr d6;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_ActiveEvent {
		public byte type;
		public byte gain;
		public byte state;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_KeyboardEvent {
		public byte type;
		public byte which;
		public byte state;
		public SDL_keysym keysym;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_MouseMotionEvent {
		public byte type;
		public byte which;
		public byte state;
		public ushort x, y;
		public short xrel;
		public short yrel;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_MouseButtonEvent {
		public byte type;
		public byte which;
		public byte button;
		public byte state;
		public ushort x, y;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_JoyAxisEvent {
		public byte type;
		public byte which;
		public byte axis;
		public short val;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_JoyBallEvent {
		public byte type;
		public byte which;
		public byte ball;
		public short xrel;
		public short yrel;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_JoyHatEvent {
		public byte type;
		public byte which;
		public byte hat;
		public byte val;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_JoyButtonEvent {
		public byte type;
		public byte which;
		public byte button;
		public byte state;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_ResizeEvent {
		public byte type;
		public int w;
		public int h;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_ExposeEvent {
		public byte type;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_QuitEvent {
		public byte type;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_UserEvent {
		public byte type;
		public int code;
		public void *data1;
		public void *data2;
	}
	[StructLayout(LayoutKind.Sequential, Pack=4)]
	public struct SDL_version {
		public byte major;
		public byte minor;
		public byte patch;
	}

	private const string SDL_DLL = "SDL";
	private const string EMU7800SDL_DLL = "EMU7800SDL";

	// General
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_Init(int flags);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_InitSubSystem(int flags);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_Quit();
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern string SDL_GetError();
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern uint SDL_GetTicks();

	// Video
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern SDL_Surface *SDL_SetVideoMode(int width, int height, int bpp, int flags);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern void SDL_FreeSurface(SDL_Surface *surface);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_Flip(SDL_Surface *screen);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_FillRect(SDL_Surface *surface, SDL_Rect *rect, uint color);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern uint SDL_MapRGBA(SDL_PixelFormat *fmt, byte r, byte g, byte b, byte a);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_ShowCursor(int toggle);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern SDL_Surface *SDL_CreateRGBSurface(int flags, int width, int height, int depth, uint Rmask, uint Gmask, uint Bmask, uint Amask);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl, EntryPoint="SDL_UpperBlit"), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_BlitSurface(SDL_Surface *src, SDL_Rect *srcrect, SDL_Surface *dst, SDL_Rect *dstrect);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_LockSurface(SDL_Surface *surface);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_UnlockSurface(SDL_Surface *surface);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_SaveBMP_RW(SDL_Surface *surface, IntPtr dst, int freedst);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern SDL_Surface *SDL_ConvertSurface(SDL_Surface *src, SDL_PixelFormat *fmt, int flags);

	// RWops
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern IntPtr SDL_RWFromFile(string file, string mode);

	// Events
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_PollEvent(SDL_Event *evt);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_WaitEvent(SDL_Event *evt);

	// WM
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern void SDL_WM_SetCaption(string title, string icon);

	// Joystick
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_NumJoysticks();
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern string SDL_JoystickName(int index);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern IntPtr SDL_JoystickOpen(int index);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_JoystickOpened(int index);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_JoystickIndex(IntPtr joystick);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_JoystickNumAxes(IntPtr joystick);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_JoystickNumBalls(IntPtr joystick);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_JoystickNumHats(IntPtr joystick);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int SDL_JoystickNumButtons(IntPtr joystick);
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern void SDL_JoystickClose(IntPtr joystick);

	// Audio
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern void SDL_CloseAudio();
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern void SDL_PauseAudio(int pause_on);

	[DllImport(EMU7800SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int EMU7800SDL_OpenAudio(int freq, int format, int channels, int samples, int numsamples);
	[DllImport(EMU7800SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern int EMU7800SDL_EnqueueAudio(byte[] buf, int len);

	// SDL Version
	[DllImport(SDL_DLL, CallingConvention=CallingConvention.Cdecl), SuppressUnmanagedCodeSecurity]
	public static extern SDL_version *SDL_Linked_Version();
}

unsafe public class SDLVideo {
	public static SDLSurface SetVideoMode(int w, int h, bool fullscreen) {
		int flags = (int)(SDLNatives.Video.HWSurface
				| SDLNatives.Video.DoubleBuf
				| SDLNatives.Video.AnyFormat);
		
		if (fullscreen) {
			flags |= (int)(SDLNatives.Video.FullScreen);
		}

		SDLNatives.SDL_Surface *s = SDLNatives.SDL_SetVideoMode(w, h, 32, flags);

		return SDLSurface.FromScreenPtr(s);
	}
}

unsafe public class SDLSurface : IDisposable {
	private bool _disposed;
	private SDLNatives.SDL_Surface *_surface;

	private SDLSurface(SDLNatives.SDL_Surface *surface) {
		_surface = surface;
		_disposed = false;
	}

	internal static SDLSurface FromScreenPtr(SDLNatives.SDL_Surface *surface) {
		if (surface == null) {
			return null;
		} else {
			return new SDLSurface(surface);
		}
	}

	~SDLSurface() {
		if (!_disposed) {
			SDLNatives.SDL_FreeSurface(_surface);
		}
	}

	public void Dispose() {
		if (!_disposed) {
			_disposed = true;
			SDLNatives.SDL_FreeSurface(_surface);
			GC.SuppressFinalize(this);
		}
	}

	public int Flip() {
		return SDLNatives.SDL_Flip(_surface);
	}

	public SDLSurface CreateCompatibleSDLSurface(int w, int h, bool hardware) {
		SDLNatives.SDL_Surface *surf = SDLNatives.SDL_CreateRGBSurface(
			hardware ? (int)SDLNatives.Video.HWSurface : (int)SDLNatives.Video.SWSurface,
			w, h,
			_surface->format->BitsPerPixel,
			_surface->format->Rmask,
			_surface->format->Gmask,
			_surface->format->Bmask,
			_surface->format->Amask);
		if (surf == null)
			return null;
		SDLNatives.SDL_Surface *ret = SDLNatives.SDL_ConvertSurface(
			surf, _surface->format,
			hardware ? (int)SDLNatives.Video.HWSurface : (int)SDLNatives.Video.SWSurface);
		SDLNatives.SDL_FreeSurface(surf);
		if (ret == null)
			return null;
		return new SDLSurface(ret);
	}

	public int Width { get{ return (int)_surface->w; } }
	public int Height { get{ return (int)_surface->h; } }

	public int Blit(SDLSurface dest) {
		SDLNatives.SDL_Rect s = new SDLNatives.SDL_Rect(
			new Rectangle(0, 0, this.Width, this.Height));
		SDLNatives.SDL_Rect d = new SDLNatives.SDL_Rect(
			new Rectangle(0, 0, dest.Width, dest.Height));

		return SDLNatives.SDL_BlitSurface(_surface, &s, dest._surface, &d);
	}

	public int Lock() {
		return MustLock ? SDLNatives.SDL_LockSurface(_surface) : 0;
	}

	public IntPtr Pixels {
		get { return _surface->pixels; }
	}

	public int Unlock() {
		return MustLock ? SDLNatives.SDL_UnlockSurface(_surface) : 0;
	}

	public bool MustLock {
		get {
			return (_surface->offset != 0 || ((_surface->flags & (int)(SDLNatives.Video.HWSurface|SDLNatives.Video.AsyncBlit|SDLNatives.Video.RLEAccel)) != 0));
		}
	}

	public int SaveBMP(string file) {
		return SDLNatives.SDL_SaveBMP_RW(_surface, SDLNatives.SDL_RWFromFile(file, "wb"), 1);
	}

	public int BytesPerPixel {
		get {
			return _surface->format->BytesPerPixel;
		}
	}

	public int Pitch {
		get {
			return _surface->pitch;
		}
	}

	public int FillRect(Color color) {
		SDLNatives.SDL_Rect sdlrect = new SDLNatives.SDL_Rect(
			new Rectangle(0, 0, this.Width, this.Height));
		uint pf = SDLNatives.SDL_MapRGBA(_surface->format, color.R, color.G, color.B, color.A);
		return SDLNatives.SDL_FillRect(_surface, &sdlrect, pf);
	}
}

public delegate void KeyboardEventHandler(int device, bool down, int scancode, SDLKey key, SDLMod mod);
public delegate void JoyButtonEventHandler(int device, int button, bool down);
public delegate void JoyAxisEventHandler(int device, int axis, int val);
public delegate void MouseButtonEventHandler(int device, bool down, SDLMouseButton button, int x, int y);
public delegate void MouseMotionEventHandler(bool down, int x, int y, int xrel, int yrel);
public delegate void QuitEventHandler();

unsafe class SDLEvents {
	public static event KeyboardEventHandler Keyboard;
	public static event JoyButtonEventHandler JoyButton;
	public static event JoyAxisEventHandler JoyAxis;
	public static event MouseButtonEventHandler MouseButton;
	public static event MouseMotionEventHandler MouseMotion;
	public static event QuitEventHandler Quit;

	public static int PauseWait() {
		SDLNatives.SDL_Event ev;
		int ret;

		while (true) {
			ret = SDLNatives.SDL_WaitEvent(&ev);
			if (ret <= 0) {
				return ret;
			}
			switch ((SDLNatives.Event)ev.type) {
			case SDLNatives.Event.JOYBUTTONDOWN:
			case SDLNatives.Event.JOYAXISMOTION:
			case SDLNatives.Event.KEYDOWN:
			case SDLNatives.Event.QUIT:
				return 0;
			default:
				continue;
			}
		}
	}

	public static int PollAndDelegate() {
		SDLNatives.SDL_Event ev;

		int ret = SDLNatives.SDL_PollEvent(&ev);
		if (ret <= 0) {
			return ret;
		}
		switch ((SDLNatives.Event)ev.type) {
		case SDLNatives.Event.JOYBUTTONDOWN:
		case SDLNatives.Event.JOYBUTTONUP:
			if (JoyButton != null) {
				SDLNatives.SDL_JoyButtonEvent *jev = (SDLNatives.SDL_JoyButtonEvent *)&ev;
				JoyButton(jev->which, jev->button,
					ev.type == (int)SDLNatives.Event.JOYBUTTONDOWN);
			}
			break;
		case SDLNatives.Event.JOYAXISMOTION:
			if (JoyAxis != null) {
				SDLNatives.SDL_JoyAxisEvent *jev = (SDLNatives.SDL_JoyAxisEvent *)&ev;
				JoyAxis(jev->which, jev->axis, jev->val);
			}
			break;
		case SDLNatives.Event.KEYDOWN:
		case SDLNatives.Event.KEYUP:
			if (Keyboard != null) {
				SDLNatives.SDL_KeyboardEvent *kev = (SDLNatives.SDL_KeyboardEvent *)&ev;
				Keyboard(kev->which,
					(int)kev->state == (int)SDLNatives.State.Pressed,
					kev->keysym.scancode,
					(SDLKey)kev->keysym.sym,
					(SDLMod)kev->keysym.mod);
			}
			break;
		case SDLNatives.Event.MOUSEBUTTONDOWN:
		case SDLNatives.Event.MOUSEBUTTONUP:
			if (MouseButton != null) {
				SDLNatives.SDL_MouseButtonEvent *mbev = (SDLNatives.SDL_MouseButtonEvent *)&ev;
				MouseButton(mbev->which,
					(int)mbev->state == (int)SDLNatives.State.Pressed,
					(SDLMouseButton)mbev->button,
					mbev->x, mbev->y);
			}
			break;
		case SDLNatives.Event.MOUSEMOTION:
			if (MouseMotion != null) {
				SDLNatives.SDL_MouseMotionEvent *mmev = (SDLNatives.SDL_MouseMotionEvent *)&ev;
				MouseMotion((int)mmev->state == (int)SDLNatives.State.Pressed,
					mmev->x, mmev->y, mmev->xrel, mmev->yrel);
			}
			break;
		case SDLNatives.Event.QUIT:
			if (Quit != null) {
				Quit();
			}
			break;
		default:
			break;
		}
		return ret;
	}
}

unsafe class SDLVersion {
	public static SDLNatives.SDL_version Version {
		get {
			return *SDLNatives.SDL_Linked_Version();
		}
	}
}
}