package com.blissj.app;

import java.awt.*;

public class BlissSplashWindow extends Window
{

    public BlissSplashWindow() {
        super(new Frame());
        initUI();
    }

    public void update(Graphics g) {
        paint(g);
    }

    public void paint(Graphics g) {
        g.drawImage(logo, 0, 0, logo.getWidth(this), logo.getHeight(this),
                Color.black, this);
    }

    private void initUI() {
        setBackground(new Color(119, 147, 191));
        logo = getToolkit().getImage(getClass().getClassLoader().getResource(
                "com/blissj/app/images/blisssplash.gif"));
        MediaTracker mt = new MediaTracker(this);
        mt.addImage(logo, 0);
        try {
            mt.waitForID(0);
        }
        catch (InterruptedException ignored) { }
        setSize(logo.getWidth(null), logo.getHeight(null));
    }

    private Image logo;

}
