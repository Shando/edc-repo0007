package com.blissj.app;

public interface OptionEditor
{

    public void reloadOption();

    public void commitSelection();

}
