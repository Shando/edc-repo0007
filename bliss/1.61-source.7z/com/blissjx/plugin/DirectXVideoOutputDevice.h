
#ifndef DIRECTXVIDEOOUTPUTDEVICE_H
#define DIRECTXVIDEOOUTPUTDEVICE_H

#include <D3d8.h>
#include <D3dx8tex.h>
#include <D3d8types.h>
#include <windows.h>
#include "DirectInputDevice.h"
#include "DirectXAudioOutputDevice.h"

//potential error messages initializing DirectX
#define ERR_UNABLE_TO_INIT_WINDOW                   1
#define ERR_UNABLE_TO_RETRIEVE_VIDEO_MODE           2
#define ERR_UNABLE_TO_SET_REQUESTED_VIDEO_MODE      3
#define ERR_REQUEST_FOR_IN_MEMORY_TEXTURE_FAILED    4
#define ERR_REQUEST_FOR_HARDWARE_TEXTURE_FAILED     5
#define ERR_REQUEST_FOR_VERTEX_BUFFER_FAILED        6
#define ERR_UNABLE_TO_LOCK_VERTEX_BUFFER            7
#define ERR_REQUEST_TO_CLEAR_BACK_BUFFER_FAILED     8
#define ERR_INCORRECT_API_LEVEL                     9
#define ERR_UNABLE_TO_GET_SURFACE_ATTRIBUTES        10
#define ERR_UNABLE_TO_GET_DRAWING_BUFFER            11
#define ERR_UNABLE_TO_CREATE_FONT					12

typedef enum _STRETCHMODE {
    STRETCH_SOFTWARE   = 1,
    STRETCH_HARDWARE2D = 2,
    STRETCH_HARDWARE3D = 3
} STRETCHMODE;

class DirectXVideoOutputDevice
{

    friend class Win32PlugIn;
    friend class DirectInputDevice;
    friend class DirectXAudioOutputDevice;
    friend LRESULT CALLBACK MsgProc(HWND hWnd, UINT msg, WPARAM wParam,
            LPARAM lParam);
    friend void displayImageUsingPrecalculatedStretch(
            DirectXVideoOutputDevice*, UINT8*);
    friend void displayImageUsingSoftwareCopyHardwareStretch(
            DirectXVideoOutputDevice*, UINT8*);
    friend void displayImageUsingTexturedPolygon(
            DirectXVideoOutputDevice*, UINT8*);

    public:
        DirectXVideoOutputDevice();
        ~DirectXVideoOutputDevice();

        INT32	init(const CHAR*);

        void	displayImage(UINT8* image, BOOL hasChanged);
        void	release();

        BOOL	isFullScreenMode();
        void	setFullScreenMode(BOOL b);
        void	setStretchMode(STRETCHMODE);

		bool		deviceIsHAL();
        STRETCHMODE	getStretchMode();
        const CHAR* getErrorDescription(INT32 errorCode);

        BOOL      stop;

    private:
        INT32 initWindow(const CHAR*);
        void destroyWindow();
        INT32 initDirectX();
        INT32 createResources();
        void destroyResources();
        void destroyDirectX();
        void getDisplayModes();

        D3DDISPLAYMODE* modes;
        INT32           modeCount;
        D3DDISPLAYMODE* defaultFullScreenMode;

        D3DPRESENT_PARAMETERS presentation;

        //display parameters
        BOOL         fullScreen;
        STRETCHMODE  stretchMode;
        BOOL         paintNeeded;

        INT32                    m_width;
        INT32                    m_height;
        INT32*                   m_paStretch;
        BOOL                     is32bit;


        //display device data
		bool					m_bHardware;	// Hardware Acceleration Present?
        HWND                    m_hWnd;
        IDirect3D8*             m_pD3D;
        IDirect3DDevice8*       m_pd3dDevice;
        IDirect3DSurface8*      m_pBackBuffer;
        D3DSURFACE_DESC         m_BackDesc;

        //needed only for 3D hardware stretch mode
        BOOL                    filtered;
        VOID*                   m_pMemPalette;
        IDirect3DVertexBuffer8* m_pVB;
        IDirect3DTexture8*      m_pMemTexture;
        D3DSURFACE_DESC         m_pMemDesc;
        IDirect3DTexture8*      m_pCardTexture;

		int						m_nRelative;
		LPD3DXFONT				m_pBigFont;
		LPD3DXFONT				m_pSmallFont;

        static const INT32 DEFAULT_RESOLUTION_WIDTH;
        static const INT32 DEFAULT_RESOLUTION_HEIGHT;

};

#endif
