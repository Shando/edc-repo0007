package com.blissjweb.plugin;

import java.io.*;

class FifoInputStream extends InputStream
{

    public synchronized void write(int i) {
        try {
            if (size == queue.length)
                wait();

            queue[(start+size)%queue.length] = i;
            size++;
            notify();
        }
        catch (InterruptedException ignored) {}
    }

    public synchronized int read() {
        if (size == 0)
            return 0;

        int value = queue[start];
        start = (start+1)%queue.length;
        size--;
        notify();

        return value;
    }

    private int start = 0;
    private int size = 0;
    private int[] queue = new int[800];

}

