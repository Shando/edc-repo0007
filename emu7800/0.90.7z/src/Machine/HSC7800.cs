/*
 * HSC7800.cs
 * 
 * The 7800 High Score cartridge--courtesy of Matthias <matthias@atari8bit.de>.
 * 
 */
using System;
using System.Diagnostics;
using System.IO;

namespace EMU7800.Machine
{
    [Serializable]
    public sealed class HSC7800 : IDevice
    {
        byte[] ROM;
        ushort Mask;

        public static ushort Size { get; private set; }

        public void Reset()
        {
            LoadRAM();
        }

        public void Map(AddressSpace addrSpace) { }

        public byte this[ushort addr]
        {
            get { return ROM[addr & Mask]; }
            set { }
        }

        public RAM6116 SRAM  { get; private set; }

        public void SaveSRAM()
        {
            var bsfn = BackingStoreFullName;
            Trace.Write("Saving Highscore Cartridge RAM: " + bsfn + "... ");
            try
            {
                using (var bw = new BinaryWriter(File.Create(bsfn)))
                {
                    for (ushort addr = 0; addr < 0x0800; addr++)
                    {
                        bw.Write(SRAM[addr]);
                    }
                    bw.Flush();
                }
                Trace.WriteLine("ok");
            }
            catch (IOException ex)
            {
                Trace.WriteLine(Environment.NewLine + ex);
            }
        }

        #region Constructors

        public HSC7800()
        {
            SRAM = new RAM6116();
            LoadROM("c8a73288ab97226c52602204ab894286");
        }

        #endregion

        #region Helpers

        static string BackingStoreFullName
        {
            get { return Path.Combine(GlobalSettings.Instance.OutputDirectory, "emu7800 scores.hsc"); }
        }

        void LoadROM(string md5)
        {
            ROM = null;
            string foundFullName = null;
            var di = new DirectoryInfo(GlobalSettings.Instance.RomDirectory);

            Trace.Write("Loading Highscore Cartridge ROM... ");

            foreach (var fi in di.GetFiles())
            {
                if (fi.Length != 4096) continue;
                ROM = null;
                try
                {
                    using (var br = new BinaryReader(File.OpenRead(fi.FullName)))
                    {
                        ROM = br.ReadBytes((int)fi.Length);
                    }
                }
                catch (IOException ex)
                {
                    Trace.WriteLine(Environment.NewLine + ex);
                }
                if (md5 != Utility.ComputeMD5Digest(ROM))
                {
                    ROM = null;
                }
                else if (ROM != null)
                {
                    foundFullName = fi.FullName;
                    break;
                }
            }

            if (ROM == null) throw new ApplicationException("7800 Highscore BIOS not found in ROM directory: " + di.FullName);

            Trace.WriteLine("ok, found " + foundFullName);
            Size = Mask = (ushort)ROM.Length;
            Mask--;
        }

        void LoadRAM()
        {
            var bsfn = BackingStoreFullName;
            
            Trace.Write("Loading Highscore Cartridge RAM: " + bsfn + "... ");
            if (!File.Exists(bsfn))
            {
                Trace.WriteLine("not found");
                return;
            }

            byte[] data;
            try
            {
                using (var br = new BinaryReader(File.OpenRead(bsfn)))
                {
                    data = br.ReadBytes(0x0800);
                }
                Trace.WriteLine("ok");
            }
            catch (IOException ex)
            {
                Trace.WriteLine(Environment.NewLine + ex);
                return;
            }

            for (ushort addr = 0; addr < data.Length; addr++)
            {
                SRAM[addr] = data[addr];
            }
        }

        #endregion
    }
}