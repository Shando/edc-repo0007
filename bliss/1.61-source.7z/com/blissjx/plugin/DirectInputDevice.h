
#ifndef DIRECTXINPUTDEVICE_H
#define DIRECTXINPUTDEVICE_H

#include <windows.h>
#include <dinput.h>
#include "DirectInputSignal.h"

// Potential error messages initializing DirectInput:
//
#define ERR_UNABLE_TO_CREATE_INPUT              1
#define ERR_UNABLE_TO_CREATE_KEYBOARD			2
#define ERR_UNABLE_TO_SET_KEYBOARD				3


struct JOYAXESDATA
{
    LONG lMaxDeltaX;
    LONG lCenterX;
    LONG lMaxDeltaY;
    LONG lCenterY;
    LONG lMaxDeltaZ;
    LONG lCenterZ;

};

class Win32PlugIn;

BOOL CALLBACK EnumJoysticksCallback(const DIDEVICEINSTANCE* pdidInstance,
        VOID* pContext);

class DirectInputDevice
{

    friend class Win32PlugIn;
    friend BOOL CALLBACK EnumJoysticksCallback(
            const DIDEVICEINSTANCE* pdidInstance, VOID* pContext);

    public:
        DirectInputDevice();
        ~DirectInputDevice();

        DirectInputSignal* getDefaultSignal(INT32 controlID);
        DirectInputSignal* createInputSignal(const CHAR* configKey);

        INT32 init();
        const CHAR* getErrorDescription(INT32 errorCode);
        void poll();
        float getSignalValue(DirectInputSignal* signal);
        void release();
        INT32 initConfigMode();
        DirectInputSignal* pollForInputSignal();
        void releaseConfigMode();
        BOOL stop;

    private:
        DirectInputSignal* createKeyboardSignal(ULONG keyID);
        INT32 initDirectInput();
        INT32 initDirectInputDevices(HWND);
        float getJoystickSignalValue(INT32 joystickNum, INT32 inputCode);
        void releaseDirectInput();
        DirectInputSignal* checkKeyboardForInputSignal();
        DirectInputSignal* checkJoystickForInputSignal(INT32 joystickNum);

        IDirectInput8* m_pDI;
        BOOL m_bLastPollSuccessful;
        IDirectInputDevice8* m_pdiKeyboard;
        CHAR m_KeyboardBuffer[256];
        IDirectInputDevice8* m_pdiJoysticks[10];
        CHAR m_JoystickNames[10][MAX_PATH];
        JOYAXESDATA m_JoystickAxes[10];
        DIJOYSTATE2 m_JoystickStates[10];
        INT32 m_iJoystickCount;

    public:
        const static INT32 PLAYER_ONE_ID_START;
        const static INT32 PLAYER_ONE_ID_END;
        const static INT32 PLAYER_ONE_NORTH;
        const static INT32 PLAYER_ONE_NORTHEAST;
        const static INT32 PLAYER_ONE_EAST;
        const static INT32 PLAYER_ONE_SOUTHEAST;
        const static INT32 PLAYER_ONE_SOUTH;
        const static INT32 PLAYER_ONE_SOUTHWEST;
        const static INT32 PLAYER_ONE_WEST;
        const static INT32 PLAYER_ONE_NORTHWEST;
        const static INT32 PLAYER_ONE_BUTTON_ONE;
        const static INT32 PLAYER_ONE_BUTTON_TWO;
        const static INT32 PLAYER_ONE_BUTTON_THREE;
        const static INT32 PLAYER_ONE_BUTTON_FOUR;
        const static INT32 PLAYER_ONE_BUTTON_FIVE;
        const static INT32 PLAYER_ONE_BUTTON_SIX;
        const static INT32 PLAYER_ONE_KEYPAD_ONE;
        const static INT32 PLAYER_ONE_KEYPAD_TWO;
        const static INT32 PLAYER_ONE_KEYPAD_THREE;
        const static INT32 PLAYER_ONE_KEYPAD_FOUR;
        const static INT32 PLAYER_ONE_KEYPAD_FIVE;
        const static INT32 PLAYER_ONE_KEYPAD_SIX;
        const static INT32 PLAYER_ONE_KEYPAD_SEVEN;
        const static INT32 PLAYER_ONE_KEYPAD_EIGHT;
        const static INT32 PLAYER_ONE_KEYPAD_NINE;
        const static INT32 PLAYER_ONE_KEYPAD_ZERO;
        const static INT32 PLAYER_ONE_KEYPAD_DELETE;
        const static INT32 PLAYER_ONE_KEYPAD_ENTER;
        const static INT32 PLAYER_ONE_KEYPAD_ASTERIX;
        const static INT32 PLAYER_ONE_KEYPAD_POUND;

        const static INT32 PLAYER_TWO_ID_START;
        const static INT32 PLAYER_TWO_ID_END;
        const static INT32 PLAYER_TWO_NORTH;
        const static INT32 PLAYER_TWO_NORTHEAST;
        const static INT32 PLAYER_TWO_EAST;
        const static INT32 PLAYER_TWO_SOUTHEAST;
        const static INT32 PLAYER_TWO_SOUTH;
        const static INT32 PLAYER_TWO_SOUTHWEST;
        const static INT32 PLAYER_TWO_WEST;
        const static INT32 PLAYER_TWO_NORTHWEST;
        const static INT32 PLAYER_TWO_BUTTON_ONE;
        const static INT32 PLAYER_TWO_BUTTON_TWO;
        const static INT32 PLAYER_TWO_BUTTON_THREE;
        const static INT32 PLAYER_TWO_BUTTON_FOUR;
        const static INT32 PLAYER_TWO_BUTTON_FIVE;
        const static INT32 PLAYER_TWO_BUTTON_SIX;
        const static INT32 PLAYER_TWO_KEYPAD_ONE;
        const static INT32 PLAYER_TWO_KEYPAD_TWO;
        const static INT32 PLAYER_TWO_KEYPAD_THREE;
        const static INT32 PLAYER_TWO_KEYPAD_FOUR;
        const static INT32 PLAYER_TWO_KEYPAD_FIVE;
        const static INT32 PLAYER_TWO_KEYPAD_SIX;
        const static INT32 PLAYER_TWO_KEYPAD_SEVEN;
        const static INT32 PLAYER_TWO_KEYPAD_EIGHT;
        const static INT32 PLAYER_TWO_KEYPAD_NINE;
        const static INT32 PLAYER_TWO_KEYPAD_ZERO;
        const static INT32 PLAYER_TWO_KEYPAD_DELETE;
        const static INT32 PLAYER_TWO_KEYPAD_ENTER;
        const static INT32 PLAYER_TWO_KEYPAD_ASTERIX;
        const static INT32 PLAYER_TWO_KEYPAD_POUND;

        const static INT32 KEYBOARD_ID_START;
        const static INT32 KEYBOARD_ID_END;
        const static INT32 KEYBOARD_A;
        const static INT32 KEYBOARD_B;
        const static INT32 KEYBOARD_C;
        const static INT32 KEYBOARD_D;
        const static INT32 KEYBOARD_E;
        const static INT32 KEYBOARD_F;
        const static INT32 KEYBOARD_G;
        const static INT32 KEYBOARD_H;
        const static INT32 KEYBOARD_I;
        const static INT32 KEYBOARD_J;
        const static INT32 KEYBOARD_K;
        const static INT32 KEYBOARD_L;
        const static INT32 KEYBOARD_M;
        const static INT32 KEYBOARD_N;
        const static INT32 KEYBOARD_O;
        const static INT32 KEYBOARD_P;
        const static INT32 KEYBOARD_Q;
        const static INT32 KEYBOARD_R;
        const static INT32 KEYBOARD_S;
        const static INT32 KEYBOARD_T;
        const static INT32 KEYBOARD_U;
        const static INT32 KEYBOARD_V;
        const static INT32 KEYBOARD_W;
        const static INT32 KEYBOARD_X;
        const static INT32 KEYBOARD_Y;
        const static INT32 KEYBOARD_Z;

        const static INT32 KEYBOARD_0;
        const static INT32 KEYBOARD_1;
        const static INT32 KEYBOARD_2;
        const static INT32 KEYBOARD_3;
        const static INT32 KEYBOARD_4;
        const static INT32 KEYBOARD_5;
        const static INT32 KEYBOARD_6;
        const static INT32 KEYBOARD_7;
        const static INT32 KEYBOARD_8;
        const static INT32 KEYBOARD_9;

        const static INT32 KEYBOARD_UP;
        const static INT32 KEYBOARD_DOWN;
        const static INT32 KEYBOARD_LEFT;
        const static INT32 KEYBOARD_RIGHT;

        const static INT32 KEYBOARD_COMMA;
        const static INT32 KEYBOARD_PERIOD;
        const static INT32 KEYBOARD_SPACE;
        const static INT32 KEYBOARD_SEMICOLON;
        const static INT32 KEYBOARD_COLON;
        const static INT32 KEYBOARD_ESCAPE;
        const static INT32 KEYBOARD_ENTER;
        const static INT32 KEYBOARD_CONTROL;
        const static INT32 KEYBOARD_SHIFT;

        const static INT32 MENU_ID_START;
        const static INT32 MENU_ID_END;
        const static INT32 MENU_DISPLAY;
        const static INT32 MENU_UP;
        const static INT32 MENU_DOWN;
        const static INT32 MENU_SELECT;

        const static INT32 EMULATOR_ID_START;
        const static INT32 EMULATOR_ID_END;
        const static INT32 EMULATOR_RESET;
        const static INT32 EMULATOR_PAUSE;
        const static INT32 EMULATOR_SAVE;
        const static INT32 EMULATOR_LOAD;
        const static INT32 EMULATOR_SCREENSHOT;

};

#endif

