﻿/*
 * HostDirectXFullscreen
 * 
 * A DirectX 9 based host.
 * 
 * Copyright (c) 2008 Mike Murphy
 * 
 */
namespace EMU7800.Host.DirectX
{
    public class HostDirectXFullscreen : HostDirectX
    {
        public HostDirectXFullscreen() : base(true)
        {
        }
    }
}
