
----------------------------------------------------------------------------------------------------
                        Klive v1.1 (C) Steve Snake, Reptilia Design 2002.
----------------------------------------------------------------------------------------------------

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

What's New in Klive v1.1 ?
--------------------------

Basically, I altered/added a few things that have been requested by various people:

* Altered Menus - in the default window size, they did not fit on one line under any OS except XP.
  Most options now moved into a seperate OPTIONS menu.

* Added (...) to some menu options, as requested.

* New Joystick Configuration Dialog. Now you can select any DirectInput device to be used with
  either player.

* Added PC Keyboard (Cursor Keys + Left CTRL key) as a Joystick Emulation Option.

* Added the ability to Pause the emulation.

* Added the ability to Mute the Sound emulation.

* Altered/Improved timing, especially on the Spectrum 128 and +2 machines.

* Added File History. The last 8 files loaded are stored here for quick access.

* Added basic Command Line support. You can now launch Klive with:
  KLIVE filename [-fullscreen]
  If the -fullscreen option is added, Klive will jump to full screen mode, and the ESC key will
  exit Klive immediately.

* Added WAV file support. You can now load tapes from WAV files. They can be 8 or 16 bit, but must
  be MONO.

* Added Real Tape Mode. You can now load games from real Spectrum tapes, through your sound card.

* Added TV Mode. When in FullScreen, Klive can now be set to emulate the display of a real TV.

* Added the ability to force Software Scaling when in Windowed mode. Some people, apparently, do
  not like the filtering applied by most video cards when using Hardware Scaling. Note: this mode
  WILL be quite a bit slower than Hardware Scaling.

* Added another size setting to the Window Selection: When Software Scaling is selected, scaling
  is only done for 1x, 2x, 3x and 4x, because any sub-pixel sizes would have defeated the object
  of putting this option in... therefore, a suitable size for 3x had to be added.

The text below has been amended to reflect these changes, see below for more information.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

What is Klive ?
---------------

Klive is an emulator for the Sinclair Spectrum, for Win98, WinME, Win2000 and WinXP.

Klive requires DirectX7 or above.

Klive is (hopefully) pretty accurate. It attempts to update each pixel of the screen at the exact
time that the real hardware does. For this reason, Klive will not be the fastest Spectrum emulator
available - however, it has been written from scratch, using 100% custom code, 99% of which is in
x86 ASM. This means that Klive is still pretty fast, and you should be able to easily achieve full
Spectrum speed on a P75 or below. Unfortunately I cannot test this myself ;) Also, there is still
a lot of room for optimisation, so future versions may be faster, and (possibly) more accurate.

The Z80 emulator in Klive emulates all instructions, including all undocumented ones, and all flags,
again including all undocumented ones. All instructions are, as far as I am aware, accurate as
compared to a real Z80. It also emulates machine-cycle level timings. Contended RAM is also emulated
accurately, as far as I am aware.
   
Currently, Klive supports the following hardware:

Sinclair Spectrum 48K
Sinclair Spectrum 128K
Sinclair/Amstrad Spectrum +2
Sinclair/Amstrad Spectrum +2a
Sinclair/Amstrad Spectrum +3
Sinclair Interface 2
Cursor Joystick
Kempston Joystick
Currah �Speech
Fuller Box
SpecDrum
Spectrum 128K sound on a Spectrum 48K
AY-3-8912 or YM2149 Sound Chip (selectable) with ABC or ACB Stereo support
NEC �PD765A Floppy Disk Controller (in +3 Mode)

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Why "Klive" ?
-------------

Sir Clive Sinclair is the man responsible for the Spectrum, and the man who singlehandedly started
the home computer market in the early eighties. And although I had already played around with ASM
beforehand, on my Sinclair ZX81, and before that on a machine built by a friends father, it was not
until I got my Spectrum that I got into programming in a big way. Thanks to Sir Clive I now have a
career. Thanks, Clive.

For those of you who don't know, the Klive Icon is my little piccy of Sir Clive himself.

If you want to know why I spell it "Klive" and not "Clive", then I guess you haven't seen any of my
other emulators ;)

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Do we need another Spectrum Emulator ? 
--------------------------------------

I thought not, which is why I haven't written one before. But when I recently tried to find one I
could not find one which ran well on my system. It seems that there are a LOT of DOS emulators -
none of which will work on my system - and not so many Windows emulators. Of all the ones I tried,
some gave me severe sound problems, making them pretty unusable. Others ran WAY too fast, no matter
what the settings were set to. Others still just crashed. Of the ones that DID work, they did not
work well with the software I wanted to run - and finally, the ones that looked like they might be
what I was looking for, were not free. I figured that with all the time I had wasted looking, I
could have written my own. And so I did ;)

I hope that people will find my emulator useful. But if not, no big deal, it was mainly written for
me, and I've had a lot of fun writing it. It always amazes me how all this long forgotten info for
old systems comes flooding back when you need it :)


- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Instructions, please!
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

The File Menu.
--------------

LOAD SNAPSHOT FILE
------------------

Klive can load Snapshots in the .SNA and .Z80 formats. It can also load directly from ZIP files,
(one .SNA or .Z80 file per ZIP) so you can store all your Snapshots in ZIPPED format. For this
reason, I personally prefer .SNA format, since it is uncompressed, you will usually get a smaller
ZIP file than you would with a .Z80 file. The compression method used in .Z80 files is not very
efficient.

Klive will autodetect if the Snapshot file is a 48K/128K/+3 Snapshot file, and switch to the
correct hardware automatically. This feature can be disabled if you want to force 48K snapshots to
be loaded on a 128K machine etc. (see "Miscellaneous Options", below.)


LOAD INTERFACE 2 CART
---------------------

Interface 2 Cartridges (with the extension .ROM) can be loaded from here. ROM files can also be
loaded directly from ZIP files (one ROM per ZIP).


ATTACH TAPE FILE
----------------

Tape files, in either .TAP,.TZX or .WAV format, can be loaded here. .TAP and .TZX files can be
stored in ZIP files, .WAV files cannot.

Once a tape file is attached, it is then up to you to load from the tape.

In 48K BASIC, the command LOAD "" needs to be entered, followed by pressing PLAY on the emulated
Tape Recorder. On the 128K Spectrum, you can use the "LOADER" option from the menu.

Klive currently has no "fast loading" options. I really don't see the point, personally - if you
want to load from tape files, then it's probably because you LIKE tape loaders ;) However you can
always speed up emulation and thus speed up tape loading. (See "The Speed Menu" below.)

Most of the TZX format is supported, it should be able to load most TZX files you will find.

Tape Noise can be turned on or off. (see "Miscellaneous Options" below.)

See "The Tape Menu" for more information about the emulated Tape Recorder.


ATTACH DISK FILE
----------------

The Spectrum +3 emulation in Klive comes with two disk drives. Using this menu option you can
insert +3 .DSK images into either drive. Again, these files can be ZIP files.


SAVE SNAPSHOT FILE
------------------

Klive can save Snapshots in the .SNA format.


SAVE SCREENSHOT FILE
--------------------

You can save a screenshot in PCX format with this option. What you see on screen is what will be in
the PCX file, complete with borders. These files are compressed.


LOAD/SAVE SCREEN$ FILE
----------------------

You can also save a screenshot in .SCR format. This format is an exact memory dump of the Spectrums
Screen RAM (known as a SCREEN$). Because you cannot normally view these screens on a PC, there is a
LOAD option to load them back into the emulator. However, the screen saved may not appear identical
to what was on the screen when you saved it. The border colour is not preserved, and any colour or
other effects will not be present.

			  
HARDWARE RESET
--------------

This option will reset the current emulated system, and is like switching the power off and then on
again.


FILE HISTORY
------------

The last eight files loaded are stored in the File History, for quick access.


EXIT
----

Exits Klive.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

The Hardware Menu
-----------------

From here you can select what hardware you want to emulate.

Spectrum 48K        Emulate the original 48K Spectrum.

Spectrum 128K       Emulate the original 128K Spectrum.

Spectrum +2         Emulate the Sinclair/Amstrad Spectrum +2.
                    The Spectrum +2 is essentially a Spectrum 128K with a slightly modified ROM set.
		    It is included for completeness.

Spectrum +2a        Emulate the Sinclair/Amstrad Spectrum +2a.
                    The Spectrum +2a is essentially a Spectrum +3 without a Floppy Disk controller.
		    It is included for completeness.

Spectrum +3         Emulate the Sinclair/Amstrad Spectrum +3.
                    When the +3 is emulated, three "Drive Lights" are displayed at the bottom left
		    of the screen. These are the MOTOR light (used by both drives), and a DATA light
		    for each drive.

Currah �Speech      Emulate the Currah �Speech unit. This was only compatible with the Spectrum 48K
                    and so the option is only available when Spectrum 48K is selected.
		    The Currah �Speech is compatible with several games, and can be programmed
		    easily from BASIC programs. (See "The Currah �Speech", below.) I bought two of
		    these things, and managed to convince most of my friends to buy one too ;)

                    NOTE that some games WILL NOT RUN AT ALL when the Currah unit is enabled.
		    		    
Fuller Box          Emulate the Fuller Box. This device contained an AY-3-8912 sound chip (the same
                    as used in the Spectrum 128) and a Joystick interface. This option enables the
		    Fuller Box sound chip (I have seperated the Joystick emulation from the Sound
		    emulation, so that you can use the Fuller Box Joystick without the Fuller Box
		    sound, and vice versa.) This option is available under Spectrum 48K emulation
		    only. I included this option for one reason - "Invasion of the Body Snatchas"
		    uses the Fuller Box for it's sound ;) I was very impressed at the time...

128 Sound           Enable the use of Spectrum 128K compatible sound on the Spectrum 48K. This
                    option is available under Spectrum 48K emulation only. It's mutually exclusive
		    with Fuller Box emulation. If anybody is still writing music for the Spectrum
		    and AY-3-8912 sound chip, and is interrested in this feature, I may at a later
		    date allow both the Fuller Box and 128 Sound to be enabled at once, thus giving
		    you TWO AY-3-8912 sound chips, and 6 sound channels, to play with. Anyone ? ;)

SpecDrum            Enable SpecDrum emulation. To make use of this feature you need the SpecDrum
                    software, or any other software that makes use of the SpecDrum hardware. I once
		    did some pretty cool stuff with the SpecDrum, at the time my "friends" did not
		    believe that I was musically talented enough to have done it! Thanks Guys....
		    I wish I still had this stuff. By the way, my SpecDrum came with some demos
		    as well as the software - does anyone have this stuff ?

Sound Chip Type     The Spectrum 128K and the Fuller Box used the GI AY-3-8912 sound chip.
                    (Incidentally, so did the DKTronic's Three Channel Sound unit, which I also
		    owned - does anyone know which ports this used ? I can't remember...)

		    The Yamaha YM2149 is a 100% pin and software compatible chip. However, it does
		    not produce the same sound - the volume levels are quite different.

                    The AY-3-8912 is documented as using a dB scale for it's volume settings. But
		    the values it actually outputs are not a perfect dB scale - actually, far from
		    it ;)

		    The YM2149 is much closer to a perfect dB scale (although still not exact.)

		    You will hear the difference in that the AY-3-8912 sounds much louder than the
		    YM2149 at lower volumes. Things that fade will fade much quicker on the YM2149.

		    The other main difference is in the envelopes. If an envelope is used, then the
		    YM2149 has twice as many steps as the AY-3-8912 does. The envelopes will sound
		    smoother. Try this with "Invasion of the Body Snatchas". The explosion sound
		    will sound much nicer on a YM2149.

		    This is all down to personal choice. The AY was used in the original Hardware,
		    and so sounds closer to the original hardware. But the YM2149 is a nicer chip.
                    It's really up to you.

		    While on this subject, most places on the net seem to suggest that the Sega
		    Master System, BBC Micro, and MSX used this chip. This is incorrect, they use
		    a Texas Instruments chip, which is very different, but produces a similar sound.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

The Tape Control Menu
---------------------

Controls for the emulated Tape Recorder.

Allows you to Play/Stop the tape, rewind to the beginning, or rewind or fast forward one "block" on
the tape. Info on the current tape "block" will be displayed at the bottom right of the screen.


Real Tape Mode
--------------

From the Tape Menu you can also select Real Tape Mode. Select this mode if you wish to load a game
from a real Tape Recorder, attached to your Sound Card.

While in this mode, Klive attempts to synchronise itself with the input from the Sound Card. This
means that the current SPEED setting will have no effect in this mode.

Also while in this mode, most menu options are disabled, and Sound is disabled. Sound disabling is
not 100% neccessary, but I have found that the tape loading seems to be much more reliable when
the sound is disabled. Also, because of the way Klive is syncronised while in Real Tape Mode, the
sound can distort slightly anyway.

It is recommended that you switch back out of Real Tape Mode as soon as you have finished loading
from a Real Tape. You may also find it more convenient to instead sample the tape as a .WAV file,
and load it that way - because then you can still take advantage of fast loading via changing the
speed of the emulator.

Also, note that the current Sound setting also sets the capture mode for Real Tapes. It MUST be
set to MONO for Real Tape mode to work, but you can try either MONO setting, and see which gives
best results on your system/tape.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

The Options Menu
----------------

The Speed SubMenu
-----------------

Allows you to adjust the speed of emulation from "RealTime" to "Max Power!", and also to Pause the
emulator.

There are settings for "RealTime x 2" to "RealTime x 10".

The actual speed that can be achieved depends on the speed of your PC. These settings are really
how fast Klive will ATTEMPT to run.

"Max Power!" will, however, run Klive as fast as your PC will allow. You may find it useful to
toggle between "Max Power!" and "Realtime" when loading from Tape files.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

The Sound SubMenu
-----------------

Allows you to select the sound output format, and also to Mute the sound.

Normally, you will want to use either 22050Hz or 44100Hz MONO output, since all models of the
Spectrum were Monaural. However, some Demos make use of hardware devices designed and built by
demo coders themselves, known as "ABC Stereo" or "ACB Stereo". These were just AY-3-8912 Sound
Chips wired up so that channel A went to the Left speaker, channel B went to Both speakers, and
channel C went to the Right speaker (for ABC Stereo - C went to Both and B went to Right in the
case of ACB Stereo).

If you are running such a demo you can select one of the Stereo modes, and then select either ABC
Stereo or ACB Stereo from the options at the bottom of the menu.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

The Video SubMenu
-----------------

From the Video SubMenu, you can select what size you want the Window to be on your Desktop. These
sizes all preserve the aspect ratio of the original Spectrum, and they use the hardware in your
video card to scale the display to the required size. Therefore, if you have a decent video card,
the image will be nicely filtered, and will also not slow down emulation. This behaviour can be
altered to a Software Scaling behaviour if you do not like the filtering effect of your video card,
(See MISCELLANEOUS OPTIONS below.)

From here you can also select Full Screen mode. Full Screen mode may or may not give you better
performance than Windowed mode - it all depends on your system/video card.

The VSYNC, SCANLINES and TV MODE options are only used for Full Screen mode.

If VSYNC is enabled, when you switch to Full Screen mode, Klive will request a video mode running
at 100hz refresh rate. (The original Spectrum ran at a 50hz refresh rate, but most PC monitors do
not support 50hz - and if they did, it would probably flicker, which isn't nice.) If DirectDraw
reports that your Video Card/Monitor can support 100hz, then Klive will use this mode. This means
that Klive can now update the screen once every two 100hz intervals, thus making the refresh rate
look exactly like the 50hz of an original Spectrum. Demos/Games that have smooth moving objects
will look as smooth as intended. However if your Video Card/Monitor does not support this, Klive
will simply ignore the VSYNC option.

If SCANLINES is enabled, when you switch to Full Screen mode, Klive will attempt to use a video
mode known as "Scanlines", which looks more like a real Spectrum would look on a real TV, rather
than a PC Monitor. This, too, depends on support from your Video Card, and may or may not have any
effect.

If TV MODE is enabled, when you switch to Full Screen mode, Klive will attempt to use a video
mode which simulates the output of a real TV. Again, support from your Video Card is required.

Remember that the ESC key also switches between Full Screen and Windowed mode, because many of the
options in Klive's menus are not accessible in Full Screen mode, and you will need to switch back
to Windowed mode to, say, load a new Snapshot.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

The Joysticks Dialog
--------------------

If you have Joysticks connected to your PC, Klive will detect them. You can use this Dialog to
select which type of Spectrum Joystick your PC Joysticks should emulate. You can also opt to use
the PC Keyboards' Cursor Keys and Left CTRL key as an emulated Joystick, if you do not have any
Joysticks, or you only have one and wish to use Two Player options.

Options are, for Player 1:

Kempston, Cursor, Sinclair 1, Fuller Box, or Defined Keys.

and for Player 2:

Sinclair 2, or Defined Keys.

When you select "Defined Keys", each joystick direction/button will, in effect, press a key on the
spectrum keyboard. So if your game does not have a Joystick option, you can instead set the keys
that your Joystick emulates to the same keys that the game uses.

When you select this option you will be asked to press keys to be used for UP,DOWN,LEFT,RIGHT and
FIRE buttons.

If your Joystick has more than one button, I have included the ability for you to use up to four
buttons per joystick. You will notice that you are asked for keys for FIRE, FIRE2, FIRE3 and FIRE4.
If you don't want to use more than one button, or if your Joystick doesn't have that many buttons,
you can just type any unused key for the extra buttons.

A LITTLE TIP:

If you are using a Kempston, Cursor, Sinclair or Fuller Joystick, you can still make use of the
extra three fire buttons. Just use the "Define Keys" option, selecting any keys you like for the
UP, DOWN, LEFT, RIGHT and FIRE buttons, and then the keys you want to use for the extra three fire
buttons. When you then select Kempston, Cursor, Sinclair or Fuller, the keys you defined for UP.
DOWN, LEFT, RIGHT and FIRE will be ignored - but the keys you selected for FIRE2, FIRE3 and FIRE4
will still be active! This is very useful for some games, where normally you would have to use the
Joystick AND the keyboard to play.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

MISCELLANEOUS OPTIONS
---------------------

SHOW PERCENTAGE SPEEDOMETER     Enable or Disable the Speedometer at the lower left of the screen.
                                This tells you how fast emulation is running relative to the speed
                                of real hardware. 100% means you are running at the exact speed of
                                real hardware.

SHOW SPECTRUM KEYBOARD          Shows my rendition of the original Spectrum 48K Keyboard. Useful
                                for when you need to know where a particular symbol or keyword is
				on the original Spectrum Keyboard. Note that I have also mirrored
				keys on the Spectrum Keyboard to the extended PC keyboard where
				possible - so +,-,*,/ etc. on the PC Keypad can be used instead of
				having to find the equivalent keys on the Spectrum Keyboard.

ENABLE TAPE NOISE               Enable or Disable the noise from Tape while loading. If you want,
                                you could enable this, and record the output from your sound card
				for loading into a real Spectrum.

SWITCH TO xx WHEN LOADING xx    Enable or Disable automatic switching of hardware when loading
                                Snapshot files.

CTRL=/LSHIFT= etc.              Personal Taste - you can select how the SHIFT and CTRL keys map on
                                to the Spectrum Keyboard with these options.

ACT LIKE AN ISSUE 2 SPECTRUM    Klive emulates an Issue 3 Spectrum by default. Some early Spectrum
                                games did not work with the Issue 3 Spectrum. If the controls in
				a game do not work or are erratic, you can try switching this on.
				Note that this only affects the Spectrum 48K - all later Spectrum
				Hardware acted like an Issue 3 Spectrum.

USE ALTERNATE TIMING SYSTEM     By default, Klive uses the sound card to achieve accurate timing.
                                This is the best method, it provides an accurate timer, and ensures
				that the sound does not skip/jump/pop etc. However some sound cards
				or their drivers do not provide accurate information.
				If the speedometer does not sit at 100%, or is more than 2 out in
				either direction, the first thing to try is changing the sound
				format (see "The Sound Menu", below.) If this does not work you can
				instead select the Alternate Timing System. This should work in all
				cases, however you may notice skips/jumps/pops in the sound on
				occasion.
				
USE SOFTWARE SCALE (WINDOWED)   When this option is enabled, Klive will use Software Scaling to
                                draw the screen when in Windowed mode. This is slower than the
				default (Hardware Scaling) in 99% of cases. However the pixels
				will be "clean", and not filtered. Some people like it this way.
	
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

The Currah �Speech
------------------

From 48K Basic, the Currah �Speech will speak all your keypresses. (after a Reset, you need to hit
Enter at least once before this is enabled.)

This can be turned off by typing LET keys=0 and turned on again by typing LET keys=1.

To get it to speak to you, you use the basic string s$. E.G.

LET s$="hel(oo)"

will cause the Currah �Speech to say "hello" to you.

(Note: to use this inside a basic program, you should put PAUSE 1 after each "LET s$..." to make
sure that the Currah ROM gets to see the string before it is overwritten.)

That's all there is to it :)

The Currah �Speech uses what are known as "Allophones" - short sounds that, when played one after
another, can form any word in the English Language. All you have to do is learn how to build up the
word you want to say from these Allophones. For example, the word "hel(oo)" above is built from 4
Allophones - h, e, l and (oo). Experiment with the full set of Allophones until it sounds right. It
doesn't take long to get used to it.

The Currah �Speech can also ramp up and down the clock rate of the speech chip slightly. To get it
to do this, you just use capital letters to ramp up the pitch. Try:

LET s$="HEL(oo)"

for a more friendly sounding "Hello".

The full list of Allphones are: (all taken from the Currah Manual)

   All single letters a to z, except x and q.

   and

   (aa) or (ay)  (as in the "ay" in "hay")
   (ee)          (as in the "ee" in "see")
   (ii)          (as in the "i" in "hive")
   (oo) or (eau) (as in the "o" in "stove")
   (bb)          (as in the "b" in "bat") 
   (dd)          (as in the "d" in "do")
   (gg)          (as in the "g" in "got")
   (ggg)         (as in the "g" in "big")
   (hh)          (as in the "h" in "hoe")
   (ll)          (as in the "l" in "let")
   (nn)          (as in the "n" in "no")
   (rr)          (as in the "r" in "run") 
   (tt)          (as in the "t" in "to")
   (yy)          (as in the "y" in "yeah")
   (ar)          (as in the "ar" in "arm")
   (aer)         (as in the "air" in "repair")
   (ch)          (as in the "ch" in "church")
   (ck)          (as in the "ck" in "clock")
   (ear)         (as in the "ear" in "clear")
   (eh)          (as in the "ar" in "wary")
   (er)          (as in the "er" in "leader")
   (err)         (as in the "ur" in "purr")
   (ng)          (as in the "ng" in "tongue")
   (or)          (as in the "or" in "sore")
   (ou)          (as in the "oo" in "root")
   (ouu)         (as in the "oo" in "food")
   (ow)          (as in the "ow" in "now")
   (oy)          (as in the "oy" in "boy")
   (sh)          (as in the "sh" in "ship")
   (th)          (as in the "th" in "thin")
   (dth)         (as in the "th" in "then")
   (uh)          (as in the "oo" in "took")
   (wh)          (as in the "wh" in "whig")
   (zh)          (as in the "z" in "azure")

   apostrophe    (very short pause - e.g. in "can't")
   space         (pause between words)
   comma         (pause between phrases)
   full stop     (pause between sentences)

The Currah �Speech Manual is also available online, but note there are a number of errors in it,
especially in the machine code section.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Extra Information
-----------------

Currently, there is no support to save to tape. (You can, however, record the tape sound to a tape
for loading into a real Spectrum - see Miscellaneous Options, above.) Similarly, in +3 mode, there
is no support to save to a +3 disk. If you want to save something, you must currently save to a
Snapshot file.

Currently, the Floppy Disk Controller emulation in the +3 is very preliminary. This thing has to be
emulated with a lot of accuracy, because of the large number of commercial games produced on +3
disks. Disk copy protection works by forcing the Floppy Disk Controller to do things that, under
normal use, it would never do. Most commercial disks cannot be copied because the Floppy Disk
Controller cannot actually write the data that is on these disks. Therefore, in order to get these
games to work, you need to work out exactly what the Floppy Disk Controller does when it finds this
weird data on a disk. This is not easy!

However, at the moment, it DOES work with 99% of the commercial disk images I have encountered. I
will continue to improve this accuracy - if you find anything that doesn't work, or you have any
information, please contact me.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Legal Stuff
-----------

Klive is Freeware. If it works for you, great. Although I believe it has no serious bugs, if it
causes any damage whatsoever, I am not responsible. Use it at your own risk.

Klive must not be distributed for money (other than a small fee for media/postage etc.) and must
not be distributed with copyrighted software. Other than that, you are welcome to distribute it
via your website etc.

Klive contains the Spectrum 48K, Spectrum 128K, Spectrum +2 and Spectrum +3 ROMs, which are
Copyright (C) Amstrad. Amstrad has kindly given their permission for these Copyrighted ROMs to be
included in Emulators. This is absolutely stunning, and I am very grateful to Amstrad for this!

Klive also contains the Currah �Speech ROM. The copyright holder for this ROM is not known, but I
do not believe I am causing anyone harm by including this small, commercially unprofitable, ROM.
If the copyright holder of this ROM wishes to come forward and make his/her/their wishes known, I
would be very grateful to hear from him/her/them.

None of the ROMs in Klive have been modified in any way.

All other code is (C) Steve Snake.

----------------------------------------------------------------------------------------------------
Klive (C) Steve Snake - kega_emu at hotmail dot com
----------------------------------------------------------------------------------------------------
