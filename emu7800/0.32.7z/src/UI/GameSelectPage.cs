/*
 * GameSelectPage.cs
 * 
 * A ControlPanelTabPage that facilitates game ROM selection.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */

using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;

namespace EMU7800 {

public class GameSelectPage : ControlPanelTabPage {
	private ControlPanelForm ControlPanelForm;

	private Label label1, label2, label3, label4;

	private ComboBox cmbBox;
	private Button btnBrowse;
	private OpenFileDialog openFileDialog1;
	private TreeView treeView1;
	private TreeNode tnTitle, tnUnknown;
	private int ROMFileCount;

	private GameSettings StagedGameSettings = null;

	public override void ClearChanges() {
		label1.Text = "Current Game Program:";
		if (ControlPanelForm.CurrGameSettings != null) {
			label2.Text = ControlPanelForm.CurrGameSettings.Title;
		} else {
			label2.Text = "(None)";
			treeView1.SelectedNode = null;
		}
		label2.BackColor = label1.BackColor;
	}
		
	public override void ApplyChanges() {
		GameSettings gs = StagedGameSettings;
		StagedGameSettings = null;

		gs.Load();

		Cart c = Cart.New(gs);
		Machine m = Machine.New(gs, c, new InputAdapter());
		if (m != null) {
			m.ClipLocation = gs.ClipLocation;
			ControlPanelForm.Host.InstallMachine(m);
			ControlPanelForm.CurrGameSettings = gs;
		}
			
		label1.Text = "Current Game Program:";
		label2.Text = ControlPanelForm.CurrGameSettings.Title;
		label2.BackColor = label1.BackColor;
	}

	public GameSelectPage(ControlPanelForm controlPanelForm) {
		ControlPanelForm = controlPanelForm;

		Text = "Game Programs";
				
		label1 = new Label();
		label1.Text = "Current Game Program:";
		label1.Location = new Point(15, 10);
		label1.Size = new Size(Width, label1.PreferredHeight);
	
		label2 = new Label();
		label2.Text = "(None)";
		label2.Location = new Point(15, 25);
		label2.Size = new Size(Width, label2.PreferredHeight);
		label2.Font = new Font(label2.Font, FontStyle.Bold);

		label3 = new Label();
		label3.Location = new Point(15, 45);
		label3.Size = new Size(Width, label3.PreferredHeight);
		label3.Text = "Current ROM Directory";

		label4 = new Label();
		label4.Size = new Size(Width, label4.PreferredHeight);
		label4.Text = "X";

		cmbBox = new ComboBox();
		cmbBox.Text = Globals.ROMDirectory;
		cmbBox.Location = new Point(15, 60);
		cmbBox.Items.Add(cmbBox.Text);
		cmbBox.SelectedValueChanged += new EventHandler(OnComboBoxChanged);

		btnBrowse = new Button();
		btnBrowse.Text = "Select ROM File";
		btnBrowse.Location = new Point(15, 85);
		btnBrowse.Size = new Size(105, 25);
		btnBrowse.Click += new EventHandler(OnBrowseClick);

		treeView1 = new TreeView();
		treeView1.Location = new Point(15, 130);
		treeView1.HideSelection = false;
		treeView1.AfterSelect += new TreeViewEventHandler(OnClickTreeView1);

		Layout += new LayoutEventHandler(OnLayout);

		Controls.AddRange(new Control[] {
			label1, label2, label3, label4,
			cmbBox, btnBrowse, treeView1});

		DoLoadTreeView();
	}

	private void OnComboBoxChanged(Object sender, EventArgs e) {
		if (cmbBox.Text != Globals.ROMDirectory) {
			Globals.ROMDirectory = cmbBox.Text;
			DoLoadTreeView();
		}
	}

	private void OnBrowseClick(Object sender, EventArgs e) {
		openFileDialog1 = new OpenFileDialog();
		openFileDialog1.Title = "Select ROM File";
		openFileDialog1.Filter = "ROM files (*.bin)|*.bin|All files (*.*)|*.*" ;
		openFileDialog1.FilterIndex = 2;

		string initdir = cmbBox.Text.Replace(@"/", @"\");
		if (!Directory.Exists(initdir)) {
			initdir = Globals.RootDir;
		}
		openFileDialog1.InitialDirectory = initdir;

		if(openFileDialog1.ShowDialog() == DialogResult.OK) {
			string fn = openFileDialog1.FileName;

			int i;
			for (i=fn.Length - 1; i >= 0; i--) {
				if (fn.Substring(i, 1) == @"\"
					|| fn.Substring(i, 1) == ":") {
					break;
				}
			}

			string romdir = fn.Substring(0, i + 1).Replace(@"\", "/");
			cmbBox.Text = romdir;

			bool found = false;
			foreach (string s in cmbBox.Items) {
				if (s == romdir) {
					found = true;
					break;
				}
			}

			if (!found) {
				cmbBox.Items.Add(romdir);
			}

			Globals.ROMDirectory = romdir;
			DoLoadTreeView();

			SelectTitle(openFileDialog1.FileName.Replace(@"\", "/"));
		}
	}
	
	private void OnClickTreeView1(Object sender, TreeViewEventArgs e) {
		TreeNode tn = e.Node;
		if (e.Node != null && e.Node.Tag != null) {
			StagedGameSettings = ((GameSettings)e.Node.Tag);
			label1.Text = "Selected Game Program:";
			label2.Text = StagedGameSettings.Title;
			label2.BackColor = Color.Yellow;
			ControlPanelForm.ApplyButtonEnabled = true;
		}
	}

	private void OnLayout(Object sender, LayoutEventArgs e) {
		label2.Size = new Size(Size.Width - 2*15, label2.PreferredHeight);

		cmbBox.Size = new Size(Width - 30, 45);
		treeView1.Size = new Size(Width - 2*15,
			Size.Height - treeView1.Location.Y - 2*15);

		label4.Location = new Point(15, Size.Height - 20);
	}

	private void DoLoadTreeView() {
		Cursor prevCursor = ControlPanelForm.Cursor;
		ControlPanelForm.Cursor = Cursors.WaitCursor;

		IDictionaryEnumerator de = GameSettings.ROMProperties.GetEnumerator();
		while (de.MoveNext()) {
			GameSettings gs = (GameSettings)de.Value;
			gs.ROMFound = false;
		}

		ROMFileCount = 0;

		try {
			LoadTreeView();
		} catch (Exception e) {
			Log.Msg("Error loading TreeView: {0}\n", e.Message);
		}

		StringBuilder sb = new StringBuilder();
		sb.Append(ROMFileCount);
		sb.Append(" ROM file");
		if (ROMFileCount != 1) {
			sb.Append("s");
		}
		sb.Append(" recognized");
		label4.Text = sb.ToString();

		ControlPanelForm.Cursor = prevCursor;
	}

	private void LoadTreeView() {
		treeView1.BeginUpdate();
		treeView1.Nodes.Clear();

		tnTitle = new TreeNode("Title");
		treeView1.Nodes.Add(tnTitle);

		string[] manList = new string[] {
			"Activision", "Atari",
			"CBS Electronics", "Coleco",
			"Epyx",
			"Imagic",
			"Konami",
			"Mattel",
			"Mystique",
			"Parker Bros",
			"Sega",
			"Starsoft",
			"Telesys",
			"Tigervision",
			"20th Century Fox",
		};
		Hashtable mtbl = AddTreeSubRoot(treeView1, "Manufacturer", manList);

		string[] yearList = new string[] {
			"1977","1978","1979","1980","1981","1982","1983",
			"1984","1985","1986","1987","1988", "1989", "1990",
		};
		Hashtable ytbl = AddTreeSubRoot(treeView1, "Year", yearList);

		string[] rareList = new string[] {
			 "Common", "Uncommon", "Rare", "Extremely Rare",
			 "Unbelievably Rare", "Prototype", "Unreleased Prototype",
		};
		Hashtable raretbl = AddTreeSubRoot(treeView1, "Rarity", rareList);

#if DEBUG
		string[] machList = Enum.GetNames(typeof(MachineType));
		Hashtable machtbl = AddTreeSubRoot(treeView1, "Machine Type", machList);

		string[] cartList = Enum.GetNames(typeof(CartType));
		Hashtable carttbl = AddTreeSubRoot(treeView1, "Cartridge Type", cartList);
#endif

		tnUnknown = new TreeNode("Unknown");
		treeView1.Nodes.Add(tnUnknown);

		MD5 MD5 = new MD5CryptoServiceProvider();
		StringBuilder md5 = new StringBuilder();
		FileInfo[] romFiles = new DirectoryInfo(Globals.ROMDirectory).GetFiles();
	
		foreach (FileInfo fi in romFiles) {
			if (fi.Name.ToLower().PadLeft(4).Substring(fi.Name.Length - 4, 4) != ".bin") {
				continue;
			}

			switch (fi.Length) {
			case 2048:  break;
			case 4096:  break;
			case 8192:  break;
			case 10495: break;  // Pitfall II is an odd size
			case 16384: break;
			case 32768: break;
			case 65535: break;
			default:
				continue;
			}

			BinaryReader br = new BinaryReader(File.OpenRead(fi.FullName));
			byte[] ROM = br.ReadBytes((int)fi.Length);
			br.Close();

			md5.Length = 0;
			foreach (Byte b in MD5.ComputeHash(ROM)) {
				md5.AppendFormat("{0:x2}", b); 
			}
			
			if (!GameSettings.ROMProperties.ContainsKey(md5.ToString())) {
				Log.Msg("Unrecognized ROM: {0}  MD5={1}\n",
					fi.FullName, md5.ToString());
				continue;
			}

			GameSettings gs = (GameSettings)GameSettings.ROMProperties[md5.ToString()];

			if (gs.ROMFound) {
				Log.Msg("{0} has duplicate MD5 checksum with already recognized {1}\n",
					fi.Name, gs.ROMFileName);
				continue;
			}

			gs.ROMFound = true;
			gs.ROMFullName = fi.FullName.Replace(@"\", "/");
			gs.ROMFileName = fi.Name.Replace(@"\", "/");
			gs.Size = fi.Length;
			ROMFileCount++;

			if (gs.CartType == CartType.Null) {
				// CartType defaults determined by size
				switch (gs.Size) {
				case 2048:   gs.CartType = CartType.A2K;  break;
				case 4096:   gs.CartType = CartType.A4K;  break;
				case 8192:   gs.CartType = CartType.A8K;  break;
				case 16384:  gs.CartType = CartType.A16K; break;
				}
			}

			if (gs.CartType == CartType.Null) {
				TreeNode tnUnk = new TreeNode(gs.Title);
				tnUnknown.Nodes.Add(tnUnk);
				Log.Msg("Unknown CartType: {0}, {1}, MD5={2}\n",
					gs.Title, gs.ROMFullName, gs.SaveKey);
				continue;
			}

			if (gs.MachineType == MachineType.Null) {
				TreeNode tnUnk = new TreeNode(gs.Title);
				tnUnknown.Nodes.Add(tnUnk);
				Log.Msg("Unknown MachineType: {0}, {1}  MD5={2}\n",
					gs.Title, gs.ROMFullName, gs.SaveKey);
				continue;
			}

			TreeNode tn = new TreeNode(BuildTitle(gs.Title, gs.Manufacturer, gs.Year));
			tn.Tag = gs;
			tnTitle.Nodes.Add(tn);

			AddTreeNode(mtbl, gs, gs.Manufacturer,
				gs.Title, gs.Year);
			AddTreeNode(ytbl, gs, gs.Year,
				gs.Title, gs.Manufacturer);
			AddTreeNode(raretbl, gs, gs.Rarity,
				gs.Title, gs.Manufacturer, gs.Year);

#if DEBUG
			AddTreeNode(machtbl, gs, gs.MachineType.ToString(),
				gs.Title, gs.Manufacturer, gs.Year);
			AddTreeNode(carttbl, gs, gs.CartType.ToString(),
				gs.Title, gs.Manufacturer, gs.Year);
#endif

			// Let the GUI breath a little
			Application.DoEvents();
		}

		treeView1.Sorted = true;
		treeView1.EndUpdate();
		treeView1.Update();
	}

	private void SelectTitle(string fullName) {
		foreach (TreeNode tn in tnTitle.Nodes) {
			if (tn.Tag == null) {
				continue;
			}
			if (fullName == ((GameSettings)tn.Tag).ROMFullName) {
				treeView1.SelectedNode = tn;
				return;
			}
		}
		foreach (TreeNode tn in tnUnknown.Nodes) {
			string ROMFileName = tn.Text.Split(',')[0];
			if (fullName == ROMFileName) {
				treeView1.SelectedNode = tn;
				return;
			}
		}
	}

	private Hashtable AddTreeSubRoot(TreeView root, string label, string[] subList) {
		TreeNode tnparent = new TreeNode(label);
		root.Nodes.Add(tnparent);
		Hashtable t = new Hashtable();
		TreeNode tn;
		foreach (string s in subList) {
			tn = new TreeNode(s);
			tnparent.Nodes.Add(tn);
			t.Add(s, tn);
		}
		tn = new TreeNode("Other");
		tnparent.Nodes.Add(tn);
		t.Add("Other", tn);
		return t;
	}

	private void AddTreeNode(Hashtable t, GameSettings gs, string key,
			params string[] titlebits) {
		TreeNode tn = new TreeNode(BuildTitle(titlebits));
		tn.Tag = gs;
		if (!t.ContainsKey(key)) {
			key = "Other";
		}
		((TreeNode)t[key]).Nodes.Add(tn);
	}

	private string BuildTitle(params string[] titlebits) {
		StringBuilder title = new StringBuilder();

		for (int i=0; i < titlebits.Length; i++) {
			if (titlebits[i].Length > 0) {
				if (i > 0) {
					title.Append(", ");
				}
				title.Append(titlebits[i]);
			}
		}
		return title.ToString();
	}
}
}