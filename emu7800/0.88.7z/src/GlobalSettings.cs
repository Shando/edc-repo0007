/*
 * GlobalSettings
 *
 * Retains settings across program invocations.
 * 
 * Copyright (c) 2004-2008 Mike Murphy
 * 
 */
using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Drawing;
using System.IO;
using System.IO.IsolatedStorage;
using System.Reflection;
using System.Xml;

namespace EMU7800
{
    public class GlobalSettings
    {
        #region Fields

        private const string ConfigRoot = "EMU7800.Configuration";
        private XmlDocument _ConfigDoc;
        private int? _CachedFrameRateAdjust;
        private int? _CachedNumSoundBuffers;
        private int? _CachedSoundVolume;
        private bool? _CachedDeactivateMouseInput;
        private bool? _CachedNOPRegisterDumping;
        private int? _CachedJoyBTrigger;
        private int? _CachedJoyBBooster;
        private int? _CachedCpuSpin;

        #endregion

        #region Public Properties

        // cannot databind to static members
        [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
        public string BaseDirectory
        {
            get { return Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location); }
        }

        [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
        public string OutputDirectory
        {
            get { return Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory); }
        }

        [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
        public string RomDirectory
        {
            get
            {
                var romDir = GetVal("ROMDirectory", Path.Combine(BaseDirectory, "roms"));
                if (!Directory.Exists(romDir)) romDir = BaseDirectory;
                return romDir;
            }
            set
            {
                if (Directory.Exists(value))
                {
                    SetVal("ROMDirectory", value);
                }
            }
        }

        [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
        public string HostSelect
        {
            get { return GetVal("HostSelect", string.Empty); }
            set { SetVal("HostSelect", value); }
        }

        public int FrameRateAdjust
        {
            get
            {
                if (!_CachedFrameRateAdjust.HasValue)
                {
                    _CachedFrameRateAdjust = GetVal("FrameRateAdjust", 0);
                }
                return (int)_CachedFrameRateAdjust;
            }
            set
            {
                SetVal("FrameRateAdjust", value.ToString());
                _CachedFrameRateAdjust = value;
            }
        }

        public int NumSoundBuffers
        {
            get
            {
                if (!_CachedNumSoundBuffers.HasValue)
                {
                    _CachedNumSoundBuffers = GetVal("NumSoundBuffers", 10);
                }
                return (int)_CachedNumSoundBuffers;
            }
            set
            {
                SetVal("NumSoundBuffers", value.ToString());
                _CachedNumSoundBuffers = value;
            }
        }

        public int SoundVolume
        {
            get
            {
                if (!_CachedSoundVolume.HasValue)
                {
                    _CachedSoundVolume = GetVal("SoundVolume", 8);
                }
                return (int)_CachedSoundVolume;
            }
            set
            {
                SetVal("SoundVolume", value.ToString());
                _CachedSoundVolume = value;
            }
        }

        [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
        public bool Skip7800BIOS
        {
            get { return GetVal("Skip7800BIOS", false); }
            set { SetVal("Skip7800BIOS", value.ToString()); }
        }

        [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
        public bool Use7800HSC
        {
            get { return GetVal("Use7800HSC", false); }
            set { SetVal("Use7800HSC", value.ToString()); }
        }

        public bool DeactivateMouseInput
        {
            get
            {
                if (!_CachedDeactivateMouseInput.HasValue)
                {
                    _CachedDeactivateMouseInput = GetVal("DeactivateMouseInput", false);
                }
                return (bool)_CachedDeactivateMouseInput;
            }
            set
            {
                 if (!DeactivateMouseInput.Equals(value))
                 {
                     SetVal("DeactivateMouseInput", value.ToString());
                     _CachedDeactivateMouseInput = value;
                 }
            }
        }

        public Size ControlPanelFormSize
        {
            get
            {
                var w = GetVal("ControlPanelFormWidth", 0);
                var h = GetVal("ControlPanelFormHeight", 0);
                return new Size(w < 500 ? 500 : w, h < 500 ? 500 : h);
            }
            set
            {
                if (!ControlPanelFormSize.Equals(value))
                {
                    SetVal("ControlPanelFormWidth", value.Width.ToString());
                    SetVal("ControlPanelFormHeight", value.Height.ToString());
                }
            }
        }

        public bool NOPRegisterDumping
        {
            get
            {
                if (!_CachedNOPRegisterDumping.HasValue)
                {
                    _CachedNOPRegisterDumping = GetVal("NOPRegisterDumping", false);
                }
                return (bool)_CachedNOPRegisterDumping;
            }
            set
            {
                SetVal("NOPRegisterDumping", value.ToString());
                _CachedNOPRegisterDumping = value;
            }
        }

        public int JoyBTrigger
        {
            get
            {
                if (!_CachedJoyBTrigger.HasValue)
                {
                    _CachedJoyBTrigger = GetVal("JoyBTrigger", 0);
                }
                return (int)_CachedJoyBTrigger;
            }
            set
            {
                SetVal("JoyBTrigger", value.ToString());
                _CachedJoyBTrigger = value;
            }
        }

        public int JoyBBooster
        {
            get
            {
                if (!_CachedJoyBBooster.HasValue)
                {
                    _CachedJoyBBooster = GetVal("JoyBBooster", 1);
                }
                return (int)_CachedJoyBBooster;
            }
            set
            {
                SetVal("JoyBBooster", value.ToString());
                _CachedJoyBBooster = value;
            }
        }

        public int CpuSpin
        {
            get
            {
                if (!_CachedCpuSpin.HasValue)
                {
                    _CachedCpuSpin = GetVal("CpuSpin", 1);
                }
                return (int)_CachedCpuSpin;
            }
            set
            {
                value = value < 0 ? 0 : value;
                SetVal("CpuSpin", value.ToString());
                _CachedCpuSpin = value;
            }
        }

        public string GetUserValue(string name)
        {
            return GetVal("UserValue" + name, string.Empty);
        }

        public void SetUserValue(string name, string value)
        {
            SetVal("UserValue" + name, value);
        }

        public void Save()
        {
            Persist();
        }

        #endregion

        #region Constructors

        public static readonly GlobalSettings Instance = new GlobalSettings();
        private GlobalSettings()
        {
        }

        #endregion

        #region Property Helpers

        private bool GetVal(string name, bool defaultVal)
        {
            LoadIfNecessary();
            bool value;
            return bool.TryParse(GetVal(name, defaultVal.ToString()), out value) ? value : defaultVal;
        }

        private int GetVal(string name, int defaultVal)
        {
            LoadIfNecessary();
            int value;
            return int.TryParse(GetVal(name, defaultVal.ToString()), out value) ? value : defaultVal;
        }

        private string GetVal(string name, string defaultVal)
        {
            LoadIfNecessary();
            if (_ConfigDoc.DocumentElement != null)
            {
                var n = _ConfigDoc.DocumentElement.SelectSingleNode(name);
                return n != null ? n.InnerText : defaultVal;
            }
            return null;
        }

        private void SetVal(string name, string val)
        {
            LoadIfNecessary();
            if (_ConfigDoc.DocumentElement != null)
            {
                var n = _ConfigDoc.DocumentElement.SelectSingleNode(name);
                if (n == null)
                {
                    n = _ConfigDoc.CreateElement(name);
                    _ConfigDoc.DocumentElement.AppendChild(n);
                }
                n.InnerText = val;
            }
            ReportChangedSetting(name, val);
        }

        #endregion

        #region Backing Store Helpers

        void LoadIfNecessary()
        {
            if (_ConfigDoc != null) return;

            _ConfigDoc = new XmlDocument();
            try
            {
                using (var isf = IsolatedStorageFile.GetUserStoreForAssembly())
                using (var fs = new IsolatedStorageFileStream("EMU7800.configuration", FileMode.Open, FileAccess.Read, isf))
                {
                    _ConfigDoc.Load(fs);
                }
            }
            catch (Exception ex)
            {
                if (Utility.IsCriticalException(ex)) throw;
                _ConfigDoc.RemoveAll();
                if (!(ex is FileNotFoundException))
                {
                    Trace.WriteLine("GlobalSettings: unable to load configuration: " + ex.Message);
                }
            }

            if (_ConfigDoc.DocumentElement == null || !_ConfigDoc.DocumentElement.Name.Equals(ConfigRoot))
            {
                _ConfigDoc.RemoveAll();
                _ConfigDoc.AppendChild(_ConfigDoc.CreateElement(ConfigRoot));
            }
        }

        void Persist()
        {
            try
            {
                using (var isf = IsolatedStorageFile.GetUserStoreForAssembly())
                using (var fs = new IsolatedStorageFileStream("EMU7800.configuration", FileMode.Create, FileAccess.Write, isf))
                {
                    _ConfigDoc.Save(fs);
                }
            }
            catch (Exception ex)
            {
                if (Utility.IsCriticalException(ex)) throw;
                Trace.WriteLine("GlobalSettings: unable to save global settings: " + ex.Message);
            }
        }

        static void ReportChangedSetting(string name, object val)
        {
            Trace.WriteLine("GlobalSetting " + name + " changed to " + val);
        }

        #endregion
    }
}
