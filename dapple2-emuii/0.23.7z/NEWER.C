/*
 * NEWER - determines if the target is newer than the source, or if it must
 * be rebuilt.  Used by Dapple ]['s mk.bat utility to avoid rebuilding a
 * file that hasn't been changed.  This program will build with Turbo C++
 * 1.01; it *might* build with gcc, but no guarantees.
 *
 * Written by Steve Nickolas.  (C) 2003.  You may do whatever you want with
 * this file as long as (a) you do not remove this paragraph and (b) you
 * agree that use of this program is entirely at your own risk and all
 * warranties (including implied warranties of merchantability or fitness
 * for a particular purpose) are disclaimed.
 *
 * Version 1.00 2003.0213
 *
 * Usage:  newer target source
 * Returns 1 if target needs to be rebuilt, 0 if target does not need to be
 * rebuilt.  Any other return signifies an error.
 *
 * Note: this program is highly nonoptimal.  Who cares, it's certainly
 * faster than waiting for a CPU core to build on a 486 with gcc -O3.
 */

#include <io.h>
#include <stdio.h>

int main (int parmno, char **parmlist)
{
 FILE *file;
 struct ftime stime, ttime;
 unsigned long stimel, ttimel; /* 32 bits, same length as struct ftime */

 if (parmno!=3)
 {
  fprintf (stderr,"usage: newer target source\n");
  return -1;
 }

 file=fopen(parmlist[2],"rb");
 if (!file)
 {
  fprintf (stderr,"Source file ");
  perror (parmlist[2]);
  return -1;
 }

 if (getftime(fileno(file),&stime))
 {
  fprintf (stderr,"Cannot get file time for ");
  perror (parmlist[2]);
  fclose(file);
  return -1;
 }

 fclose(file);

 file=fopen(parmlist[1],"rb");
 if (!file) return 1; /* assume need to update, if we can't open it */

 if (getftime(fileno(file),&ttime))
 {
  fprintf (stderr,"Cannot get file time for ");
  perror (parmlist[1]);
  fclose(file);
  return -1;
 }

 fclose(file);

 stimel=* (unsigned long*) &stime;
 ttimel=* (unsigned long*) &ttime;

 if (stimel>ttimel) return 1; /* needs updating */
 return 0;
}