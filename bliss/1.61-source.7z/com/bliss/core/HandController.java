package com.bliss.core;

import com.bliss.core.devices.*;

public class HandController implements IODevice
{

    HandController(int playerNum) {
        this.playerNum = playerNum;
        controlIDs = (playerNum == 0 ? CONTROL_IDS_PLAYER_ONE
                : CONTROL_IDS_PLAYER_TWO);
    }

    public void reset() {
        inputValue = 0xFF;
    }

    /**
     * There are 23 discrete controls on a hand controller.
     *
     *    12 keypad buttons
     *     3 action buttons (top two are wired together)
     *     8 disc pad sensors
     */
    public int getControlCount() {
        return 23;
    }

    public int getControlID(int controlNum) {
        return controlIDs[controlNum];
    }

    public String getControlDescription(int controlNum) {
        return Intellivision.RESOURCES.getString(descriptionKeys[controlNum]);
    }

    public void setInputDevice(InputDevice inputDevice) {
        this.inputDevice = inputDevice;
    }

    public void setOutputValue(int value) {}

    public int getInputValue() {
        return inputValue;
    }

    public void poll() {
        inputValue = 0;

        for (int i = 0; i < 15; i++) {
            if (inputDevice.getControlValue(controlIDs[i]) ==
                    InputDevice.SIGNAL_ON)
                inputValue |= buttonOutputValues[i];
        }

        //evaluate the disc
        float neswVector =
                (inputDevice.getControlValue(controlIDs[ID_DISC_NORTH_EAST]) -
                inputDevice.getControlValue(controlIDs[ID_DISC_SOUTH_WEST])) *
                vectorParse;
        float nwseVector =
                (inputDevice.getControlValue(controlIDs[ID_DISC_NORTH_WEST]) -
                inputDevice.getControlValue(controlIDs[ID_DISC_SOUTH_EAST])) *
                vectorParse;
        float yPos = inputDevice.getControlValue(controlIDs[ID_DISC_NORTH]) -
                inputDevice.getControlValue(controlIDs[ID_DISC_SOUTH]) +
                nwseVector + neswVector;
        float xPos = inputDevice.getControlValue(controlIDs[ID_DISC_EAST]) -
                inputDevice.getControlValue(controlIDs[ID_DISC_WEST]) -
                nwseVector + neswVector;

        if (xPos != 0 || yPos != 0) {
            double positionInRadians = (Math.atan2(-xPos, -yPos)+Math.PI);
            double offset = (2d * Math.PI)/16d;
            int directionValue = directionOutputValues[(int)((positionInRadians+
                    (offset/2d))/offset) & 0x0F];
            inputValue |= directionValue;
        }

        inputValue = (0xFF ^ inputValue);
    }

    private int           playerNum;
    private InputDevice   inputDevice;
    private int           inputValue = 0xFF;
    private int[]         controlIDs;

    private final static int[] CONTROL_IDS_PLAYER_ONE = {
            InputDevice.PLAYER_ONE_KEYPAD_ONE,
            InputDevice.PLAYER_ONE_KEYPAD_TWO,
            InputDevice.PLAYER_ONE_KEYPAD_THREE,
            InputDevice.PLAYER_ONE_KEYPAD_FOUR,
            InputDevice.PLAYER_ONE_KEYPAD_FIVE,
            InputDevice.PLAYER_ONE_KEYPAD_SIX,
            InputDevice.PLAYER_ONE_KEYPAD_SEVEN,
            InputDevice.PLAYER_ONE_KEYPAD_EIGHT,
            InputDevice.PLAYER_ONE_KEYPAD_NINE,
            InputDevice.PLAYER_ONE_KEYPAD_DELETE,
            InputDevice.PLAYER_ONE_KEYPAD_ZERO,
            InputDevice.PLAYER_ONE_KEYPAD_ENTER,
            InputDevice.PLAYER_ONE_BUTTON_ONE,
            InputDevice.PLAYER_ONE_BUTTON_TWO,
            InputDevice.PLAYER_ONE_BUTTON_THREE,
            InputDevice.PLAYER_ONE_NORTH,
            InputDevice.PLAYER_ONE_NORTHEAST,
            InputDevice.PLAYER_ONE_EAST,
            InputDevice.PLAYER_ONE_SOUTHEAST,
            InputDevice.PLAYER_ONE_SOUTH,
            InputDevice.PLAYER_ONE_SOUTHWEST,
            InputDevice.PLAYER_ONE_WEST,
            InputDevice.PLAYER_ONE_NORTHWEST,
        };
    private final static int[] CONTROL_IDS_PLAYER_TWO = {
            InputDevice.PLAYER_TWO_KEYPAD_ONE,
            InputDevice.PLAYER_TWO_KEYPAD_TWO,
            InputDevice.PLAYER_TWO_KEYPAD_THREE,
            InputDevice.PLAYER_TWO_KEYPAD_FOUR,
            InputDevice.PLAYER_TWO_KEYPAD_FIVE,
            InputDevice.PLAYER_TWO_KEYPAD_SIX,
            InputDevice.PLAYER_TWO_KEYPAD_SEVEN,
            InputDevice.PLAYER_TWO_KEYPAD_EIGHT,
            InputDevice.PLAYER_TWO_KEYPAD_NINE,
            InputDevice.PLAYER_TWO_KEYPAD_DELETE,
            InputDevice.PLAYER_TWO_KEYPAD_ZERO,
            InputDevice.PLAYER_TWO_KEYPAD_ENTER,
            InputDevice.PLAYER_TWO_BUTTON_ONE,
            InputDevice.PLAYER_TWO_BUTTON_TWO,
            InputDevice.PLAYER_TWO_BUTTON_THREE,
            InputDevice.PLAYER_TWO_NORTH,
            InputDevice.PLAYER_TWO_NORTHEAST,
            InputDevice.PLAYER_TWO_EAST,
            InputDevice.PLAYER_TWO_SOUTHEAST,
            InputDevice.PLAYER_TWO_SOUTH,
            InputDevice.PLAYER_TWO_SOUTHWEST,
            InputDevice.PLAYER_TWO_WEST,
            InputDevice.PLAYER_ONE_NORTHWEST,
        };

    private final static float vectorParse = (float)Math.sin(Math.PI/4);

    private final static int ID_DISC_NORTH            = 15;
    private final static int ID_DISC_NORTH_EAST       = 16;
    private final static int ID_DISC_EAST             = 17;
    private final static int ID_DISC_SOUTH_EAST       = 18;
    private final static int ID_DISC_SOUTH            = 19;
    private final static int ID_DISC_SOUTH_WEST       = 20;
    private final static int ID_DISC_WEST             = 21;
    private final static int ID_DISC_NORTH_WEST       = 22;

    private final static int[] buttonOutputValues = {
            0x81, //OUTPUT_KEYPAD_ONE
            0x41, //OUTPUT_KEYPAD_TWO
            0x21, //OUTPUT_KEYPAD_THREE
            0x82, //OUTPUT_KEYPAD_FOUR
            0x42, //OUTPUT_KEYPAD_FIVE
            0x22, //OUTPUT_KEYPAD_SIX
            0x84, //OUTPUT_KEYPAD_SEVEN
            0x44, //OUTPUT_KEYPAD_EIGHT
            0x24, //OUTPUT_KEYPAD_NINE
            0x88, //OUTPUT_KEYPAD_CLEAR
            0x48, //OUTPUT_KEYPAD_ZERO
            0x28, //OUTPUT_KEYPAD_ENTER
            0xA0, //OUTPUT_ACTION_BUTTON_TOP
            0x60, //OUTPUT_ACTION_BUTTON_BOTTOM_LEFT
            0xC0  //OUTPUT_ACTION_BUTTON_BOTTOM_RIGHT
        };

    private final static int[] directionOutputValues = {
            0x04, //OUTPUT_DISC_NORTH
            0x14, //OUTPUT_DISC_NORTH_NORTH_EAST
            0x16, //OUTPUT_DISC_NORTH_EAST
            0x06, //OUTPUT_DISC_EAST_NORTH_EAST
            0x02, //OUTPUT_DISC_EAST
            0x12, //OUTPUT_DISC_EAST_SOUTH_EAST
            0x13, //OUTPUT_DISC_SOUTH_EAST
            0x03, //OUTPUT_DISC_SOUTH_SOUTH_EAST
            0x01, //OUTPUT_DISC_SOUTH
            0x11, //OUTPUT_DISC_SOUTH_SOUTH_WEST
            0x19, //OUTPUT_DISC_SOUTH_WEST
            0x09, //OUTPUT_DISC_WEST_SOUTH_WEST
            0x08, //OUTPUT_DISC_WEST
            0x18, //OUTPUT_DISC_WEST_NORTH_WEST
            0x1C, //OUTPUT_DISC_NORTH_WEST
            0x0C  //OUTPUT_DISC_NORTH_NORTH_WEST
        };

    private final static String[] descriptionKeys = {
            "InputKeyPadOne",
            "InputKeyPadTwo",
            "InputKeyPadThree",
            "InputKeyPadFour",
            "InputKeyPadFive",
            "InputKeyPadSix",
            "InputKeyPadSeven",
            "InputKeyPadEight",
            "InputKeyPadNine",
            "InputKeyPadClear",
            "InputKeyPadZero",
            "InputKeyPadEnter",
            "InputActionButtonsTop",
            "InputActionButtonBottomLeft",
            "InputActionButtonBottomRight",
            "InputDiscNorth",
            "InputDiscNorthEast",
            "InputDiscEast",
            "InputDiscSouthEast",
            "InputDiscSouth",
            "InputDiscSouthWest",
            "InputDiscWest",
            "InputDiscNorthWest"
        };

}
