/*
 * Dapple ][ Emulator  Version 0.06
 * Copyright (C) 2002, 2003 Dapple ][ Development.  All rights reserved.
 *
 * Component:  DISK: routines for emulating two disk drives
 * Revision:   (0.06) 2003.0129
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <stdio.h>
#include <string.h>
#include "asmlib.h"
#include "dapple.h"

/* dapple.c */
extern unsigned char exitprogram;
extern unsigned int  window;
extern unsigned char inidiskpath1[256];
extern unsigned char inidiskpath2[256];
void setmessage(unsigned char *message);
unsigned int fileselectmenu(unsigned int keyboard, unsigned int window,
			    unsigned char *title,
			    unsigned char *filename, unsigned char *tail,
			    unsigned char optnew);

/* cpu.c */
void cpusetdelay(unsigned int value);
unsigned int cpugetdelay();
void cpusetlinecycle(unsigned int value);
unsigned int cpugetlinecycle();

/* video.c */
extern unsigned char	virtcopy;


static unsigned char	driveselect;
static unsigned int	drivelatch;
static unsigned int	drivelatch0ee;
unsigned char		drivedata1 [233472];
unsigned char		drivedata2 [233472];
static unsigned int	drivephase1;
static unsigned int	drivephase2;
static unsigned int	drivetrack1;
static unsigned int	drivetrack2;
static unsigned int	drivebytepointer1;
static unsigned int	drivebytepointer2;
static unsigned char	driveaccess1;
static unsigned char	driveaccess2;
static unsigned char	drivemotorflag1;
static unsigned char	drivemotorflag2;
static unsigned char	drivewriteprotected1;
static unsigned char	drivewriteprotected2;
unsigned char		drivefastmode;
unsigned char		drivefastflag;
unsigned char		drivemessageflag;
static unsigned int	driveoldlinecycle;
static unsigned int	driveolddelay;
static unsigned char	driveselectmenu;

#define false 0
#define true 1

/* Drive		*/
/* - driveempty		*/
/* - drivereset		*/
/* - driveinit		*/
/* - driveconvertsecnib	*/
/* - driveload		*/
/* - driveread		*/
/* - drivewrite		*/



/*-------------------------------------*/


      void drivestore(FILE *file) {
      } /* drivestore */


/*-------------------------------------*/


      void driverestore(FILE *file) {
      } /* driverestore */


/*-------------------------------------*/


      /* set all bytes of emulated disk to 0xaa */
      void driveempty(unsigned char diskdata[233472]) {
	register unsigned int i;

	for ( i=0; i<233472; i++) {
	  diskdata[i] = 0xaa;
	} /* for i */
      } /* driveempty */


/*-------------------------------------*/


      void drivereset() {

	driveselect	= true;		/* drive 1 */
	driveaccess1	= true;		/* read */
	driveaccess2	= true;		/* read */
	drivemotorflag1	= false;	/* off */
	drivemotorflag2	= false;	/* off */
	imagefillbox(window, 628, 8, 629, 9, 0x404040 /*COL_DRV_OFF*/);
	imagefillbox(window, 632, 8, 633, 9, 0x404040 /*COL_DRV_OFF*/);
	drivefastmode	= false;

      } /* drivereset */


/*-------------------------------------*/


      void driveinit() {

	driveempty(drivedata1);
	driveempty(drivedata2);
	drivelatch	= 0xaa;
	drivelatch0ee	= 0;
	drivetrack1	= 34;
	drivetrack2	= 34;
	drivephase1	= 35*2-1;
	drivephase2	= 35*2-1;
	drivebytepointer1 = 0;
	drivebytepointer2 = 0;
	drivewriteprotected1 = false;
	drivewriteprotected2 = false;
	drivefastmode	= false;
	drivefastflag	= true;
	drivemessageflag = false;
	driveselectmenu	= 0;
	drivereset();

      } /* driveinit */


/*-------------------------------------*/


      void driveconvertsecnib (unsigned char source[144360], unsigned char dest[233472], unsigned int volume) {
	unsigned int	track;
	unsigned int	sector;
	unsigned int	secpointer;
	unsigned int	nibpointer;
	unsigned int	zappointer;
	unsigned int	happointer;
	unsigned char	diskbyte;
	unsigned char	diskzap[256];
	unsigned char	diskhap[256];
	static unsigned char dossit [] = {
	  0x00, 0x0d, 0x0b, 0x09, 0x07, 0x05, 0x03, 0x01,
	  0x0e, 0x0c, 0x0a, 0x08, 0x06, 0x04, 0x02, 0x0f
	};
	static unsigned int dospos [] = {
	  0x00, 0x0d, 0x0b, 0x09, 0x07, 0x05, 0x03, 0x01,
	  0x0e, 0x0c, 0x0a, 0x08, 0x06, 0x04, 0x02, 0x0f
	};
	static unsigned char prodossit [] = {
	  0x00, 0x02, 0x04, 0x06, 0x08, 0x0a, 0x0c, 0x0e,
	  0x01, 0x03, 0x05, 0x07, 0x09, 0x0b, 0x0d, 0x0f
	};
	static unsigned char diskwit [] = {
	  0x96, 0x97, 0x9a, 0x9b, 0x9d, 0x9e, 0x9f, 0xa6,
	  0xa7, 0xab, 0xac, 0xad, 0xae, 0xaf, 0xb2, 0xb3,
	  0xb4, 0xb5, 0xb6, 0xb7, 0xb9, 0xba, 0xbb, 0xbc,
	  0xbd, 0xbe, 0xbf, 0xcb, 0xcd, 0xce, 0xcf, 0xd3,
	  0xd6, 0xd7, 0xd9, 0xda, 0xdb, 0xdc, 0xdd, 0xde,
	  0xdf, 0xe5, 0xe6, 0xe7, 0xe9, 0xea, 0xeb, 0xec,
	  0xed, 0xee, 0xef, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6,
	  0xf7, 0xf9, 0xfa, 0xfb, 0xfc, 0xfd, 0xfe, 0xff
	};

	secpointer	= 0;
	for ( track=0; track < 35; track++) {
	  for ( sector=0; sector < 16; sector++) {
	    nibpointer	= (track * 0x1a00) + (dospos[sector] * 416);
	    dest[nibpointer++]	= 0x00;		/* write header prolog */
	    dest[nibpointer++]	= 0xd5;
	    dest[nibpointer++]	= 0xaa;
	    dest[nibpointer++]	= 0x96;
	    dest[nibpointer++]	= ((volume >> 1) & 0x55) | 0xaa;
	    dest[nibpointer++]	= ( volume       & 0x55) | 0xaa;
	    dest[nibpointer++]	= ((track >> 1)  & 0x55) | 0xaa;
	    dest[nibpointer++]	= ( track        & 0x55) | 0xaa;
	    dest[nibpointer++]	= ((dossit[sector] >> 1) & 0x55) | 0xaa;
	    dest[nibpointer++]	= ( dossit[sector]	 & 0x55) | 0xaa;
	    dest[nibpointer++]	= (((volume ^ track ^ dossit[sector]) >> 1) & 0x55) | 0xaa;
	    dest[nibpointer++]	= (( volume ^ track ^ dossit[sector])	    & 0x55) | 0xaa;
	    dest[nibpointer++]	= 0xde;		/* write header epilog */
	    dest[nibpointer++]	= 0xaa;
	    dest[nibpointer++]	= 0xeb;
	    dest[nibpointer++]	= 0x00;		/* gap */
	    dest[nibpointer++]	= 0x01;
	    dest[nibpointer++]	= 0x00;
	    dest[nibpointer++]	= 0x01;
	    dest[nibpointer++]	= 0x00;
	    dest[nibpointer++]	= 0xd5;		/* write data prolog */
	    dest[nibpointer++]	= 0xaa;
	    dest[nibpointer++]	= 0xad;

	    for ( zappointer=0; zappointer < 256; zappointer++) {	/* clear buffers */
	      diskzap[zappointer]	= 0;
	      diskhap[zappointer]	= 0;
	    }

	    happointer	= 2;
	    do {
	      for ( zappointer=0; zappointer < 0x56; zappointer++) {
		happointer		= (happointer - 1) & 0xff;
		diskbyte		= source[secpointer + happointer];
		diskzap[zappointer]	= (diskzap[zappointer] << 2)
					  | ((diskbyte & 0x1) << 1)
					  | ((diskbyte & 0x2) >> 1);
		diskhap[happointer]	= diskbyte >> 2;
	      }
	    }
	    while (happointer != 0);

	    for ( zappointer=0x56; zappointer > 0; zappointer--) {
	      dest[nibpointer++]	= diskwit[diskzap[zappointer] ^ diskzap[zappointer-1]];
	    }

	    dest[nibpointer++]		= diskwit[diskzap[0] ^ diskhap[0]];

	    for (happointer=1; happointer < 256; happointer++) {
	      dest[nibpointer++]	= diskwit[diskhap[happointer] ^ diskhap[happointer-1]];
	    }

	    dest[nibpointer++]		= diskwit[diskhap[255]];

	    dest[nibpointer++]	= 0xde;		/* write data epilog */
	    dest[nibpointer++]	= 0xaa;
	    dest[nibpointer++]	= 0xeb;
	    dest[nibpointer++]	= 0x00;
	    dest[nibpointer++]	= 0x01;
	    dest[nibpointer++]	= 0x00;
	    for ( zappointer=0; zappointer<11; zappointer++) {	/* write gap */
	      dest[nibpointer++]= 0x01;
	      dest[nibpointer++]= 0x00;
	      dest[nibpointer++]= 0x01;
	      dest[nibpointer++]= 0x00;
	    }
	    secpointer	= secpointer + 256;
	  } /* for sector */
	} /* for track */
      } /* driveconvertsecnib */


/*-------------------------------------*/


      /* load standard DOS image (.DSK) or Nibble image (.NIB) */
      unsigned int driveload(unsigned int keyboard, unsigned int window,
      			     unsigned char diskdata[233472], unsigned char *filename) {
	FILE *file;
	unsigned int filelength;
	unsigned char diskbuffer [143360];

	stringwrite(window, "Attempting to load disk image '");
	stringwrite(window, filename);
	stringwrite(window, "'...\r");
	file = fopen(filename,"rb");
	if (!file) {
	  stringwrite(window, "Diskimage not found. Press a key to continue\r");
	  imageupdate();
	  do { }
	  while ( (unsigned char)channelin(keyboard) == 0);
 	  return 0;
	}

	fseek(file,0,SEEK_END);		/* get filelength */
	filelength=ftell(file);
	fseek(file,0,SEEK_SET);
	stringwrite(window, "Loading disk image...\r");
	imageupdate();

	if (filelength < 232960 /*==143360*/) {
	  fread(diskbuffer,143360,1,file);
	  fclose(file);
	  driveconvertsecnib(diskbuffer, diskdata, 254);
	  stringwrite(window, "Converting image...\r");
	  imageupdate();
/*	  debugger(diskdata, 233472); */
	  return 143360;
	}
	else {
	  if (filelength==232960) {
	    fread(diskdata,232960,1,file);
	    fclose(file);
	    return 232960;
	  }
	  else {
	    fclose(file);
	    stringwrite(window, "Wrong disk image format.\r");
	    imageupdate();
	    do { }
	    while ( (unsigned char)channelin(keyboard) == 0);
	    return 0;	/* wrong file size */
	  }
	}
      } /* driveload */


/*-------------------------------------*/


      void drivetrackmessage () {
	unsigned char message[256];
	register unsigned int i;

	if (drivemessageflag) {
	  strcpy (message, "Drive 1 Track: xx / Drive 2 Track: xx");
	  i = drivetrack1 / 10;
	  if (i == 0) { message[15] = ' '; }
	  else	      { message[15] = i + '0'; }
	  message[16] = (drivetrack1 % 10) + '0';
	  i = drivetrack2 / 10;
	  if (i == 0) { message[35] = ' '; }
	  else	      { message[35] = i + '0'; }
	  message[36] = (drivetrack2 % 10) + '0';
	  setmessage(message);
	}
      } /* drivetrackmessage */


/*-------------------------------------*/


      unsigned char driveread (unsigned int addr) {
	unsigned int i;
	unsigned char bytebuffer;

	switch (addr & 0xf) {
	  case 0x0 :			/* --- */
	  case 0x2 :
	  case 0x4 :
	  case 0x6 :
	    return 0x0d;
	  case 0x1 :			/* set phase 0 */
	  case 0x3 :			/* set phase 1 */
	  case 0x5 :			/* set phase 2 */
	  case 0x7 :			/* set phase 3 */
	    addr = (addr &0xf) >> 1;
	    if (driveselect) {
	      i = (drivephase1 + 1) & 3;
	      if (i == addr) {
	        if (drivephase1 < (35*2-1)) {
	          drivephase1++;
	          drivetrack1 = drivephase1 >> 1;
	          drivetrackmessage();
	        }
	      }
	      else {
	        if ( ((i+2)&3) == addr) {
		  if (drivephase1 > 0) {
		    drivephase1--;
		    drivetrack1 = drivephase1 >> 1;
	            drivetrackmessage();
		  }
		}
	      }
	    }
	    else {
	      i = (drivephase2 + 1) & 3;
	      if (i == addr) {
		if (drivephase2 < (35*2-1)) {
		  drivephase2++;
		  drivetrack2 = drivephase2 >> 1;
	          drivetrackmessage();
		}
	      }
	      else {
	        if ( ((i+2)&3) == addr) {
		  if (drivephase2 > 0) {
		    drivephase2--;
		    drivetrack2 = drivephase2 >> 1;
	            drivetrackmessage();
		  }
		}
	      }
	    }
	    return 0xd;
	  case 0x8 :	/* motor off */
	    if (driveselect) {
	      drivemotorflag1	= false;
	      imagefillbox(window, 628, 8, 629, 9, RGBLGHTOFF);
	      drivemotorflag2	= false;
	      imagefillbox(window, 632, 8, 633, 9, RGBLGHTOFF);
	      virtcopy = 1;
	    }
	    else {
	      drivemotorflag1	= false;
	      imagefillbox(window, 628, 8, 629, 9, RGBLGHTOFF);
	      drivemotorflag2	= false;
	      imagefillbox(window, 632, 8, 633, 9, RGBLGHTOFF);
	      virtcopy = 1;
	    }
	    if (drivefastmode) {
	      cpusetlinecycle(driveoldlinecycle);
	      cpusetdelay(driveolddelay);
	      drivefastmode	= false;
	    }
	    return 0xa0;
	  case 0x9 :	/* motor on */
	    if (driveselect) {
	      drivemotorflag1	= true;
	      imagefillbox(window, 628, 8, 629, 9, RGBLGHTON);
	      drivemotorflag2	= false;
	      imagefillbox(window, 632, 8, 633, 9, RGBLGHTOFF);
	      virtcopy = 1;
	    }
	    else {
	      drivemotorflag1	= false;
	      imagefillbox(window, 628, 8, 629, 9, RGBLGHTOFF);
	      drivemotorflag2	= true;
	      imagefillbox(window, 632, 8, 633, 9, RGBLGHTON);
	      virtcopy = 1;
	    }
	    if (drivefastflag) {
	      if (!drivefastmode) {
	        driveoldlinecycle	= cpugetlinecycle();
	        driveolddelay		= cpugetdelay();
	        cpusetdelay(0);
	        cpusetlinecycle(65*8);
	        drivefastmode	= true;
	      }
	    }
	    return 0xa0;
	  case 0xa :			/* set drive 1 */
	    driveselect = true;
	    return 0xa0;
	  case 0xb :			/* set drive 2 */
	    driveselect = false;
	    return 0xa0;
	  case 0xc :			/* read/write byte to/from disk */
	    if (driveselect) {
	      if (driveaccess1) {
		bytebuffer = drivedata1[drivetrack1 * 0x1a00 + drivebytepointer1];
	      }
	      else {
		if (!drivewriteprotected1) {
		  drivedata1[drivetrack1 * 0x1a00 + drivebytepointer1] = drivelatch;
		}
		bytebuffer = drivelatch;
	      }
//	      if (drivemotorflag1) {
		drivebytepointer1++;
		if (drivebytepointer1 >= 0x1a00) {
		  drivebytepointer1 = 0;
		}
//	      }
	      return bytebuffer;
	    }
	    else {
	      if (driveaccess2) {
		bytebuffer = drivedata2[drivetrack2 * 0x1a00 + drivebytepointer2];
	      }
	      else {
		if (!drivewriteprotected2) {
		  drivedata2[drivetrack2 * 0x1a00 + drivebytepointer2] = drivelatch;
		}
		bytebuffer	= drivelatch;
	      }
//	      if (drivemotorflag2) {
		drivebytepointer2++;
		if (drivebytepointer2 >= 0x1a00) {
		  drivebytepointer2 = 0;
		}
//	      }
	      return bytebuffer;
	    }
	  case 0xd :
	    return 0xa0;
	  case 0xe :			/* set disk read */
	    if (driveselect) {
	      driveaccess1 = true;
	      return (((drivewriteprotected1)? 0x80 : 0x00) | drivelatch0ee);
	    }
	    else {
	      driveaccess2 = true;
	      return (((drivewriteprotected2)? 0x80 : 0x00) | drivelatch0ee);
	    }
	  case 0xf :			/* set disk write */
	    if (driveselect) {
	      driveaccess1 = false;
	      return 0;
	    }
	    else {
	      driveaccess2 = false;
	      return 1;
	    }
	} /* switch */
      } /* driveread */


/*-------------------------------------*/


      void drivewrite(unsigned int addr, unsigned int value) {

	switch (addr&0xf) {

	  case 0x0 :
	  case 0x1 :
	  case 0x2 :
	  case 0x3 :
	  case 0x4 :
	  case 0x5 :
	  case 0x6 :
	  case 0x7 :
	    return;
	  case 0x8 :
	    if (driveselect) {
	      drivemotorflag1	= false;
	      imagefillbox(window, 628, 8, 629, 9, RGBLGHTOFF);
	      drivemotorflag2	= false;
	      imagefillbox(window, 632, 8, 633, 9, RGBLGHTOFF);
	      virtcopy = 1;
	    }
	    else {
	      drivemotorflag1	= false;
	      imagefillbox(window, 628, 8, 629, 9, RGBLGHTOFF);
	      drivemotorflag2	= false;
	      imagefillbox(window, 632, 8, 633, 9, RGBLGHTOFF);
	      virtcopy = 1;
	    }
	    if (drivefastmode) {
	      cpusetlinecycle(driveoldlinecycle);
	      cpusetdelay(driveolddelay);
	      drivefastmode	= false;
	    }
	    return;
	  case 0x9 :
	    if (driveselect) {
	      drivemotorflag1	= true;
	      imagefillbox(window, 628, 8, 629, 9, RGBLGHTON);
	      drivemotorflag2	= false;
	      imagefillbox(window, 632, 8, 633, 9, RGBLGHTOFF);
	      virtcopy = 1;
	    }
	    else {
	      drivemotorflag1	= false;
	      imagefillbox(window, 628, 8, 629, 9, RGBLGHTOFF);
	      drivemotorflag2	= true;
	      imagefillbox(window, 632, 8, 633, 9, RGBLGHTON);
	      virtcopy = 1;
	    }
	    if (drivefastflag) {
	      if (!drivefastmode) {
	        driveoldlinecycle	= cpugetlinecycle();
	        driveolddelay		= cpugetdelay();
	        cpusetdelay(0);
	        cpusetlinecycle(65*8);
	        drivefastmode	= true;
	      }
	    }
	    return;
	  case 0xa :
	    driveselect = true;		/* set drive 1 */
	    return;
	  case 0xb :
	    driveselect = false;	/* set drive 2 */
	    return;
	  case 0xc :
	    return;
	  case 0xd :
	    drivelatch	= value;
	    return;
	  case 0xe :			/* set disk read */
	    if (driveselect) {
	      driveaccess1 = true;
	    }
	    else {
	      driveaccess2 = true;
	    }
	    return;
	  case 0xf :			/* set disk write */
	    drivelatch0ee	= value & 0x1f;
	    if (driveselect) {
	      driveaccess1 = false;
	    }
	    else {
	      driveaccess2 = false;
	    }
	    return;
	} /* switch */

      } /* drivewrite */


/*-------------------------------------*/


      void drivemenu () {
	unsigned int screen;
	unsigned int keyboard;
	unsigned int window;
	unsigned char key;
	unsigned char update;
	unsigned char filename[260];

	screen = screenstore();
	if (!windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1, "Drive Options", &keyboard, &window)) {

	  update = 1;
	  do {
	    if (update) {
	      channelout(window, 12);		/* clear window */
	      stringwrite(window, "\r[ESC] - Quit\r\r");

	      stringwrite(window, "\rCurrent drive is drive ");
	      channelout(window, driveselectmenu + '1');
	      stringwrite(window, ".\rFilename: ");
	      if (driveselectmenu) {
	        if (!inidiskpath2[0]) {
	          stringwrite(window, "<empty>");
	        }
	        else {
	          stringwrite(window, inidiskpath2);
	        }
	      }
	      else {
	        if (!inidiskpath1[0]) {
	          stringwrite(window, "<empty>");
	        }
	        else {
	          stringwrite(window, inidiskpath1);
	        }
	      }
	      channelout(window, 13);

	      stringwrite(window, "\r[1] - Select Drive 1");
	      stringwrite(window, "\r[2] - Select Drive 2");
	      stringwrite(window, "\r[E] - Eject disk");
	      stringwrite(window, "\r[L] - Load a disk image");
	      stringwrite(window, "\r\r[M] - Drive Message: ");
	      if (drivemessageflag) {
	        stringwrite(window, "On");
	      }
	      else {
	        stringwrite(window, "Off");
	      }

	      stringwrite(window, "\r[F] - Drive Fast Access: ");
	      if (drivefastflag) {
	        stringwrite(window, "On");
	      }
	      else {
	        stringwrite(window, "Off");
	      }

	      imageupdate();
	      update = 0;
	    }
	    do {
	      key = (unsigned char)channelin(keyboard);
	    }
	    while ((key == 0) && (!exitprogram));
	    switch (key) {
	      case '1' :
		driveselectmenu = 0;
		update = 1;
		break;
	      case '2' :
		driveselectmenu = 1;
		update = 1;
		break;
	      case 'e' :
	      case 'E' :
		if (driveselectmenu) {
		  driveempty(drivedata2);
		  strcpy(inidiskpath2, "");
		}
		else {
		  driveempty(drivedata1);
		  strcpy(inidiskpath1, "");
		}
		update = 1;
		break;
	      case 'f' :
	      case 'F' :
	        drivefastflag = !drivefastflag;
	        update = 1;
	        break;
	      case 'l' :
	      case 'L' :
	        if (driveselectmenu) {
		  if (fileselectmenu(keyboard, window, "Drive 2 (*.DSK, *.NIB, *.IIE, *.DO, *.PO, *.2MG)",
				     filename, "._img_", 0)) {
		    channelout(window, 12);
	            if (driveload(keyboard, window, drivedata2, filename)) {
	              strcpy(inidiskpath2, filename);
	            }
	          }
	        }
	        else {
		  if (fileselectmenu(keyboard, window, "Drive 1 (*.DSK, *.NIB, *.IIE, *.DO, *.PO, *.2MG)",
				     filename, "._img_", 0)) {
		    channelout(window, 12);
	            if (driveload(keyboard, window, drivedata1, filename)) {
	              strcpy(inidiskpath1, filename);
	            }
	          }
	        }
	        update = 1;
	        break;
	      case 'm' :
	      case 'M' :
	        drivemessageflag = !drivemessageflag;
	        update = 1;
	        break;
	    } /* switch (key) */
	  }
	  while ((key != 27) && (key != 32) && (key != 13) && (!exitprogram));
	  channelclose(keyboard);
	  channelclose(window);
	}
	screenrestore(screen);

      } /* drivemenu */
