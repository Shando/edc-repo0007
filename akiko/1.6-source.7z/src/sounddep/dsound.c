/*
 * UAE - The Un*x Amiga Emulator
 *
 * Win32 interface
 *
 * Copyright 1997 Mathias Ortmann
 * Copyright 1997-2001 Brian King
 * Copyright 2000-2001 Bernd Roesch
 */

#ifdef __GNUC__
#define INITGUID
#endif
#include <windows.h>
#include <stdlib.h>
#include <stdarg.h>
#include <mmsystem.h>
#ifdef _MSC_VER
#include <dsound.h>
#else
#include "winstuff.h"
#endif
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <io.h>

#include "sysconfig.h"
#include "sysdeps.h"

#include <ctype.h>
#include <assert.h>
#include "config.h"
#include "options.h"
#include "threaddep/penguin.h"
#include "uae.h"
#include "gensound.h"
#include "sounddep/sound.h"
#include "events.h"
#include "memory.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "xwin.h"
#include "osdep/win32.h"
#include "gui.h"
DSBPOSITIONNOTIFY           rgdsbpn[4];
HANDLE                      rghEvent[4];
LPDIRECTSOUNDNOTIFY         lpdsNotify;

int i;
char *sndptr, *sndptrmax, soundneutral,*tempmem;
static HWND dsound_tmpw;

static WAVEFORMATEX wavfmt;

LPSTR lpData;

static BOOL sound_stopped = TRUE;
static frame_time_t basevsynctime = 0;
signed long bufsamples;
unsigned int samplecount;
DWORD soundbufsize;

DWORD tooslow = 0, toofast = 0;
static long oldfreeblock=-1,oldfreeblock4=-1;


int timer_available = 0;
UINT timer_period = 0;

static HANDLE hVBlankEvent, hSoundCompleteEvent;

MMRESULT idVBlankTimer;
/*
typedef enum
{
    waveout_looping,
    waveout_dblbuff,
    dxsound_looping,
    dxsound_dblbuff
} win32_sound_style_e;
*/
static int last_sound_setting;

static DWORD sound_flushes  = 0;
static int directsound_notification = 0;
MMTIME mmtime;

static HMODULE hDSound = NULL;

typedef HRESULT (WINAPI *DirectSoundCreateFuncPtr)(GUID FAR *, LPDIRECTSOUND FAR *, IUnknown FAR *);
static DirectSoundCreateFuncPtr pDirectSoundCreate = NULL;

extern HWND hAmigaWnd;
#ifdef __GNUC__
DEFINE_GUID(IID_IDirectSoundNotify, 0xb0210783, 0x89cd, 0x11d0, 0xaf, 0x8, 0x0, 0xa0, 0xc9, 0x25, 0xcd, 0x16);
#endif

LPDIRECTSOUND lpDS = NULL;
LPDIRECTSOUNDBUFFER lpDSBprimary = NULL;
LPDIRECTSOUNDBUFFER lpDSB = NULL;
LPDIRECTSOUNDNOTIFY lpDSBN = NULL;
 
char *DSError( HRESULT error )
{
    switch( error )
    {
    case DSERR_ALLOCATED:
        return "Allocated";

    case DSERR_CONTROLUNAVAIL:
        return "Control Unavailable";

    case DSERR_INVALIDPARAM:
        return "Invalid Parameter";

    case DSERR_INVALIDCALL:
        return "Invalid Call";

    case DSERR_GENERIC:
        return "Generic";

    case DSERR_PRIOLEVELNEEDED:
        return "Priority Level Needed";

    case DSERR_OUTOFMEMORY:
        return "Out of Memory";

    case DSERR_BADFORMAT:
        return "Bad Format";

    case DSERR_UNSUPPORTED:
        return "Unsupported";

    case DSERR_NODRIVER:
        return "No Driver";

    case DSERR_ALREADYINITIALIZED:
        return "Already Initialized";

    case DSERR_NOAGGREGATION:
        return "No Aggregation";

    case DSERR_BUFFERLOST:
        return "Buffer Lost";

    case DSERR_OTHERAPPHASPRIO:
        return "Other Application Has Priority";

    case DSERR_UNINITIALIZED:
        return "Uninitialized";

    case DSERR_NOINTERFACE:
        return "No Interface";

    default:
        return "Unknown";
    }
}

DWORD sync_timer = 0;
HANDLE hSyncEvent = NULL;

int setup_sound (void)
{
    sound_available = 1;

    if( hSyncEvent = CreateEvent( NULL, FALSE, FALSE, NULL ) )
    {
	sync_timer = timeSetEvent( 20, 1, hSyncEvent, 0, TIME_PERIODIC | TIME_CALLBACK_EVENT_SET );
    }

    return 1;
}

void cleanup_sound( void )
{
    if( sound_available )
    {
	if( sync_timer )
	{
	    timeKillEvent( sync_timer );
	}
	if( hSyncEvent )
	{
	    CloseHandle( hSyncEvent );
	}
    }
}

void synchronize_timing( void )
{
    if( sync_timer && ( currprefs.produce_sound <= 1 ) && ( currprefs.m68k_speed == 0 ) )
    {
	// Synchronize to 20ms
	WaitForSingleObject( hSyncEvent, INFINITE );
    }
}

long calcsound=1;
void close_sound (void)
{
    if( lpDSB )
    {
        IDirectSoundBuffer_Release( lpDSB );
        lpDSB = NULL;
    }
    if( lpDSBprimary )
    {
        IDirectSoundBuffer_Release( lpDSBprimary );
        lpDSBprimary = NULL;
    }
    if( lpDS )
    {
        IDirectSound_Release( lpDS );
        lpDS = NULL;
    }
    if( hDSound )
        FreeLibrary( hDSound );

    sound_stopped = TRUE;
	oldfreeblock=-1;
	oldfreeblock4=-1;

	calcsound=1;
	DestroyWindow(dsound_tmpw);dsound_tmpw=0;
	free(tempmem);
    }

void startsound( int force )
{
	
    HRESULT hr;
	 static   DWORD dwBytes,dwBytes1,dwBytes2,dwData1,dwData2;
	long freeblock,i;
	static long tile=2;
	long blksize=soundbufsize/tile;//for buffer parts
	
    
        
		if( sound_flushes == 1 )
	{
	    
		/* Lock the entire buffer */
	   	hr = IDirectSoundBuffer_Lock( lpDSB, 0, soundbufsize, &lpData, &dwBytes,&dwData2,&dwBytes2,0 );
		if( hr == DSERR_BUFFERLOST )
		{
		    IDirectSoundBuffer_Restore( lpDSB );
		    hr = IDirectSoundBuffer_Lock( lpDSB, 0, 0, &lpData, &dwBytes,&dwData2,&dwBytes2, DSBLOCK_ENTIREBUFFER );
			
		}
	  
	    /* Get the big looping IDirectSoundBuffer_Play() rolling here, but only once at startup */
	    hr = IDirectSoundBuffer_Play( lpDSB, 0, 0, DSBPLAY_LOOPING );
		hr=IDirectSoundBuffer_Unlock(lpDSB,lpData,dwBytes,dwData2,dwBytes2); 
        
        //memset( lpData, 0x80,4 );

	}
/*
		{
long dwEvt=1;

  dwEvt = MsgWaitForMultipleObjects(
            2,      // How many possible events
            rghEvent,       // Location of handles
            FALSE,          // Wait for all?
            INFINITE,       // How long to wait
            QS_ALLINPUT);   // Any message is an event

			
calcsound=1;
if (dwEvt==0)freeblock=0;
if (dwEvt==1)freeblock=1;


if (dwEvt>1 ){calcsound=0;return;}
		}
*/

  hr=IDirectSoundBuffer_GetCurrentPosition(lpDSB,&i,0);
  if( hr != DSERR_BUFFERLOST )
		{		   		
  
  freeblock=i/(blksize);
  if (freeblock==oldfreeblock){calcsound=0;return;}
  calcsound=1;
   }
if (oldfreeblock==-1)oldfreeblock=0;
//if(dwBytes1)IDirectSoundBuffer_Unlock(lpDSB, dwData1,dwBytes1,dwData2, dwBytes2); 
hr = IDirectSoundBuffer_Lock( lpDSB, oldfreeblock*blksize,blksize, &dwData1, &dwBytes1,&dwData2,&dwBytes2,0);


		if( hr == DSERR_BUFFERLOST )
			{
			write_log("lostbuf%d  %x\n",freeblock,blksize);
		    IDirectSoundBuffer_Restore( lpDSB );
		    hr = IDirectSoundBuffer_Lock( lpDSB, 0, 0, &lpData, &dwBytes, NULL, NULL, DSBLOCK_ENTIREBUFFER );
		  	dwData1=lpData;dwBytes1=dwBytes;dwBytes2=0;dwData2=0;
		}
		
	
				//write_log("%d  %x\n",freeblock,blksize);
			
                
							//sndptr=lpData+(oldfreeblock*blksize);	
	
		     memcpy(lpData+(oldfreeblock*blksize),tempmem,blksize);
             oldfreeblock=freeblock;
 		     		    sndptr=tempmem;
  
    sndptrmax=sndptr+blksize;
 
IDirectSoundBuffer_Unlock(lpDSB, dwData1,dwBytes1,dwData2, dwBytes2); 
     
   
}

 void stopsound( void )
{
    HRESULT hr;

    if( sound_stopped == FALSE )
    {
        sndptr = lpData;
        samplecount = 0;
        hr = IDirectSoundBuffer_Stop( lpDSB );
        if( hr != DS_OK )
        {
            write_log( "SoundStop() failure: %s\n", DSError( hr ) );
        }
        else
	{
            write_log( "Sound Stopped...\n" );
	}

	/* Unlock the entire buffer */
	    close_sound();

        
        sound_stopped = TRUE;
    }
}

/* Use this to pause or stop Win32 sound output */
void pause_sound( int full_stop )
{
    if( currprefs.produce_sound > 1 )
    {
        if( full_stop )
        {
            last_sound_setting = currprefs.produce_sound;
            if( last_sound_setting > 1 )
                changed_prefs.produce_sound = 1;
            else
                changed_prefs.produce_sound = 0;
        }
        else
        {
            stopsound();
        }
    }
}

/* Use this to resume Win32 sound output */
void resume_sound( void )
{
    if( ( ( currprefs.produce_sound > 1 ) || ( last_sound_setting > 1 ) ) && sound_stopped )
    {
        sound_flushes = 0; /* Because flush_sound_buffer() will increment this to 1 */
        if( last_sound_setting > 1 )
            changed_prefs.produce_sound = last_sound_setting;
    }
		if (sound_stopped==TRUE)init_sound();
}

void flush_sound_buffer( void )
{
    sound_flushes++;

    startsound(1);
	
}


static int init_sound_win32(void);

int dsound_newwindow (HWND w)
{
    HRESULT hr;

    if( currprefs.win32_sound_style < dxsound_looping )
        return 1;

#if 0
    if (lpDS == 0)
	return 1;

    if (w == 0)
    {
	    w = dsound_tmpw;
        write_log( "DirectSound using temp window.\n" );
    }
    else
        write_log( "DirectSound using window 0x%x.\n", w );

    hr = IDirectSound_SetCooperativeLevel (lpDS, w, DSSCL_PRIORITY );
    if (hr != DS_OK) {
	write_log( "SetCooperativeLevel() failure: %s\n", DSError (hr));
	return 0;
    }
#else
    if (currprefs.produce_sound < 2)
        return 1;

    if (w == 0)
    {
        stopsound();
        close_sound();
        write_log ( "Sound shutting down...\n" );
    }
    else
    {
        init_sound_win32();
        write_log ( "Sound starting up...\n" );
        if( currprefs.win32_sound_style >= dxsound_looping ) 
        {
            hr = IDirectSound_SetCooperativeLevel (lpDS, w, DSSCL_PRIORITY );
            if (hr != DS_OK) {
                write_log( "SetCooperativeLevel() failure: %s\n", DSError (hr));
                return 0;
            }
        }
    }
#endif
    return 1;
}

static int init_sound_win32 (void)
{
    HRESULT hr;
    DSBUFFERDESC sound_buffer;
    DSCAPS DSCaps;
    DWORD dwBytes;
    
    if (lpDS )
        return 0;

    if( currprefs.produce_sound < 1 ) 
    {
        write_log( "Sound output disabled.\n" );
        return 1;
    }

    wavfmt.wFormatTag = WAVE_FORMAT_PCM;
    wavfmt.nChannels = 1 + currprefs.stereo;
    wavfmt.nSamplesPerSec = currprefs.sound_freq;
    wavfmt.wBitsPerSample = currprefs.sound_bits;
    wavfmt.nBlockAlign = currprefs.sound_bits / 8 * wavfmt.nChannels;
    wavfmt.nAvgBytesPerSec = wavfmt.nBlockAlign * currprefs.sound_freq;

    soundneutral = currprefs.sound_bits == 8 ? 128 : 0;
    bufsamples =  currprefs.sound_freq / 11025;
    soundbufsize = (1024*(changed_prefs.win32_sound_tweak+1));
    hr = DirectSoundCreate( NULL, &lpDS, NULL );
    if (hr != DS_OK) 
    {
        write_log( "DirectSoundCreate() failure: %s\n", DSError (hr));
        return 0;
    }

    dsound_tmpw = CreateWindowEx( WS_EX_ACCEPTFILES,
                                  "PCsuxRox",
                                  "Argh",
                                  WS_CAPTION,
                                  CW_USEDEFAULT, CW_USEDEFAULT,
                                  10, 10,
                                  NULL,
                                  NULL,
                                  0,
                                  NULL);

    if (! dsound_newwindow (dsound_tmpw))
        return 0;

    memset (&sound_buffer, 0, sizeof( DSBUFFERDESC ));
    sound_buffer.dwSize = sizeof( DSBUFFERDESC );
    sound_buffer.dwFlags = DSBCAPS_PRIMARYBUFFER;
    sound_buffer.dwBufferBytes = 0;
    sound_buffer.lpwfxFormat = NULL;

    DSCaps.dwSize = sizeof( DSCAPS );
    hr = IDirectSound_GetCaps( lpDS, &DSCaps );
    if( hr == DS_OK )
    {
	if( DSCaps.dwFlags & DSCAPS_EMULDRIVER )
	    write_log( "Your DirectSound Driver is emulated via WaveOut - yuck!\n" );
    }
	if FAILED(IDirectSound_SetCooperativeLevel(
            lpDS,dsound_tmpw, DSSCL_PRIORITY))
        return 0;
    hr = IDirectSound_CreateSoundBuffer (lpDS, &sound_buffer, &lpDSBprimary, NULL);
    if( hr != DS_OK ) 
    {
        write_log( "CreateSoundBuffer() failure: %s\n", DSError( hr ) );
        return 0;
    }

   
 
    hr = IDirectSoundBuffer_SetFormat (lpDSBprimary, &wavfmt);
    if( hr != DS_OK ) 
    {
        write_log( "SetFormat() failure: %s\n", DSError (hr));
        return 0;
    }
    sound_buffer.dwBufferBytes = soundbufsize;
    sound_buffer.lpwfxFormat = &wavfmt;
    sound_buffer.dwFlags = DSBCAPS_CTRLFREQUENCY | DSBCAPS_CTRLVOLUME /*| DSBCAPS_CTRLPOSITIONNOTIFY */| DSBCAPS_GETCURRENTPOSITION2|DSBCAPS_GLOBALFOCUS ;
    hr = IDirectSound_CreateSoundBuffer( lpDS, &sound_buffer, &lpDSB, NULL );
    if (hr != DS_OK) 
    {
        write_log ("CreateSoundBuffer() failure: %s\n", DSError (hr));
        return 0;
    }
/*  //used for PositionNotify 
    for ( i = 0; i < 2; i++)
    {
        rghEvent[i] = CreateEvent(NULL, FALSE, FALSE, NULL);
        if (NULL == rghEvent[i]) return FALSE;
    }
    rgdsbpn[0].dwOffset = 0;
    rgdsbpn[0].hEventNotify = rghEvent[0];
    rgdsbpn[1].dwOffset = (soundbufsize/2)*1;
    rgdsbpn[1].hEventNotify = rghEvent[1];

   
    if FAILED(IDirectSoundBuffer_QueryInterface(lpDSB, 
            &IID_IDirectSoundNotify, (VOID **)&lpdsNotify))
        return FALSE; 
 
    if FAILED(IDirectSoundNotify_SetNotificationPositions(
             lpdsNotify, 2,rgdsbpn))
    {
        IDirectSoundNotify_Release(lpdsNotify);
        return FALSE;
    }

*/

    hr = IDirectSoundBuffer_SetVolume (lpDSB, 0);
    if (hr != DS_OK) 
    {
        write_log( "SetVolume() 2 failure: %s\n", DSError (hr));
        return 0;
    }

     
    
	tempmem=malloc(soundbufsize);
	if(tempmem==0)return 0;
    sndptr = tempmem;
    sndptrmax = tempmem + soundbufsize;
    samplecount = 0;
    memset( tempmem, soundneutral, soundbufsize );
    write_log("Init Sound Rate %d Buffsize %d\n",currprefs.sound_freq,soundbufsize); 
    sound_stopped =FALSE;

    return currprefs.sound_freq;
}

static int rate;
int init_sound (void)
{
    if(sound_stopped==TRUE)
    {
	if (currprefs.sound_bits == 16) {
	    init_sound_table16 ();
	    sample_handler = currprefs.stereo ? sample16s_handler : sample16_handler;
	} else {
	    init_sound_table8 ();
	    sample_handler = currprefs.stereo ? sample8s_handler : sample8_handler;
	}
    
	if ((rate = init_sound_win32 ()) )
	    {
	    //extern unsigned long last_cycles;
	    scaled_sample_evtime = (unsigned long) maxhpos * maxvpos * vblank_hz * CYCLE_UNIT / rate;
	    scaled_sample_evtime_ok = 1;
	    //last_cycles=cycles;

	    return rate;
	}
      /*  write_log( "%s driver found and configured for %d bits at %d Hz %s\n",
	    ( currprefs.win32_sound_style >= dxsound_looping ) ? "DirectSound" : "DirectSound", currprefs.sound_bits, rate,
	    currprefs.stereo ? "stereo" : "" );

	return 1;*/
	return 0;
    }
    return 1;
}

void update_sound (void)
{
    if( rate >= 11050 )
    {
        scaled_sample_evtime = (unsigned long) maxhpos * maxvpos * vblank_hz * CYCLE_UNIT / rate;
    }
    vsyncmintime = vsynctime;
}     
