
#ifndef WIN32CLOCKDEVICE_H
#define WIN32CLOCKDEVICE_H

#include <windows.h>

class Win32ClockDevice
{

    public:
        INT64 getTickFrequency();
        INT64 getTick();

};

#endif

