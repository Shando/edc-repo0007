package com.bliss.core;

import java.io.IOException;

public class MemoryAlias extends Memory
{
    public MemoryAlias(Memory m, int location) {
        this(m, location, false);
    }

    public MemoryAlias(Memory m, int location, boolean writeOnly) {
        this.aliasedMemory = m;
        this.location = location;
        this.writeOnly = writeOnly;
        this.offset = location - m.getLocation();
    }

    public void reset() {
        visible = true;
    }

    public void save(SaveOutputStream sos) throws IOException {
        sos.writeBoolean(visible);
    }

    public void load(LoadInputStream lis) throws IOException {
        visible = lis.readBoolean();
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public boolean isVisible() {
        return visible;
    }

    public int getLocation() {
        return location;
    }

    public int peek(int location) {
        return (writeOnly ? Memory.UNMAPPED_PEEK :
                (visible ? aliasedMemory.peek(location-offset) : location));
    }

    public void poke(int location, int value) {
        if (visible)
            aliasedMemory.poke(location-offset, value);
    }

    public int getSize() {
        return aliasedMemory.getSize();
    }

    protected Memory  aliasedMemory;
    protected int     location;
    protected int     offset;
    protected boolean writeOnly;
    protected boolean visible = true;
    
}
