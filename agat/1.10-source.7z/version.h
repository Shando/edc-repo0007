#define VERSION_NAME_STR	"Agat v1.10"
#define VERSION_STR	"1.10"
#define VERSION_VER	1, 10, 0, 0
#define VERSION_VER_STR	"1, 10, 0, 0\0"

