/*
 * GameSelectPage.cs
 * 
 * A TabPage that facilitates game ROM selection.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */
using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace EMU7800 {

public class GameSelectPage : TabPage {
	private ControlPanelForm ControlPanelForm;

	private Label lblGameTitle, lblROMDir, lblROMCount;
	private ComboBox cmbROMDir;
	private Button btnBrowse;
	private OpenFileDialog ofdROMSelect;
	private bool InitialTreeViewLoaded = false;
	private TreeView tvROMList;
	private TreeNode tnTitle, tnUnknown;
	private int ROMFileCount;

	private GameSettings CurrGameSettings;
		
	public GameSelectPage(ControlPanelForm f) {
		ControlPanelForm = f;

		Text = "Game Programs";

		lblROMDir = new Label();
		lblROMDir.Location = new Point(5, 5);
		lblROMDir.Size = new Size(Width, lblROMDir.PreferredHeight);
		lblROMDir.Text = "Current ROM Directory";

		cmbROMDir = new ComboBox();
		cmbROMDir.Text = Globals.ROMDirectory;
		cmbROMDir.Location = new Point(5, 20);
		cmbROMDir.Items.Add(cmbROMDir.Text);
		cmbROMDir.SelectedValueChanged += new EventHandler(OnComboBoxChanged);

		btnBrowse = new Button();
		btnBrowse.Text = "Browse";
		btnBrowse.Location = new Point(5, 45);
		btnBrowse.Size = new Size(70, 25);
		btnBrowse.Click += new EventHandler(OnBrowseClick);

		lblGameTitle = new Label();
		lblGameTitle.Location = new Point(5, 80);
		lblGameTitle.Size = new Size(220, 30);
		lblGameTitle.Text = Globals.Copyright;
		lblGameTitle.BorderStyle = BorderStyle.FixedSingle;
		lblGameTitle.TextAlign = ContentAlignment.MiddleCenter;

		tvROMList = new TreeView();
		tvROMList.Location = new Point(5, 120);
		tvROMList.HideSelection = false;
		tvROMList.AfterSelect += new TreeViewEventHandler(OnClickTreeView);

		lblROMCount = new Label();
		lblROMCount.Size = new Size(Width, lblROMCount.PreferredHeight);
		lblROMCount.Text = "";

		Layout += new LayoutEventHandler(OnLayout);
		VisibleChanged += new EventHandler(OnVisibleChanged);
		MouseEnter += new EventHandler(OnMouseEnter);
		tvROMList.MouseEnter += new EventHandler(OnMouseEnter);

		Controls.AddRange(new Control[] {
			lblGameTitle, lblROMDir, lblROMCount,
			cmbROMDir, btnBrowse, tvROMList});
	}

	private void OnMouseEnter(object sender, EventArgs e) {
		if (!InitialTreeViewLoaded) {
			InitialTreeViewLoaded = true;
			DoLoadTreeView();
		}
	}

	private void OnVisibleChanged(object sender, EventArgs e) {
		if (CurrGameSettings != ControlPanelForm.CurrGameSettings) {
			lblGameTitle.Text = "(unknown title selected)";
		}
	}

	private void OnComboBoxChanged(object sender, EventArgs e) {
		if (cmbROMDir.Text != Globals.ROMDirectory) {
			Globals.ROMDirectory = cmbROMDir.Text;
			DoLoadTreeView();
		}
	}

	private void OnBrowseClick(object sender, EventArgs e) {
		ofdROMSelect = new OpenFileDialog();
		ofdROMSelect.Title = "Select ROM File";
		ofdROMSelect.Filter = "ROMs (*.bin)|*.bin|A78 ROMs (*.a78)|*.a78" ;
		ofdROMSelect.FilterIndex = 1;

		string initdir = cmbROMDir.Text.Replace(@"/", @"\");
		if (!Directory.Exists(initdir)) {
			initdir = Globals.RootDir;
		}
		ofdROMSelect.InitialDirectory = initdir;

		if(ofdROMSelect.ShowDialog() == DialogResult.OK) {
			string fn = ofdROMSelect.FileName;
			string romdir = fn.Substring(0, fn.LastIndexOf(@"\") + 1).Replace(@"\", "/");
			cmbROMDir.Text = romdir;

			bool found = false;
			foreach (string s in cmbROMDir.Items) {
				if (s == romdir) {
					found = true;
					break;
				}
			}

			if (!found) {
				cmbROMDir.Items.Add(romdir);
				Globals.ROMDirectory = romdir;
				DoLoadTreeView();
			}

			SelectTitle(ofdROMSelect.FileName.Replace(@"\", "/"));
		}
	}
	
	private void OnClickTreeView(object sender, TreeViewEventArgs e) {
		if (e.Node == null || e.Node.Tag == null || ControlPanelForm.HostRunning) {
			return;
		}
		
		CurrGameSettings = ((GameSettings)e.Node.Tag);
		ControlPanelForm.CurrGameSettings = CurrGameSettings;
		GameSettings gs = ControlPanelForm.CurrGameSettings;

		s.Length = 0;
		s.Append(gs.Title);

		switch (gs.MachineType) {
		case MachineType.A2600NTSC:
			s.Append(", 2600 NTSC");
			break;
		case MachineType.A2600PAL:
			s.Append(", 2600 PAL");
			break;
		case MachineType.A7800NTSC:
			s.Append(", 7800 NTSC");
			break;
		case MachineType.A7800PAL:
			s.Append(", 7800 PAL");
			break;
		}
		
		if (gs.Manufacturer.Trim().Length > 0) {
			s.AppendFormat(", {0}", gs.Manufacturer);
		}
		if (gs.Year.Trim().Length > 0) {
			s.AppendFormat(", {0}", gs.Year);
		}
		lblGameTitle.Text = s.ToString();

		ControlPanelForm.StartButtonEnabled = true;
		ControlPanelForm.ResumeButtonEnabled = false;
	}

	private void OnLayout(object sender, LayoutEventArgs e) {
		cmbROMDir.Size = new Size(Width - 2*5, cmbROMDir.Size.Height);

		tvROMList.Size = new Size(Width - 2*5,
			Size.Height - tvROMList.Location.Y - 20);

		lblROMCount.Location = new Point(5, Size.Height - 15);
	}

	private void DoLoadTreeView() {
		Cursor prevCursor = ControlPanelForm.Cursor;
		ControlPanelForm.Cursor = Cursors.WaitCursor;

		ROMFileCount = 0;

		try {
			LoadTreeView();
		} catch (Exception e) {
			Log.Msg("Error loading TreeView: {0}\n", e.Message);
		}

		StringBuilder sb = new StringBuilder();
		sb.Append(ROMFileCount);
		sb.Append(" ROM file");
		if (ROMFileCount != 1) {
			sb.Append("s");
		}
		sb.Append(" recognized");
		lblROMCount.Text = sb.ToString();

		ControlPanelForm.Cursor = prevCursor;
	}

	private StringBuilder s = new StringBuilder();

	private byte[] GetROM(FileInfo fi, int offset) {
		byte[] rom = null;
		try {
			BinaryReader r = new BinaryReader(File.OpenRead(fi.FullName));
			r.BaseStream.Seek(offset, SeekOrigin.Begin);
			rom = r.ReadBytes((int)fi.Length - offset);
			r.Close();
		} catch (Exception e) {
			Log.Msg("Error in GetROM(): {0}\n", e.ToString());
		}
		return rom;
	}

	private GameSettings GetGameSettingsFromFile(FileInfo fi, int offset) {
		string md5sum = MD5.ComputeMD5Digest(GetROM(fi, offset));

		if (!GameSettings.ROMProperties.ContainsKey(md5sum)) {
			Log.Msg("Unrecognized file: \n{0}\nMD5={1}\n",
				fi.FullName, md5sum.ToString());
			return null;
		}

		GameSettings gs = (GameSettings)GameSettings.ROMProperties[md5sum];
		gs.ROMFullName = fi.FullName.Replace(@"\", "/");
		gs.ROMFileName = fi.Name.Replace(@"\", "/");
		gs.Offset = offset;
		gs.Size = fi.Length - offset;

		return gs;
	}

	private void LoadTreeView() {
		tvROMList.BeginUpdate();
		tvROMList.Nodes.Clear();

		tnTitle = new TreeNode("Title");
		tvROMList.Nodes.Add(tnTitle);

		string[] manList = new string[] {
			"Absolute",
			"Activision",
			"Atari",
			"CBS Electronics",
			"Coleco",
			"Epyx",
			"Froggo",
			"Imagic",
			"Konami",
			"Mattel",
			"Milton Bradley",
			"Mystique",
			"Parker Bros",
			"Sega",
			"Starsoft",
			"Telesys",
			"Tigervision",
			"20th Century Fox",
		};
		Hashtable mtbl = AddTreeSubRoot(tvROMList, "Manufacturer", manList);

		string[] yearList = new string[] {
			"1977","1978","1979","1980","1981","1982","1983",
			"1984","1985","1986","1987","1988", "1989", "1990",
		};
		Hashtable ytbl = AddTreeSubRoot(tvROMList, "Year", yearList);

		string[] rareList = new string[] {
			"Common", "Uncommon", "Rare", "Extremely Rare",
			"Unbelievably Rare", "Prototype", "Unreleased Prototype",
		};
		Hashtable raretbl = AddTreeSubRoot(tvROMList, "Rarity", rareList);

		string[] machList = new String[] {
			"2600 NTSC", "2600 PAL",
			"7800 NTSC", "7800 PAL",
		};
		Hashtable machtbl = AddTreeSubRoot(tvROMList, "Machine Type", machList);
#if DEBUG
		string[] cartList = Enum.GetNames(typeof(CartType));
		Hashtable carttbl = AddTreeSubRoot(tvROMList, "Cartridge Type", cartList);
#endif
		tnUnknown = new TreeNode("Unknown");
		tvROMList.Nodes.Add(tnUnknown);

		StringBuilder md5 = new StringBuilder();
		FileInfo[] romFiles = new DirectoryInfo(Globals.ROMDirectory).GetFiles();
	
		foreach (FileInfo fi in romFiles) {
			GameSettings gs = null;

			switch (fi.Extension.ToLower()) {
			case ".bin":
				gs = GetGameSettingsFromFile(fi, 0);
				break;
			case ".a78":
				gs = GetGameSettingsFromFile(fi, 128);
				break;
			}

			if (gs == null) {
				continue;
			}

			ROMFileCount++;

			TreeNode tn = new TreeNode(BuildTitle(gs.Title, gs.Manufacturer, gs.Year));
			tn.Tag = gs;
			tnTitle.Nodes.Add(tn);

			AddTreeNode(mtbl, gs, gs.Manufacturer,
				gs.Title, gs.Year);
			AddTreeNode(ytbl, gs, gs.Year,
				gs.Title, gs.Manufacturer);
			AddTreeNode(raretbl, gs, gs.Rarity,
				gs.Title, gs.Manufacturer, gs.Year);
			AddTreeNode(machtbl, gs, machList[(int)gs.MachineType],
				gs.Title, gs.Manufacturer, gs.Year);
#if DEBUG
			AddTreeNode(carttbl, gs, gs.CartType.ToString(),
				gs.Title, gs.Manufacturer, gs.Year);
#endif
			Application.DoEvents();
		}

		tvROMList.Sorted = true;
		tvROMList.EndUpdate();
		tvROMList.Update();
	}

	private void SelectTitle(string fullName) {
		FileInfo fi = new FileInfo(fullName);
		int offset = 0;
		if (fi.Extension == ".a78") {
			offset = 128;
		}
		string md5sum = MD5.ComputeMD5Digest(GetROM(fi, offset));
		if (md5sum == null) {
			return;
		}
		foreach (TreeNode tn in tnTitle.Nodes) {
			if (tn.Tag == null) {
				continue;
			}
			if (md5sum == ((GameSettings)tn.Tag).SaveKey) {
				tvROMList.SelectedNode = tn;
				return;
			}
		}
		foreach (TreeNode tn in tnUnknown.Nodes) {
			if (tn.Tag == null) {
				continue;
			}
			if (md5sum == ((GameSettings)tn.Tag).SaveKey) {
				tvROMList.SelectedNode = tn;
				return;
			}
		}
	}

	private Hashtable AddTreeSubRoot(TreeView root, string label, string[] subList) {
		TreeNode tnparent = new TreeNode(label);
		root.Nodes.Add(tnparent);
		Hashtable t = new Hashtable();
		TreeNode tn;
		foreach (string s in subList) {
			tn = new TreeNode(s);
			tnparent.Nodes.Add(tn);
			t.Add(s, tn);
		}
		tn = new TreeNode("Other");
		tnparent.Nodes.Add(tn);
		t.Add("Other", tn);
		return t;
	}

	private void AddTreeNode(Hashtable t, GameSettings gs, string key,
			params string[] titlebits) {
		TreeNode tn = new TreeNode(BuildTitle(titlebits));
		tn.Tag = gs;
		if (!t.ContainsKey(key)) {
			key = "Other";
		}
		((TreeNode)t[key]).Nodes.Add(tn);
	}

	private string BuildTitle(params string[] titlebits) {
		StringBuilder title = new StringBuilder();

		for (int i=0; i < titlebits.Length; i++) {
			if (titlebits[i].Length > 0) {
				if (i > 0) {
					title.Append(", ");
				}
				title.Append(titlebits[i]);
			}
		}
		return title.ToString();
	}
}
}