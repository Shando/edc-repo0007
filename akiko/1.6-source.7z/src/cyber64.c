#include "sysconfig.h"
#include "sysdeps.h"

#include "config.h"
#include "options.h"
#include "events.h"
#include "threaddep/penguin.h"
#include "uae.h"
#include "memory.h"
#include "custom.h"
#include "newcpu.h"
#include "xwin.h"
#include "cyber64.h"
#include <asm/io.h>

#ifdef CYBER64

#define USE_IO 1
#define ALWAYS_IO 1

static uae_u32 cyber64_lget (uaecptr) REGPARAM;
static uae_u32 cyber64_wget (uaecptr) REGPARAM;
static uae_u32 cyber64_bget (uaecptr) REGPARAM;
static void cyber64_lput (uaecptr, uae_u32) REGPARAM;
static void cyber64_wput (uaecptr, uae_u32) REGPARAM;
static void cyber64_bput (uaecptr, uae_u32) REGPARAM;
static int cyber64_check (uaecptr addr, uae_u32 size) REGPARAM;
static uae_u8 *cyber64_xlate (uaecptr addr) REGPARAM;

addrbank cyber64_bank = {
    cyber64_lget, cyber64_wget, cyber64_bget,
    cyber64_lput, cyber64_wput, cyber64_bput,
    cyber64_xlate, cyber64_check, NULL
};

static uae_u32 cyber64regs_lget (uaecptr) REGPARAM;
static uae_u32 cyber64regs_wget (uaecptr) REGPARAM;
static uae_u32 cyber64regs_bget (uaecptr) REGPARAM;
static void cyber64regs_lput (uaecptr, uae_u32) REGPARAM;
static void cyber64regs_wput (uaecptr, uae_u32) REGPARAM;
static void cyber64regs_bput (uaecptr, uae_u32) REGPARAM;
static int cyber64regs_check (uaecptr addr, uae_u32 size) REGPARAM;
static uae_u8 *cyber64regs_xlate (uaecptr addr) REGPARAM;

addrbank cyber64regs_bank = {
    cyber64regs_lget, cyber64regs_wget, cyber64regs_bget,
    cyber64regs_lput, cyber64regs_wput, cyber64regs_bput,
    cyber64regs_xlate, cyber64regs_check, NULL
};


static uae_u8* cyber_mem=NULL;
static uae_u8* cyber_regs=NULL;

extern uae_u32 cyber64_start;
#define CYBER_SIZE     0x200000
#define CYBER_OFFSET 0x01400000

int dummy;

static uae_u16 swap16(uae_u16 x)
{
    return ((x&0xff00)>>8)|((x&0x00ff)<<8);
}

static uae_u32 swap32(uae_u32 x)
{
    return ((x&0xff00)<<8)|((x&0x00ff)<<24)|
	((x&0xff0000)>>8)|((x&0xff000000)>>24);
}

static void check_mem() 
{
    cyber_mem[0]=123;
    cyber_mem[dummy]=213;
    write_log("Cyber: lost mem? %d\n",cyber_mem[0]);
}

static void switch_cursor_mode(void)
{
    uae_u8 was;
    outb(0x55,0x3d4);
    was=inb(0x3d5);
    outb(0x55,0x3d4);
    outb(was&(~0x10),0x3d5);
    write_log("Cyber switched cursor mode\n");
}

uae_u32 REGPARAM2 cyber64_lget (uaecptr addr)
{
    uae_u32 answer;
    int needlook=0;

    addr-=cyber64_start;
    addr-=CYBER_OFFSET;
    if (addr>=CYBER_SIZE) {
	special_mem|=S_READ;
	write_log ("Cyber64 lget at %08lx (%08x)\n", addr, answer);
	needlook=1;
	return 0;
    }
    addr&=(CYBER_SIZE-1);
    answer=do_get_mem_long((uae_u32*)(cyber_mem+addr));

    if (needlook)
	write_log ("Cyber64 reallget at %08lx (%08x)\n", addr, answer);

    // write_log ("Cyber64 lget at %08lx (%08x)\n", addr, answer);
    return answer;
}

uae_u32 REGPARAM2 cyber64_wget (uaecptr addr)
{
    uae_u16 answer;

    addr-=cyber64_start;
    addr-=CYBER_OFFSET;
    if (addr>=CYBER_SIZE) {
	special_mem|=S_READ;
	write_log ("Cyber64 wget at %08lx (%04x)\n", addr, answer);
    }
    addr&=(CYBER_SIZE-1);
    answer=do_get_mem_word((uae_u16*)(cyber_mem+addr));

    // write_log ("Cyber64 wget at %08lx (%04x)\n", addr, answer);
    return answer;
}

uae_u32 REGPARAM2 cyber64_bget (uaecptr addr)
{
    uae_u8 answer;

    addr-=cyber64_start;
    addr-=CYBER_OFFSET;
    if (addr>=CYBER_SIZE) {
	special_mem|=S_READ;
	write_log ("Cyber64 bget at %08lx (%02x)\n", addr, answer);
    }
    addr&=(CYBER_SIZE-1);
    answer=*(uae_u8*)(cyber_mem+addr);
    // write_log ("Cyber64 bget at %08lx (%02x)\n", addr, answer);
    return answer;
}

void REGPARAM2 cyber64_lput (uaecptr addr, uae_u32 l)
{
    addr-=cyber64_start;
    // write_log("Raw addr %08x ",addr);
    addr-=CYBER_OFFSET;
    if (addr>=CYBER_SIZE) {
	special_mem|=S_WRITE;
	write_log ("Cyber64 lput at %08lx(%08x)\n", addr,l);
	addr&=(CYBER_SIZE-1);
	write_log ("Cyber64 reallput at %08lx(%08x)\n", addr,l);
    }
    addr&=(CYBER_SIZE-1);
    // write_log ("Cyber64 lput at %08lx(%08x)\n", addr,l);

    do_put_mem_long((uae_u32*)(cyber_mem+addr),l);
}

void REGPARAM2 cyber64_wput (uaecptr addr, uae_u32 w)
{
    w&=0xffff;
    // write_log("Raw addr %08x ",addr);
    addr-=cyber64_start;
    addr-=CYBER_OFFSET;
    if (addr>CYBER_SIZE) {
	special_mem|=S_WRITE;
	write_log ("Cyber64 wput at %08lx(%04x)\n", addr,w);
	return;
    }
    addr&=(CYBER_SIZE-1);
    //write_log ("Cyber64 wput at %08lx(%04x)\n", addr,w);

    do_put_mem_word((uae_u16*)(cyber_mem+addr),w);
}

void REGPARAM2 cyber64_bput (uaecptr addr, uae_u32 b)
{
    b&=0xff;
    // write_log("Raw addr %08x ",addr);
    addr-=cyber64_start;
    addr-=CYBER_OFFSET;
    if (addr>CYBER_SIZE) {
	write_log ("Cyber64 bput at %08lx(%02x)\n", addr,b);
	special_mem|=S_WRITE;
	return;
    }
    addr&=(CYBER_SIZE-1);
    //write_log ("Cyber64 bput at %08lx(%02x)\n", addr,b);
    do_put_mem_byte(cyber_mem+addr,b);
}

int REGPARAM2 cyber64_check (uaecptr addr, uae_u32 size)
{
    special_mem |= S_READ;
    addr-=cyber64_start;
    addr-=CYBER_OFFSET;
    addr&=(CYBER_SIZE-1);
    write_log ("Cyber64 check at %08lx\n", addr);

    return 0;
}

uae_u8* REGPARAM2 cyber64_xlate (uaecptr addr)
{
    special_mem |= S_READ;
    addr-=cyber64_start;
    addr-=CYBER_OFFSET;
    addr&=(CYBER_SIZE-1);
    write_log ("Cyber64 xlate at %08lx\n", addr);

    return 0;
}

uae_u32 REGPARAM2 cyber64regs_lget (uaecptr addr)
{
    uae_u32 answer;

    special_mem|=S_READ;
    addr&=0xffff;

    if (ALWAYS_IO)
	answer=inl(addr);
    else
	answer=do_get_mem_long((uae_u32*)(cyber_regs+addr));

    // write_log ("Cyber64regs lget at %08lx (%08x)\n", addr,answer);
    
    return answer;
}

uae_u32 REGPARAM2 cyber64regs_wget (uaecptr addr)
{
    uae_u16 answer;

    special_mem|=S_READ;
    addr&=0xffff;
    if (ALWAYS_IO)
	answer=inw(addr);
    else
	answer=do_get_mem_word((uae_u16*)(cyber_regs+addr));

    // write_log ("Cyber64regs wget at %08lx (%04x)\n", addr,answer);

    return answer;
}

uae_u32 REGPARAM2 cyber64regs_bget (uaecptr addr)
{
    uae_u8 answer;

    special_mem|=S_READ;
    addr&=0xffff;
    if ((addr>=0x3c0 && addr<=0x3df && USE_IO) || ALWAYS_IO) 
	answer=inb(addr);
    else
	answer=do_get_mem_byte(cyber_regs+addr);

    // write_log ("Cyber64regs bget at %08lx (%02x)\n", addr,answer);
    
    return answer;
}


void REGPARAM2 cyber64regs_lput (uaecptr addr, uae_u32 l)
{
    special_mem|=S_WRITE;
    addr&=0xffff;

    // write_log ("Cyber64regs lput at %08lx(%08x)\n", addr,l);
    if (addr==0xe2e8 || addr==0x9ee8) {
	l=swap32(l);
    }
    if (ALWAYS_IO)
	outl((l),addr);
    else
	do_put_mem_long((uae_u32*)(cyber_regs+addr),l);
}

void REGPARAM2 cyber64regs_wput (uaecptr addr, uae_u32 w)
{
    special_mem|=S_WRITE;
    addr&=0xffff;
    
    // write_log ("Cyber64regs wput at %08lx(%04x)\n", addr,w);

    if (addr==0x3d4 && (w&0xff)==0x5a) {
	// write_log("Cyber: Not done\n");
	switch_cursor_mode();
	return; /* Don't change the base address! */
    }

    if (ALWAYS_IO)
	outw((w),addr);
    else
	do_put_mem_word((uae_u16*)(cyber_regs+addr),w);
}

void REGPARAM2 cyber64regs_bput (uaecptr addr, uae_u32 b)
{
    static int was_bad=0;
    static int was_worse=0;

    special_mem|=S_WRITE;
    addr&=0xffff;
    
    // write_log ("Cyber64regs bput at %08lx(%02x)\n", addr,b);

    if (was_bad)
	b=b&(~0x40);

    was_bad=(addr==0x3c4 && b==0x0a);
    
    if (was_worse) {
	/* as good a time as any to change the cursor mode */
	switch_cursor_mode();
	was_worse=0;

	return;
    }
    was_worse=(addr==0x3d4 && b==0x5a);
    if (was_worse)
	return; /* Don't even select that register */
    
    if ((addr>=0x3c0 && addr<=0x3df && USE_IO) || ALWAYS_IO) 
	outb(b,addr);
    else 
	do_put_mem_byte(cyber_regs+addr,b);
    
    // check_mem();
}

int REGPARAM2 cyber64regs_check (uaecptr addr, uae_u32 size)
{
    special_mem |= S_READ;
    // write_log ("Cyber64regs check at %08lx\n", addr);

    return 0;
}

uae_u8* REGPARAM2 cyber64regs_xlate (uaecptr addr)
{
    special_mem |= S_READ;
    // write_log ("Cyber64regs xlate at %08lx\n", addr);

    return 0;
}

#define CYBER_ADDR 0xeb000000
#define IO_OUT16VAL(v, r)       (((v) << 8) | (r))

void setup_cyber64(void)
{
    int mem;

    if (ioperm(0x3c0,0x20,1) == -1) {
	fprintf(stderr, "Failed to enable Cyber IO\n"); 
    }
    if (iopl(3) == -1) {
	fprintf(stderr, "Failed to enable Cyber IO\n"); 
    }
    

    mem=open("/dev/mem",O_RDWR);
    cyber_mem=mmap(NATMEM_OFFSET+cyber64_start+CYBER_OFFSET,
		   CYBER_SIZE,PROT_READ|PROT_WRITE,MAP_SHARED,mem,CYBER_ADDR);
    fprintf (stderr, "Cyber: addr: %p, from 0x%08x\n",
	     cyber_mem,CYBER_ADDR);
    
    cyber_regs=mmap(0,0x10000,PROT_READ|PROT_WRITE,MAP_SHARED,mem,0xa0000);
    close(mem);
    fprintf (stderr, "Cyberregs: addr: %p, from 0x%08x\n",
	     cyber_regs,0xa0000);
}

#endif
