/*
 * Dapple ][ Emulator  Version 0.05
 * Copyright (C) 2002, 2003 Dapple ][ Development.  All rights reserved.
 *
 * Component:  INI: DAPPLE.INI file handling
 * Revision:   (0.05) 2003.0129
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

#include <stdio.h>
#include <string.h>
#include "Dapple.h"

/* dapple.c */
extern unsigned int  inicpudelay;
extern unsigned char inidiskpath1[256];
extern unsigned char inidiskpath2[256];
extern unsigned char keycapslock;       /* capslock mode on? */
extern unsigned char keygerman;         /* switch 'Y' and 'Z' on German keyboards? */
extern unsigned char inidebugflag;      /* debugger on? */
extern Charset       inicharmode;
void keyboardsetlayout(unsigned char layout);
unsigned char keyboardgetlayout();

/* video.c */
void virtsetmonochrome(unsigned int mode);
unsigned char virtgetmonochrome();
void virtsetpalette(unsigned char mode);
unsigned char virtgetpalette();
void virtsethresmode(unsigned int mode);
unsigned char virtgethresmode();

/* memory.c */
extern unsigned char soundflag;
extern unsigned char memrompath[256];
extern unsigned char memnolc;
void memorysetclearmode(unsigned char);
unsigned char memorygetclearmode();

/* cpu65c02.c */
typedef enum {CPU6502, CPU65C02, CPU65SC02} CPUTYPE;
void cpusettype(CPUTYPE value);
CPUTYPE cpugettype();

/* disk.c */
extern unsigned char drivemessageflag; /* display current drive track? */
extern unsigned char drivefastflag;

      void writeini () {
        FILE *file;
        unsigned char vpal;
        unsigned char vmono;
        unsigned char vhmode;
        CPUTYPE cputype;

        vpal    = virtgetpalette();
        vmono   = virtgetmonochrome();
        vhmode  = virtgethresmode();
        cputype = cpugettype();

        file=fopen("dapple2.ini","wt");
        if (!file) return;
        fprintf(file,"[Dapple 2]\n");

/* keyboard */
        fprintf(file,"\n; ---- Keyboard ----\n\n");
        fprintf(file,"Capslock=%s\n",   keycapslock?    "Yes":"No");
        fprintf(file,"SwitchYZ=%s\n",   keygerman?      "Yes":"No");
        fprintf(file,"Layout=%s\n",     keyboardgetlayout()?    "Germany":"USA");

/* sound */
        fprintf(file,"\n; ---- Sound ----\n\n");
        fprintf(file,"Sound=%s\n",      soundflag?"Yes":"No");

/* video */
        fprintf(file,"\n; ---- Video ----\n\n");
        fprintf(file,"Monitor=%s\n",    vmono==0?       "Color":
                                        vmono==1?       "Mono":
                                        vmono==2?       "Green":
                                                        "Amber");
        fprintf(file,"Palette=%s\n",    vpal==0?        "IIgs":
                                        vpal==1?        "Standard":
/*                                      vpal==2?  */    "ApplePC"/*:
                                        vpal==3?        "MESS":
                                                        "EGA"*/);
        fprintf(file,"HiResMode=%s\n",  vhmode==0?      "Composite":
                                                        "RGB");
        fprintf(file,"Charset=%s\n",    inicharmode==USA     ?"USA":
                                        inicharmode==France  ?"France":
                                        inicharmode==Germany ?"Germany":
                                        inicharmode==UK      ?"UK":
                                        inicharmode==Denmark1?"Denmark1":
                                        inicharmode==Sweden  ?"Sweden":
                                        inicharmode==Italy   ?"Italy":
                                        inicharmode==Spain   ?"Spain":
                                        inicharmode==Japan   ?"Japan":
                                        inicharmode==Norway  ?"Norway":
                                        inicharmode==Denmark2?"Denmark2":
                                                              "???");

/* memory */
        fprintf(file,"\n; ---- Memory ----\n\n");
        fprintf(file,"DefaultBIOS=%s\n",memrompath);
        fprintf(file,"LanguageCard=%s\n", memnolc ? "No":"Yes");
        fprintf(file,"ClearPattern=%s\n", memorygetclearmode()==1 ? "00":"EA");

/* drive */
        fprintf(file,"\n; ---- Drive ----\n\n");
        fprintf(file,"Disk1=%s\n",inidiskpath1);
        fprintf(file,"Disk2=%s\n",inidiskpath2);
        fprintf(file,"DriveFastMode=%s\n",drivefastflag?"Yes":"No");
        fprintf(file,"DriveMessage=%s\n",drivemessageflag?"Yes":"No");

/* cpu */
        fprintf(file,"\n; ---- CPU ----\n\n");
        fprintf(file,"Delay=$%04X\n",inicpudelay);
        fprintf(file,"CPU=%s\n",        cputype==CPU6502        ?"6502":
                                        cputype==CPU65C02       ?"65C02":
                                                                 "65SC02");

//      fprintf(file,"ShiftMod=%s\n",dqshift?"No":"Yes");
//      fprintf(file,"ShiftManip=%s\n",shiftshutoff?"No":"Yes");
//      fprintf(file,"Joystick=%s\n",joyenabled?"Yes":"No");
//      fprintf(file,"HighParallel=%s\n",tweakpic?"Yes":"No");
//      fprintf(file,"ParallelOutput=%s\n",parallel);
//      fprintf(file,"HardDisk=%s\n",   dqhdv?"No":"Yes");

/*
        fprintf(file,"JoyCalibrateMinX=%u\n",GameMinX);
        fprintf(file,"JoyCalibrateMinY=%u\n",GameMinY);
        fprintf(file,"JoyCalibrateMaxX=%u\n",GameMaxX);
        fprintf(file,"JoyCalibrateMaxY=%u\n",GameMaxY);
 */


//      fprintf(file,"PrtScF8=%s\n", nof8?"No":"Yes");
//      fprintf(file,"TweakBksp=%s\n", tweakbksp?"Yes":"No");

        fclose(file);
      } /* writeini */


/*-------------------------------------*/


      void readini () {
        FILE *file;
        unsigned char wip[128];
        unsigned char vpal;
        unsigned char vmono;
        unsigned char vhmode;

        file=fopen("dapple2.ini","rt");
        if (!file) return;

        vpal    = 0xff;
        vmono   = 0xff;
        vhmode  = 0xff;

        while (!feof(file)) {

          fgets(wip,128,file);
          wip[strlen(wip)-1]=0;

/* keyboard */
          if (!stricmp(wip,"Capslock=Yes"))     keycapslock = 1;
          if (!stricmp(wip,"Capslock=No"))      keycapslock = 0;
          if (!stricmp(wip,"SwitchYZ=Yes"))     keygerman = 1;
          if (!stricmp(wip,"SwitchYZ=No"))      keygerman = 0;
          if (!stricmp(wip,"Layout=USA"))       keyboardsetlayout(0);
          if (!stricmp(wip,"Layout=Germany"))   keyboardsetlayout(1);

/* sound */
          if (!stricmp(wip,"Sound=Yes"))        soundflag = 1;
          if (!stricmp(wip,"Sound=No"))         soundflag = 0;

/* video */
          if (!stricmp(wip,"Monitor=Color"))    vmono = 0;
          if (!stricmp(wip,"Monitor=Mono"))     vmono = 1;
          if (!stricmp(wip,"Monitor=Green"))    vmono = 2;
          if (!stricmp(wip,"Monitor=Amber"))    vmono = 3;

          if (!stricmp(wip,"Console=Color"))    vmono = 0;
          if (!stricmp(wip,"Console=Amber"))    vmono = 3;

          if (!stricmp(wip,"Palette=IIgs"))     vpal = 0;
          if (!stricmp(wip,"Palette=Standard")) vpal = 1;
          if (!stricmp(wip,"Palette=ApplePC"))  vpal = 2;
//        if (!stricmp(wip,"Palette=MESS"))     vpal = 3;
//        if (!stricmp(wip,"Palette=EGA"))      vpal = 4;

          if (!stricmp(wip,"HiResmode=Sharp"))  vhmode = 0;
          if (!stricmp(wip,"HiResmode=RGB"))    vhmode = 1;

          if (!stricmp(wip,"Charset=USA"))      inicharmode = USA;
          if (!stricmp(wip,"Charset=France"))   inicharmode = France;
          if (!stricmp(wip,"Charset=Germany"))  inicharmode = Germany;
          if (!stricmp(wip,"Charset=UK"))       inicharmode = UK;
          if (!stricmp(wip,"Charset=Denmark1")) inicharmode = Denmark1;
          if (!stricmp(wip,"Charset=Sweden"))   inicharmode = Sweden;
          if (!stricmp(wip,"Charset=Italy"))    inicharmode = Italy;
          if (!stricmp(wip,"Charset=Spain"))    inicharmode = Spain;
          if (!stricmp(wip,"Charset=Japan"))    inicharmode = Japan;
          if (!stricmp(wip,"Charset=Norway"))   inicharmode = Norway;
          if (!stricmp(wip,"Charset=Denmark2")) inicharmode = Denmark2;

/* memory */
          if (!strnicmp(wip,"DefaultBios=",12)) strcpy(memrompath,&wip[12]);
          if (!stricmp(wip,"LanguageCard=Yes")) memnolc = 0;
          if (!stricmp(wip,"LanguageCard=No"))  memnolc = 1;
          if (!stricmp(wip,"ClearPattern=00"))  memorysetclearmode(1);
          if (!stricmp(wip,"ClearPattern=EA"))  memorysetclearmode(2);

/* drive */
          if (!strnicmp(wip,"Disk1=",6))        strcpy(inidiskpath1,&wip[6]);
          if (!strnicmp(wip,"Disk2=",6))        strcpy(inidiskpath2,&wip[6]);
          if (!stricmp(wip,"DriveFastmode=Yes"))drivefastflag = 1;
          if (!stricmp(wip,"DriveFastmode=No")) drivefastflag = 0;
          if (!stricmp(wip,"DriveMessage=Yes")) drivemessageflag = 1;
          if (!stricmp(wip,"DriveMessage=No"))  drivemessageflag = 0;

/* cpu */
          if (!stricmp(wip,"CPU=6502"))         cpusettype(CPU6502);
          if (!stricmp(wip,"CPU=65C02"))        cpusettype(CPU65C02);
          if (!stricmp(wip,"CPU=65SC02"))       cpusettype(CPU65SC02);
          if (!strnicmp(wip,"Delay=$",7))       sscanf(wip,"Delay=$%x",&inicpudelay);

//        if (!stricmp(wip,"ShiftMod=No"))      dqshift = 1;
//        if (!stricmp(wip,"ShiftMod=Yes"))     dqshift = 0;
//        if (!stricmp(wip,"ShiftManip=Yes"))   setshiftmanip(0);
//        if (!stricmp(wip,"ShiftManip=No"))    setshiftmanip(1);
//        if (!stricmp(wip,"Joystick=Yes"))     joyenabled = 1;
//        if (!stricmp(wip,"Joystick=No"))      joyenabled = 0;
//        if (!stricmp(wip,"PrtScF8=No"))       nof8 = 1;
//        if (!stricmp(wip,"PrtScF8=Yes"))      nof8 = 0;
//        if (!stricmp(wip,"HardDisk=No"))      dqhdv = 1;
//        if (!stricmp(wip,"HardDisk=Yes"))     dqhdv = 0;
//        if (!stricmp(wip,"HighParallel=Yes")) tweakpic = 1;
//        if (!stricmp(wip,"HighParallel=No"))  tweakpic = 0;
//        if (!strnicmp(wip,"ParallelOutput=",15))      strcpy(parallel,&wip[15]);
//        if (!stricmp(wip,"TweakBksp=Yes"))    tweakbksp = 1;
//        if (!stricmp(wip,"TweakBksp=No"))     tweakbksp = 0;

/*
          if (!strnicmp(wip,"JoyCalibrateMinX=",17)) sscanf(wip,"JoyCalibrateMinX=%u",&GameMinX);
          if (!strnicmp(wip,"JoyCalibrateMinY=",17)) sscanf(wip,"JoyCalibrateMinY=%u",&GameMinY);
          if (!strnicmp(wip,"JoyCalibrateMaxX=",17)) sscanf(wip,"JoyCalibrateMaxX=%u",&GameMaxX);
          if (!strnicmp(wip,"JoyCalibrateMaxY=",17)) sscanf(wip,"JoyCalibrateMaxY=%u",&GameMaxY);
 */
        } /* while */
        fclose(file);
        if (vmono != 0xff) { virtsetmonochrome(vmono);  }
        if (vpal  != 0xff) { virtsetpalette   (vpal);   }
        if (vhmode!= 0xff) { virtsethresmode  (vhmode); }

      } /* readini */

