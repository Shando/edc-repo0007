/*
 * EMU][ Apple ][-class emulator
 * Copyright (C) 2002, 2003 by the EMU][ Project/Dapple ][ Team
 *
 * $Header: /winc/emuiil/source/cpu65c02.c,v 1.3 2003/06/30 19:28:36 dosius Exp $
 *
 * Component: CPU65C02: CPU emulation
 * ADC and SBC instructions contributed by Scott Hemphill.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * $Log: cpu65c02.c,v $
 * Revision 1.3  2003/06/30 19:28:36  dosius
 * Integrated HP's changes to all files.
 *
 * Revision 1.1  2003/06/25 18:28:28  dosius
 * Initial revision
 *
 */

#include <stdio.h>
#include <string.h>
#include "asmlib.h"
#include "dapple.h"

/* extern declarations */

/* dapple.c */
extern unsigned char appletype;
extern unsigned char inimenulanguage;
extern unsigned char inidebugflag;
extern unsigned char callingpath[260];
extern unsigned int inicpudelay;
extern unsigned int window;
extern unsigned int messagecount;
extern unsigned char messageflag;
void stringwriteyesno(unsigned int window, unsigned char value);
unsigned int fileselectmenu(unsigned char *windowtitle, unsigned char *title,
			    unsigned char *filename, unsigned char *filepath, unsigned char *tail,
			    unsigned char optnew);
void windowpresskey(unsigned int keyboard, unsigned int window);
void setmessage(unsigned char *message);
void applereset();
void keyconvert();

/* memory.c */
extern unsigned char memram[0x28000];
extern unsigned char memlcramr;
unsigned char memoryread(unsigned int addr);
void memorywrite(unsigned int addr, unsigned int value);

#ifdef REECOP
/* rom */
void romexecute(unsigned int addr);
#endif

/* video.c */
extern unsigned char virtcopy;
extern unsigned int  virtrasterline;
void virtpaletteset(unsigned int index, unsigned int r,
                    unsigned int b,     unsigned int g);
void virtsetmode();
void virtcacheinit();
void virtline();
void virtscreencopy();

/* mouse.c */
void mousevbl();

/* disk.c */
extern unsigned char drivefastmode;

/* intern declarations */

/* type of CPU */
/* Had to change this, because some operations are done by both, 65c02 and 65sc02. */
static const unsigned char CPU6502	= 0x01;
static const unsigned char CPU65C02	= 0x02;
static const unsigned char CPU65SC02	= 0x04;
unsigned char		cputype;

unsigned int		areg;		/* Accumulator		*/
unsigned int		xreg;		/* X-Register		*/
unsigned int		yreg;		/* Y-Register		*/
unsigned int		stack;		/* Stack-Register	*/
unsigned short		pc;		/* Program counter	*/

unsigned char		nflag;		/* N-Flag		*/
unsigned char		vflag;		/* Overflow-Flag	*/
unsigned char		iflag;		/* Interrupt-Flag	*/
unsigned char		bflag;		/* Break-Flag		*/
unsigned char		dflag;		/* Decimal-Flag		*/
unsigned char		zflag;		/* Zero-Flag		*/
unsigned char		cflag;		/* Carry-Flag		*/

static unsigned char	bytebuffer;
static unsigned int	address;	/* 16-bit address	*/
unsigned int		cycle;		/* Number of cycles	*/
static unsigned int	lastcycle;
static unsigned int	linecycles;
static unsigned char	traceflag;	/* set tracemode	*/
static unsigned char	breakflag;	/* allow breakpoint	*/
static unsigned short	breakpoint;
static unsigned int	cpudelay;
unsigned char		cpuwriteregsflag;
unsigned char		cpumessageflag;

/* state of the processor */
unsigned char stateflags;


/*--------------------------------------*/

/* CPU */
/* - cpusetbreakpoint   */
/* - cpugetbreakpoint   */
/* - cpuclearbreakpoint */
/* - cpusettracemode    */
/* - cpugettracemode    */
/* - cpusetpc           */
/* - cpugetpc           */
/* - cpugeta            */
/* - cpugetx            */
/* - cpugety            */
/* - cpusetlinecycle	*/
/* - cpugetlinecycle	*/
/* - cpusetdelay	*/
/* - cpugetdelay	*/
/* - cpusettype		*/
/* - cpugettype		*/
/* - cpuinuse		*/
/* - cpureset           */
/* - cpuinit            */
/* - cpustore           */
/* - cpurestore         */
/* - cpuline            */
/* - cpurun		*/

/*--------------------------------------*/

/* flags		*/
/* - flagssetnz		*/
/* - flagsgen		*/
/* - flagsget		*/
/* - flagstostring	*/

      void flagssetnz(unsigned int value) {

	zflag = (value == 0) ? 1 : 0;
	nflag = (value > 0x7f) ? 1 : 0;

      } /* flagssetnz */


/*--------------------------------------*/


      unsigned char cpuflagsgen() {
	register unsigned char f;

	f = 0x20;
	if ( nflag != 0 ) { f = f | 0x80; }
	if ( vflag != 0 ) { f = f | 0x40; }
	if ( bflag != 0 ) { f = f | 0x10; }
	if ( dflag != 0 ) { f = f | 0x08; }
	if ( iflag != 0 ) { f = f | 0x04; }
	if ( zflag != 0 ) { f = f | 0x02; }
	if ( cflag != 0 ) { f = f | 0x01; }
	return(f);
      } /* cpuflagsgen */


/*--------------------------------------*/


      void cpuflagsget(unsigned int value) {

	nflag = ((value & 0x80) == 0) ? 0 : 1;
	vflag = ((value & 0x40) == 0) ? 0 : 1;
	bflag = ((value & 0x10) == 0) ? 0 : 1;
	dflag = ((value & 0x08) == 0) ? 0 : 1;
	iflag = ((value & 0x04) == 0) ? 0 : 1;
	zflag = ((value & 0x02) == 0) ? 0 : 1;
	cflag = ((value & 0x01) == 0) ? 0 : 1;
      } /* cpuflagsget */


/*--------------------------------------*/


      void cpuflagstostring(unsigned int value, unsigned char *stringptr) {

	if (value & 0x80) { *stringptr++ = '-'; }
	else		  { *stringptr++ = 'N'; }
	if (value & 0x40) { *stringptr++ = '-'; }
	else		  { *stringptr++ = 'V'; }
	if (value & 0x20) { *stringptr++ = '-'; }
	else		  { *stringptr++ = '1'; }
	if (value & 0x10) { *stringptr++ = '-'; }
	else		  { *stringptr++ = 'B'; }
	if (value & 0x08) { *stringptr++ = '-'; }
	else		  { *stringptr++ = 'D'; }
	if (value & 0x04) { *stringptr++ = '-'; }
	else		  { *stringptr++ = 'I'; }
	if (value & 0x02) { *stringptr++ = '-'; }
	else		  { *stringptr++ = 'Z'; }
	if (value & 0x01) { *stringptr   = '-'; }
	else		  { *stringptr   = 'C'; }

      } /* cpuflagstostring */


/*--------------------------------------*/


      void cpusetbreakpoint(unsigned int value) {

	if (value > 0xffff) {
	  breakflag = 0;
	}
	else {
	  breakpoint = value;
	  breakflag  = 1;
	}

      } /* cpusetbreakpoint */


/*--------------------------------------*/


      unsigned int cpugetbreakpoint() {

	if (breakflag) {
	  return breakpoint;
	}
	else {
	  return 0xffffffff;
	}

      } /* cpugetbreakpoint */


/*-------------------------------------*/


      void cpuclearbreakpoint() {

	 breakflag = 0;

      } /* cpuclearbreakpoint */


/*-------------------------------------*/


      void cpusettracemode(unsigned char mode) {

	if (mode) {
	  traceflag = 1;
	}
	else {
	  traceflag = 0;
	}
      } /* cpusettracemode */


/*--------------------------------------*/


      unsigned char cpugettracemode() {

	return traceflag;

      } /* cpugettracemode */


/*--------------------------------------*/


      void cpusetpc(unsigned int address) {

	pc = address & 0xffff;

      } /* cpusetpc */


/*--------------------------------------*/


      unsigned short cpugetpc() {

	return pc;

      } /* cpugetpc */


/*--------------------------------------*/


      void cpusetsp(unsigned int address) {

	stack = address & 0xff;

      } /* cpusetsp */


/*--------------------------------------*/


      unsigned int cpugetsp() {

	return (stack | 0x100);

      } /* cpugetsp */


/*--------------------------------------*/


      unsigned char cpugeta() {

	return areg;

      } /* cpugeta */


/*--------------------------------------*/


      unsigned char cpugetx() {

	return xreg;

      } /* cpugetx */


/*--------------------------------------*/


      unsigned char cpugety() {

	return yreg;

      } /* cpugety */


/*--------------------------------------*/


      void cpusetlinecycle(unsigned int value) {

	linecycles = value;

      } /* cpusetlinecycle */


/*--------------------------------------*/


      unsigned int cpugetlinecycle() {

	return linecycles;

      } /* cpugetlinecycle */


/*--------------------------------------*/


      void cpusetdelay(unsigned int value) {

	cpudelay = value;

      } /* cpusetdelay */


/*--------------------------------------*/


      unsigned int cpugetdelay() {

	return cpudelay;

      } /* cpugetdelay */


/*--------------------------------------*/


      void cpusettype (unsigned int value) {

	switch (value) {
	  case 0 :
	    cputype = CPU6502;
	    break;
	  case 1 :
	    cputype = CPU65C02;
	    break;
	  case 2 :
	    cputype = CPU65SC02;
	    break;
	} /* switch */

      } /* cpusettype */


/*--------------------------------------*/


      unsigned char cpugettype () {

	if (cputype == CPU6502) {
	  return 0;
	}
	else {
	  if (cputype == CPU65C02) {
	    return 1;
	  }
	  else {
	    return 2;
	  }
	}

      } /* cpugettype */


/*--------------------------------------*/


      void cpusetstate(unsigned int value) {

	value = value & (STATEHALT | STATERESET | STATETRACE | STATEIRQ | STATENMI) & (~stateflags);
/*
	Don't put a message on screen with Dapple, because mouse VBL just generates too many interrupts ...

	if (value & STATEIRQ) {
	  setmessage("CPU IRQ triggered");
	}
*/
	if (value & STATENMI) {
	  setmessage("CPU NMI triggered");
	}
	if (value & STATERESET) {
	  setmessage("CPU Reset triggered");
	}
	if (value & STATEHALT) {
	  setmessage("CPU halted");
	  imagefillbox(window, SLOTX1, 388, SLOTX1+1, 389, RGBLGHTOFF);
	}
	if (value & STATETRACE) {
	  setmessage("CPU trace mode set");
	}
	  
	stateflags = stateflags | (unsigned char)value;

      } /* cpusetstate */


/*--------------------------------------*/


      void cpuclearstate(unsigned int value) {

	value = value
		& (STATEHALT | STATERESET | STATETRACE | STATEIRQ | STATENMI | STATEBPT | STATEGURU)
		& (stateflags);

	if (value & STATEIRQ) {
	  setmessage("CPU IRQ cleared");
	}
	if (value & STATENMI) {
	  setmessage("CPU NMI cleared");
	}
	if (value & STATERESET) {
	  setmessage("CPU Reset cleared");
	}
	if (value & STATEHALT) {
	  setmessage("CPU started");
	  if (stateflags & STATEGURU) {	/* if it was an illegal opcode ==> reset whole machine */
	    applereset();
	  }
	  imagefillbox(window, SLOTX1, 388, SLOTX1+1, 389, RGBLGHTON);
	}
	if (value & STATETRACE) {
	  setmessage("CPU trace mode cleared");
	}
	if (value & STATEGURU) {	/* if it was an illegal opcode ==> reset whole machine */
	  applereset();
	}
	stateflags = stateflags & (~((unsigned char)value));

      } /* cpuclearstate */


/*--------------------------------------*/


      unsigned char cpugetstate() {

	return stateflags;

      } /* cpugetstate */


/*--------------------------------------*/


      unsigned char cpuinuse() {

	return ((stateflags & STATEHALT)
	      ||(stateflags & STATEBPT)
	      ||(stateflags & STATEGURU)) ? 0 : -1;

      } /* cpuinuse */


/*--------------------------------------*/


      void cpureset() {

	if (appletype & APPLEIIC) {
	  if (cputype == CPU6502) {		/* the Apple//c demands at least a 65c02 */
	    cpusettype(1);
	  }
	}
	stateflags = stateflags | STATERESET;
	imagefillbox(window, SLOTX1, 388, SLOTX1+1,389, RGBLGHTON);
	virtcopy = 1;

      } /* cpureset */


/*--------------------------------------*/


      void cpuinit() {

	cpusettype(1);

	areg	= 0;			/* clear register */
	xreg	= 0;
	yreg	= 0;
	zflag	= 0;			/* clear flags */
	nflag	= 0;
	cflag	= 0;
	vflag	= 0;
	iflag	= 0;
	dflag	= 0;
	bflag	= 0;
	stack	= 0xff;			/* + 0x100 ! ==> pullstack/pushstack */

	stateflags = 0;

	cycle   = 0;			/* clear cycle count */
	lastcycle = 0;

	cpusettracemode(0);		/* trace mode off */
	cpuclearbreakpoint();		/* no breakpoint */

	cpusetdelay(inicpudelay);
	cpusetlinecycle(65);
	cpuwriteregsflag = 0;
	cpumessageflag = 0;
	cpureset();

      } /* cpuinit */


/*--------------------------------------*/


      void hex8tostringf(unsigned int value, unsigned char *stringpointer) {
        register unsigned char c;

	c = (unsigned char)value >> 4;
	if (c > 9) { c = c + 'A' - 10; }
	else { c = c + '0'; }
	*stringpointer = c;
	c = (unsigned char)value & 0xf;
	if (c > 9) { c = c + 'A' - 10; }
	else { c = c + '0'; }
	*(stringpointer+1) = c;

      }

      void cpuwriteregs(unsigned int window) {
	unsigned char message[80];

	strcpy(message, "A: $xx, X: $xx, Y: $xx, PC: $xxxx, SP: $01xx, Flags: NV1BDIZC");
	hex8tostringf(areg, &message[4]);
	hex8tostringf(xreg, &message[12]);
	hex8tostringf(yreg, &message[20]);
	hex8tostringf(pc >> 8,   &message[29]);
	hex8tostringf(pc & 0xff, &message[31]);
	hex8tostringf(stack &0xff, &message[42]);
	cpuflagstostring( cpuflagsgen(), &message[53]);
	stringwrite(window, message);

      } /* cpuwriteregs */


/*--------------------------------------*/


      unsigned int cpustore(unsigned int winprotocol, FILE *file) {
	unsigned char flags;
	unsigned char header[32];

	memset(header, 0x00, sizeof(header));
	strcpy(header, "CPU STATE V0.27");
	fwrite(header,		 sizeof(header),	1, file);

	fwrite(&cputype,	 sizeof(cputype),	1,file);
	fwrite(&areg,		 sizeof(areg),		1,file);
	fwrite(&xreg,		 sizeof(xreg),		1,file);
	fwrite(&yreg,		 sizeof(yreg),		1,file);
	fwrite(&pc,		 sizeof(pc),		1,file);
	fwrite(&stack,		 sizeof(stack),		1,file);
	flags = cpuflagsgen();
	fwrite(&flags,		 sizeof(flags),		1,file);
	fwrite(&stateflags,	 sizeof(stateflags),	1,file);
	fwrite(&cycle,		 sizeof(cycle),		1,file);
	fwrite(&lastcycle,	 sizeof(lastcycle),	1,file);
	fwrite(&linecycles,	 sizeof(linecycles),	1,file);
	fwrite(&cpudelay,	 sizeof(cpudelay),	1,file);
	fwrite(&inicpudelay,	 sizeof(inicpudelay),	1,file);
	fwrite(&traceflag,	 sizeof(traceflag),	1,file);
	fwrite(&breakflag,	 sizeof(breakflag),	1,file);
	fwrite(&breakpoint,	 sizeof(breakpoint),	1,file);
	fwrite(&cpuwriteregsflag,sizeof(cpuwriteregsflag),1,file);
	fwrite(&cpumessageflag,	 sizeof(cpumessageflag),1,file);

	stringwrite(winprotocol, "CPU stored.\r");

	return 0;

      } /* cpustore */


/*--------------------------------------*/


      unsigned int cpurestore(unsigned int winprotocol, FILE *file) {
        unsigned char flags;
        unsigned char header[32];

	fread(header,		sizeof(header),		1,file);
	if (strcmp(header, "CPU STATE V0.27")) {
	  stringwrite(winprotocol, "CPU emulation data not found.\r");
	  return 1;
	}

        fread(&cputype,		sizeof(cputype),	1,file);
        fread(&areg,		sizeof(areg),		1,file);
        fread(&xreg,		sizeof(xreg),		1,file);
        fread(&yreg,		sizeof(yreg),		1,file);
        fread(&pc,		sizeof(pc),		1,file);
        fread(&stack,		sizeof(stack),		1,file);
        fread(&flags,		sizeof(flags),		1,file);
        cpuflagsget(flags);
        fread(&stateflags,	sizeof(stateflags),	1,file);
        fread(&cycle,		sizeof(cycle),		1,file);
        fread(&lastcycle,	sizeof(lastcycle),	1,file);
        fread(&linecycles,	sizeof(linecycles),	1,file);
        fread(&cpudelay,	sizeof(cpudelay),	1,file);
        fread(&inicpudelay,	sizeof(inicpudelay),	1,file);
        fread(&traceflag,	sizeof(traceflag),	1,file);
        fread(&breakflag,	sizeof(breakflag),	1,file);
        fread(&breakpoint,	sizeof(breakpoint),	1,file);
        fread(&cpuwriteregsflag,sizeof(cpuwriteregsflag),1,file);
	fread(&cpumessageflag,	sizeof(cpumessageflag),	1,file);

	if (stateflags & STATEHALT) {
	  imagefillbox(window, SLOTX1, 388, SLOTX1+1, 389, RGBLGHTOFF);
	}
	else {
	  imagefillbox(window, SLOTX1, 388, SLOTX1+1, 389, RGBLGHTON);
	}
	if (cpuwriteregsflag) {
	  imagesettextcolor(window, RGBBLACK, RGBWHITE);
	  imagesetcursor(window, 0, 7);
	  cpuwriteregs(window);
	}
	else {
	  imagefillbox(window, 0, 0, 639, 7, RGBBLACK);
	}

	stringwrite(winprotocol, "CPU restored.\r");

	return 0;

      } /* cpurestore */


/*--------------------------------------*/

/* addressing modes */

#define incpc pc++

/* standard read zero page instruction */
      unsigned char readzp() {
	address = memoryread(pc);
	incpc;
	return memoryread(address);
      } /* readzp */

/* save address for read-and-modify instructions */
      unsigned char readzpm() {
	address = memoryread(pc);
	incpc;
	return memoryread(address);
      } /* readzp */

/* standard read zero page,x instruction */
      unsigned char readzpx() {
	address = (memoryread(pc) + xreg) & 0xff;
	incpc;
	return memoryread(address);
      } /* readzpx */

/* save address for read-and-modify instructions */
      unsigned char readzpxm() {
	address = (memoryread(pc) + xreg) & 0xff;
	incpc;
	return memoryread(address);
      } /* readzpx */

/* standard read zero page,y instruction */
      unsigned char readzpy() {
	address = (memoryread(pc) + yreg) & 0xff;
	incpc;
	return memoryread(address);
      } /* readzpy */


/* standard read abs instruction */
      unsigned char readabs() {
	address = memoryread(pc);
	incpc;
	address = address + ( memoryread(pc) << 8 );
	incpc;
	return memoryread(address);
      } /* readabs */

/* save address for read-and-modify instructions */
      unsigned char readabsm() {
	address = memoryread(pc);
	incpc;
	address = address + ( memoryread(pc) << 8 );
	incpc;
	return memoryread(address);
      } /* readabs */

/* standard read abs,x instruction */
      unsigned char readabsx() {
	address = memoryread(pc);
	incpc;
	address = (address + ( memoryread(pc) << 8 ) + xreg) & 0xffff;
	incpc;
	return memoryread(address);
      } /* readabsx */

/* save address for read-and-modify instructions */
      unsigned char readabsxm() {
	address = memoryread(pc);
	incpc;
	address = (address + ( memoryread(pc) << 8 ) + xreg) & 0xffff;
	incpc;
	return memoryread(address);
      } /* readabsxm */

/* standard read abs,y instruction */
      unsigned char readabsy() {
	address = memoryread(pc);
	incpc;
	address = (address + ( memoryread(pc) << 8 ) + yreg) & 0xffff;
	incpc;
	return memoryread(address);
      } /* readabsy */

/* save address for read-and-modify instructions */
      unsigned char readabsym() {
	address = memoryread(pc);
	incpc;
	address = (address + ( memoryread(pc) << 8 ) + yreg) & 0xffff;
	incpc;
	return memoryread(address);
      } /* readabsym */

      unsigned char readindzp() {
	address = memoryread(pc);
	incpc;
	address = memoryread(address) + ( memoryread((address + 1) & 0xff) << 8);
	return memoryread(address);
      } /* readindzp */


      unsigned char readindzpx() {
	address = ( memoryread(pc) + xreg ) & 0xff;
	incpc;
	address = memoryread(address) + ( memoryread((address + 1) & 0xff) << 8);
	return memoryread(address);
      } /* readindzpx */


      unsigned char readindzpy() {
	address = memoryread(pc);
	incpc;
	address = ( memoryread(address) + ( memoryread((address + 1) & 0xff) << 8) + yreg) & 0xffff;
	return memoryread(address);
      } /* readindzpy */



/* standard write zero page instruction */
      void writezp (unsigned int value) {
	address = memoryread(pc);
	incpc;
	memorywrite(address, value);
      } /* writezp */


/* standard write zero page,x instruction */
      void writezpx (unsigned int value) {
	address = ( memoryread(pc) + xreg ) & 0xff;
	incpc;
	memorywrite(address, value);
      } /* writezpx */


/* standard write zero page,y instruction */
      void writezpy (unsigned int value) {
	address = ( memoryread(pc) + yreg ) & 0xff;
	incpc;
	memorywrite(address, value);
      } /* writezpy */


/* standard write abs instruction */
      void writeabs (unsigned int value) {
	address = memoryread(pc);
	incpc;
	address = address + ( memoryread(pc) << 8 );
	incpc;
	memorywrite(address, value);
      } /* writeabs */


/* standard write abs,x instruction */
      void writeabsx (unsigned int value) {
	address = memoryread(pc);
	incpc;
	address = (address + ( memoryread(pc) << 8 ) + xreg) & 0xffff;
	incpc;
	memorywrite(address, value);
      } /* writeabsx */


/* standard write abs,x instruction */
      void writeabsy (unsigned int value) {
	address = memoryread(pc);
	incpc;
	address = (address + ( memoryread(pc) << 8 ) + yreg) & 0xffff;
	incpc;
	memorywrite(address, value);
      } /* writeabsy */

      void writeindzp (unsigned int value) {
	address = memoryread(pc);
	incpc;
	address = memoryread(address) + ( memoryread((address + 1) & 0xff) << 8);
	memorywrite(address, value);
      } /* writeindzp */


      void writeindzpx (unsigned int value) {
	address = ( memoryread(pc) + xreg ) & 0xff;
	incpc;
	address = memoryread(address) + ( memoryread((address + 1) & 0xff) << 8);
	memorywrite(address, value);
      } /* writeindzpx */


/* standard write (zp),y instruction */
      void writeindzpy (unsigned int value) {
	address = memoryread(pc);
	incpc;
	address = ( memoryread(address) + ( memoryread((address + 1) & 0xff) << 8 ) + yreg) & 0xffff;
	memorywrite(address, value);
      } /* writeindzpy */


/*--------------------------------------*/


/* Stack */

      unsigned char pullstack() {
	stack = (stack + 1) & 0xff;
	return memoryread(stack | 0x100);
      } /* pullstack */


      void pushstack (register unsigned int value) {
	memorywrite(stack | 0x100, value);
	stack = (stack - 1) & 0xff;
      } /* pushstack */


/*--------------------------------------*/


/* Adc */

/* The following code was provided by Mr. Scott Hemphill. */
/* Thanks a lot! */

      void adc(unsigned int value) {
	register unsigned int w;

	if ((areg ^ value) & 0x80) {
	  vflag = 0;
	}
	else {
	  vflag = 1;
	}

	if (dflag) {
	  w = (areg & 0xf) + (value & 0xf) + cflag;
	  if (w >= 10) {
	    w = 0x10 | ((w+6)&0xf);
	  }
	  w += (areg & 0xf0) + (value & 0xf0);
	  if (w >= 160) {
	    cflag = 1;
	    if (vflag && w >= 0x180) vflag = 0;
	    w += 0x60;
	  }
	  else {
	    cflag = 0;
	    if (vflag && w < 0x80) vflag = 0;
	  }
	}
	else {
	  w = areg + value + cflag;
	  if (w >= 0x100) {
	    cflag = 1;
	    if (vflag && w >= 0x180) vflag = 0;
	  }
	  else {
	    cflag = 0;
	    if (vflag && w < 0x80) vflag = 0;
	  }
	}
	areg = (unsigned char)w;
	nflag = (areg >= 0x80) ? 1 : 0;
	zflag = (areg == 0)    ? 1 : 0;
      } /* adc */


/* Sbc */

/* The following code was provided by Mr. Scott Hemphill. */
/* Thanks a lot again! */

      void sbc(unsigned int value) {
	register unsigned int w;
	register unsigned char temp;

	if ((areg ^ value) & 0x80) {
	  vflag = 1;
	}
	else {
	  vflag = 0;
	}

	if (dflag) {		/* decimal subtraction */
	  temp = 0xf + (areg & 0xf) - (value & 0xf) + (cflag);
	  if (temp < 0x10) {
	    w = 0;
	    temp -= 6;
	  }
	  else {
	    w = 0x10;
	    temp -= 0x10;
	  }
	  w += 0xf0 + (areg & 0xf0) - (value & 0xf0);
	  if (w < 0x100) {
	    cflag = 0;
	    if (vflag && w < 0x80) vflag = 0;
	    w -= 0x60;
	  }
	  else {
	    cflag = 1;
	    if ((vflag) && w >= 0x180) vflag = 0;
	  }
	  w += temp;
	}
	else {			/* standard binary subtraction */
	  w = 0xff + areg - value + cflag;
	  if (w < 0x100) {
	    cflag = 0;
	    if (vflag && w < 0x80) vflag = 0;
	  }
	  else {
	    cflag = 1;
	    if (vflag && w >= 0x180) vflag = 0;
	  }
	}
	areg = (unsigned char)w;
	nflag = (areg >= 0x80) ? 1 : 0;
	zflag = (areg == 0)    ? 1 : 0;
      } /* sbc */


/*--------------------------------------*/


/* Cmp */

      void cmp(unsigned int value) {

	cflag = (areg >= value) ? 1 : 0;
	nflag = (((areg - value) & 0x80) == 0) ? 0 : 1;
	zflag = (areg == value) ? 1 : 0;

      } /* cmp */

/* Cpx */

      void cpx(unsigned int value) {

	cflag = (xreg >= value) ? 1 : 0;
	nflag = (((xreg - value) & 0x80) == 0) ? 0 : 1;
	zflag = (xreg == value) ? 1 : 0;

      } /* cpx */

/* Cpy */

      void cpy(unsigned int value) {

	cflag = (yreg >= value) ? 1 : 0;
	nflag = (((yreg - value) & 0x80) == 0) ? 0 : 1;
	zflag = (yreg == value) ? 1 : 0;

      } /* cpy */


/*--------------------------------------*/


      void cpubrk() {
	unsigned char message[80];

	if (cpumessageflag) {
	  strcpy(message, "BRK instruction hit at address $xxxx");
	  hex8tostringf((pc - 1) >> 8,   &message[32]);
	  hex8tostringf((pc - 1) & 0xff, &message[34]);
	  setmessage(message);
	}
	stateflags = stateflags | STATEBRK;	/* give the surrounding environment	*/
	incpc;					/* the chance to respond to a BRK	*/
	pushstack(pc >> 8);			/* e.g. with a debugger			*/
	pushstack(pc & 0xff);
	pc    = address + ( memoryread(pc) << 8 );
	pushstack( cpuflagsgen() | 0x10 );
	if (cputype & (CPU65C02 | CPU65SC02)) {
	  dflag = 0;                            /* 65c02 and 65sc02 clear the D-flag.	*/
	}
	iflag = 1;
	bflag = 1;

      } /* cpubrk */


      void cpuillegal(unsigned int opcode) {
        unsigned char message[80];

	pc = (pc - 1) & 0xffff;
	stateflags = stateflags | STATEGURU | STATEHALT;
	imagefillbox(window, SLOTX1, 388, SLOTX1+1, 389, RGBLGHTOFF);

	strcpy(message, "Illegal instruction $xx hit at address $xxxx");
	hex8tostringf(opcode,    &message[21]);
	hex8tostringf(pc >> 8,   &message[40]);
	hex8tostringf(pc & 0xff, &message[42]);
	setmessage(message);

      } /* cpuillegal */


/* the following function will only show that an illegal opcode was executed,
   but will not halt the CPU */
      void cpushowillegal(unsigned int opcode) {
	unsigned char message[80];

	if (cpumessageflag) {
	  strcpy(message, "Illegal instruction $xx hit at address $xxxx");
	  hex8tostringf(opcode,    &message[21]);
	  hex8tostringf((pc - 1) >> 8,   &message[40]);
	  hex8tostringf((pc - 1) & 0xff, &message[42]);
	  setmessage(message);
	}

      } /* cpushowillegal */


/*--------------------------------------*/


      void cpuline() {

	do {	/* ... while (!tracemode) */

/* test interrupt signals et al. */
	  if (stateflags) {
	    if (stateflags & STATERESET) {
	      stateflags = stateflags & ~(STATEHALT | STATERESET | STATEGURU | STATEBPT | STATEBRK);
	      if (cputype & (CPU65C02 | CPU65SC02)) {
	        dflag = 0;			/* on a 65c02/65sc02 the dflag gets cleared on reset */
	      }
	      pc = memoryread(0xfffc) | (memoryread(0xfffd) << 8);
	      cycle = cycle + 5;
	    }
	    if (stateflags & STATEHALT) {	/* processor still halted? */
	      virtcopy = 1;
	      virtscreencopy();
	      return;
	    }
	    if (stateflags & STATEBRK) {
	      stateflags = stateflags & ~STATEBRK;
	      pc    = memoryread(0xfffe) | (memoryread(0xffff) << 8);
	      cycle = cycle + 7;
	    }
	    if (stateflags & STATENMI) {
	      stateflags = stateflags & ~STATENMI;
	      pushstack(pc >> 8);
	      pushstack(pc & 0xff);
	      pushstack( cpuflagsgen() );
	      if (cputype & (CPU65C02 | CPU65SC02)) {
		dflag = 0;			/* on a 65c02/65sc02 the dflag gets cleared on nmi */
	      }
	      pc    = memoryread(0xfffa) | (memoryread(0xfffb) << 8);
	      cycle = cycle + 6;
	    }
	    else {
	      if (stateflags & STATEIRQ) {
	        if (!iflag) {
		  stateflags = stateflags & ~STATEIRQ;
		  pushstack(pc >> 8);
		  pushstack(pc & 0xff);
		  pushstack( cpuflagsgen() );
		  iflag = 1;
		  if (cputype & (CPU65C02 | CPU65SC02)) {
		    dflag = 0;		/* on a 65c02/65sc02 the dflag gets cleared on irq */
		  }
		  pc    = memoryread(0xfffe) | (memoryread(0xffff) << 8);
		  cycle = cycle + 6;
		} /* if /!iflag) */
	      }
	    }
	    stateflags = stateflags &  ~(STATETRACE | STATEGURU | STATEBPT);	/* remove these */
	  } /* if (stateflags) */

/* test for breakpoint */
	  if (pc == breakpoint) {
	    if (breakflag) {        /* breakpoint allowed? */
	      stateflags = stateflags | STATEBPT;
	      setmessage("CPU stopped because breakpoint was reached");
	      imagefillbox(window, SLOTX1, 388, SLOTX1+1, 389, RGBLGHTOFF);
	      virtcopy = 1;
	      virtscreencopy();
	      return;
	    }
	  }

/* draw line on screen */
	  if ((cycle - lastcycle) >= linecycles) {
	    lastcycle = lastcycle + linecycles;
	    virtline();
	    if (!virtrasterline) {
	      return;
	    }
	  }

/* interprete next opcode */
	  bytebuffer	= memoryread(pc);
	  incpc;
	  switch (bytebuffer) {
	    case 0x00 :					/* BRK */
	      cpubrk();
	      return;
                case 0x01 :				/* ORA (zp,x) */
                  areg  = areg | readindzpx();
                  flagssetnz(areg);
                  cycle = cycle + 6;
                  break;
                case 0x02 :				/* COP */
#ifdef REECOP
                  if ((pc >= 0xd000) && (!memlcramr)) {
                    pc--;
                    romexecute(pc);
                  }
                  else {
#endif
                    if (cputype == CPU6502) {
                      cpuillegal(0x02);			/* illegal 6502 */
                    }
                    else {				/* NOP2 65C02 */
                      incpc;
                      cycle = cycle + 2;
                    }
#ifdef REECOP
                  }
#endif
                  break;
                case 0x03 :				/* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x04 :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x04);		/* illegal SKB 6502 */
                    incpc;
                    cycle = cycle + 2;
                  }
                  else {
                    bytebuffer	= readzpm();		/* TSB zp 65C02 */
                    zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                    memorywrite(address, areg | bytebuffer);
                    cycle = cycle + 5;
                  }
                  break;
                case 0x05 :                             /* ORA zp */
                  areg  = areg | readzp();
                  flagssetnz(areg);
                  cycle = cycle + 3;
                  break;
                case 0x06 :                             /* ASL zp */
                  bytebuffer    = readzpm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = (bytebuffer << 1) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = bytebuffer << 1;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x07 :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x07);		/* illegal SLO (ASO) zp 6502 */
                    bytebuffer    = readzpm();
                    if ( bytebuffer > 0x7f ) {
                      bytebuffer  = (bytebuffer << 1) & 0xff;
                      cflag       = 1;
                    }
                    else {
                      bytebuffer  = bytebuffer << 1;
                      cflag       = 0;
                    }
                    memorywrite(address, bytebuffer);
                    areg = areg | bytebuffer;
                    flagssetnz(areg);
                    cycle = cycle + 5;
                  }
                  else {				/* RMB0 zp */
                    bytebuffer    = readzpm() & 0xfe;
                    memorywrite(address, bytebuffer);
                    cycle = cycle + 5;
                  }
                  break;
                case 0x08 :                             /* PHP */
                  pushstack( cpuflagsgen() );
                  cycle = cycle + 3;
                  break;
                case 0x09 :                             /* ORA # */
                  areg  = areg | memoryread(pc);
		  incpc;
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x0a :                             /* ASL */
                  if ( areg > 0x7f ) {
                    areg        = (areg << 1) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    areg        = areg << 1;
                    cflag       = 0;
                  }
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x0b :                             /* NOP 65C02 */
                  cycle = cycle + 1;
                  break;
                case 0x0c :
		  if (cputype == CPU6502) {
		    cpushowillegal(0x0c);		/* illegal SKW 6502 */
		    pc = (pc + 2) & 0xffff;
		    cycle = cycle + 4;
		  }
		  else {
                    bytebuffer    = readabsm();		/* TSB abs 65C02 */
                    zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                    memorywrite(address, areg | bytebuffer);
                    cycle = cycle + 6;
                  }
                  break;
                case 0x0d :				/* ORA abs */
                  areg  = areg | readabs();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x0e :                             /* ASL abs */
                  bytebuffer    = readabsm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = (bytebuffer << 1) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = bytebuffer << 1;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 6;
                  break;
                case 0x0f :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x0f);		/* illegal SLO (ASO) abs,x 6502 */
                    bytebuffer    = readabsm();
                    if ( bytebuffer > 0x7f ) {
                      bytebuffer  = (bytebuffer << 1) & 0xff;
                      cflag       = 1;
                    }
                    else {
                      bytebuffer  = bytebuffer << 1;
                      cflag       = 0;
                    }
                    memorywrite(address, bytebuffer);
                    areg = areg | bytebuffer;
                    flagssetnz(areg);
                    cycle = cycle + 6;
                  }
                  else {
                    if (cputype == CPU65C02) {
                      pc	= (pc + 2) & 0xffff;	/* NOP3 65C02 */
                      cycle	= cycle + 2;
                    }
                    else {
                      if (!(readzp() & 0x01)) {		/* BBR0 65SC02 */
                        bytebuffer= memoryread(pc);
                        if ( bytebuffer > 0x7f) {
                          pc	= (pc - 255 + bytebuffer) & 0xffff;
                        }
                        else {
                          pc	= (pc + 1 + bytebuffer) & 0xffff;
                        }
                        cycle	= cycle + 5;
                      }
                      else {
                        incpc;
                        cycle	= cycle + 3;
                      }
                    }
                  }
                  break;
                case 0x10 :                             /* BPL */
                  if ( nflag == 0) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                    pc          = (pc + 1) & 0xffff;
                    cycle       = cycle + 2;
                  }
                  break;
                case 0x11 :                             /* ORA (zp),y */
                  areg  = areg | readindzpy();
                  flagssetnz(areg);
                  cycle = cycle + 5;
                  break;
                case 0x12 :
                  if (cputype == 6502) {
                    cpuillegal(0x12);			/* illegal 6502 */
                  }
                  else {				/* ORA (zp) 65C02 */
                    areg  = areg | readindzp();
                    flagssetnz(areg);
                    cycle = cycle + 5;
                  }
                  break;
                case 0x13 :
                  if (cputype == CPU6502) {
                    cpuillegal(0x12);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0x14 :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x14);		/* illegal SKB 6502 */
                    incpc;
                    cycle = cycle + 3;
                  }
                  else {				/* TRB zp 65C02 */
                    bytebuffer    = readzpm();
                    zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                    memorywrite(address, (~areg) & bytebuffer);
                    cycle = cycle + 5;
                  }
                  break;
                case 0x15 :                             /* ORA zp,x */
                  areg  = areg | readzpx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x16 :                             /* ASL zp,x */
                  bytebuffer    = readzpxm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = (bytebuffer << 1) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = bytebuffer << 1;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 6;
                  break;
                case 0x17 :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x17);		/* illegal SLO (ASO) zp,x 6502 */
                    bytebuffer    = readzpxm();
                    if ( bytebuffer > 0x7f ) {
                      bytebuffer  = (bytebuffer << 1) & 0xff;
                      cflag       = 1;
                    }
                    else {
                      bytebuffer  = bytebuffer << 1;
                      cflag       = 0;
                    }
                    memorywrite(address, bytebuffer);
                    areg = areg | bytebuffer;
                    flagssetnz(areg);
                    cycle = cycle + 6;
                  }
                  else {				/* RMB1 zp 65SC02 */
                    bytebuffer    = readzpm() & 0xfd;
                    memorywrite(address, bytebuffer);
                    cycle = cycle + 5;
                  }
                  break;
                case 0x18 :                             /* CLC */
                  cflag = 0;
                  cycle = cycle + 2;
                  break;
                case 0x19 :                             /* ORA abs,y */
                  areg  = areg | readabsy();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x1a :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x1a);		/* illegal NOP 6502 */
                    cycle = cycle + 2;
                  }
                  else {				/* INA 65C02 */
                    areg  = (areg + 1) & 0xff;
                    flagssetnz(xreg);
                    cycle = cycle + 2;
                  }
                  break;
                case 0x1b :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x1b);		/* illegal SLO (ASO) abs,y 6502 */
                    bytebuffer    = readabsym();
                    if ( bytebuffer > 0x7f ) {
                      bytebuffer  = (bytebuffer << 1) & 0xff;
                      cflag       = 1;
                    }
                    else {
                      bytebuffer  = bytebuffer << 1;
                      cflag       = 0;
                    }
                    memorywrite(address, bytebuffer);
                    areg = areg | bytebuffer;
                    flagssetnz(areg);
                    cycle = cycle + 7;
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0x1c :
		  if (cputype == CPU6502) {
		    cpushowillegal(0x1c);		/* illegal SKW 6502 */
		    pc = (pc + 2) & 0xffff;
		    cycle = cycle + 4;
		  }
                  else {				/* TRB abs 65C02 */
                    bytebuffer    = readabsm();
                    zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                    memorywrite(address, (~areg) & bytebuffer);
                    cycle = cycle + 6;
                  }
                  break;
                case 0x1d :                             /* ORA abs,x */
                  areg  = areg | readabsx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x1e :                             /* ASL abs,x */
                  bytebuffer    = readabsxm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = (bytebuffer << 1) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = bytebuffer << 1;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 7;
                  break;
                case 0x1f :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x1f);		/* illegal SLO (ASO) abs,x 6502 */
                    bytebuffer    = readabsxm();
                    if ( bytebuffer > 0x7f ) {
                      bytebuffer  = (bytebuffer << 1) & 0xff;
                      cflag       = 1;
                    }
                    else {
                      bytebuffer  = bytebuffer << 1;
                      cflag       = 0;
                    }
                    memorywrite(address, bytebuffer);
                    areg = areg | bytebuffer;
                    flagssetnz(areg);
                    cycle = cycle + 7;
                  }
                  else {
                    if (cputype == CPU65C02) {
                      pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                      cycle = cycle + 3;
                    }
                    else {
                      if (!(readzp() & 0x02)) {           /* BBR1 65SC02 */
                        bytebuffer= memoryread(pc);
                        if ( bytebuffer > 0x7f) {
                          pc	= (pc - 255 + bytebuffer) & 0xffff;
                        }
                        else {
                          pc	= (pc + 1 + bytebuffer) & 0xffff;
                        }
                        cycle	= cycle + 5;
                      }
                      else {
                        incpc;
                        cycle	= cycle + 3;
                      }
                    }
                  }
                  break;
                case 0x20 :                             /* JSR abs */
                  address       = memoryread(pc);
		  incpc;
                  pushstack(pc >> 8);
                  pushstack(pc & 0xff);
                  pc            = address + ( memoryread(pc) << 8 );
                  cycle = cycle + 6;
                  break;
                case 0x21 :                             /* AND (zp,x) */
                  areg  = areg & readindzpx();
                  flagssetnz(areg);
                  cycle = cycle + 6;
                  break;
                case 0x22 :
                  if (cputype == CPU6502) {
                    cpuillegal(0x22);			/* illegal 6502 */
                  }
                  else {				/* NOP2 65C02 */
                    pc    = (pc + 1) & 0xffff;
                    cycle = cycle + 2;
                  }
                  break;
                case 0x23 :
                  if (cputype == CPU6502) {
                    cpuillegal(0x23);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0x24 :                             /* BIT zp */
                  bytebuffer    = readzp();
                  vflag = ((bytebuffer & 0x40) == 0) ? 0 : 1;
                  nflag = ((bytebuffer & 0x80) == 0) ? 0 : 1;
                  zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                  cycle = cycle + 3;
                  break;
                case 0x25 :                             /* AND zp */
                  areg  = areg & readzp();
                  flagssetnz(areg);
                  cycle = cycle + 3;
                  break;
                case 0x26 :                             /* ROL zp */
                  bytebuffer    = readzpm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = ((bytebuffer << 1) | cflag) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = (bytebuffer << 1) | cflag;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x27 :                             /* RMB2 zp */
                  bytebuffer    = readzpm() & 0xfb;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x28 :                             /* PLP */
                  cpuflagsget( pullstack() );
                  cycle = cycle + 4;
                  break;
                case 0x29 :                             /* AND # */
                  areg  = areg & memoryread(pc);
		  incpc;
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x2a :                             /* ROL */
                  if (areg > 0x7f) {
                    areg        = ((areg << 1) | cflag) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    areg        = (areg << 1) | cflag;
                    cflag       = 0;
                  }
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x2b :
                  if (cputype == CPU6502) {
                    cpuillegal(0x2b);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0x2c :                             /* BIT abs */
                  bytebuffer    = readabs();
                  vflag = ((bytebuffer & 0x40) == 0) ? 0 : 1;
                  nflag = ((bytebuffer & 0x80) == 0) ? 0 : 1;
                  zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                  cycle = cycle + 4;
                  break;
                case 0x2d :                             /* AND abs */
                  areg  = areg & readabs();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x2e :                             /* ROL abs */
                  bytebuffer    = readabsm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = ((bytebuffer << 1) | cflag) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = (bytebuffer << 1) | cflag;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 6;
                  break;
                case 0x2f :
                  if (cputype == CPU65SC02) {
                    if (!(readzp() & 0x04)) {           /* BBR2 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0x30 :                             /* BMI */
                  if ( nflag != 0 ) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f ) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                    pc          = (pc + 1) & 0xffff;
                    cycle       = cycle + 2;
                  }
                  break;
                case 0x31 :                             /* AND (zp),y */
                  areg  = areg & readindzpy();
                  flagssetnz(areg);
                  cycle = cycle + 5;
                  break;
                case 0x32 :
                  if (cputype == CPU6502) {
                    cpuillegal(0x32);			/* illegal 6502 */
                  }
                  else {				/* AND (zp) 65C02 */
                    areg  = areg & readindzp();
                    flagssetnz(areg);
                    cycle = cycle + 5;
                  }
                  break;
                case 0x33 :
                  if (cputype == CPU6502) {
                    cpuillegal(0x33);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0x34 :
		  if (cputype == CPU6502) {
		    cpushowillegal(0x34);		/* illegal SKB 6502 */
		    incpc;
		    cycle = cycle + 4;
		  }
		  else {				/* BIT zp,x 65C02 */
                    bytebuffer    = readzpx();
                    vflag = ((bytebuffer & 0x40) == 0) ? 0 : 1;
                    nflag = ((bytebuffer & 0x80) == 0) ? 0 : 1;
                    zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                    cycle = cycle + 4;
 		  }
 		  break;
                case 0x35 :                             /* AND zp,x */
                  areg  = areg & readzpx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x36 :                             /* ROL zp,x */
                  bytebuffer    = readzpxm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = ((bytebuffer << 1) | cflag) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = (bytebuffer << 1) | cflag;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 6;
                  break;
                case 0x37 :                             /* RMB3 zp */
                  bytebuffer    = readzpm() & 0xf7;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x38 :                             /* SEC */
                  cflag = 1;
                  cycle = cycle + 2;
                  break;
                case 0x39 :                             /* AND abs,y */
                  areg  = areg & readabsy();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x3a :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x3a);		/* illegal NOP 6502 */
                    cycle = cycle + 2;
                  }
                  else {				/* DEA 65C02 */
                    areg  = (areg - 1) & 0xff;
                    flagssetnz(xreg);
                    cycle = cycle + 2;
                  }
                  break;
                case 0x3b :
                  if (cputype == CPU6502) {
                    cpuillegal(0x3b);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0x3c :
		  if (cputype == CPU6502) {
		    cpushowillegal(0x3c);		/* illegal SKW 6502 */
		    pc = (pc + 2) & 0xffff;
		    cycle = cycle + 4;
		  }
		  else {
                    bytebuffer    = readabsx();		/* BIT abs,x 65C02 */
                    vflag = ((bytebuffer & 0x40) == 0) ? 0 : 1;
                    nflag = ((bytebuffer & 0x80) == 0) ? 0 : 1;
                    zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                    cycle = cycle + 4;
                  }
                  break;
                case 0x3d :                             /* AND abs,x */
                  areg  = areg & readabsx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x3e :                             /* ROL abs,x */
                  bytebuffer    = readabsxm();
                  if ( bytebuffer > 0x7f ) {
                    bytebuffer  = ((bytebuffer << 1) | cflag) & 0xff;
                    cflag       = 1;
                  }
                  else {
                    bytebuffer  = (bytebuffer << 1) | cflag;
                    cflag       = 0;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x3f :
                  if (cputype == CPU65SC02) {
                    if (!(readzp() & 0x08)) {           /* BBR3 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0x40 :                             /* RTI */
                  cpuflagsget( pullstack() );
                  pc    = pullstack() + (pullstack() << 8);
                  cycle = cycle + 6;
                  break;
                case 0x41 :                             /* EOR (zp,x) */
                  areg  = areg ^ readindzpx();
                  flagssetnz(areg);
                  cycle = cycle + 6;
                  break;
                case 0x42 :
                  if (cputype == CPU6502) {
                    cpuillegal(0x42);			/* illegal 6502 */
                  }
                  else {				/* NOP2 65C02 */
                    incpc;
                    cycle = cycle + 2;
                  }
                  break;
                case 0x43 :
                  if (cputype == CPU6502) {
                    cpuillegal(0x43);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0x44 :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x44);		/* illegal SKB 6502 */
                    incpc;
                    cycle = cycle + 3;
                  }
                  else {				/* NOP3 65C02 */
                    pc    = (pc + 1) & 0xffff;
                    cycle = cycle + 3;
                  }
                  break;
                case 0x45 :                             /* EOR zp */
                  areg  = areg ^ readzp();
                  flagssetnz(areg);
                  cycle = cycle + 3;
                  break;
                case 0x46 :                             /* LSR zp */
                  bytebuffer    = readzpm();
                  cflag         = ((bytebuffer & 1) == 0) ? 0 : 1;
                  bytebuffer    = bytebuffer >> 1;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 5;
                  break;
                case 0x47 :                             /* RMB4 zp */
                  bytebuffer    = readzpm() & 0xef;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x48 :                             /* PHA */
                  pushstack(areg);
                  cycle = cycle + 3;
                  break;
                case 0x49 :                             /* EOR # */
                  areg  = areg ^ memoryread(pc);
		  incpc;
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x4a :                             /* LSR */
                  cflag = ((areg & 1) == 0) ? 0 : 1;
                  areg  = areg >> 1;
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x4b :
                  if (cputype == CPU6502) {
                    cpuillegal(0x4b);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0x4c :                             /* JMP abs */
                  pc    = memoryread(pc) + ( memoryread( (pc + 1) & 0xffff) << 8 );
                  cycle = cycle + 3;
                  break;
                case 0x4d :                             /* EOR abs */
                  areg  = areg ^ readabs();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x4e :                             /* LSR abs */
                  bytebuffer    = readabsm();
                  cflag         = ((bytebuffer & 1) == 0) ? 0 : 1;
                  bytebuffer    = bytebuffer >> 1;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 6;
                  break;
                case 0x4f :
                  if (cputype == CPU65SC02) {
                    if (!(readzp() & 0x10)) {           /* BBR4 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0x50 :                             /* BVC */
                  if ( vflag == 0) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                    pc          = (pc + 1) & 0xffff;
                    cycle       = cycle + 2;
                  }
                  break;
                case 0x51 :                             /* EOR (zp),y */
                  areg  = areg ^ readindzpy();
                  flagssetnz(areg);
                  cycle = cycle + 5;
                  break;
                case 0x52 :
                  if (cputype == CPU6502) {
                    cpuillegal(0x52);			/* illegal 6502 */
                  }
                  else {				/* EOR (zp) 65C02 */
                    areg  = areg ^ readindzp();
                    flagssetnz(areg);
                    cycle = cycle + 5;
                  }
                  break;
                case 0x53 :
                  if (cputype == CPU6502) {
                    cpuillegal(0x53);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0x54 :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x54);		/* illegal SKB 6502 */
                    incpc;
                    cycle = cycle + 4;
                  }
                  else {				/* NOP4 65C02 */
                    pc    = (pc + 1) & 0xffff;
                    cycle = cycle + 4;
                  }
                  break;
                case 0x55 :                             /* EOR zp,x */
                  areg  = areg ^ readzpx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x56 :                             /* LSR zp,x */
                  bytebuffer    = readzpxm();
                  cflag         = ((bytebuffer & 1) == 0) ? 0 : 1;
                  bytebuffer    = bytebuffer >> 1;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 6;
                  break;
                case 0x57 :                             /* RMB5 zp */
                  bytebuffer    = readzpm() & 0xdf;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x58 :                             /* CLI */
                  iflag = 0;
                  cycle = cycle + 2;
                  break;
                case 0x59 :                             /* EOR abs,y */
                  areg  = areg ^ readabsy();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x5a :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x5a);		/* illegal NOP 6502 */
                    cycle = cycle + 2;
                  }
                  else {				/* PHY 65C02 */
                    pushstack(yreg);
                    cycle = cycle + 3;
                  }
                  break;
                case 0x5b :
                  if (cputype == CPU6502) {
                    cpuillegal(0x5b);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0x5c :
		  if (cputype == CPU6502) {
		    cpushowillegal(0x5c);		/* illegal SKW 6502 */
		    pc = (pc + 2) & 0xffff;
		    cycle = cycle + 4;
		  }
                  else {				/* NOP8 65C02 */
                    pc    = (pc + 2) & 0xffff;
                    cycle = cycle + 8;
                  }
                  break;
                case 0x5d :                             /* EOR abs,x */
                  areg  = areg ^ readabsx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x5e :                             /* LSR abs,x */
                  bytebuffer    = readabsxm();
                  cflag         = ((bytebuffer & 1) == 0) ? 0 : 1;
                  bytebuffer    = bytebuffer >> 1;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 7;
                  break;
                case 0x5f :
                  if (cputype == CPU65SC02) {
                    if (!(readzp() & 0x20)) {           /* BBR5 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0x60 :                             /* RTS */
                  pc    = ((pullstack() + (pullstack() << 8)) + 1) & 0xffff;
                  cycle = cycle + 6;
                  break;
                case 0x61 :                             /* ADC (zp,x) */
                  adc(readindzpx());
                  cycle = cycle + 6;
                  break;
                case 0x62 :                             /* NOP2 65C02 */
                  pc    = (pc + 1) & 0xffff;
                  cycle = cycle + 2;
                  break;
                case 0x63 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x64 :
		  if (cputype == CPU6502) {
		    cpushowillegal(0x64);		/* illegal SKB 6502 */
		    incpc;
		    cycle = cycle + 3;
		  }
		  else {				/* STZ zp 65C02 */
                    writezp(0);
                    cycle = cycle + 3;
		  }
                  break;
                case 0x65 :                             /* ADC zp */
                  adc(readzp());
                  cycle = cycle + 3;
                  break;
                case 0x66 :                             /* ROR zp */
                  bytebuffer    = readzpm();
                  if (cflag) {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = (bytebuffer >> 1) | 0x80;
                  }
                  else {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = bytebuffer >> 1;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x67 :                             /* RMB6 zp */
                  bytebuffer    = readzpm() & 0xbf;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x68 :                             /* PLA */
                  areg  = pullstack();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0x69 :                             /* ADC # */
                  adc(memoryread(pc));
		  incpc;
                  cycle = cycle + 2;
                  break;
                case 0x6a :                             /* ROR */
                  if (cflag) {
                    cflag       = (areg & 1) ? 1 : 0;
                    areg        = (areg >> 1) | 0x80;
                  }
                  else {
                    cflag       = (areg & 1) ? 1 : 0;
                    areg        = areg >> 1;
                  }
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x6b :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x6c :                             /* JMP (abs) */
                  address	= memoryread(pc) + ( memoryread((pc + 1) & 0xffff) << 8 );
                  if (cputype == CPU6502) {		/* bug in 6502! */
                    pc		= memoryread(address)
				+ ( memoryread(((address + 1) & 0xff) | (address & 0xff00)) << 8 );
                  }
                  else {
                    pc		= memoryread(address)
				+ ( memoryread((address + 1) & 0xffff) << 8 );
                  }
                  cycle = cycle + 5;
                  break;
                case 0x6d :                             /* ADC abs */
                  adc(readabs());
                  cycle = cycle + 4;
                  break;
                case 0x6e :                             /* ROR abs */
                  bytebuffer    = readabsm();
                  if (cflag) {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = (bytebuffer >> 1) | 0x80;
                  }
                  else {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = bytebuffer >> 1;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 6;
                  break;
                case 0x6f :
                  if (cputype == CPU65SC02) {
                    if (!(readzp() & 0x40)) {           /* BBR6 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0x70 :                             /* BVS */
                  if ( vflag != 0) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                    pc          = (pc + 1) & 0xffff;
                    cycle       = cycle + 2;
                  }
                  break;
                case 0x71 :                             /* ADC (zp),y */
                  adc(readindzpy());
                  cycle = cycle + 5;
                  break;
                case 0x72 :                             /* ADC (zp) */
                  adc(readindzp());
                  cycle = cycle + 5;
                  break;
                case 0x73 :                             /* NOP 65C02 */
                  cycle = cycle + 2;
                  break;
                case 0x74 :
		  if (cputype == CPU6502) {
		    cpushowillegal(0x74);		/* illegal SKB 6502 */
		    incpc;
		    cycle = cycle + 4;
		  }
		  else {				/* STZ zp,x 65C02 */
                    writezpx(0);
                    cycle = cycle + 4;
                  }
                  break;
                case 0x75 :                             /* ADC zp,x */
                  adc(readzpx());
                  cycle = cycle + 4;
                  break;
                case 0x76 :                             /* ROR zp,x */
                  bytebuffer    = readzpxm();
                  if (cflag) {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = (bytebuffer >> 1) | 0x80;
                  }
                  else {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = bytebuffer >> 1;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 6;
                  break;
                case 0x77 :                             /* RMB7 zp */
                  bytebuffer    = readzpm() & 0x7f;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0x78 :                             /* SEI */
                  iflag = 1;
                  cycle = cycle + 2;
                  break;
                case 0x79 :                             /* ADC abs,y */
                  adc(readabsy());
                  cycle = cycle + 4;
                  break;
                case 0x7a :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x7a);		/* illegal NOP 6502 */
                    cycle = cycle + 2;
                  }
                  else {				/* PLY */
                    yreg  = pullstack();
                    flagssetnz(yreg);
                    cycle = cycle + 4;
                  }
                  break;
                case 0x7b :
                  if (cputype == CPU6502) {
                    cpuillegal(0x7b);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0x7c :
		  if (cputype == CPU6502) {
		    cpushowillegal(0x7c);		/* illegal SKW 6502 */
		    pc = (pc + 2) & 0xffff;
		    cycle = cycle + 4;
		  }
		  else {
		    address	= (memoryread(pc) + ( memoryread((pc + 1) & 0xffff) << 8 ) /* JMP (abs,x) 65C02 */
				 + xreg) & 0xffff;
		    pc		= memoryread(address)
				 + ( memoryread((address + 1) & 0xffff) << 8 );
		    cycle = cycle + 5;
		  }
		  break;
                case 0x7d :				/* ADC abs,x */
                  adc(readabsx());
                  cycle = cycle + 4;
                  break;
                case 0x7e :				/* ROR abs,x */
                  bytebuffer    = readabsxm();
                  if (cflag) {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = (bytebuffer >> 1) | 0x80;
                  }
                  else {
                    cflag       = (bytebuffer & 1) ? 1 : 0;
                    bytebuffer  = bytebuffer >> 1;
                  }
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 7;
                  break;
                case 0x7f :
                  if (cputype == CPU65SC02) {
                    if (!(readzp() & 0x80)) {           /* BBR7 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0x80 :
		  if (cputype == CPU6502) {
		    cpushowillegal(0x80);		/* Illegal SKB 6502 */
		    incpc;
		    cycle = cycle + 2;
		  }
		  else {				/* BRA 65C02/65SC02 */
		    bytebuffer= memoryread(pc);
		    if ( bytebuffer > 0x7f) {
		      pc  = (pc - 255 + bytebuffer) & 0xffff;
		    }
		    else {
		      pc  = (pc + 1 + bytebuffer) & 0xffff;
		    }
		    cycle = cycle + 3;
		  }
		  break;
                case 0x81 :                             /* STA (zp,x) */
                  writeindzpx(areg);
                  cycle = cycle + 6;
                  break;
                case 0x82 :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x82);		/* illegal SKB 6502 */
                    incpc;
                    cycle = cycle + 2;
                  }
                  else {				/* NOP2 65C02 */
                    incpc;
                    cycle = cycle + 2;
                  }
                  break;
                case 0x83 :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x83);		/* illegal 6502 AXS (SAX) (zp,x) */
                    writeindzpx(areg & xreg);
                    cycle = cycle + 6;
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0x84 :                             /* STY zp */
                  writezp(yreg);
                  cycle = cycle + 3;
                  break;
                case 0x85 :                             /* STA zp */
                  writezp(areg);
                  cycle = cycle + 3;
                  break;
                case 0x86 :                             /* STX zp */
                  writezp(xreg);
                  cycle = cycle + 3;
                  break;
                case 0x87 :
                  if (cputype == CPU6502) {
		    cpushowillegal(0x87);		/* illegal AXS (SAX) zp 6502 */
		    writezp(areg & xreg);
		    cycle = cycle + 3;
		  }
		  else {
		    if (cputype == CPU65C02) {
		      incpc;				/* NOP2 65C02 */
		      cycle = cycle + 3;		/* correct? */
		    }
		    else {				/* SMB0 zp 65SC02 */
		      bytebuffer    = readzpm() | 0x01;
		      memorywrite(address, bytebuffer);
		      cycle = cycle + 5;
		    }
		  }
                  break;
                case 0x88 :                             /* DEY */
                  yreg  = (yreg - 1) & 0xff;
                  flagssetnz(yreg);
                  cycle = cycle + 2;
                  break;
                case 0x89 :
                  if (cputype == CPU6502) {
                    cpuillegal(0x89);			/* illegal 6502 */
                  }
                  else {				/* BIT # */
                    bytebuffer    = memoryread(pc);
                    incpc;
                    vflag = ((bytebuffer & 0x40) == 0) ? 0 : 1;
                    nflag = ((bytebuffer & 0x80) == 0) ? 0 : 1;
                    zflag = ((bytebuffer & areg) == 0) ? 1 : 0;
                    cycle = cycle + 2;
                  }
                  break;
                case 0x8a :                             /* TXA */
                  areg  = xreg;
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x8b :
                  if (cputype == CPU6502) {
                    cpuillegal(0x8b);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0x8c :                             /* STY abs */
                  writeabs(yreg);
                  cycle = cycle + 4;
                  break;
                case 0x8d :                             /* STA abs */
                  writeabs(areg);
                  cycle = cycle + 4;
                  break;
                case 0x8e :                             /* STX abs */
                  writeabs(xreg);
                  cycle = cycle + 4;
                  break;
                case 0x8f :
                  if (cputype == CPU6502) {
                    cpushowillegal(0x8f);		/* illegal AXS (SAX) abs 6502 */
                    writeabs(areg & xreg);
                    cycle = cycle + 4;
                  }
                  else {
                    if (cputype == CPU65C02) {
                      pc  = (pc + 2) & 0xffff;		/* NOP3 65C02 */
                      cycle = cycle + 4;		/* correct? */
                    }
                    else {
                      if (readzp() & 0x01) {		/* BBS0 65SC02 */
                        bytebuffer= memoryread(pc);
                        if ( bytebuffer > 0x7f) {
                          pc      = (pc - 255 + bytebuffer) & 0xffff;
                        }
                        else {
                          pc      = (pc + 1 + bytebuffer) & 0xffff;
                        }
                        cycle     = cycle + 5;
                      }
                      else {
                        incpc;
                        cycle     = cycle + 3;
                      }
                    }
                  }
                  break;
                case 0x90 :                             /* BCC */
                  if ( cflag == 0) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                   pc           = (pc + 1) & 0xffff;
                   cycle        = cycle + 2;
                  }
                  break;
                case 0x91 :                             /* STA (zp),y */
                  writeindzpy(areg);
                  cycle = cycle + 6;
                  break;
                case 0x92 :
                  if (cputype == CPU6502) {
                    cpuillegal(0x92);			/* illegal 6502 */
                  }
                  else {				/* STA (zp) */
                    writeindzp(areg);
                    cycle = cycle + 6;
                  }
                  break;
                case 0x93 :
                  if (cputype == CPU6502) {
                    cpuillegal(0x93);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0x94 :                             /* STY zp,x */
                  writezpx(yreg);
                  cycle = cycle + 4;
                  break;
                case 0x95 :                             /* STA zp,x */
                  writezpx(areg);
                  cycle = cycle + 4;
                  break;
                case 0x96 :                             /* STX zp,y */
                  writezpy(xreg);
                  cycle = cycle + 4;
                  break;
                case 0x97 :
		  if (cputype == CPU6502) {
		    cpushowillegal(0x97);		/* illegal AXS (SAX) zp,y 6502 */
		    writezpy(areg & xreg);
		    cycle = cycle + 4;
		  }
		  else {
		    if (cputype == CPU65C02) {
		      incpc;				/* NOP2 65C02 */
		      cycle = cycle + 4;		/* correct? */
		    }
                    else {				/* SMB1 zp 65SC02 */
                      bytebuffer    = readzpm() | 0x02;
                      memorywrite(address, bytebuffer);
                      cycle = cycle + 5;
                    }
                  }
                  break;
                case 0x98 :                             /* TYA */
                  areg  = yreg;
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0x99 :                             /* STA abs,y */
                  writeabsy(areg);
                  cycle = cycle + 5;
                  break;
                case 0x9a :                             /* TXS */
                  stack = xreg;
                  cycle = cycle + 2;
                  break;
                case 0x9b :
                  if (cputype == CPU6502) {
                    cpuillegal(0x9b);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0x9c :
                  if (cputype == CPU6502) {
                    cpuillegal(0x9c);			/* illegal 6502 */
                  }
                  else {				/* STZ abs 65C02 */
                    writeabs(0);
                    cycle = cycle + 4;
                  }
                  break;
                case 0x9d :                             /* STA abs,x */
                  writeabsx(areg);
                  cycle = cycle + 5;
                  break;
                case 0x9e :                             /* STZ abs,x */
                  writeabsx(0);
                  cycle = cycle + 5;
                  break;
                case 0x9f :
                  if (cputype == CPU65SC02) {
                    if (readzp() & 0x02) {              /* BBS1 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0xa0 :                             /* LDY # */
                  yreg  = memoryread(pc);
		  incpc;
                  flagssetnz(yreg);
                  cycle = cycle + 2;
                  break;
                case 0xa1 :                             /* LDA (zp,x) */
                  areg  = readindzpx();
                  flagssetnz(areg);
                  cycle = cycle + 6;
                  break;
                case 0xa2 :				/* LDX # */
                  xreg  = memoryread(pc);
		  incpc;
                  flagssetnz(xreg);
                  cycle = cycle + 2;
                  break;
                case 0xa3 :
		  if (cputype == CPU6502) {
		    cpushowillegal(0xa3);		/* illegal LAX (zp,x) 6502 */
		    areg = readindzpx();
		    xreg = areg;
		    flagssetnz(areg);
		    cycle = cycle + 6;
		  }
                  else {
                    cycle = cycle + 2;			/* NOP 65C02 */
                  }
                  break;
                case 0xa4 :				/* LDY zp */
                  yreg  = readzp();
                  flagssetnz(yreg);
                  cycle = cycle + 3;
                  break;
                case 0xa5 :				/* LDA zp */
                  areg  = readzp();
                  flagssetnz(areg);
                  cycle = cycle + 3;
                  break;
                case 0xa6 :                             /* LDX zp */
                  xreg  = readzp();
                  flagssetnz(xreg);
                  cycle = cycle + 3;
                  break;
                case 0xa7 :
		  if (cputype == CPU6502) {
		    cpushowillegal(0xa7);		/* illegal LAX zp 6502 */
		    areg = readzp();
		    xreg = areg;
		    flagssetnz(areg);
		    cycle = cycle + 3;
		  }
		  else {
		    if (cputype == CPU65C02) {
		      incpc;				/* NOP2 65C02 */
		      cycle = cycle + 3;
		    }
		    else {
                      bytebuffer    = readzpm() | 0x04;	/* SMB2 zp 65SC02 */
                      memorywrite(address, bytebuffer);
                      cycle = cycle + 5;
                    }
                  }
                  break;
                case 0xa8 :                             /* TAY */
                  yreg  = areg;
                  flagssetnz(yreg);
                  cycle = cycle + 2;
                  break;
                case 0xa9 :                             /* LDA # */
                  areg  = memoryread(pc);
		  incpc;
                  flagssetnz(areg);
                  cycle = cycle + 2;
                  break;
                case 0xaa :                             /* TAX */
                  xreg  = areg;
                  flagssetnz(xreg);
                  cycle = cycle + 2;
                  break;
                case 0xab :
                  if (cputype == CPU6502) {
                    cpuillegal(0xab);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0xac :                             /* LDY abs */
                  yreg  = readabs();
                  flagssetnz(yreg);
                  cycle = cycle + 4;
                  break;
                case 0xad :                             /* LDA abs */
                  areg  = readabs();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0xae :                             /* LDX abs */
                  xreg  = readabs();
                  flagssetnz(xreg);
                  cycle = cycle + 4;
                  break;
                case 0xaf :
		  if (cputype == CPU6502) {
		    cpushowillegal(0xaf);		/* illegal LAX abs 6502 */
		    areg = readabs();
		    xreg = areg;
		    flagssetnz(areg);
		    cycle = cycle + 4;
		  }
		  else {
		    if (cputype == CPU65C02) {
		      pc = (pc + 2) & 0xffff;		/* NOP3 65C02 */
		      cycle = cycle + 4;		/* correct? */
		    }
		    else {
                      if (readzp() & 0x04) {		/* BBS2 65SC02 */
                        bytebuffer= memoryread(pc);
                         if ( bytebuffer > 0x7f) {
                          pc	= (pc - 255 + bytebuffer) & 0xffff;
                        }
                        else {
                          pc	= (pc + 1 + bytebuffer) & 0xffff;
                        }
                        cycle	= cycle + 5;
                      }
                      else {
                        pc	= (pc + 1) & 0xffff;
                        cycle	= cycle + 3;
                      }
                    }
                  }
                  break;
                case 0xb0 :                             /* BCS */
                  if ( cflag != 0) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                    pc          = (pc + 1) & 0xffff;
                    cycle       = cycle + 2;
                  }
                  break;
                case 0xb1 :                             /* LDA (zp),y */
                  areg  = readindzpy();
                  flagssetnz(areg);
                  cycle = cycle + 5;
                  break;
                case 0xb2 :
                  if (cputype == CPU6502) {
                    cpuillegal(0xb2);			/* illegal 6502 */
                  }
                  else {				/* LDA (zp) 65C02 */
                    areg  = readindzp();
                    flagssetnz(areg);
                    cycle = cycle + 5;
                  }
                  break;
                case 0xb3 :
		  if (cputype == CPU6502) {
		    cpushowillegal(0xb3);		/* illegal LAX (zp),y 6502 */
		    areg = readindzpy();
		    xreg = areg;
		    flagssetnz(areg);
		    cycle = cycle + 5;
		  }
                  else {
                    cycle = cycle + 2;			/* NOP 65C02 */
                  }
                  break;
                case 0xb4 :				/* LDY zp,x */
                  yreg  = readzpx();
                  flagssetnz(yreg);
                  cycle = cycle + 4;
                  break;
                case 0xb5 :                             /* LDA zp,x */
                  areg  = readzpx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0xb6 :                             /* LDX zp,y */
                  xreg  = readzpy();
                  flagssetnz(xreg);
                  cycle = cycle + 4;
                  break;
                case 0xb7 :
		  if (cputype == CPU6502) {
		    cpushowillegal(0xb7);		/* illegal LAX zp,y 6502 */
		    areg = readzpy();
		    xreg = areg;
		    flagssetnz(areg);
		    cycle = cycle + 4;
		  }
		  else {
		    if (cputype == CPU65C02) {
		      incpc;				/* NOP2 65C02 */
		      cycle = cycle + 4;		/* correct? */
		    }
		    else {
		      bytebuffer = readzpm() | 0x08;	/* SMB3 zp 65SC02 */
		      memorywrite(address, bytebuffer);
		      cycle = cycle + 5;
		    }
		  }
                  break;
                case 0xb8 :                             /* CLV */
                  vflag = 0;
                  cycle = cycle + 2;
                  break;
                case 0xb9 :                             /* LDA abs,y */
                  areg  = readabsy();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0xba :                             /* TSX */
                  xreg  = stack;
                  flagssetnz(xreg);
                  cycle = cycle + 2;
                  break;
                case 0xbb :
                  if (cputype == CPU6502) {
                    cpuillegal(0xbb);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0xbc :                             /* LDY abs,x */
                  yreg  = readabsx();
                  flagssetnz(yreg);
                  cycle = cycle + 4;
                  break;
                case 0xbd :                             /* LDA abs,x */
                  areg  = readabsx();
                  flagssetnz(areg);
                  cycle = cycle + 4;
                  break;
                case 0xbe :                             /* LDX abs,y */
                  xreg  = readabsy();
                  flagssetnz(xreg);
                  cycle = cycle + 4;
                  break;
                case 0xbf :
		  if (cputype == CPU6502) {
		    cpushowillegal(0xbf);		/* illegal LAX abs,y 6502 */
		    areg = readabsy();
		    xreg = areg;
		    flagssetnz(areg);
		    cycle = cycle + 4;
		  }
		  else {
		    if (cputype == CPU65C02) {
                      pc  = (pc + 2) & 0xffff;		/* NOP3 65C02 */
                      cycle = cycle + 4;
                    }
                    else {
                      if (readzp() & 0x08) {		/* BBS3 65SC02 */
                        bytebuffer= memoryread(pc);
                        if ( bytebuffer > 0x7f) {
                          pc	= (pc - 255 + bytebuffer) & 0xffff;
                        }
                        else {
                          pc	= (pc + 1 + bytebuffer) & 0xffff;
                        }
                        cycle	= cycle + 5;
                      }
                      else {
                        incpc;
                        cycle	= cycle + 3;
                      }
                    }
                  }
                  break;
                case 0xc0 :                             /* CPY # */
                  cpy(memoryread(pc));
		  incpc;
                  cycle = cycle + 2;
                  break;
                case 0xc1 :                             /* CMP (zp,x) */
                  cmp(readindzpx());
                  cycle = cycle + 6;
                  break;
                case 0xc2 :
                  if (cputype == CPU6502) {
                    cpushowillegal(0xc2);		/* illegal SKB 6502 */
                    incpc;
                    cycle = cycle + 2;
                  }
                  else {				/* NOP2 65C02 */
                    incpc;
                    cycle = cycle + 2;
                  }
                  break;
                case 0xc3 :
                  if (cputype == CPU6502) {
                    cpuillegal(0xc3);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0xc4 :                             /* CPY zp */
                  cpy(readzp());
                  cycle = cycle + 3;
                  break;
                case 0xc5 :                             /* CMP zp */
                  cmp(readzp());
                  cycle = cycle + 3;
                  break;
                case 0xc6 :                             /* DEC zp */
                  bytebuffer    = (readzpm() - 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 5;
                  break;
                case 0xc7 :                             /* SMB4 zp */
                  bytebuffer    = readzpm() | 0x10;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0xc8 :                             /* INY */
                  yreg  = (yreg + 1) & 0xff;
                  flagssetnz(yreg);
                  cycle = cycle + 2;
                  break;
                case 0xc9 :                             /* CMP # */
                  cmp(memoryread(pc));
		  incpc;
                  cycle = cycle + 2;
                  break;
                case 0xca :                             /* DEX */
                  xreg  = (xreg - 1) & 0xff;
                  flagssetnz(xreg);
                  cycle = cycle + 2;
                  break;
                case 0xcb :
                  if (cputype == CPU6502) {
                    cpuillegal(0xcb);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0xcc :                             /* CPY abs */
                  cpy(readabs());
                  cycle = cycle + 4;
                  break;
                case 0xcd :                             /* CMP abs */
                  cmp(readabs());
                  cycle = cycle + 4;
                  break;
                case 0xce :                             /* DEC abs */
                  bytebuffer    = (readabsm() - 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 6;
                  break;
                case 0xcf :
                  if (cputype == CPU65SC02) {
                    if (readzp() & 0x10) {              /* BBS4 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0xd0 :                             /* BNE */
                  if ( zflag == 0) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                    pc          = (pc + 1) & 0xffff;
                    cycle       = cycle + 2;
                  }
                  break;
                case 0xd1 :                             /* CMP (zp),y */
                  cmp(readindzpy());
                  cycle = cycle + 5;
                  break;
                case 0xd2 :
                  if (cputype == CPU6502) {
                    cpuillegal(0xd2);			/* illegal 6502 */
                  }
                  else {				/* CMP (zp) */
                    cmp(readindzp());
                    cycle = cycle + 5;
                  }
                  break;
                case 0xd3 :
                  if (cputype == CPU6502) {
                    cpuillegal(0xd3);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0xd4 :
                  if (cputype == CPU6502) {
                    cpushowillegal(0xd4);		/* illegal SKB 6502 */
                    incpc;
                    cycle = cycle + 4;
                  }
                  else {				/* NOP4 65C02 */
                    incpc;
                    cycle = cycle + 4;
                  }
                  break;
                case 0xd5 :                             /* CMP zp,x */
                  cmp(readzpx());
                  cycle = cycle + 4;
                  break;
                case 0xd6 :                             /* DEC zp,x */
                  bytebuffer    = (readzpxm() - 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 6;
                  break;
                case 0xd7 :                             /* SMB5 zp */
                  bytebuffer    = readzpm() | 0x20;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0xd8 :                             /* CLD */
                  dflag = 0;
                  cycle = cycle + 2;
                  break;
                case 0xd9 :                             /* CMP abs,y */
                  cmp(readabsy());
                  cycle = cycle + 4;
                  break;
                case 0xda :
                  if (cputype == CPU6502) {
                    cpushowillegal(0xda);		/* illegal NOP 6502 */
                    cycle = cycle + 2;
                  }
                  else {				/* PHX 65C02 */
                    pushstack(xreg);
                    cycle = cycle + 3;
                  }
                  break;
                case 0xdb :
                  if (cputype == CPU6502) {
                    cpuillegal(0xdb);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0xdc :
		  if (cputype == CPU6502) {
		    cpushowillegal(0xdc);		/* illegal SKW 6502 */
		    pc = (pc + 2) & 0xffff;
		    cycle = cycle + 4;
		  }
                  else {				/* NOP4 65C02 */
                    pc    = (pc + 2) & 0xffff;
                    cycle = cycle + 4;
                  }
                  break;
                case 0xdd :                             /* CMP abs,x */
                  cmp(readabsx());
                  cycle = cycle + 4;
                  break;
                case 0xde :                             /* DEC abs,x */
                  bytebuffer    = (readabsxm() - 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 7;
                  break;
                case 0xdf :
                  if (cputype == CPU65SC02) {
                    if (readzp() & 0x20) {              /* BBS5 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0xe0 :                             /* CPX # */
                  cpx(memoryread(pc));
		  incpc;
                  cycle = cycle + 2;
                  break;
                case 0xe1 :                             /* SBC (zp,x) */
                  sbc(readindzpx());
                  cycle = cycle + 5;
                  break;
                case 0xe2 :
                  if (cputype == CPU6502) {
                    cpushowillegal(0xe2);		/* illegal SKB 6502 */
                    incpc;
                    cycle = cycle + 2;
                  }
                  else {				/* NOP2 65C02 */
                    incpc;
                    cycle = cycle + 2;
		  }
                  break;
                case 0xe3 :
                  if (cputype == CPU6502) {
                    cpuillegal(0xe3);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0xe4 :                             /* CPX zp */
                  cpx(readzp());
                  cycle = cycle + 3;
                  break;
                case 0xe5 :                             /* SBC zp */
                  sbc(readzp());
                  cycle = cycle + 3;
                  break;
                case 0xe6 :                             /* INC zp */
                  bytebuffer    = (readzpm() + 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 5;
                  break;
                case 0xe7 :                             /* SMB6 zp */
                  bytebuffer    = readzpm() | 0x40;
                  memorywrite(address, bytebuffer);
                  cycle = cycle + 5;
                  break;
                case 0xe8 :                             /* INX */
                  xreg  = (xreg + 1) & 0xff;
                  flagssetnz(xreg);
                  cycle = cycle + 2;
                  break;
                case 0xe9 :                             /* SBC # */
                  sbc(memoryread(pc));
                  pc    = (pc + 1) & 0xffff;
                  cycle = cycle + 2;
                  break;
                case 0xea :                             /* NOP */
                  cycle = cycle + 2;
                  break;
                case 0xeb :
                  if (cputype == CPU6502) {
                    cpuillegal(0xeb);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0xec :                             /* CPX abs */
                  cpx(readabs());
                  cycle = cycle + 4;
                  break;
                case 0xed :                             /* SBC abs */
                  sbc(readabs());
                  cycle = cycle + 4;
                  break;
                case 0xee :                             /* INC abs */
                  bytebuffer    = (readabsm() + 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 6;
                  break;
                case 0xef :
                  if (cputype == CPU65SC02) {
                    if (readzp() & 0x40) {              /* BBS6 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
                case 0xf0 :                             /* BEQ */
                  if ( zflag != 0 ) {
                    bytebuffer= memoryread(pc);
                    if ( bytebuffer > 0x7f ) {
                      pc        = (pc - 255 + bytebuffer) & 0xffff;
                    }
                    else {
                      pc        = (pc + 1 + bytebuffer) & 0xffff;
                    }
                    cycle       = cycle + 3;
                  }
                  else {
                    pc          = (pc + 1) & 0xffff;
                    cycle       = cycle + 2;
                  }
                  break;
                case 0xf1 :                             /* SBC (zp),y */
                  sbc(readindzpy());
                  cycle = cycle + 5;
                  break;
                case 0xf2 :
                  if (cputype == CPU6502) {
                    cpuillegal(0xf2);			/* illegal KIL 6502 */
                  }
                  else {				/* SBC (zp) 65C02 */
                    sbc(readindzp());
                    cycle = cycle + 5;
                  }
                  break;
                case 0xf3 :
                  if (cputype == CPU6502) {
                    cpuillegal(0xf3);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0xf4 :
                  if (cputype == CPU6502) {
                    cpushowillegal(0xf4);		/* illegal SKB 6502 */
                    incpc;
                    cycle = cycle + 4;
                  }
                  else {				/* NOP4 65C02 */
                    incpc;
                    cycle = cycle + 4;
                  }
                  break;
                case 0xf5 :                             /* SBC zp,x */
                  sbc(readzpx());
                  cycle = cycle + 4;
                  break;
                case 0xf6 :                             /* INC zp,x */
                  bytebuffer    = (readzpxm() + 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 6;
                  break;
                case 0xf7 :
                  if (cputype == CPU6502) {
                    cpushowillegal(0xf7);		/* illegal INS zp,x 6502 */
                    bytebuffer	= (readzpxm() + 1) & 0xff;
                    memorywrite(address, bytebuffer);
                    sbc(bytebuffer);
                    cycle	= cycle + 6;
                  }
                  else {
                    if (cputype == CPU65C02) {
                      incpc;				/* NOP2 65C02 correct? */
                      cycle	= cycle + 6;
                    }
                    else {
                      bytebuffer    = readzpm() | 0x80;	/* SMB7 zp 65SC02 */
                      memorywrite(address, bytebuffer);
                      cycle = cycle + 5;
                    }
                  }
                  break;
                case 0xf8 :                             /* SED */
                  dflag = 1;
                  cycle = cycle + 2;
                  break;
                case 0xf9 :                             /* SBC abs,y */
                  sbc(readabsy());
                  cycle = cycle + 4;
                  break;
                case 0xfa :
                  if (cputype == CPU6502) {
                    cpushowillegal(0xfa);		/* illegal NOP 6502 */
                    cycle = cycle + 2;
                  }
                  else {				/* PLX 65C02 */
                    xreg  = pullstack();
                    flagssetnz(xreg);
                    cycle = cycle + 4;
                  }
                  break;
                case 0xfb :
                  if (cputype == CPU6502) {
                    cpuillegal(0xfb);			/* illegal 6502 */
                  }
                  else {				/* NOP 65C02 */
                    cycle = cycle + 2;
                  }
                  break;
                case 0xfc :
                  if (cputype == CPU6502) {
                    cpushowillegal(0xfc);		/* illegal SKW 6502 */
                    pc = (pc + 2) & 0xffff;
                    cycle = cycle + 4;
                  }
                  else {				/* NOP4 65C02 */
                    pc = (pc + 2) & 0xffff;
                    cycle = cycle + 4;
                  }
                  break;
                case 0xfd :                             /* SBC abs,x */
                  sbc(readabsx());
                  cycle = cycle + 4;
                  break;
                case 0xfe :                             /* INC abs,x */
                  bytebuffer    = (readabsxm() + 1) & 0xff;
                  flagssetnz(bytebuffer);
                  memorywrite(address, bytebuffer);
                  cycle         = cycle + 7;
                  break;
                case 0xff :
                  if (cputype == CPU65SC02) {
                    if (readzp() & 0x80) {              /* BBS7 65SC02 */
                      bytebuffer= memoryread(pc);
                      if ( bytebuffer > 0x7f) {
                        pc      = (pc - 255 + bytebuffer) & 0xffff;
                      }
                      else {
                        pc      = (pc + 1 + bytebuffer) & 0xffff;
                      }
                      cycle     = cycle + 5;
                    }
                    else {
                      pc        = (pc + 1) & 0xffff;
                      cycle     = cycle + 3;
                    }
                    break;
                  }
                  else {
                    pc  = (pc + 2) & 0xffff;            /* NOP3 65C02 */
                    break;
                  }
              } /* switch */
              {
                register unsigned int delay;
                for (delay=cpudelay; delay; delay--);
              }
            } /* do */
            while (!traceflag);
            stateflags = stateflags | STATETRACE;

	    setmessage("CPU stopped because of trace mode");
	    imagefillbox(window, SLOTX1, 388, SLOTX1+1, 389, RGBLGHTOFF);
	    virtcopy = 1;

      } /* cpuline */


/*--------------------------------------*/


     void cpumenu() {
	unsigned int  menukeyboard;
	unsigned int  menuwindow;
	unsigned char key;
	unsigned int  update;
	unsigned char waitstates[32];
	unsigned char filepath[260];

	if (!windowaddio( -1, -1, WINDOWXSIZE, WINDOWYSIZE, -1, 1,
"!\
ECPU Options;\
GCPU Optionen;\
", 0, &menukeyboard, &menuwindow)) {
	  update = 1;
	  do {
	    if (update) {
	      channelout(menuwindow, 12);		/* clear window */
	      stringwritemessage(menuwindow,
"!\
E\r[ESC] - Quit\r\r;\
G\r[ESC] - Verlasse Men�\r\r;\
");

	      stringwrite(menuwindow, "\r[1] - CPU 6502:   ");
	      channelout(menuwindow, cputype==CPU6502 ?   '*':' ');
	      stringwrite(menuwindow, "\r[2] - CPU 65C02:  ");
	      channelout(menuwindow, cputype==CPU65C02 ?  '*':' ');
	      stringwrite(menuwindow, "\r[3] - CPU 65SC02: ");
	      channelout(menuwindow, cputype==CPU65SC02 ? '*':' ');

	      stringwritemessage(menuwindow,
"!\
E\rPlease note: Differences between processors have not been\rfully implemented yet.;\
G\rBitte beachten: Unterschiede zwischen Prozessoren wurden noch\rnicht vollst�ndig implementiert.;\
");
	      stringwritemessage(menuwindow,
"!\
E\r\r[M] - Mode: ;\r\
G\r\r[M] - Modus: ;\r\
;");
	      if (cpugetlinecycle() <65) {
		stringwrite(menuwindow, "0.5 Mhz");
	      }
	      else {
		if (cpugetlinecycle() <= 65) {
		  stringwrite(menuwindow, "1 Mhz");
		}
		else {
		  if (cpugetlinecycle() <= 130) {
		    stringwrite(menuwindow, "2 Mhz");
		  }
		  else {
		    stringwrite(menuwindow, "Fast Mode");
		  }
		}
	      }

	      stringwritemessage(menuwindow,
"!\
E\r\r[A] - Assemble Source File (65c02 Assembler 0.1 Beta);\
G\r\r[A] - Assembliere Quelldatei (65c02 Assembler 0.1 Beta);\
;");

	      stringwritemessage(menuwindow,
"!\
E\r[B] - Set Breakpoint (;\
G\r[B] - Setze Breakpoint (;\
;");

	      if (breakflag) {
	        hex32tostringd(breakpoint, waitstates);
	        stringwrite(menuwindow, waitstates);
	        stringwrite(menuwindow, ")");
	      }
	      else {
	        stringwritemessage(menuwindow,
"!\
ENo breakpoint set);\
GKein Breakpoint gesetzt);\
;");
	      }

	      stringwritemessage(menuwindow,
"!\
E\r[D] - 65c02 Debugger;\
G\r[D] - 65c02 Debugger;\
;");

	      stringwritemessage(menuwindow,
"!\
E\r[I] - Information about BRK and illegal opcodes: ;\
G\r[I] - Informationen �ber BRK und illegale Opcodes: ;\
;");

	      stringwriteyesno(menuwindow, cpumessageflag);

	      stringwrite(menuwindow, "\r[P] - Pause ");
	      if (stateflags & STATEHALT) {
		stringwritemessage(menuwindow,
"!\
E(CPU paused);\
G(CPU angehalten);\
;");
	      }
	      else {
		stringwritemessage(menuwindow,
"!\
E(CPU running);\
G(CPU l�uft);\
;");
	      }

	      stringwritemessage(menuwindow,
"!\
E\r[S] - Show CPU registers: ;\
G\r[S] - Zeige CPU-Register an: ;\
;");
	      stringwriteyesno(menuwindow, cpuwriteregsflag);

	      stringwritemessage(menuwindow,
"!\
E\r[W] - Wait states (;\
G\r[W] - Wartezyklen (;\
;");
	      hex32tostringd(inicpudelay, waitstates);
	      stringwrite(menuwindow, waitstates);
	      stringwrite(menuwindow, ")");

	      update = 0;
	    }
	    do {
	      imageupdate();
	      key = (unsigned char)channelin(menukeyboard);
	    }
	    while ((key == 0) && (!exitprogram));
	    switch (key) {
	      case '1' :
		if (appletype & APPLEIIC) {
		  stringwritemessage(menuwindow,
"!\
E\r\rThe Apple//c needs at least a 65C02 processor.\r;\
G\r\rDer Apple//c ben�tigt mindestens einen 65C02 Prozessor.\r;\
;");
		  windowpresskey(menukeyboard, menuwindow);
		}
	        else {
		  cpusettype(0);
		}
		update = 1;
		break;
	      case '2' :
		cpusettype(1);
		update = 1;
		break;
	      case '3' :
		cpusettype(2);
		update = 1;
		break;
	      case 'a' :
	      case 'A' :
		if (fileselectmenu(
"!\
EAssemble Source File;\
EAssembliere Source Datei;\
",
"!\
ESource File (*.S, *.ASM, *.A65, *.TXT);\
GSource File (*.S, *.ASM, *.A65, *.TXT);\
",
				   filepath, callingpath, "._s_", 0)) {
		  assembler(memram, sizeof(memram), filepath);	/* assemble source code */
		  virtsetmode();
		  virtcacheinit();
		}
		update = 1;
		break;
	      case 'b' :
	      case 'B' :
	        stringwritemessage(menuwindow,
"!\
E\r\rPlease enter new breakpoint value:\r\
(<ESC> keeps current value,\r values > $ffff will clear the breakpoint)\r>;\
G\r\rBitte geben Sie den neuen Breakpointwert ein:\r\
(<ESC> beh�lt alten Wert bei,\r Werte > $ffff l�schen den Breakpoint)\r>;\
;");
	        update = hexread(menukeyboard, menuwindow, cpugetbreakpoint());
	        if (update != cpugetbreakpoint()) {
		  cpusetbreakpoint(update);
	        }
	        update = 1;
	        break;
	      case 'd' :
	      case 'D' :
		inidebugflag = 1;
		ramdebugger(memram, sizeof(memram));
		inidebugflag = 0;
		virtsetmode();
		virtcacheinit();
		update = 1;
		break;
	      case 'i' :
	      case 'I' :
		cpumessageflag = !cpumessageflag;
		update = 1;
		break;
	      case 'm' :
	      case 'M' :
		if (cpugetlinecycle() > 130) {
		  cpusetdelay(inicpudelay*2);
		  cpusetlinecycle(65/2);
		}
		else {
		  if (cpugetlinecycle() < 65) {
		    cpusetdelay(inicpudelay);
		    cpusetlinecycle(65);
		  }
		  else {
		    if (cpugetlinecycle() == 65) {
		      cpusetdelay(inicpudelay/2);
		      cpusetlinecycle(65*2);
		    }
		    else {
		      cpusetdelay(0);
		      cpusetlinecycle(65*8);
		    }
		  }
		}
		drivefastmode = 0;
		update = 1;
		break;
	      case 'p' :
	      case 'P' :
		if (stateflags & STATEHALT) {
		  cpuclearstate(STATEHALT);
		}
		else {
		  cpusetstate(STATEHALT);
		}
		update = 1;
		break;
	      case 's' :
	      case 'S' :
		cpuwriteregsflag = !cpuwriteregsflag;
		if (!cpuwriteregsflag) {
		  imagefillbox(window, 0, 0, 639, 7, RGBBLACK);
		}
		else {
		  imagesettextcolor(window, RGBBLACK, RGBWHITE);
		  imagesetcursor(window, 0, 7);
		  cpuwriteregs(window);
		}
		update = 1;
		break;
	      case 'w' :
	      case 'W' :
	        stringwritemessage(menuwindow,
"!\
E\r\rPlease enter new delay value:\r(<ESC> keeps current value)\r>;\
G\r\rBitte geben Sie den neuen Verz�gerungswert ein:\r(<ESC> beh�lt alten Wert bei)\r>;\
;");
	        update = hexread(menukeyboard, menuwindow, inicpudelay);
	        if (inicpudelay != update) {
	          inicpudelay = update;
		  cpusetdelay(inicpudelay);
		  cpusetlinecycle(65);
		  drivefastmode = 0;
	        }
	        update = 1;
	        break;
	    } /* switch (key) */
	  }
	  while ((key != 27) && (key != 32) && (key != 13) && (!exitprogram));
	  channelclose(menukeyboard);
	  channelclose(menuwindow);
	  messageflag = 1;
	}
      } /* cpumenu */
