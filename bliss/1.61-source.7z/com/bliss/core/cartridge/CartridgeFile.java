package com.bliss.core.cartridge;

import java.io.*;
import com.bliss.core.*;

public class CartridgeFile
{

    public CartridgeFile(CartridgeType cartType, File file) {
        this(cartType, file, null);
    }

    public CartridgeFile(CartridgeType cartType, File file, String zipEntry) {
        this.cartType = cartType;
        this.file = file;
        this.zipEntry = zipEntry;
    }

    public CartridgeType getType() {
        return cartType;
    }

    public File getFile() {
        return file;
    }

    public String getZipEntryName() {
        return zipEntry;
    }

    private CartridgeType cartType;
    private File          file;
    private String        zipEntry;

}
