#include "runmgr.h"


int clear_system_state_file(struct SYS_RUN_STATE*sr);
int load_system_state_file(struct SYS_RUN_STATE*sr);
int save_system_state_file(struct SYS_RUN_STATE*sr);
