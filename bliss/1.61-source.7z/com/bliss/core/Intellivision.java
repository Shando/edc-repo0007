package com.bliss.core;

import java.awt.*;
import java.awt.image.*;
import java.io.*;
import java.util.*;
import java.text.*;
import com.bliss.core.devices.*;
import com.bliss.core.cartridge.*;
import com.bliss.core.ivoice.*;

/**
 * The all-important Intellivision.  An Intellivision is composed primarily
 * of Peripherals, which are devices that need to be "ticked" with the CPU
 * clock, and Memories, which are storage hardware like ROM or RAM.
 * You'll notice this theme of Peripherals, Memories, and things that contain
 * one or the other or both all throughout this Intellivision emulation code.
 *
 * @author Kyle Davis
 */
public class Intellivision
{

    static ResourceBundle RESOURCES = ResourceBundle.getBundle(
            "i18n/IntellivisionResources");

    public final static int NTSC_CLOCK_SPEED = 3579545; //in Hz
    public final static int PAL_CLOCK_SPEED  = 4000000; //in Hz

    public Intellivision() {
        init();
    }

    public void setFrameSkip(int skip) {
        director.setFrameSkip(skip);
    }

    public void setHighQualityAudioMixing(boolean b) {
        am.setHighQualityMixing(b);
    }

    public void setAudioAccuracy(int setting) {
        psg.setClockDivisor(setting);
        ecs.setPSGClockDivisor(setting);
    }

    public void setPaused(boolean b) {
        processorBus.setPaused(b);
    }

    public byte[] getImageBank() {
        return stic.stagingBankData;
    }

    public HandController getHandControllerOne() {
        return player1Controller;
    }

    public HandController getHandControllerTwo() {
        return player2Controller;
    }

    public ECSKeyboard getECSKeyboard() {
        return keyboard;
    }

    public EmulationDirector getDirector() {
        return director;
    }

    public void enableECSSupport(int[] image) {
        ecs.setECSROMImage(image);
    }

    public void enableIntellivoiceSupport(int[] image) {
        intellivoice.setIntellivoiceImage(image);
    }

    public void addIntellivisionListener(IntellivisionListener el) {
        if (listeners == null)
            listeners = new Vector();

        listeners.addElement(el);
    }

    public void removeIntellivisionListener(IntellivisionListener el) {
        if (listeners == null)
            return;

        listeners.removeElement(el);

        if (listeners.size() == 0)
            listeners = null;
    }

    public Option[] getVideoOptions() {
        return combinedVideoOptions;
    }

    public Option[] getAudioOptions() {
        return combinedAudioOptions;
    }

    public Option[] getInputVideoOptions() {
        return combinedInputOptions;
    }

    void saveGame() throws IOException {
        if (gameSaveDir == null) {
            String userDir = System.getProperty("user.dir");
            gameSaveDir = new File(userDir + File.separator + "saves");
        }

        //check to see if a file exists with the same name as our save game
        //directory
        if (gameSaveDir.exists() && gameSaveDir.isFile())
            throw new IOException("Unable to create save game directory: " +
                    gameSaveDir.getAbsolutePath());

        //if the directory does not exist, create it
        if (!gameSaveDir.exists())
            gameSaveDir.mkdir();

        //check to see if the output file already exists and if so, try to
        //delete it
        File outputFile = new File(gameSaveDir, currentCartridge.getType().
                getName() + ".sav");
        if (outputFile.exists() && !outputFile.delete())
            throw new IOException("Unable to overwrite existing save game: " +
                    outputFile.getAbsolutePath());

        //open the output stream
        SaveOutputStream sos = new SaveOutputStream(new BufferedOutputStream(
                new FileOutputStream(outputFile), 4096));

        //save whether or not the Intellivoice is mapped
        sos.writeBoolean(intellivoiceInUse);

        //save the state of the memory bus
        memoryBus.save(sos);

        //save the state of the processor bus
        processorBus.save(sos);

        //we're done...close the output stream
        sos.close();
    }

    void loadGame() throws IOException {
        if (gameSaveDir == null) {
            String userDir = System.getProperty("user.dir");
            gameSaveDir = new File(userDir + File.separator + "saves");
        }

        //check to see if a file exists with the same name as our save game
        //directory
        if (gameSaveDir.exists() && gameSaveDir.isFile())
            throw new IOException("No save game directory: " +
                    gameSaveDir.getAbsolutePath());

        //check to be sure the save game directory exists
        if (!gameSaveDir.exists())
            throw new IOException("No save game directory: " +
                    gameSaveDir.getAbsolutePath());

        //check to be sure our input file exists
        File inputFile = new File(gameSaveDir, currentCartridge.getType().
                getName() + ".sav");
        if (!inputFile.exists() || inputFile.isDirectory())
            throw new IOException("No save game file: " +
                    gameSaveDir.getAbsolutePath());

        //open the save game file
        LoadInputStream lis = new LoadInputStream(new BufferedInputStream(
                new FileInputStream(inputFile), 4096));

        //check to see if the Intellivoice should be used
        boolean useIntellivoice = lis.readBoolean();
        if (useIntellivoice && !intellivoiceInUse) {
            addPeripheral(intellivoice);
            intellivoiceAudioLine.acquire();
            intellivoiceInUse = true;
        }
        else if (!useIntellivoice && intellivoiceInUse)  {
            removePeripheral(intellivoice);
            intellivoiceAudioLine.release();
            intellivoiceInUse = false;
        }

        //restore the memory bus
        memoryBus.load(lis);

        //restore the processor bus
        processorBus.load(lis);

        //close the input stream
        lis.close();
    }

    void writeSnapshot() throws IOException {
        if (snapshotDir == null) {
            String userDir = System.getProperty("user.dir");
            snapshotDir = new File(userDir + File.separator + "pics");
        }

        if (snapshotDir.exists() && snapshotDir.isFile())
            throw new IOException("Unable to create snapshot directory: " +
                    snapshotDir.getAbsolutePath());

        if (!snapshotDir.exists())
            snapshotDir.mkdir();

        String[] existingFileNames = snapshotDir.list(existingSnapFilter);
        int fileCounter = 1;
        for (int i = 0; i < existingFileNames.length; i++) {
            try {
                File existingFile = new File(snapshotDir, existingFileNames[i]);
                String nextFilename = existingFile.getName();
                int nextFileNum = Integer.parseInt(nextFilename.substring(
                        nextFilename.lastIndexOf("_") + 1,
                        nextFilename.length()-4));
                if (nextFileNum >= fileCounter)
                    fileCounter = nextFileNum+1;
            }
            catch (NumberFormatException nfe) {
            }
        }
        File outputFile = new File(snapshotDir, currentCartridge.getType().
                getName() + "_" + fileCounter + ".png");
        BufferedOutputStream bos = new BufferedOutputStream(
                new FileOutputStream(outputFile), 4096);
        stic.writeSnapshot(bos);
        bos.close();
    }

    public void setPlugIn(PlugIn plugIn) {
        if (this.plugIn == plugIn)
            return;

        this.plugIn = plugIn;

        //determine our combined set of video controllers
        Option[] extendedVideoOptions = plugIn.getVideoOutputDevice().
                getOptions();
        combinedVideoOptions = new Option[basicVideoOptions.length +
                extendedVideoOptions.length];
        System.arraycopy(basicVideoOptions, 0, combinedVideoOptions, 0,
                basicVideoOptions.length);
        System.arraycopy(extendedVideoOptions, 0, combinedVideoOptions,
                basicVideoOptions.length, extendedVideoOptions.length);

        //determine our combined set of audio controllers
        Option[] extendedAudioOptions = plugIn.getAudioOutputDevice().
                getOptions();
        combinedAudioOptions = new Option[basicAudioOptions.length +
                extendedAudioOptions.length];
        System.arraycopy(basicAudioOptions, 0, combinedAudioOptions, 0,
                basicAudioOptions.length);
        System.arraycopy(extendedAudioOptions, 0, combinedAudioOptions,
                basicAudioOptions.length, extendedAudioOptions.length);

        //determine our combined set of input controllers
        Option[] extendedInputOptions = plugIn.getInputDevice().
                getOptions();
        combinedInputOptions = new Option[basicInputOptions.length +
                extendedInputOptions.length];
        System.arraycopy(basicInputOptions, 0, combinedInputOptions, 0,
                basicInputOptions.length);
        System.arraycopy(extendedInputOptions, 0, combinedInputOptions,
                basicInputOptions.length, extendedInputOptions.length);

        //director needs the plug-in
        director.changePlugIn(plugIn);

        //give the audio output device to the audio mixer
        am.setAudioOutputDevice(plugIn.getAudioOutputDevice());

        //give the input device to the hand controllers and keyboard
        player1Controller.setInputDevice(plugIn.getInputDevice());
        player2Controller.setInputDevice(plugIn.getInputDevice());
        ecs.keyboard.setInputDevice(plugIn.getInputDevice());
    }

    public PlugIn getPlugIn() {
        return plugIn;
    }

    public void setAudioEnabled(boolean b) {
        this.audioEnabled = b;
        am.isIdle = !b;
        psg.isIdle = !b;
        ecs.psg2.isIdle = !b;
        intellivoice.setAudioEnabled(b);
    }

    public void setExecImage(int[] execImage) {
        System.arraycopy(execImage, 0, this.execImage, 0,
                this.execImage.length);
        hasExecImage = true;
    }

    public boolean hasExecImage() {
        return hasExecImage;
    }

    public void setGROMImage(int[] gromImage) {
        stic.setGROMImage(gromImage);
    }

    public boolean hasGROMImage() {
        return stic.hasGROMImage();
    }

    /**
     * Turns the Intellivision on.
     */
    public void turnOn() {
        if (on)
            return;

        if (execROM == null)
            throw new EmulationException(RESOURCES.getString(
                    "ErrorNoExecutiveROM"));

        if (!stic.hasGROMImage())
            throw new EmulationException(RESOURCES.getString(
                    "ErrorNoGROM"));

        if (currentCartridge.getType().requiresECS() && !ecs.hasECSROMImage())
            throw new EmulationException(RESOURCES.getString(
                    "ErrorNoECS"));

        reset();

        thread = new EmulationThread();
        thread.setPriority(thread.getPriority()-1);
        thread.start();
        thread.waitForStart();

        on = true;
    }

    /**
     * Turns the Intellivision off.
     */
    public void turnOff() {
        turnOff(false);
    }

    public void turnOff(boolean waitForExit) {
        if (!on)
            return;

        processorBus.stop();

        //wait for the thread to exit, if necessary
        if (waitForExit)
            thread.waitForExit();

        on = false;
    }

    /**
     * Pushes the reset button on the Intellivision.
     */
    public void reset() {
        director.reset();
        processorBus.reset();
        memoryBus.reset();
    }

    /**
     * Inserts a cartridge into the Intellivision cartridge slot.
     *
     * @param cartridge the cartridge to insert
     */
    public void insertCartridge(Cartridge cartridge) {
        //remove the old cartridge
        Cartridge oldCart = currentCartridge;
        if (currentCartridge != null)
            removeCartridge();
        this.currentCartridge = cartridge;

        //add the ECS if this cartridge needs it
        if (currentCartridge.requiresECS()) {
            addPeripheral(ecs);
            ecsAudioLine.acquire();
            ecsInUse = true;
        }

        //add the Intellivoice if this cartridge can use it and we
        //have the ROM necessary for it
        if (currentCartridge.usesIntellivoice() &&
                intellivoice.hasIntellivoiceImage())
        {
            addPeripheral(intellivoice);
            intellivoiceAudioLine.acquire();
            intellivoiceInUse = true;
        }

        //add the new cartridge
        addPeripheral(cartridge);

        fireCartridgeChanged(oldCart, currentCartridge);
    }

    /**
     * Removes the current cartridge from the Intellivision cartridge slot.
     */
    public void removeCartridge() {
        if (currentCartridge == null)
            return;

        Cartridge oldCart = currentCartridge;
        removePeripheral(currentCartridge);

        //remove the Intellivoice
        if (intellivoiceInUse) {
            removePeripheral(intellivoice);
            intellivoiceAudioLine.release();
            intellivoiceInUse = false;
        }

        if (ecsInUse) {
            removePeripheral(ecs);
            ecsAudioLine.release();
            ecsInUse = false;
        }

        currentCartridge = null;
        fireCartridgeChanged(oldCart, null);
    }

    /**
     * Gets the cartridge that is current inserted into the Intellivision
     * cartridge slot.
     */
    public Cartridge getCartridge() {
        return currentCartridge;
    }

    /**
     * Initializes all of the basic hardware included in the Intellivision
     * Master Component as well as the ECS and Intellivoice peripherals.
     * This method is called only onces when the Intellivision is constructed.
     */
    protected void init() {
        //create the director
        director = new EmulationDirector(this);

        //init the processor bus
        processorBus = new ProcessorBus(director);

        //init the memory map
        memoryBus = new MemoryBus(0x10000);

        //create the input devices
        this.player1Controller = new HandController(0);
        this.player2Controller = new HandController(1);
        this.keyboard = new ECSKeyboard();

        //8 bit RAM used by EXEC and cartridge
        RAM8bit = new RAM(0x00F0, 0x0100, 8);
        memoryBus.addMemory(RAM8bit);

        //the executive (EXEC) rom
        execImage = new int[4096];
        execROM = new ROM(execImage, 0x1000);
        memoryBus.addMemory(execROM);

        //16 bit RAM used for...
        //    02F0       EXEC Object GRAM Allocation Table Pointer
        //    02F1-0318  1610 Stack
        //    0319-031C  16 bit RAM for EXEC
        //    031D-035C  Moving Object RAM Data Bases
        //    035D-035F  16 bit RAM for EXEC
        RAM16bit = new RAM(0x0070, 0x02F0, 16);
        memoryBus.addMemory(RAM16bit);

        SignalLine SR1toINTRMLine = new SignalLine();
        SignalLine SR2toBUSRQLine = new SignalLine();
        SignalLine BUSAKtoSSTLine = new SignalLine();

        //init the CPU
        cpu = new CP1610(memoryBus, SR1toINTRMLine, SR2toBUSRQLine,
                BUSAKtoSSTLine, 0x1000, 0x1004);
        processorBus.addProcessor(cpu);

        //init the STIC
        stic = new AY38900(director, cpu, SR1toINTRMLine, SR2toBUSRQLine,
                BUSAKtoSSTLine);
        addPeripheral(stic);

        //create the audio mixer line
        am = new AudioMixer(processorBus);
        processorBus.addProcessor(am);

        //init the SOUND CHIP
        psgAudioLine = am.getAudioOutputLine();
        psg = new AY38914(psgAudioLine, 0x01F0, player1Controller,
                player2Controller);
        psgAudioLine.acquire();
        addPeripheral(psg);

        //create the ECS for ECS cartridge support
        ecsAudioLine = am.getAudioOutputLine();
        this.ecs = new ECS(ecsAudioLine, keyboard);

        //create the Intellivoice for Intellivoice cartridge support
        intellivoiceAudioLine = am.getAudioOutputLine();
        this.intellivoice = new Intellivoice(intellivoiceAudioLine);
    }

    private void addPeripheral(Peripheral p) {
        peripherals[periphCount] = p;
        periphCount++;

        int count = p.getProcessorCount();
        for (int i = 0; i < count; i++)
            processorBus.addProcessor(p.getProcessor(i));

        count = p.getMemoryCount();
        for (int i = 0; i < count; i++)
            memoryBus.addMemory(p.getMemory(i));
    }

    private void removePeripheral(Peripheral p) {
        for (int i = 0; i < periphCount; i++) {
            if (peripherals[i] == p) {
                for (int j = i; j < (periphCount-1); j++)
                    peripherals[j] = peripherals[j+1];
                periphCount--;

                int count = p.getProcessorCount();
                for (int j = 0; j < count; j++)
                    processorBus.removeProcessor(p.getProcessor(j));

                count = p.getMemoryCount();
                for (int j = 0; j < count; j++)
                    memoryBus.removeMemory(p.getMemory(j));

                break;
            }
        }
    }

    protected void fireTurnedOn() {
        if (listeners == null)
            return;

        for (Enumeration e = ((Vector)listeners.clone()).elements();
                e.hasMoreElements();)
            ((IntellivisionListener)e.nextElement()).turnedOn(this);
    }

    protected void fireCartridgeChanged(Cartridge oldCart, Cartridge newCart) {
        if (listeners == null)
            return;

        for (Enumeration e = listeners.elements(); e.hasMoreElements();)
            ((IntellivisionListener)e.nextElement()).cartridgeChanged(this,
                    oldCart, newCart);
    }

    protected void fireErrorOccurred(String errorMessage) {
        if (listeners == null)
            return;

        for (Enumeration e = ((Vector)listeners.clone()).elements();
                e.hasMoreElements();)
            ((IntellivisionListener)e.nextElement()).errorOccurred(this,
                    errorMessage);
    }

    protected void fireTurnedOff() {
        if (listeners == null)
            return;

        for (Enumeration e = ((Vector)listeners.clone()).elements();
                e.hasMoreElements();)
            ((IntellivisionListener)e.nextElement()).turnedOff(this);
    }

    //the emulation thread
    private EmulationThread     thread;

    //input controllers
    HandController              player1Controller;
    HandController              player2Controller;
    private EmulationDirector   director;
    private ECSKeyboard         keyboard;

    //output directories
    private File gameSaveDir;
    private File snapshotDir;

    protected Cartridge         currentCartridge;
    protected boolean           on;
    protected boolean           audioEnabled = true;
    protected PlugIn            plugIn;

    //our list of peripherals
    protected Peripheral[]      peripherals = new Peripheral[MAX_PERIPHERALS];
    protected int               periphCount;

    //core peripherals
    protected CP1610            cpu;
    protected AY38900           stic;
    protected AY38914           psg;
    protected AudioMixer.AudioOutputLine psgAudioLine;
    protected AudioMixer        am;
    protected ProcessorBus      processorBus;
    protected MemoryBus         memoryBus;

    //core memories
    protected RAM               RAM8bit;
    protected RAM               RAM16bit;
    protected int[]             execImage;
    protected ROM               execROM;
    protected boolean           hasExecImage = false;

    //the ECS peripheral
    ECS                         ecs;
    AudioMixer.AudioOutputLine  ecsAudioLine;
    boolean                     ecsInUse;

    //the Intellivoice peripheral
    protected Intellivoice      intellivoice;
    AudioMixer.AudioOutputLine  intellivoiceAudioLine;
    protected boolean           intellivoiceInUse;

    //emulation listeners
    protected Vector listeners;

    //existing snapshot file filter
    private FilenameFilter existingSnapFilter = new FilenameFilter() {
            public boolean accept(File dir, String name) {
                return (name.startsWith(currentCartridge.getType().getName() +
                        "_") && name.endsWith(".png"));
            }
        };
    private FilenameFilter existingSaveFilter = new FilenameFilter() {
            public boolean accept(File dir, String name) {
                return (name.startsWith(currentCartridge.getType().getName() +
                        "_") && name.endsWith(".sav"));
            }
        };

    //controllers for emulation settings
    private Option[] basicVideoOptions = {
            new ChoiceOption() {
                public String getDescription() {
                    return Intellivision.RESOURCES.getString(
                            "ControllerFrameSkip");
                }
                public Object[] getChoices() {
                    return frameSkipChoices;
                }
                public String getDescription(Object choice) {
                    Object[] args = { choice };
                    return MessageFormat.format(frameSkipFormat, args);
                }
                public void setValue(Object choice) {
                    director.setFrameSkip(((Integer)choice).intValue());
                }
                public Object getValue() {
                    return new Integer(director.getFrameSkip());
                }
                private String frameSkipFormat = Intellivision.
                        RESOURCES.getString("ControllerFrameSkipFormat");
            }
        };
    private Option[] basicAudioOptions = {
            new ChoiceOption() {
                public String getDescription() {
                    return RESOURCES.getString("ControllerAudioAccuracy");
                }
                public String getDescription(Object choice) {
                    return RESOURCES.getString("ControllerAudioAccuracyOption" +
                            ((Integer)choice).toString());
                }
                public Object[] getChoices() {
                    return choices;
                }
                public Object getValue() {
                    return new Integer(psg.getClockDivisor());
                }
                public void setValue(Object value) {
                    int intValue = ((Integer)value).intValue();
                    psg.setClockDivisor(intValue);
                    ecs.setPSGClockDivisor(intValue);
                }
                private Integer[] choices = {
                        new Integer(1),
                        new Integer(2),
                        new Integer(4),
                        new Integer(8)
                    };
            },
            new BooleanOption() {
                public String getDescription() {
                    return description;
                }
                public String getDescription(Object value) {
                    return "";
                }
                public boolean isEnabled() {
                    return am.isHighQualityMixing();
                }
                public void setEnabled(boolean enabled) {
                    am.setHighQualityMixing(enabled);
                }
                private String description = 
                        RESOURCES.getString("ControllerHighQualityMixing");
            }
        };

    private Option[] basicInputOptions = new Option[0];
    private Option[] combinedVideoOptions;
    private Option[] combinedAudioOptions;
    private Option[] combinedInputOptions;

    private final static int MAX_PERIPHERALS = 12;

    private final static Integer[] frameSkipChoices = {
            new Integer(0), new Integer(1), new Integer(2),
            new Integer(3), new Integer(4), new Integer(5) };

    class EmulationThread extends Thread
    {
        public void run() {
            try {
                synchronized(this) {
                    stillRunning = true;
                    this.notifyAll();
                }
                plugIn.init(Intellivision.this);
                fireTurnedOn();
                processorBus.run();
                plugIn.release(Intellivision.this);
                fireTurnedOff();
            }
            catch (EmulationException e) {
                plugIn.release(Intellivision.this);
                fireTurnedOff();
                fireErrorOccurred(e.getPresentableMessage());
            }
            catch (Exception e) {
                plugIn.release(Intellivision.this);
                fireTurnedOff();
                e.printStackTrace(System.err);
                fireErrorOccurred(RESOURCES.getString("ErrorUnexpected"));
            }
            synchronized(this) {
                stillRunning = false;
                this.notifyAll();
            }
        }
        synchronized void waitForStart() {
            if (!stillRunning) {
                try { this.wait(); }
                catch (InterruptedException ignored) {}
            }
        }
        synchronized void waitForExit() {
            if (stillRunning) {
                try { this.wait(); }
                catch (InterruptedException ignored) {}
            }
        }
        private boolean stillRunning = false;
    }

}
