package com.blissj.app.actions;

import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.blissj.app.*;

public class RefreshAction extends AbstractAction
{

    public RefreshAction(BlissMainFrame frame) {
        this.frame = frame;
        putValue(NAME, Bliss.RESOURCES.getString(
                "ActionRefresh"));
    }

    public void actionPerformed(ActionEvent ae) {
        setEnabled(false);
        frame.scanCartridgeDirectory();
    }

    private BlissMainFrame      frame;

}
