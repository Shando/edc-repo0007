// std_file.h:  Auxillary File Functions
//                J.Litton 19990817
///
//////////////////////////////////////////////////////////////////////

#if !defined(STDFILE_H__INCLUDED_)
#define STDFILE_H__INCLUDED_


bool			fileExists(const char* sFile);

#endif