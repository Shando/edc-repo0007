/*
 * GameSettings.cs
 * 
 * Represents attribute data associated with ROMs
 * 
 * Copyright 2003 (c) Mike Murphy
 * 
 */

using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.IO.IsolatedStorage;
using System.Reflection;
using System.Text;

namespace EMU7800 {

public class GameSettings {
	public readonly string SaveKey;
	public string Title, Manufacturer, Year, ModelNo, Rarity, Manual;
	public CartType CartType;
	public MachineType MachineType;
	public Controller LController, RController;

	public bool ROMFound;
	public string ROMFullName, ROMFileName;
	public long Size;

	// Savable attributes
	public Point ClipLocation;

	public static readonly Hashtable ROMProperties = new Hashtable();

	public override string ToString() {
		return String.Format("GameSettings:\n"
			+ " SaveKey: {0}\n"
			+ " Title: {1}\n"
			+ " Manufacturer: {2}\n"
			+ " Year: {3}\n"
			+ " ModelNo: {4}\n"
			+ " Rarity: {5}\n"
			+ " Manual: {6}\n"
			+ " CartType: {7}\n"
			+ " MachineType: {8}\n"
			+ " LController: {9}\n"
			+ " RController: {10}\n"
			+ " FileName: {11}\n"
			+ " Size: {12}",
			SaveKey,
			Title, Manufacturer, Year, ModelNo, Rarity, Manual,
			CartType, MachineType, LController, RController,
			ROMFileName, Size);
	}

	public GameSettings(string saveKey) {
		SaveKey = saveKey;
	}

	public void Load() {
		string fn = String.Format("ROM.{0}.txt", SaveKey);

		Log.Msg("[{0}]\n", fn);

		if (MachineType == MachineType.A2600NTSC) {
			ClipLocation = new Point(0, 15);
		}
		if (MachineType == MachineType.A2600PAL) {
			ClipLocation = new Point(0, 30);
		}

		try {

		IsolatedStorageFileStream f
			= new IsolatedStorageFileStream(fn, FileMode.OpenOrCreate);
		StreamReader reader
			= new StreamReader(f);

		string line;
		string[] kval;
		do {
			line = reader.ReadLine();
			if (line == null) {
				break;
			}
			kval = line.Split('=');
			string key = kval[0];
			string val = kval[1];

			switch (key) {
			case "ClipLocation":
				try {
					int w = Int32.Parse(val.Split(' ')[0]);
					int h = Int32.Parse(val.Split(' ')[1]);
					ClipLocation = new Point(w, h);
				} catch {
					Log.Msg("Error reading {0} key\n", key);
				}
				Log.Msg("ClipLocation=({0}, {1})\n", ClipLocation.X, ClipLocation.Y);
				break;
			}
		} while (line != null);

		f.Close();

		} catch (Exception e) {
			Log.Msg("Error reading {0}: {1}\n", fn, e.Message);
		}

		Log.Msg("[/{0}]\n", fn);
	}

	public void Save() {
		string fn = String.Format("ROM.{0}.txt", SaveKey);

		try {

		IsolatedStorageFileStream f
			= new IsolatedStorageFileStream(fn, FileMode.Create);
		StreamWriter w = new StreamWriter(f);
		w.WriteLine("Title={0}", Title);
		w.WriteLine("ClipLocation={0} {1}", ClipLocation.X, ClipLocation.Y);
		w.Flush();
		w.Close();
		f.Close();

		} catch (Exception e) {
			Log.Msg("Error saving {0}: {1}\n", fn, e.Message);
		}
	}

	public static GameSettings New(string md5) {
		GameSettings gs = null;
		if (md5 != null && ROMProperties.ContainsKey(md5)) {
			gs = (GameSettings)ROMProperties[md5];
		}
		return gs;
	}

	// Initialize ROMProperties
	static GameSettings() {
		StreamReader r;

		try {
			r = new StreamReader(Assembly.GetExecutingAssembly().GetManifestResourceStream("EMU7800.ROMProperties.txt"));
		} catch (Exception e) {
			Log.Msg("Cannot load ROMProperties.txt from assembly: {0}\n", e.Message);
			return;
		}

		string line = r.ReadLine();

		Hashtable Column = new Hashtable();
		int colno = 0;
		foreach (string colnm in line.Split(',')) {
			Column[colnm] = colno++;
		}
			
		while (true) {
			line = r.ReadLine();
			if (line == null) {
				break;
			}

			string[] row = line.Split(',');
			string md5 = row[(int)Column["MD5"]];

			GameSettings gs = new GameSettings(md5);
			gs.Title = row[(int)Column["Title"]];
			gs.Manufacturer = row[(int)Column["Manufacturer"]];
			gs.Year = row[(int)Column["Year"]];
			gs.ModelNo = row[(int)Column["ModelNo"]];
			gs.Rarity = row[(int)Column["Rarity"]];			
			gs.Manual = row[(int)Column["Manual"]];

			gs.CartType = EnumCartType(row[(int)Column["CartType"]]);
			gs.MachineType = EnumMachineType(row[(int)Column["MachineType"]]);
			gs.LController = EnumController(row[(int)Column["LController"]]);
			gs.RController = EnumController(row[(int)Column["RController"]]);
			
			gs.ROMFound = false;

			ROMProperties[md5] = gs;
		}
		r.Close();
	}

	private static CartType EnumCartType(string cartType) {
		CartType ct;

		try {
			ct = (CartType)Enum.Parse(typeof(CartType), 
				cartType.ToUpper());
		} catch (ArgumentException) {
			ct = CartType.Null;
		}
		return ct;
	}

	private static MachineType EnumMachineType(string machineType) {
		MachineType mt;

		try {
			mt = (MachineType)Enum.Parse(typeof(MachineType),
				machineType.ToUpper());
		} catch (ArgumentException) {
			mt = MachineType.A2600NTSC;
		}
		return mt;
	}
			
	private static Controller EnumController(string controller) {
		Controller c;

		try {
			c = (Controller)Enum.Parse(typeof(Controller),
				controller);
		} catch (ArgumentException) {
			c = Controller.Joystick;
		}
		return c;
	}
}
}
