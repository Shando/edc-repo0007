/*
 * GreenScreen.cs
 * 
 * A TabPage that provides a command line interface.
 * 
 * Copyright (c) 2003, 2004 Mike Murphy
 * 
 */
using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace EMU7800 {

public class GreenScreenPage : TabPage {
	private ControlPanelForm ControlPanelForm;

	private Label label1, label2;
	private TextBox outBox;
	private TextBox inpBox;

	public GreenScreenPage(ControlPanelForm f) {
		ControlPanelForm = f;
	
		Text = "Console";

		label2 = new Label();
		label2.Text = "Command-line Input";

		inpBox = new TextBox();
		inpBox.Text ="";
		inpBox.BackColor = System.Drawing.SystemColors.ControlText;
		inpBox.ForeColor = Color.Lime;
		inpBox.Font = new Font("Courier New", 10F,
			FontStyle.Regular, GraphicsUnit.Point, ((System.Byte)(0))); 
		inpBox.Multiline = false;
		inpBox.AcceptsReturn = true;
		inpBox.AcceptsTab = true;
		inpBox.KeyPress += new KeyPressEventHandler(OnKeyPress);
		inpBox.TextChanged += new EventHandler(OnTextChanged);
		inpBox.TabStop = true;
		inpBox.TabIndex = 0;

		label1 = new Label();
		label1.Text = "Output Message Log";
		
		outBox = new TextBox();
		outBox.Text = "";
		outBox.Multiline = true;
		outBox.ScrollBars = ScrollBars.Both;
		outBox.ReadOnly = true;
		outBox.AcceptsTab = false;
		outBox.WordWrap = false;
		outBox.BackColor = System.Drawing.SystemColors.ControlText;
		outBox.ForeColor = Color.Lime;
		outBox.Font = inpBox.Font;
		outBox.TabStop = false;
				
		Controls.AddRange(new Control[] {label1, outBox, label2, inpBox});

		Layout += new LayoutEventHandler(OnLayout);
		VisibleChanged += new EventHandler(OnVisibleChanged);
		Log.LogBroadcast += new LogBroadcastHandler(OnLogBroadcast);
	}

	private void OnVisibleChanged(Object sender, EventArgs e) {
		if (outBox.Visible && !Log.Flushing) {
			Log.Flushing = true;
			Log.FlushMsgs();
		}		
		inpBox.Text = null;
		inpBox.Focus();
	}

	private void OnLogBroadcast(string msgs) {
		outBox.AppendText(msgs);
	}

	private void OnLayout(Object sender, LayoutEventArgs e) {
		int w = Size.Width - 30;

		label1.Location = new Point(15, 10);
		label1.Size = new Size(w, label1.PreferredHeight);

		outBox.Location = new Point(15,
			label1.Location.Y + label1.Size.Height + 2);
		outBox.Size = new Size(w, Size.Height - 90);

		label2.Location = new Point(15,
			outBox.Location.Y + outBox.Size.Height + 5);
		label2.Size = new Size(w, label2.PreferredHeight);

		inpBox.Location = new Point(15,
			label2.Location.Y + label2.Size.Height + 2);
		inpBox.Size = new Size(w, 35);
	}
	
	private void OnKeyPress(Object sender, KeyPressEventArgs e) {
		if (e.KeyChar == (char)13) {
         		e.Handled = true;
			IssueInpBoxCommand();
   		}
	}

	private void OnTextChanged(Object sender, EventArgs e) {
	}

	private void IssueInpBoxCommand() {
		string commandline = inpBox.Text;
		inpBox.Text = "";
		Log.Msg(">{0}\n", commandline);
		ExecuteCommandLine(new CommandLine(commandline));
		inpBox.Focus();
	}

	private void ExecuteCommandLine(CommandLine cl) {		bool recog = false;		RecordPlaybackInputAdapter ria;		GameSettings gs;		if (EMU7800App.Instance.M != null && EMU7800App.Instance.M.ExecuteCommandLine(cl)) {			recog = true;		}		switch (cl.Verb) {
		case "clear":
			outBox.Clear();
			Log.Msg("log cleared\n");
			break;
		case "cpunop":
			if (cl.Parms.Length > 0) {
				EMU7800App.Instance.Settings.NOPRegisterDumping = 
					(cl.Parms[0].StrValue.ToUpper() == "ON");
			}
			Log.Msg("CPU NOP register dumping: {0}\n",
				(EMU7800App.Instance.Settings.NOPRegisterDumping ? "ON" : "OFF"));
			break;
		case "disablemouse":
                        if (!cl.CheckParms("s")) {
				Log.Msg("need on/off parm\n");
			} else {
				EMU7800App.Instance.Settings.DeactivateMouseInput =
					(cl.Parms[0].StrValue.ToUpper() == "ON");
			}
			Log.Msg("Disable mouse: {0}\n", 
				(EMU7800App.Instance.Settings.DeactivateMouseInput ? "ON" : "OFF"));
			break;
		case "dumpromprops":
			EMU7800App.Instance.ROMProperties.Dump();
			Log.Msg("ok\n");
			break;
		case "gs":
			gs = ControlPanelForm.CurrGameSettings;
			if (cl.Parms.Length > 0) {
				string var = cl.Parms[0].StrValue.ToLower();
				string val = "";
				for (int i=1; i < cl.Parms.Length; i++) {
					if (i > 1)
						val += " ";
					val += cl.Parms[i].StrValue;
				}
				switch (var) {
				case "title": gs.Title = val; break;
				case "manufacturer": gs.Manufacturer = val; break;
				case "year": gs.Year = val; break;
				case "modelno":	gs.ModelNo = val; break;
				case "rarity": gs.Rarity = val; break;
				case "carttype":
					try {
						gs.CartType = (CartType)Enum.Parse(typeof(CartType), val, true);
					} catch {
						Log.Msg("Valid CartTypes:\n");
						foreach (string typ in Enum.GetNames(typeof(CartType))) {
							Log.Msg("{0} ", typ);
						}
						Log.Msg("\n");
					}
					break;
				case "machinetype":
					try {
						gs.MachineType = (MachineType)Enum.Parse(typeof(MachineType), val, true);
					} catch {
						Log.Msg("Valid MachineTypes:\n");
						foreach (string typ in Enum.GetNames(typeof(MachineType))) {
							Log.Msg("{0} ", typ);
						}
						Log.Msg("\n");
					}
					break;
				case "lcontroller":
				case "rcontroller":
					try {
						Controller c = (Controller)Enum.Parse(typeof(Controller), val, true);
						if (var.Substring(0, 1) == "l") {
							gs.LController = c;
						} else {
							gs.RController = c;
						}
					} catch {
						Log.Msg("Valid Controllers:\n");
						foreach (string typ in Enum.GetNames(typeof(Controller))) {
							Log.Msg("{0} ", typ);
						}
						Log.Msg("\n");
					}
					break;
				default:
					Log.Msg("unrecognized GameSettings field\n");
					break;
				}
			} else {
				Log.Msg("{0}\n", gs);
			}
			ControlPanelForm.CurrGameSettings = gs;
			break;
		case "outdir":
			Log.Msg("outdir:\n{0}\n", EMU7800App.Instance.Settings.OutputDirectory);
			break;
		case "ls":
			Log.Msg("Files in outdir:\n");
                        FileInfo[] files;
			try {
				files = new DirectoryInfo(EMU7800App.Instance.Settings.OutputDirectory).GetFiles();
			} catch (DirectoryNotFoundException) {
				Log.Msg("Directory {0} does not exist\n", EMU7800App.Instance.Settings.OutputDirectory);
				break;
			}
			foreach (FileInfo fi in files) {
				Log.Msg("{0} {1}k\n", fi.Name.PadRight(25, ' '),
					fi.Length/1024);
			}
			break;
		case "rec":
			if (!cl.CheckParms("s")) {
				Log.Msg("need filename\n");
				break;
			}
			if (ControlPanelForm.CurrGameSettings == null) {
				Log.Msg("no game selected\n");
				break;
			}
			ria = new RecordPlaybackInputAdapter(cl.Parms[0].StrValue,
				ControlPanelForm.CurrGameSettings.MD5Sum);
			EMU7800App.Instance.IA = ria;
			EMU7800App.Instance.RunMachine(ControlPanelForm.CurrGameSettings);
			ria.StopRecording();
			break;
		case "pb":
			if (!cl.CheckParms("s")) {
				Log.Msg("need filename\n");
				break;
			}
			ria = new RecordPlaybackInputAdapter(cl.Parms[0].StrValue);
			if (ria.PlaybackSaveKey == null) {
				Log.Msg("error starting playback\n");
				break;
			}
			gs = EMU7800App.Instance.ROMProperties.GetGameSettings(ria.PlaybackSaveKey);
			if (gs == null) {
				Log.Msg("rom not found in current rom directory\n");
				break;
			}
			ControlPanelForm.CurrGameSettings = gs;
			EMU7800App.Instance.IA = ria;
			EMU7800App.Instance.RunMachine(gs);
			ria.StopPlayback();
			break;
		case "stop":
			InputAdapter ia = EMU7800App.Instance.IA;
			try {
				((RecordPlaybackInputAdapter)ia).StopRecording();
				((RecordPlaybackInputAdapter)ia).StopPlayback();
				Log.Msg("stopped\n");
			} catch {
				Log.Msg("no recording or playback in effect\n");
			}
			break;
		case "run":
			if (ControlPanelForm.CurrGameSettings.FileInfo == null) {
				Log.Msg("GameSettings incomplete\n");
			} else {
				EMU7800App.Instance.RunMachine(ControlPanelForm.CurrGameSettings);
			}
			break;
		case "opacity":
			if (cl.CheckParms("i")) {
				int op = cl.Parms[0].IntValue;
				if (op > 100) {
					op = 100;
				} else if (op < 25) {
					op = 25;
				}
				ControlPanelForm.Opacity = (double)op/100.0;
				Log.Msg("Opacity set to {0}%\n", op);
			} else {
				Log.Msg("bad opacity parm\n");			
			}
			break;
		case "joybuttons":
			if (cl.Parms.Length == 0) {
				Log.Msg("joybuttons: trigger:{0} booster:{1}\n", EMU7800App.Instance.Settings.JoyBTrigger, EMU7800App.Instance.Settings.JoyBBooster);
			} else if (cl.CheckParms("ii")) {
				EMU7800App.Instance.Settings.JoyBTrigger = cl.Parms[0].IntValue;
				EMU7800App.Instance.Settings.JoyBBooster = cl.Parms[1].IntValue;
				Log.Msg("joystick button bindings set\n");
			} else {
				Log.Msg("bad parms\n");
				Log.Msg("usage: joybuttons [trigger#] [booster#] [select#] [reset#] [swap#]\n");
			}
			break;
		case "fps":
			if (cl.CheckParms("i")) {
				EMU7800App.Instance.Settings.FrameRateAdjust = cl.Parms[0].IntValue;
			} else if (cl.Parms.Length > 0) {
				Log.Msg("bad FPS parm\n");
			}
			Log.Msg("FPS delta changed\n");
			break;
		case "sb":
			if (cl.CheckParms("i")) {
				EMU7800App.Instance.Settings.NumSoundBuffers = cl.Parms[0].IntValue;
			} else if (cl.Parms.Length > 0) {
				Log.Msg("bad parm\n");
			}
			Log.Msg("number of sound buffers changed\n");
			break;
		case "save":
			if (cl.CheckParms("s")) {
				try {
					string fn = String.Format("{0}\\{1}",
						EMU7800App.Instance.Settings.OutputDirectory, cl.Parms[0].StrValue);
					EMU7800App.Instance.M.Serialize(fn);
					Log.Msg("machine state saved\n");
				} catch (Exception e) {
					Log.Msg("error saving machine state: {0}\n", e.ToString());
				}
			} else {
				Log.Msg("bad argument\n");
			}
			break;
		case "restore":
			if (cl.CheckParms("s")) {
				try {
					string fn = String.Format("{0}\\{1}",
						EMU7800App.Instance.Settings.OutputDirectory, cl.Parms[0].StrValue);
					EMU7800App.Instance.M = Machine.Deserialize(fn);
					ControlPanelForm.StartButtonEnabled = false;
					ControlPanelForm.ResumeButtonEnabled = true;
					Log.Msg("machine state restored\n");
				} catch (Exception e) {
					Log.Msg("error restoring machine state: {0}\n", e.ToString());
				}
			} else {
				Log.Msg("bad argument\n");
			}
			break;
		case "help":
		case "h":
		case "?":
			Log.Msg("** General Commands **\n"
				+ " ?: this help menu\n"
				+ " clear: clear log messages (64k limit)\n"
				+ " cpunop [on]|[off]: turn on/off cpu NOP register dumping\n"				+ " disablemouse [on]|[off]: disable mouse input\n"				+ " fps [ratedelta]: adj. frames per second\n"
				+ " gs [attribute] [value]: show/set game settings\n"
				+ " halt: stop running machine\n"
				+ " joybuttons [trigger#] [booster#]\n"
				+ " ls: show files in outdir\n"
				+ " opacity [50-100]\n"
				+ " outdir [newdir]: show/update output directory\n"
				+ " pb [filen]: playback recording\n"
				+ " rec [filen]: start recording input\n"
				+ " restore [fn]: restore machine state\n"
				+ " resume: resume stopped machine\n"
				+ " run: run ROM specified in GameSettings\n"
				+ " sb [num]: number of sound buffers\n"
				+ " stop: stop playback or recording\n"
				+ " save [fn]: save machine state\n"
			);
			break;
		default:
			if (!recog) {
				Log.Msg("Unrecognized command\n");
			}
			break;
		}
	}
}
}