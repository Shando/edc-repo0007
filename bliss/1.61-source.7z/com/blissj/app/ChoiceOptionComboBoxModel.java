package com.blissj.app;

import javax.swing.*;
import com.bliss.core.ChoiceOption;

public class ChoiceOptionComboBoxModel extends AbstractListModel
        implements ComboBoxModel, OptionEditor
{

    public ChoiceOptionComboBoxModel(ChoiceOption option) {
        this.option = option;
        Object[] choices = option.getChoices();
        choiceDescriptions = new String[choices.length];
        for (int i = 0; i < choices.length; i++)
            choiceDescriptions[i] = option.getDescription(choices[i]);
        reloadOption();
    }

    public void reloadOption() {
        selectedItem = option.getDescription(option.getValue());
    }

    public void commitSelection() {
        for (int i = 0; i < choiceDescriptions.length; i++) {
            if (choiceDescriptions[i].equals(selectedItem)) {
                option.setValue(option.getChoices()[i]);
                break;
            }
        }
    }

    public int getSize() {
        return choiceDescriptions.length;
    }

    public Object getElementAt(int index) {
        return choiceDescriptions[index];
    }

    public Object getSelectedItem() {
        return selectedItem;
    }

    public void setSelectedItem(Object selectedItem) {
        this.selectedItem = selectedItem;
        fireContentsChanged(this, -1, -1);
    }

    private ChoiceOption option;
    private String[] choiceDescriptions;
    private Object selectedItem;

}
