PCAEWin source distribution
--------------------------------------------

This archive contains all the source files needed to build PCAEWin in
Borland Delphi 5.0. Before compiling you should first:

- Install my modified version of DelphiX (DelphiX....zip)
- Install the TMT-Lite components that come on the Delphi Companion
  tools CD

All of MY source code is released under the GPL (see file "COPYING").

John Dullea
December, 2000
