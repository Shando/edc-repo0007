package com.bliss.core;

import java.io.*;

public class RAM extends Memory
{
    public RAM(int size, int location, int bitWidth) {
        image = new int[size];
        this.location = location;
        this.bitWidth = bitWidth;
        this.trimmer = ((int)Math.pow(2, (double)bitWidth)) - 1;
    }

    public void save(SaveOutputStream os) throws IOException {
        for (int i = 0; i < image.length; i++)
            os.writeInt(image[i]);
    }

    public void load(LoadInputStream is) throws IOException {
        for (int i = 0; i < image.length; i++)
            image[i] = is.readInt(0, trimmer);
    }

    public void reset() {
        for (int i = 0; i < image.length; i++)
             image[i] = 0;
    }

    public int getLocation() {
        return location;
    }

    public int peek(int location) {
        return image[location-this.location];
    }

    public void poke(int location, int value) {
        image[location-this.location] = (value & trimmer);
    }

    public int getSize() {
        return image.length;
    }

    int[] image;
    int location;
    int bitWidth;
    int trimmer;

}
