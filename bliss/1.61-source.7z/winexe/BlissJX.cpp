
#include <windows.h>
#include <stdio.h>

//This creates a "stub" win32 EXE that launches the Java application.
//An EXE stub greatly simplifies Java app usage for users who are less
//familiar with how to run Java applications, and it eliminates the
//problems with DOS windows appearing and the need to associate .jar
//files with javaw.exe from a JRE.
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance, 
                     LPSTR     lpCmdLine, 
                     int       nCmdShow)
{

    STARTUPINFO si;
    PROCESS_INFORMATION pi;
    CHAR buf[512];

    memset(&si, 0, sizeof(STARTUPINFO));
    memset(&pi, 0, sizeof(PROCESS_INFORMATION));
    si.cb = sizeof(STARTUPINFO);

    CHAR currentDir[MAX_PATH];
    GetModuleFileName(NULL, currentDir, MAX_PATH);
    INT32 len = strlen(currentDir);
    while (currentDir[len] != '\\')
        len--;
    currentDir[len+1] = NULL;

    sprintf(buf, "%s%s %s -cp \"%s;%s%s\" %s %s",
            currentDir, "jre\\bin\\javaw.exe",
            "-DPlugInClass=com.blissjx.plugin.Win32PlugIn",
            currentDir, currentDir, "BlissJX.jar",
            "com.blissj.app.Bliss", lpCmdLine);
    CreateProcess(NULL, buf,
            NULL, NULL, FALSE, DETACHED_PROCESS, NULL, NULL, &si, &pi);

    // Wait until child process exits.
/*
    WaitForSingleObject( pi.hProcess, INFINITE );
*/

    // Close process and thread handles. 
    CloseHandle( pi.hProcess );
    CloseHandle( pi.hThread );

    return 0;
}

