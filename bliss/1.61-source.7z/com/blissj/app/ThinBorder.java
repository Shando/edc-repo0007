package com.blissj.app;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 * A class which implements a simple thin border which can 
 * either be raised or lowered.  If no highlight/shadow
 * colors are initialized when the border is created, then
 * these colors will be dynamically derived from the background 
 * color of the component argument passed into the paintBorder() 
 * method.
 *
 * @author Kyle Davis
 */
public class ThinBorder extends AbstractBorder
{

    public static final int RAISED  = 0;
    public static final int LOWERED = 1;

    public static ThinBorder createBorder(int type) {
        if (type == RAISED)
            return raisedBorder;
        else
            return loweredBorder;
    }

    public static ThinBorder createBorder(int type, Color shadow,
            Color highlight)
    {
        return new ThinBorder(type, shadow, highlight);
    }

    /**
     * Paints the border for the specified component with the 
     * specified position and size.
     *
     * @param c the component for which this border is being painted
     * @param g the paint graphics
     * @param x the x position of the painted border
     * @param y the y position of the painted border
     * @param width the width of the painted border
     * @param height the height of the painted border
     */
    public void paintBorder(Component c, Graphics g, int x, int y,
            int width, int height)
    {
        int w = width;
        int h = height;
        g.translate(x, y);
        
        Color currentShadow = (shadow == null)
                ? UIManager.getColor("controlShadow") : shadow;
        Color currentHighlight = (highlight == null)
                ? UIManager.getColor("controlLtHighlight") : highlight;
        g.setColor(thinType == RAISED ? currentShadow : currentHighlight);
        g.drawRect(0, 0, w-1, h-1);

        g.setColor(thinType == RAISED ? currentHighlight : currentShadow);
        g.drawLine(0, 0, w-2, 0);
        g.drawLine(0, 1, 0, h-2);

        g.translate(-x, -y);
    }

    /**
     * Returns the insets of the border.
     * @param c the component for which this border insets value applies
     */
    public Insets getBorderInsets(Component c)       {
        return new Insets(1, 1, 1, 1);
    }

    /** 
     * Reinitialize the insets parameter with this Border's current Insets. 
     * @param c the component for which this border insets value applies
     * @param insets the object to be reinitialized
     */
    public Insets getBorderInsets(Component c, Insets insets) {
        insets.left = insets.top = insets.right = insets.bottom = 1;
        return insets;
    }

    /**
     * Returns whether or not the border is opaque.
     */
    public boolean isBorderOpaque() { return true; }

    /**
     * Returns which thin-type is set on the thin border.
     */
    public int getThinType() {
        return thinType;
    }

    /**
     * Creates a thin border with the specified thin-type whose
     * whose colors will be derived from the background color of
     * the component passed into the paintBorder method.
     *
     * @param thinType the type of the border
     */
    private ThinBorder(int thinType) {
        this(thinType, null, null);
    }

    private ThinBorder(int thinType, Color shadow, Color highlight) {
        this.thinType = thinType;
        this.shadow = shadow;
        this.highlight = highlight;
    }

    protected int thinType;
    protected Color highlight;
    protected Color shadow;

    private static ThinBorder raisedBorder = new ThinBorder(RAISED);
    private static ThinBorder loweredBorder = new ThinBorder(LOWERED);
}
