//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource1.rc
//
#define IDD_MAIN                        101
#define IDD_ABOUT                       102
#define IDD_CONFIG                      103
#define IDD_MEMORY                      104
#define IDD_DEVSEL                      105
#define IDD_CPUCFG                      106
#define IDD_JOYCFG                      107
#define IDD_SNDCFG                      108
#define IDB_APPLE2                      108
#define IDD_MONCFG                      109
#define IDB_AGAT7                       109
#define IDD_TEACCFG                     110
#define IDB_AGAT9                       110
#define IDB_APPLE2_LOGO                 111
#define IDD_SHUGCFG                     112
#define IDB_AGAT7_LOGO                  112
#define IDD_SYSCHOOSE                   113
#define IDB_AGAT9_LOGO                  113
#define IDI_MAIN                        114
#define IDD_TAPECFG                     114
#define IDD_VTCFG                       115
#define IDD_PRN9CFG                     116
#define IDD_PRNACFG                     117
#define IDC_NEW                         200
#define IDC_RESET                       201
#define IDC_CONFIG                      202
#define IDC_DELETE                      203
#define IDC_ABOUT                       204
#define IDC_STOP                        205
#define IDC_CALLHELP                    206
#define IDC_CFGLIST                     1000
#define IDC_SYSTYPE                     1001
#define IDC_PERIPHERAL                  1002
#define IDC_MEMLIST                     1004
#define IDC_DEVLIST                     1005
#define IDC_CPUFREQ                     1006
#define IDC_UNDOC                       1007
#define IDC_NONE                        1008
#define IDC_MOUSE                       1009
#define IDC_JOYSTICK                    1010
#define IDC_FREQ                        1011
#define IDC_BUFSIZE                     1012
#define IDC_MMSYSTEM                    1013
#define IDC_DIRECTSOUND                 1014
#define IDC_MONO                        1015
#define IDC_BEEPER                      1015
#define IDC_COLOR                       1016
#define IDC_DRV1                        1018
#define IDC_DRV2                        1019
#define IDC_IMG1                        1020
#define IDC_IMGSEL1                     1021
#define IDC_IMG2                        1022
#define IDC_IMGSEL2                     1023
#define IDC_IMGROM                      1027
#define IDC_IMGROMSEL                   1028
#define IDC_RO1                         1029
#define IDC_RO2                         1030
#define IDC_AGAT_7                      1030
#define IDC_AGAT_9                      1031
#define IDC_CPU_TYPE                    1031
#define IDC_APPLE_2                     1032
#define IDC_FILE                        1033
#define IDC_FNAME                       1034
#define IDC_CHOOSE                      1035
#define IDC_FAST                        1036
#define IDC_UPDATE                      1037
#define IDC_IRQ                         1038
#define IDC_NMI                         1039
#define IDC_HRESET                      1040
#define IDC_SAVESTATE                   1041
#define IDC_LOADSTATE                   1042
#define IDC_CLEARSTATE                  1043
#define IDD_MY                          1044
#define IDC_FW_NAME                     1045
#define IDC_CHOOSE_FW                   1046
#define IDC_FNT_NAME                    1047
#define IDC_CHOOSE_FNT                  1048
#define IDC_XFNT_NAME                   1049
#define IDC_FW1_NAME                    1049
#define IDC_CHOOSE_XFNT                 1050
#define IDC_FW2_NAME                    1050
#define IDC_CHOOSE_FW1                  1051
#define IDC_CHOOSE_FW2                  1052
#define IDC_PRINT_MODE                  1053
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1054
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
