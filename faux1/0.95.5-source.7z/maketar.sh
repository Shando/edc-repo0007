#!/bin/sh
# make the tgz source file for distribution to sourceforge
#
# part of the faux1 project and subject to the GNU GLP 2.0 or later license
#
# date...... programmer.. description..
# 2012-02-17 j.m.reneau   original coding
# 2012-02-19 j.m.reneau   cleaned up to work with apps folder
#
VERSION=`awk '/VERSION "/,/"/' src/strings.h | sed 's/.*VERSION "\(.*\)*".*$/\1/'`
TARFILE=faux1.$VERSION.src
echo - making $TARFILE for $VERSION -
tar -cvf $TARFILE.tar * --exclude '*~' --exclude 'faux1' --exclude '*.o' --exclude '*.tar.gz'
gzip $TARFILE.tar
rm $TARFILE.tar
ls -al $TARFILE*
echo - done -

