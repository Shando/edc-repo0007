/*
 * HostGDI
 *
 * A GDI-based Host. 
 *
 * Copyright (c) 2003, 2004 Mike Murphy
 *
 */
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Reflection;
using System.Windows.Forms;

namespace EMU7800 {

public class HostGDI : Form, IHost {
	private ControlPanelForm ControlPanelForm;
	private Machine M;
	private Rectangulator Rectangulator;
	private bool ReqRefresh;
	private uint[] FrameBuffer;

	private bool Paused, Mute;

	private double FPS;
	private long FrameStartTicks;
	private const int FrameSamples = 30;

	private string textMsg;
	private string TextMsg {
		get {
			return textMsg;
		}
		set {
			textMsg = value;
			if (textMsg != null) {
				TextExpireFrameCount = M.FrameNumber + 3*M.FrameHZ;
			}
		}
	}
	private long TextExpireFrameCount;

	private Font TextFont;
	private SolidBrush TextBrush;
	private Graphics RGraphics;
	private SolidBrush SBrush = new SolidBrush(Color.Black);
	private Bitmap FrameBitmap;

	private int CurrPlayerNo = 0;
	private int[] PaddleOhms = new int[4];
	private int[] PaddleVels = new int[4];

	private int VisiblePitch, EffectiveFPS, SoundSampleRate, NumSoundBuffers;

	public HostGDI(ControlPanelForm f, Machine m) {
		ControlPanelForm = f;
		M = m;
		M.H = this;

		VisiblePitch = M.VisiblePitch;
		NumSoundBuffers = Globals.NumSoundBuffers;
		EffectiveFPS = M.FrameHZ + Globals.FrameRateAdjust;
		SoundSampleRate = M.SoundSampleRate*EffectiveFPS/M.FrameHZ;

		//if (useBitmap) {
		//	FrameBitmap = new Bitmap(VisiblePitch, M.Scanlines, PixelFormat.Format32bppArgb);
		//	FrameBuffer = new uint[VisiblePitch*M.Scanlines];
		//	Rectangulator = null;
		//} else {
			Rectangulator r = new Rectangulator(VisiblePitch, M.Scanlines);
			r.UpdateRect += new UpdateRectHandler(OnUpdateRect);
			r.Palette = M.Palette;
			r.PixelAspectXRatio = 320/VisiblePitch;
			r.OffsetLeft = 0;
			r.ClipTop = M.FirstScanline;
			r.ClipHeight = 240;
			r.UpdateTransformationParameters();
			Rectangulator = r;
			FrameBitmap = null;
			FrameBuffer = null;
		//}
	}

	public void Run() {
		Log.Msg("GDI Host startup\n");

		Text = Globals.Title + " v" + Globals.Version;
		// Try to set the icon for the form, but don't bomb the application over it
		try {
			Icon = new Icon(Assembly.GetExecutingAssembly().GetManifestResourceStream("EMU7800.Icon1.ico"));
		} catch {}

		ShowInTaskbar = true;
		FormBorderStyle = FormBorderStyle.Sizable;
		CenterToScreen();

		ClientSize = new Size(640, 480);
		MinimumSize = new Size(320 + 8, 240 + 27);
		
		// Enable double-buffering to avoid flicker
		SetStyle(ControlStyles.UserPaint, true);
		SetStyle(ControlStyles.AllPaintingInWmPaint, true);
		SetStyle(ControlStyles.DoubleBuffer, true);

		TextFont = new Font("Courier New", 18);
		TextBrush = new SolidBrush(Color.White);

		Paint += new PaintEventHandler(OnPaint);
		Layout += new LayoutEventHandler(OnLayout);
		
		KeyDown += new KeyEventHandler(OnKeyDown);
		KeyUp   += new KeyEventHandler(OnKeyUp);
		KeyPreview = true;

		ControlPanelForm.AddOwnedForm(this);

		Log.Msg("GDI Host startup complete\n");

		Show();

		Paused = false;
		ReqRefresh = true;

		int doevent_counter = 0;

Audio.winmmOpen(SoundSampleRate, M.Scanlines << 1, NumSoundBuffers);
//Audio.sdlOpen(SoundSampleRate, M.Scanlines << 1, NumSoundBuffers);

		while (true) {
			if (ReqRefresh) {
				if (Rectangulator != null) {
					RGraphics.Clear(Color.Black);
					Rectangulator.DrawEntireFrame(Paused);
				}
				ReqRefresh = false;
			}

			UpdatePaddles();
			RenderFrame();

			if (--doevent_counter <= 0) {
				Application.DoEvents();
				doevent_counter = 3;
			}
			if (!Created) {
Audio.winmmClose();
//Audio.sdlClose();
				return;
			}

			if (M.FrameNumber % FrameSamples == 0) {
				int ticks = Environment.TickCount;
				double avgticks = (ticks - FrameStartTicks);
				avgticks /= FrameSamples;
				FPS = 1000.0/avgticks;
				FrameStartTicks = ticks;
			}
		}
	}

	private void RenderFrame() {
		if (Rectangulator != null) {
			if (Paused) {
				Rectangulator.DrawEntireFrame(true);
			} else {
				Rectangulator.StartFrame();
				M.Run();
				Rectangulator.EndFrame();
			}
		} else {
			if (!Paused) {
				M.Run();
				OnUpdateFrame(FrameBuffer);
			}
		}

		if (TextExpireFrameCount > M.FrameNumber) {
			ClearTextMsg();
			ShowTextMsg();
		} else if (TextMsg != null) {
			ClearTextMsg();
			TextMsg = null;
		}
	}

	private void ClearPlayerInput(int playerno) {
		InputAdapter ia = M.InputAdapter;

		PaddleVels[playerno] = 0;
		ia[playerno, ControllerAction.Trigger] = false;
		ia[playerno, ControllerAction.Trigger2] = false;
		ia[playerno, ControllerAction.Left] = false;
		ia[playerno, ControllerAction.Up] = false;
		ia[playerno, ControllerAction.Right] = false;
		ia[playerno, ControllerAction.Down] = false;
		ia[playerno, ControllerAction.Keypad7] = false;
		ia[playerno, ControllerAction.Keypad8] = false;
		ia[playerno, ControllerAction.Keypad9] = false;
		ia[playerno, ControllerAction.Keypad4] = false;
		ia[playerno, ControllerAction.Keypad5] = false;
		ia[playerno, ControllerAction.Keypad6] = false;
		ia[playerno, ControllerAction.Keypad1] = false;
		ia[playerno, ControllerAction.Keypad2] = false;
		ia[playerno, ControllerAction.Keypad3] = false;
		ia[playerno, ControllerAction.KeypadA] = false;
		ia[playerno, ControllerAction.Keypad0] = false;
		ia[playerno, ControllerAction.KeypadP] = false;
	}

	private void OnKeyDown(Object sender, KeyEventArgs e) {
		OnKeyPress(e, true);
	}
	
	private void OnKeyUp(Object sender, KeyEventArgs e)  {
		OnKeyPress(e, false);
	}

	private void OnKeyPress(KeyEventArgs e, bool down) {
		InputAdapter ia = M.InputAdapter;
		Keys key = e.KeyCode;

		e.Handled = true;

		if (down && Paused) {
			Paused = false;
			ReqRefresh = true;
		}

		switch (key) {
		case Keys.Escape:
			if (down)
				Close();
			break;
		case Keys.P:
			if (down) {
				Paused = true;
				ReqRefresh = true;
			}
			break;
		case Keys.Tab:
			if (down) {
				ControlPanelForm.Show();
			}
			break;
		case Keys.ControlKey:
			ia[CurrPlayerNo, ControllerAction.Trigger] = down;
			break;
		case Keys.Menu:  // Alt key
			ia[CurrPlayerNo, ControllerAction.Trigger2] = down;
			break;
		case Keys.Left:
			ia[CurrPlayerNo, ControllerAction.Left] = down;
			if (down) {
				ia[CurrPlayerNo, ControllerAction.Right] = false;
			}
			PaddleVels[CurrPlayerNo] += down ? 1 : -1;
			if (PaddleVels[CurrPlayerNo] != 0)
				PaddleVels[CurrPlayerNo] /= Math.Abs(PaddleVels[CurrPlayerNo]);
			break;
		case Keys.Up:
			ia[CurrPlayerNo, ControllerAction.Up] = down;
			if (down) {
				ia[CurrPlayerNo, ControllerAction.Down] = false;
			}
			break;
		case Keys.Right:
			ia[CurrPlayerNo, ControllerAction.Right] = down;
			if (down) {
				ia[CurrPlayerNo, ControllerAction.Left] = false;
			}
			PaddleVels[CurrPlayerNo] += down ? -1 : 1;
			if (PaddleVels[CurrPlayerNo] != 0)
				PaddleVels[CurrPlayerNo] /= Math.Abs(PaddleVels[CurrPlayerNo]);
			break;
		case Keys.Down:
			ia[CurrPlayerNo, ControllerAction.Down] = down;
			if (down) {
				ia[CurrPlayerNo, ControllerAction.Up] = false;
			}
			break;
		case Keys.NumPad7:
			ia[CurrPlayerNo, ControllerAction.Keypad7] = down;
			break;
		case Keys.NumPad8:
			ia[CurrPlayerNo, ControllerAction.Keypad8] = down;
			break;
		case Keys.NumPad9:
			ia[CurrPlayerNo, ControllerAction.Keypad9] = down;
			break;
		case Keys.NumPad4:
			ia[CurrPlayerNo, ControllerAction.Keypad4] = down;
			break;
		case Keys.NumPad5:
			ia[CurrPlayerNo, ControllerAction.Keypad5] = down;
			break;
		case Keys.NumPad6:
			ia[CurrPlayerNo, ControllerAction.Keypad6] = down;
			break;
		case Keys.NumPad1:
			ia[CurrPlayerNo, ControllerAction.Keypad1] = down;
			break;
		case Keys.NumPad2:
			ia[CurrPlayerNo, ControllerAction.Keypad2] = down;
			break;
		case Keys.NumPad3:
			ia[CurrPlayerNo, ControllerAction.Keypad3] = down;
			break;
		case Keys.Multiply:
			ia[CurrPlayerNo, ControllerAction.KeypadA] = down;
			break;
		case Keys.NumPad0:
			ia[CurrPlayerNo, ControllerAction.Keypad0] = down;
			break;
		case Keys.Divide:
			ia[CurrPlayerNo, ControllerAction.KeypadP] = down;
			break;
		case Keys.R:
			ia[ConsoleSwitch.GameReset] = down;
			break;
		case Keys.S:
			ia[ConsoleSwitch.GameSelect] = down;
			break;
		case Keys.C:
			if (down) {
				ia[ConsoleSwitch.GameBW] = !ia[ConsoleSwitch.GameBW];
				TextMsg = ia[ConsoleSwitch.GameBW] ? "B/W" : "Color";
			}
			break;
		case Keys.D1:
			if (down) {
				ia[ConsoleSwitch.LDifficultyA] = !ia[ConsoleSwitch.LDifficultyA];
				TextMsg = "Left Difficulty: "
					+ (ia[ConsoleSwitch.LDifficultyA] ? "A (Pro)" : "B (Novice)");
			}
			break;
		case Keys.D2:
			if (down) {
				ia[ConsoleSwitch.RDifficultyA] = !ia[ConsoleSwitch.RDifficultyA];
				TextMsg = "Right Difficulty: "
					+ (ia[ConsoleSwitch.RDifficultyA] ? "A (Pro)" : "B (Novice)");
			}
			break;
		case Keys.F1:
			if (down) {
				ClearPlayerInput(CurrPlayerNo);
				CurrPlayerNo = 0;
				TextMsg = "Keyboard Switched to Player 1";
			}
			break;
		case Keys.F2:
			if (down) {
				ClearPlayerInput(CurrPlayerNo);
				CurrPlayerNo = 1;
				TextMsg = "Keyboard Switched to Player 2";
			}
			break;
		case Keys.F3:
			if (down) {
				ClearPlayerInput(CurrPlayerNo);
				CurrPlayerNo = 2;
				TextMsg = "Keyboard Switched to Player 3";
			}
			break;
		case Keys.F4:
			if (down) {
				ClearPlayerInput(CurrPlayerNo);
				CurrPlayerNo = 3;
				TextMsg = "Keyboard Switched to Player 4";
			}
			break;
		case Keys.F:
			if (down) {
				TextMsg = String.Format("{0:#.0}/{1} FPS\n", FPS,
					EffectiveFPS);
			}
			break;
		case Keys.M:
			if (down) {
				Mute = !Mute;
				TextMsg = Mute ? "Mute" : "Mute Off";
			}
			break;
		case Keys.F5:
			if (down && Rectangulator != null) {
				Rectangulator.OffsetLeft++;
				Rectangulator.UpdateTransformationParameters();
				ReqRefresh = true;
			}
			break;
		case Keys.F6:
			if (down && Rectangulator != null) {
				Rectangulator.OffsetLeft--;
				Rectangulator.UpdateTransformationParameters();
				ReqRefresh = true;
			}
			break;
		case Keys.F7:
			if (down && Rectangulator != null) {
				Rectangulator.ClipTop++;
				Rectangulator.UpdateTransformationParameters();
				ReqRefresh = true;
			}
			break;
		case Keys.F8:
			if (down && Rectangulator != null) {
				Rectangulator.ClipTop--;
				Rectangulator.UpdateTransformationParameters();
				ReqRefresh = true;
			}
			break;
		}
	}

	private void UpdatePaddles() {
		for (int i=0; i < 4; i++) {
			int ohms = PaddleOhms[i];
			ohms += 16384*PaddleVels[i];
			if (ohms < InputAdapter.PADDLEOHM_MIN)
				ohms = InputAdapter.PADDLEOHM_MIN;
			if (ohms > InputAdapter.PADDLEOHM_MAX)
				ohms = InputAdapter.PADDLEOHM_MAX;
			PaddleOhms[i] = ohms;
			M.InputAdapter.SetOhms(i, ohms);
		}
	}

	private void ShowTextMsg() {
		TextBrush.Color = Color.White;
		RGraphics.TextRenderingHint = TextRenderingHint.SystemDefault;
		RGraphics.DrawString(TextMsg, TextFont, TextBrush, new PointF(0.0f, 0.0f));
	}

	private void ClearTextMsg() {
		TextBrush.Color = Color.Black;
		RGraphics.FillRectangle(TextBrush, 0, 0, ClientSize.Width, 30);
	}

	private void OnLayout(object sender, LayoutEventArgs e) {
		RGraphics = CreateGraphics();
		RGraphics.CompositingMode = CompositingMode.SourceCopy;
		RGraphics.CompositingQuality = CompositingQuality.Invalid;
		RGraphics.SmoothingMode = SmoothingMode.None;
		RGraphics.InterpolationMode = InterpolationMode.NearestNeighbor;

		if (Rectangulator != null) {
			Rectangulator.ViewPortSize = ClientSize;
			Rectangulator.UpdateTransformationParameters();
		}
		ReqRefresh = true;
	}

	private void OnPaint(object sender, PaintEventArgs e) {
		ReqRefresh = true;
	}

	public void UpdateDisplay(byte[] buf, int scanline, int xstart, int len) {
		if (Rectangulator != null) {
			Rectangulator.InputScanline(buf, scanline, xstart, len);
		} else {
			int i = scanline*VisiblePitch + xstart;
			int x = xstart;
			while (len-- > 0) {
				FrameBuffer[i++] = (uint)M.Palette[buf[x++]] | (uint)0xff000000;
			}
		}
	}

	private void OnUpdateRect(DisplRect r) {
		SBrush.Color = Color.FromArgb(r.Argb);
		RGraphics.FillRectangle(SBrush, r.Rectangle);
	}

	private void OnUpdateFrame(uint[] fb) {
		BitmapData d = FrameBitmap.LockBits(
			new Rectangle(new Point(), FrameBitmap.Size),
			ImageLockMode.WriteOnly,
			FrameBitmap.PixelFormat);
		unsafe {
			uint *tptr = (uint *)d.Scan0.ToPointer();
			for (int i=0; i < fb.Length; i++) {
				*tptr++ = fb[i];
			}
		}
		FrameBitmap.UnlockBits(d);

		RGraphics.DrawImage(FrameBitmap, 0, 0, 320, 240);
	}

	public void UpdateSound(byte[] buf) {
		if (Mute) {
			for (int i=0; i < buf.Length; i++) {
				buf[i] = 0;
			}
		}
Audio.winmmEnqueueAndWait(buf);
//Audio.sdlEnqueueAndWait(buf);
	}
}
}