/*
 * GreenScreen.cs
 * 
 * A ControlPanelTabPage extension that provides a command line interface.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */

using System;
using System.Collections;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace EMU7800 {

public class GreenScreenPage : ControlPanelTabPage {
	private ControlPanelForm ControlPanelForm;

	private Label label1, label2;
	private TextBox outBox;
	private TextBox inpBox;
	
	public override void ClearChanges() {
		Log.StartLogger();
		inpBox.Text = null;
		inpBox.Focus();
	}

	public override void ApplyChanges() {
		IssueInpBoxCommand();
	}

	public GreenScreenPage(ControlPanelForm controlPanelForm) {
		ControlPanelForm = controlPanelForm;
	
		Text = "Green Screen";

		label2 = new Label();
		label2.Text = "Command-line Input";

		inpBox = new TextBox();
		inpBox.Text ="";
		inpBox.BackColor = System.Drawing.SystemColors.ControlText;
		inpBox.ForeColor = Color.Lime;
		inpBox.Font = new Font("Lucida Sans Typewriter", 10F,
			FontStyle.Regular, GraphicsUnit.Point, ((System.Byte)(0))); 
		inpBox.Multiline = false;
		inpBox.AcceptsReturn = true;
		inpBox.AcceptsTab = true;
		inpBox.KeyPress += new KeyPressEventHandler(OnKeyPress);
		inpBox.TextChanged += new EventHandler(OnTextChanged);
		inpBox.TabStop = true;
		inpBox.TabIndex = 0;

		label1 = new Label();
		label1.Text = "Output Message Log";
		
		outBox = new TextBox();
		outBox.Text = "";
		outBox.Multiline = true;
		outBox.ScrollBars = ScrollBars.Both;
		outBox.ReadOnly = true;
		outBox.AcceptsTab = false;
		outBox.WordWrap = false;
		outBox.BackColor = System.Drawing.SystemColors.ControlText;
		outBox.ForeColor = Color.Lime;
		outBox.Font = inpBox.Font;
		outBox.TabStop = false;

		Log.LogUpdated += new LogUpdatedHandler(OnLogUpdated);
				
		Controls.AddRange(new Control[] {label1, outBox, label2, inpBox});

		Layout += new LayoutEventHandler(OnLayout);
	}

	private void OnLogUpdated(string msgs) {
		outBox.AppendText(msgs);
	}

	private void OnLayout(Object sender, LayoutEventArgs e) {
		int w = Size.Width - 30;

		label1.Location = new Point(15, 10);
		label1.Size = new Size(w, label1.PreferredHeight);

		outBox.Location = new Point(15,
			label1.Location.Y + label1.Size.Height + 2);
		outBox.Size = new Size(w, Size.Height - 90);

		label2.Location = new Point(15,
			outBox.Location.Y + outBox.Size.Height + 5);
		label2.Size = new Size(w, label2.PreferredHeight);

		inpBox.Location = new Point(15,
			label2.Location.Y + label2.Size.Height + 2);
		inpBox.Size = new Size(w, 35);
	}
	
	private void OnKeyPress(Object sender, KeyPressEventArgs e) {
		if (e.KeyChar == (char)13) {
         		e.Handled = true;
			IssueInpBoxCommand();
   		}
	}

	private void OnTextChanged(Object sender, EventArgs e) {
		if (inpBox.Text.Length > 0) {
			ControlPanelForm.ApplyButtonEnabled = true;
		} else {
			ControlPanelForm.ApplyButtonEnabled = false;
		}
	}

	private void IssueInpBoxCommand() {
		Log.Msg(">{0}\n", inpBox.Text);
		ExecuteTokenList(new TokenList(inpBox.Text));
		inpBox.Text = "";
		inpBox.Focus();
	}

	private void ExecuteTokenList(TokenList tokenList) {		Machine m = ControlPanelForm.Host.GetMachine();		InputAdapter ia = m.InputAdapter;		switch (tokenList.LookAhead.Symbol) {
		case "clear":
			outBox.Clear();
			Log.Msg("log cleared\n");
			break;
		case "fps":
			DoFPS(tokenList);
			break;
		case "gs":
			Log.Msg(ControlPanelForm.CurrGameSettings.ToString() + "\n");
			break;
		case "outdir":
			tokenList.GetNextToken();
			if (!tokenList.LookAhead.EOL) {
				Globals.OutputDirectory = tokenList.GetNextToken().Symbol;
			}
			Log.Msg("outdir:\n{0}\n", Globals.OutputDirectory);
			break;
		case "ls":
			Log.Msg("Files in outdir:\n");
                        FileInfo[] files;
			try {
				files = new DirectoryInfo(Globals.OutputDirectory).GetFiles();
			} catch (DirectoryNotFoundException) {
				Log.Msg("Directory {0} does not exist\n", Globals.OutputDirectory);
				break;
			}
			foreach (FileInfo fi in files) {
				Log.Msg("{0} {1}k\n", fi.Name.PadRight(25, ' '),
					fi.Length/1024);
			}
			break;
		case "record":
			tokenList.GetNextToken();
			if (tokenList.LookAhead.EOL) {
				break;
			}
			DoRecord(tokenList.GetNextToken().Symbol);
			break;
		case "playback":
		case "replay":
			tokenList.GetNextToken();
			if (tokenList.LookAhead.EOL) {
				break;
			}
			DoPlayback(tokenList.GetNextToken().Symbol);
			break;
		case "stoprecording":
			try {
				((RecordPlaybackInputAdapter)ia).StopRecording();
			} catch {}
			break;
		case "stopplayback":
			try {
				((RecordPlaybackInputAdapter)ia).StopPlayback();
			} catch {}
			break;
		case "opacity":
			tokenList.GetNextToken();
			try {
				int op = Int32.Parse(tokenList.GetNextToken().Symbol);
				if (op > 100) {
					op = 100;
				} else if (op < 25) {
					op = 25;
				}
				ControlPanelForm.Opacity = (double)op/100.0;
				Globals.Opacity = ControlPanelForm.Opacity;
				Log.Msg("Opacity set to {0}%\n", op);
			} catch {
				Log.Msg("bad opacity parm\n");			
			}
			break;
		case "sound":
			tokenList.GetNextToken();
			if (tokenList.LookAhead.Symbol == "on") {
				Globals.SoundOn = true;
			} else if (tokenList.LookAhead.Symbol == "off") {
				Globals.SoundOn = false;
			}
		 	Log.Msg("sound {0}\n", Globals.SoundOn ? "on" : "off");
			Log.Msg("setting change will take effect at next ROM install\n");
			break;
		case "help":
		case "h":
		case "?":
			m.ExecuteTokenList(tokenList);
			Log.Msg("** Emulator Commands **\n"
				+ " ?: this help menu\n"
				+ " clear: clear log messages (64k limit)\n"
				+ " fps [rate]: adj. frames per second\n"
				+ " gs: show game settings\n"
				+ " outdir [newdir]: show/update output directory\n"
				+ " ls: show files in outdir\n"
				+ " record [filen]: start recording input\n"
				+ " playback [filen]: playback recording\n"
				+ " stoprecording\n"
				+ " stopplayback\n"
				+ " opacity [50-100]%\n"
				+ " sound [on/off]\n");
			break;
		case null:
			break;
		default:
			if (!m.ExecuteTokenList(tokenList)) {
				Log.Msg("unrecognized command\n");
			}
			break;
		}
	}

	private void DoFPS(TokenList tokenList) {
		tokenList.GetNextToken();
		Token token = tokenList.GetNextToken();

		Machine m = ControlPanelForm.Host.GetMachine();

		if (token.EOL) {
			Log.Msg("FPS is {0}\n", m.FrameHZ);
		} else if (!token.IsNumber) {
			Log.Msg("bad parameter\n");
		} else {
			m.FrameHZ = token.Number;
			Log.Msg("set FPS to {0}\n", m.FrameHZ);
		}
		return;
	}

	private void DoRecord(string fn) {
		GameSettings gs = ControlPanelForm.CurrGameSettings;
		Cart c = Cart.New(gs);
		InputAdapter ia = new RecordPlaybackInputAdapter(fn, gs.SaveKey);
		Machine m = Machine.New(gs, c, ia);
		if (m != null) {
			ControlPanelForm.Host.InstallMachine(m);
		}
	}

	private void DoPlayback(string fn) {
		RecordPlaybackInputAdapter ia = new RecordPlaybackInputAdapter(fn);
		GameSettings gs = GameSettings.New(ia.PlaybackSaveKey);
		if (gs != null) {
			Cart c = Cart.New(gs);
			Machine m = Machine.New(gs, c, ia);
			ControlPanelForm.Host.InstallMachine(m);
		}
	}
}
}