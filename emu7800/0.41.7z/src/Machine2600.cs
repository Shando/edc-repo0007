/*
 * Machine2600.cs
 * 
 * A realization of a 2600 machine.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */ 

using System;
using System.Drawing;
using System.IO;
using System.Text;

namespace EMU7800 {

public class Machine2600 : Machine {
	protected M6502 _CPU;	protected AddressSpace Mem;	protected PIA PIA;	protected TIA TIA;	protected IDevice NullDevice;

	public override M6502 CPU {
		get {
			return _CPU;
		}
	}

	protected override void DoReset() {
		TIA.Reset();
		PIA.Reset();
		CPU.Reset();
	}

	protected override void DoRun() {		TIA.StartFrame();		CPU.RunClocks = (Scanlines + 3)*76;		while (CPU.RunClocks > 0 && !CPU.Jammed) {			if (TIA.WSYNCDelayClocks > 0) {				CPU.Clock += (ulong)TIA.WSYNCDelayClocks/3;
				CPU.RunClocks -= TIA.WSYNCDelayClocks/3;
				TIA.WSYNCDelayClocks = 0;			}			if (TIA.EndOfFrame) {				break;			}			CPU.Execute();		}		TIA.EndFrame();	}

	public override bool ExecuteCommandLine(CommandLine cl) {
		switch (cl.Verb) {		case "d":
			if (cl.CheckParms("ii")) {
				Log.Msg(CPU.Disassembler.Disassemble(
					(ushort)cl.Parms[0].IntValue,
					(ushort)cl.Parms[1].IntValue)
					+ "\n");
			} else {
				Log.Msg("bad parms\n");
			}
			break;
		case "m":
			if (cl.CheckParms("ii")) {
				Log.Msg(CPU.Disassembler.MemDump(
					(ushort)cl.Parms[0].IntValue,
					(ushort)cl.Parms[1].IntValue)
					+ "\n");
			} else {
				Log.Msg("bad parms\n");
			}
			break;
		case "poke":
			if (cl.CheckParms("ii")) {
				Mem[(ushort)cl.Parms[0].IntValue] = (byte)cl.Parms[1].IntValue;
				Log.Msg("poke #${0:x2} at ${1:x4} complete\n",
					cl.Parms[0].IntValue,
					cl.Parms[1].IntValue);
			} else {
				Log.Msg("bad parms\n");
			}
			break;
		case "reset":
			Reset();
			break;
		case "r":
			Log.Msg(CPU.Disassembler.GetRegisters() + "\n");
			break;
		case "step":
			if (cl.Parms.Length > 0 && cl.Parms[0].IsInteger) {
				Step(cl.Parms[0].IntValue);
			} else {
				Log.Msg("malformed step command");
			}
			break;
		case "help":
		case "h":
		case "?":
			Log.Msg("** Machine Specific Commands **\n"			+ " d [ataddr] [toaddr]: disassemble\n"			+ " m [ataddr] [toaddr]: memory dump\n"			+ " p [ataddr] [data]: poke\n"			+ " r: display CPU registers\n"			+ " step [#]: step CPU execution\n"			+ " reset: reset CPU\n");			break;
		default:
			return false;
		}
		return true;
	}

	public Machine2600(Cart c, InputAdapter ia, int slines, int startl, int fHZ, int sRate, int[] p)
			: base (ia, slines, startl, fHZ, sRate, p) {

		Mem = new AddressSpace(this, 13, 6);  // 2600: 13bit, 64byte pages		_CPU = new M6502(Mem);		TIA = new TIA(this);		for (ushort i=0; i < 0x1000; i += 0x100) {
			Mem.Map(i, 0x0080, TIA);
		}		PIA = new PIA(this);		for (ushort i=0x0080; i < 0x1000; i += 0x100) {
			Mem.Map(i, 0x0080, PIA);
		}		Mem.Map(0x1000, 0x1000, c);
	}

	private void Step(int steps) {
		StringBuilder sb = new StringBuilder();

		sb.Append(CPU.Disassembler.Disassemble(CPU.PC, (ushort)(CPU.PC+1)));
		sb.Append(CPU.Disassembler.GetRegisters());
		sb.Append("\n");
		for (int i=0; i < steps; i++) {
			CPU.RunClocks = 2;
			CPU.Execute();
			sb.Append(CPU.Disassembler.Disassemble(CPU.PC, (ushort)(CPU.PC+1)));
			sb.Append(CPU.Disassembler.GetRegisters());
			sb.Append("\n");
		}
		Log.Msg(sb.ToString() + "\n");
	}
}

public class Machine2600NTSC : Machine2600 {
	public override string ToString() {
		return MachineType.A2600NTSC.ToString();
	}

	public Machine2600NTSC(Cart cart, InputAdapter ia)
			: base(cart, ia, 262, 16, 60, TIASound.NTSC_SAMPLES_PER_SEC, TIATables.NTSCPalette) {
		Log.Msg("{0} ready\n", this);
	}
}

public class Machine2600PAL : Machine2600 {
	public override string ToString() {
		return MachineType.A2600PAL.ToString();
	}

	public Machine2600PAL(Cart cart, InputAdapter ia)
			: base(cart, ia, 312, 32, 50, TIASound.PAL_SAMPLES_PER_SEC, TIATables.PALPalette) {
		Log.Msg("{0} ready\n", this);
	}
}
}
