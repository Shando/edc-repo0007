/* $Header: /winc/emuiil/source/version.h,v 1.3 2003/06/30 19:28:37 dosius Exp $ */

/*
 * $Log: version.h,v $
 * Revision 1.3  2003/06/30 19:28:37  dosius
 * Integrated HP's changes to all files.
 *
 * Revision 1.1  2003/06/25 18:33:08  dosius
 * Initial revision
 *
 */

/* Version information to be included in DAPPLE.C and ROM.C */

#define DappleVersion "0.31"
