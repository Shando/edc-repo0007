
		Project Tempest v0.3 (31 October 2002)
		---------------------------------------


What is Project Tempest ?
-------------------------

Project Tempest is worlds first working Atari Jaguar emulator. It currently runs several
commercial games.


What is emulated ?
------------------

MC68000:    	Completely. Using Turbo68K by Bart Trzynadlowski

GPU: 	    	All the opcodes are emulated.

DSP:	    	Most of the opcodes are emulated. Sound output is not implemented.

Object Processor: 	Everything is emulated, except 32-bit objects.

Blitter:		Z-Buffering and some operations missing.


System Requirements
--------------------

Pentium III/Athlon 800+ MHz
128MB RAM
DirectX 8.0 or higher
Windows 9x/ME/2000/XP

A faster processor is seriously recommended !

What's New IN Version 0.3
--------------------------

* Alien vs. Predator is now playable !
* More Blitter tweaking
* Fixed some OP bugs (black text in Cannon Fodder)
* Removed Boot ROM options from settings screen


How to use the emulator
------------------------

To load commercial games, select Open ROM from File menu. To start the game, press F2 or Start from
emulation menu.

To load homebrewn games and demos, select Open BIN from File menu. Write the addresses required and
press F2 or Start from emulation menu.

To stop the emulation, press F3 or Stop from emulation menu.

Press ESC key switch between fullscreen and windowed mode.


Settings
--------

Disable DSP Emulation: 	This should usually be enabled. Only some games require DSP to be emulated.
		 	Doom requires DSP emulation !

Line-based renderer:	More accurate emulation of Object Processor. Maybe a little slower but it's
			suggested to enable it.

Blitter:			Select Blitter emulator. Original Blitter is the one from earlier versions.
			New is newer Blitter emulator. It's a bit slower than Original but more compatible.
			If games are crashing try enabling the new blitter !


Controls
--------

Keyboard and DirectInput-compatible game controllers are supported.
Use Controller/Joypad 1/2 to configure controllers

Enable Joypad in Joypad screen enables the corresponding Jaguar joypad.

Also in Pinball Fantasies, Shifts and Ctrls are mapped as the flipper keys.


Credits
-------

Emulator programming by Ville Linde

Website and support by The Fox (emuunlim@emuunlim.com)
Website design by Malc Jennings


Contact Information
-------------------

Website:	  http://pt.emuunlim.com
E-Mail:	  ptemu@emuunlim.com

