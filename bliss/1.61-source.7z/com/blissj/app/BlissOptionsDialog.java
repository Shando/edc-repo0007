package com.blissj.app;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.*;
import javax.swing.*;
import javax.swing.event.*;
import com.bliss.core.*;
import com.bliss.core.devices.PlugIn;
import com.bliss.core.devices.InputDevice;
import com.bliss.core.devices.InputSignal;

public class BlissOptionsDialog extends JDialog
{

    public BlissOptionsDialog(BlissMainFrame frame, Intellivision inty) {
        super(frame);
        this.inty = inty;
        this.player1 = inty.getHandControllerOne();
        this.player2 = inty.getHandControllerTwo();
        this.keyboard = inty.getECSKeyboard();
        initUI();
        initListeners();
    }

    private void initUI() {
        setTitle(Bliss.RESOURCES.getString("OptionsDialogTitle"));
        setResizable(false);
        setModal(true);
        Container contentPane = getContentPane();
        contentPane.setLayout(new GridBagLayout());

        tabbedPane = new JTabbedPane();
        reinitConstraints(gbc);
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.ipadx = 50;
        gbc.ipady = 60;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(8, 8, 8, 8);
        contentPane.add(tabbedPane, gbc);

        //GENERAL PANEL
        generalPanel = new JPanel();
        generalPanel.setLayout(new GridBagLayout());
        tabbedPane.addTab(Bliss.RESOURCES.getString("GeneralTab"),
                generalPanel);

        cartDirLabel = new JLabel(Bliss.RESOURCES.getString(
                "CartridgeDirectoryLabel") + ":");
        reinitConstraints(gbc);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(12, 12, 8, 8);
        generalPanel.add(cartDirLabel, gbc);

        cartDirField = new JTextField();
        cartDirField.setColumns(20);
        reinitConstraints(gbc);
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(12, 0, 8, 12);
        generalPanel.add(cartDirField, gbc);

        cartDirBrowseButton = new JButton(Bliss.RESOURCES.getString(
                "BrowseButton") + "...");
        reinitConstraints(gbc);
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(0, 12, 12, 12);
        generalPanel.add(cartDirBrowseButton, gbc);

        JPanel strut = new JPanel();
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.weighty = 1.0;
        generalPanel.add(strut, gbc);

        //VIDEO PANEL
        videoPanel = new JPanel();
        videoPanel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        videoPanel.setLayout(new GridBagLayout());
        tabbedPane.addTab(Bliss.RESOURCES.getString("VideoTab"), videoPanel);

        //SOUND PANEL
        audioPanel = new JPanel();
        audioPanel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        audioPanel.setLayout(new GridBagLayout());
        tabbedPane.addTab(Bliss.RESOURCES.getString("SoundTab"), audioPanel);

        //INPUT PANEL
        inputPanel = new JPanel();
        inputPanel.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        inputPanel.setLayout(new GridBagLayout());

        //just for packing reasons, the input panel must be initialized
        initInputPanel();

        tabbedPane.addTab(Bliss.RESOURCES.getString("InputTab"), inputPanel);

        //BUTTON PANEL
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridBagLayout());
        reinitConstraints(gbc);
        gbc.gridy = 1;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(0, 8, 8, 8);
        contentPane.add(buttonPanel, gbc);

        okButton = new JButton(Bliss.RESOURCES.getString("OKButton"));
        reinitConstraints(gbc);
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(0, 0, 0, 8);
        buttonPanel.add(okButton, gbc);

        cancelButton = new JButton(Bliss.RESOURCES.getString("CancelButton"));
        reinitConstraints(gbc);
        buttonPanel.add(cancelButton, gbc);

        //make the OK button and Cancel buttons the same width
        Dimension d1 = okButton.getPreferredSize();
        Dimension d2 = cancelButton.getPreferredSize();
        int width = Math.max(d1.width, d2.width);
        okButton.setPreferredSize(new Dimension(width, d1.height));
        cancelButton.setPreferredSize(new Dimension(width, d2.height));

        pack();

        //init the dialogs
        browseDialog = new JFileChooser();
        browseDialog.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        configInputDialog = new BlissConfigureInputDialog((Frame)getOwner());
    }

    private void initListeners() {
        tabbedPane.addChangeListener(new ChangeListener() {
                public void stateChanged(ChangeEvent ce) {
                    Component component = tabbedPane.getSelectedComponent();
                    if (component == videoPanel && !videoPanelCreated) {
                        initVideoPanel();
                        if (audioPanelCreated && inputPanelCreated)
                            tabbedPane.removeChangeListener(this);
                    }
                    else if (component == audioPanel && !audioPanelCreated) {
                        initAudioPanel();
                        if (videoPanelCreated && inputPanelCreated)
                            tabbedPane.removeChangeListener(this);
                    }
                    else if (component == inputPanel && !inputPanelCreated) {
                        initInputPanel();
                        if (videoPanelCreated && audioPanelCreated)
                            tabbedPane.removeChangeListener(this);
                    }
                }
            });
        cartDirBrowseButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    File currentDir = (new File(cartDirField.getText().trim())).
                        getAbsoluteFile();
                    if (currentDir.exists() && currentDir.isDirectory()) {
                        File parentDir = currentDir.getParentFile();
                        if (parentDir != null)
                            browseDialog.setSelectedFile(currentDir);
                        else
                            browseDialog.setCurrentDirectory(currentDir);
                    }
                    int result = browseDialog.showDialog(
                            BlissOptionsDialog.this,
                            Bliss.RESOURCES.getString("SelectDirectoryButton"));
                    if (result != JFileChooser.APPROVE_OPTION)
                        return;

                    File selectedFile = browseDialog.getSelectedFile();
                    cartDirField.setText(selectedFile.getAbsolutePath());
                }
            });
        okButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    if (!assertValidConfig())
                        return;

                    commitConfig();
                    dispose();
                }
            });
        cancelButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    dispose();
                }
            });
        addComponentListener(new ComponentAdapter() {
                public void componentShown(ComponentEvent ce) {
                    tabbedPane.setSelectedIndex(0);
                    refresh();
                }
            });
    }

    private void initVideoPanel() {
        //create editors for each of the options that are specific to the
        //plug-in we'll be using
        Option[] videoOptions = inty.getVideoOptions();
        videoEditors = new OptionEditor[videoOptions.length];
        reinitConstraints(gbc);
        gbc.anchor = GridBagConstraints.WEST;
        for (int i = 0; i < videoEditors.length; i++) {
            JLabel nextLabel;
            JComponent nextEditor;
            if (videoOptions[i] instanceof BooleanOption) {
                nextLabel = new JLabel();
                videoEditors[i] = new BooleanOptionCheckBox(
                        (BooleanOption)videoOptions[i]);
                nextEditor = (JCheckBox)videoEditors[i];
            }
            else {
                nextLabel = new JLabel(videoOptions[i].getDescription() +
                        ":");
                videoEditors[i] = new ChoiceOptionComboBoxModel(
                        (ChoiceOption)videoOptions[i]);
                nextEditor = new JComboBox((ComboBoxModel)videoEditors[i]);
            }
            gbc.gridy = i + 2;
            gbc.weightx = 0.0;
            gbc.insets = new Insets(4, 0, 4, 8);
            videoPanel.add(nextLabel, gbc);

            gbc.weightx = 1.0;
            gbc.insets = new Insets(4, 0, 4, 0);
            videoPanel.add(nextEditor, gbc);
        }
 
        JPanel strut = new JPanel();
        gbc.gridy = videoEditors.length+2;
        gbc.gridwidth = 2;
        gbc.weighty = 1.0;
        videoPanel.add(strut, gbc);

        //load the video options
        for (int i = 0; i < videoEditors.length; i++)
            videoEditors[i].reloadOption();

        videoPanelCreated = true;
    }

    private void initAudioPanel() {
        //create editors for each of the options that are specific to the
        //plug-in we'll be using
        Option[] audioOptions = inty.getAudioOptions();
        audioEditors = new OptionEditor[audioOptions.length];
        reinitConstraints(gbc);
        gbc.anchor = GridBagConstraints.WEST;
        for (int i = 0; i < audioOptions.length; i++) {
            JLabel nextLabel;
            JComponent nextEditor;
            if (audioOptions[i] instanceof BooleanOption) {
                nextLabel = new JLabel();
                audioEditors[i] = new BooleanOptionCheckBox(
                        (BooleanOption)audioOptions[i]);
                nextEditor = (JCheckBox)audioEditors[i];
            }
            else {
                nextLabel = new JLabel(audioOptions[i].getDescription() + ":");
                audioEditors[i] = new ChoiceOptionComboBoxModel(
                        (ChoiceOption)audioOptions[i]);
                nextEditor = new JComboBox((ComboBoxModel)audioEditors[i]);
            }
            gbc.gridy = i + 2;
            gbc.weightx = 0.0;
            gbc.insets = new Insets(4, 0, 4, 8);
            audioPanel.add(nextLabel, gbc);

            gbc.weightx = 1.0;
            gbc.insets = new Insets(4, 0, 4, 0);
            audioPanel.add(nextEditor, gbc);
        }
 
        JPanel strut = new JPanel();
        gbc.gridy = audioEditors.length+2;
        gbc.gridwidth = 2;
        gbc.weighty = 1.0;
        audioPanel.add(strut, gbc);

        //load the audio options
        for (int i = 0; i < audioEditors.length; i++)
            audioEditors[i].reloadOption();

        audioPanelCreated = true;
    }

    private void initInputPanel() {
        JPanel separatorPanel = new JPanel();
        separatorPanel.setLayout(new GridBagLayout());

        player1Label = new JLabel(Bliss.RESOURCES.getString(
                "LeftControllerLabel"));
        reinitConstraints(gbc);
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 0, 0, 8);
        separatorPanel.add(player1Label, gbc);
        
        player1Separator = new JSeparator();
        reinitConstraints(gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        separatorPanel.add(player1Separator, gbc);

        reinitConstraints(gbc);
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 8, 0);
        inputPanel.add(separatorPanel, gbc);

        ClassLoader loader = getClass().getClassLoader();
        ImageIcon icon = new ImageIcon(loader.getResource(
                "com/blissj/app/images/leftcontroller.gif"));
        player1Icon = new JLabel(icon);
        reinitConstraints(gbc);
        gbc.gridx = 0;
        gbc.gridheight = 2;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.insets = new Insets(0, 0, 8, 8);
        inputPanel.add(player1Icon, gbc);

        player1Description = new JTextArea(Bliss.RESOURCES.
                getString("LeftControllerDescription"));
        player1Description.setEditable(false);
        player1Description.setLineWrap(true);
        player1Description.setWrapStyleWord(true);
        player1Description.setBorder(null);
        player1Description.setBackground(null);
        reinitConstraints(gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 8, 0);
        inputPanel.add(player1Description, gbc);

        player1ConfigButton = new JButton(Bliss.RESOURCES.
                getString("ConfigureButton") + "...");
        reinitConstraints(gbc);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(0, 0, 8, 0);
        inputPanel.add(player1ConfigButton, gbc);
        
        
        separatorPanel = new JPanel();
        separatorPanel.setLayout(new GridBagLayout());

        player2Label = new JLabel(Bliss.RESOURCES.getString(
                "RightControllerLabel"));
        reinitConstraints(gbc);
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 0, 0, 8);
        separatorPanel.add(player2Label, gbc);
        
        player2Separator = new JSeparator();
        reinitConstraints(gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        separatorPanel.add(player2Separator, gbc);

        reinitConstraints(gbc);
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 8, 0);
        inputPanel.add(separatorPanel, gbc);

        loader = getClass().getClassLoader();
        icon = new ImageIcon(loader.getResource(
                "com/blissj/app/images/rightcontroller.gif"));
        player2Icon = new JLabel(icon);
        reinitConstraints(gbc);
        gbc.gridx = 0;
        gbc.gridheight = 2;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.insets = new Insets(0, 0, 8, 8);
        inputPanel.add(player2Icon, gbc);
        
        player2Description = new JTextArea(Bliss.RESOURCES.
                getString("RightControllerDescription"));
        player2Description.setEditable(false);
        player2Description.setLineWrap(true);
        player2Description.setWrapStyleWord(true);
        player2Description.setBorder(null);
        player2Description.setBackground(null);
        reinitConstraints(gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 8, 0);
        inputPanel.add(player2Description, gbc);
        
        player2ConfigButton = new JButton(Bliss.RESOURCES.
                getString("ConfigureButton") + "...");
        reinitConstraints(gbc);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(0, 0, 8, 0);
        inputPanel.add(player2ConfigButton, gbc);
       
        separatorPanel = new JPanel();
        separatorPanel.setLayout(new GridBagLayout());

        ECSLabel = new JLabel(Bliss.RESOURCES.getString("ECSKeyboardLabel"));
        reinitConstraints(gbc);
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 0, 0, 8);
        separatorPanel.add(ECSLabel, gbc);
        
        ECSSeparator = new JSeparator();
        reinitConstraints(gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        separatorPanel.add(ECSSeparator, gbc);

        reinitConstraints(gbc);
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 8, 0);
        inputPanel.add(separatorPanel, gbc);

        loader = getClass().getClassLoader();
        icon = new ImageIcon(loader.getResource(
                "com/blissj/app/images/ecskeyboard.gif"));
        ECSIcon = new JLabel(icon);
        reinitConstraints(gbc);
        gbc.gridx = 0;
        gbc.gridheight = 2;
        gbc.anchor = GridBagConstraints.NORTH;
        gbc.insets = new Insets(0, 8, 8, 8);
        inputPanel.add(ECSIcon, gbc);

        ECSDescription = new JTextArea(Bliss.RESOURCES.
                getString("ECSKeyboardDescription"));
        ECSDescription.setEditable(false);
        ECSDescription.setLineWrap(true);
        ECSDescription.setWrapStyleWord(true);
        ECSDescription.setBorder(null);
        ECSDescription.setBackground(null);
        reinitConstraints(gbc);
        gbc.gridx = 1;
        gbc.weightx = 1.0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 8, 0);
        inputPanel.add(ECSDescription, gbc);
        
        ECSConfigButton = new JButton(Bliss.RESOURCES.
                getString("ConfigureButton") + "...");
        reinitConstraints(gbc);
        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(0, 0, 8, 0);
        inputPanel.add(ECSConfigButton, gbc);

        JPanel strut = new JPanel();
        reinitConstraints(gbc);
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.weighty = 1.0;
        inputPanel.add(strut, gbc);

        //add the new listeners
        player1ConfigButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    BlissUtilities.centerWindowOverParent(configInputDialog,
                            25, 10);
                    configInputDialog.configureInput(Bliss.RESOURCES.
                            getString("LeftControllerConfigureInputDialogTitle"),
                            BlissConfig.KEY_INPUT_LEFT_CONTROLLER,
                            inty.getPlugIn().getInputDevice(),
                            player1);
                }
            });
        player2ConfigButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    BlissUtilities.centerWindowOverParent(configInputDialog,
                            20, 10);
                    configInputDialog.configureInput(Bliss.RESOURCES.
                            getString("RightControllerConfigureInputDialogTitle"),
                            BlissConfig.KEY_INPUT_RIGHT_CONTROLLER,
                            inty.getPlugIn().getInputDevice(),
                            player2);
                }
            });
        ECSConfigButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    BlissUtilities.centerWindowOverParent(configInputDialog,
                            20, 10);
                    configInputDialog.configureInput(Bliss.RESOURCES.
                            getString("ECSKeyboardConfigureInputDialogTitle"),
                            BlissConfig.KEY_INPUT_ECS_KEYBOARD,
                            inty.getPlugIn().getInputDevice(),
                            keyboard);
                }
            });
        inputPanelCreated = true;
    }

    private static void reinitConstraints(GridBagConstraints gbc) {
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.NONE;
        gbc.insets.left = gbc.insets.right = 0;
        gbc.insets.top = gbc.insets.bottom = 0;
        gbc.gridx = GridBagConstraints.RELATIVE;
        gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.gridwidth = gbc.gridheight = 1;
        gbc.weightx = gbc.weighty = 0;
        gbc.ipadx = gbc.ipady = 0;
    }

    private void refresh() {
        //general options
        cartDirField.setText(Bliss.REGISTRY.getDataAsString(
                BlissConfig.KEY_GENERAL,
                BlissConfig.VALUE_CARTRIDGE_DIRECTORY,
                BlissConfig.DEFAULT_CARTRIDGE_DIRECTORY));

        if (videoPanelCreated) {
            //video options
            for (int i = 0; i < videoEditors.length; i++)
                videoEditors[i].reloadOption();
        }

        if (audioPanelCreated) {
            //audio options
            for (int i = 0; i < audioEditors.length; i++)
                audioEditors[i].reloadOption();
        }
    }

    private boolean assertValidConfig() {
        //general tab
        File file = new File(cartDirField.getText().trim());
        if (!file.exists()) {
            JOptionPane.showMessageDialog(this,
                    Bliss.RESOURCES.getString(
                        "ErrorCartridgeDirectoryDoesNotExist"),
                    Bliss.RESOURCES.getString("ErrorDialogTitle"),
                    JOptionPane.ERROR_MESSAGE);
            tabbedPane.setSelectedIndex(0);
            return false;
        }

        if (!file.isDirectory()) {
            JOptionPane.showMessageDialog(this,
                    Bliss.RESOURCES.getString(
                        "ErrorCartridgeDirectoryDoesNotExist"),
                    Bliss.RESOURCES.getString("ErrorDialogTitle"),
                    JOptionPane.ERROR_MESSAGE);
            tabbedPane.setSelectedIndex(0);
            return false;
        }

        return true;
    }

    private void commitConfig() {
        //general tab
        Bliss.REGISTRY.setData(BlissConfig.KEY_GENERAL,
                BlissConfig.VALUE_CARTRIDGE_DIRECTORY,
                cartDirField.getText().trim());

        if (videoPanelCreated) {
            //video tab
            for (int i = 0; i < videoEditors.length; i++)
                videoEditors[i].commitSelection();
        }

        if (audioPanelCreated) {
            //audio tab
            for (int i = 0; i < audioEditors.length; i++)
                audioEditors[i].commitSelection();
        }

        PlugIn plugin = inty.getPlugIn();
        InputDevice inputDevice = plugin.getInputDevice();
        String[] key = new String[BlissConfig.KEY_INPUT_LEFT_CONTROLLER.length+1];
        System.arraycopy(BlissConfig.KEY_INPUT_LEFT_CONTROLLER, 0, key, 0,
                key.length-1);
        key[key.length-1] = plugin.getPlugInName();

        //plugin options
        int end = player1.getControlCount();
        for (int i = 0; i < end; i++) {
            InputSignal nextSignal = inputDevice.getInputSignal(
                    player1.getControlID(i));
            Bliss.REGISTRY.setData(key, Integer.toString(i),
                    (nextSignal == null ? "" : nextSignal.getConfigString()));
        }

        System.arraycopy(BlissConfig.KEY_INPUT_RIGHT_CONTROLLER, 0, key, 0,
                key.length-1);
        end = player2.getControlCount();
        for (int i = 0; i < end; i++) {
            InputSignal nextSignal = inputDevice.getInputSignal(
                    player2.getControlID(i));
            Bliss.REGISTRY.setData(key, Integer.toString(i),
                    (nextSignal == null ? "" : nextSignal.getConfigString()));
        }

        System.arraycopy(BlissConfig.KEY_INPUT_ECS_KEYBOARD, 0, key, 0,
                key.length-1);
        end = keyboard.getControlCount();
        for (int i = 0; i < end; i++) {
            InputSignal nextSignal = inputDevice.getInputSignal(
                    keyboard.getControlID(i));
            Bliss.REGISTRY.setData(key, Integer.toString(i),
                    (nextSignal == null ? "" : nextSignal.getConfigString()));
        }
    }

    private Intellivision         inty;
    private HandController        player1;
    private HandController        player2;
    private ECSKeyboard           keyboard;

    //controller editors
    private OptionEditor[] videoEditors;
    private OptionEditor[] audioEditors;

    //dialogs
    private JFileChooser              browseDialog;
    private BlissConfigureInputDialog configInputDialog;

    //app components
    private GridBagConstraints gbc = new GridBagConstraints();
    private JTabbedPane     tabbedPane;
    private JPanel          generalPanel;
    private JLabel          cartDirLabel;
    private JTextField      cartDirField;
    private JButton         cartDirBrowseButton;
    private JPanel          videoPanel;
    private boolean         videoPanelCreated;
    private JPanel          audioPanel;
    private boolean         audioPanelCreated;
    private JPanel          inputPanel;
    private boolean         inputPanelCreated;
    private JLabel          player1Label;
    private JSeparator      player1Separator;
    private JLabel          player1Icon;
    private JTextArea       player1Description;
    private JButton         player1ConfigButton;
    private JLabel          player2Label;
    private JSeparator      player2Separator;
    private JLabel          player2Icon;
    private JTextArea       player2Description;
    private JButton         player2ConfigButton;
    private JLabel          ECSLabel;
    private JSeparator      ECSSeparator;
    private JLabel          ECSIcon;
    private JTextArea       ECSDescription;
    private JButton         ECSConfigButton;
    private JPanel          buttonPanel;
    private JButton         okButton;
    private JButton         cancelButton;

}
