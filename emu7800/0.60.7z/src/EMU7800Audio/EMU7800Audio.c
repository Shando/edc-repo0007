/*
 * EMU7800Audio.c
 *
 * Thunking .dll to audio functions of the Windows Multimedia API
 * and the SimpleDirect Media Layer (SDL).
 *
 * Copyright (c) 2004 Mike Murphy
 *
 */


#define DECLSPEC __declspec(dllexport)
#define CALL __cdecl

typedef unsigned char Uint8;


#include "windows.h"
#include "mmSystem.h"

static Uint8 *winmmStorage, *winmmStorageEnd;
static int winmmBufferSize;
static int winmmSoundFrameSize;
static HWAVEOUT winmmHWO;

extern DECLSPEC int CALL winmmOpen(int freq, int soundframesize, int queuelen)
{
	WAVEFORMATEX wf;
	int size;

	wf.wFormatTag = WAVE_FORMAT_PCM;
	wf.nChannels = 1;
	wf.wBitsPerSample = 8;
	wf.nSamplesPerSec = freq;
	wf.nAvgBytesPerSec = freq;
	wf.nBlockAlign = 1;
	wf.cbSize = 0;

	if (waveOutOpen(&winmmHWO, WAVE_MAPPER, &wf, 0, 0, CALLBACK_NULL) != 0) {
		return -1;
	}

	winmmSoundFrameSize = soundframesize;

	if (queuelen < 2) {
		queuelen = 2;
	} else if (queuelen > 16) {
		queuelen = 16;
	}

	winmmBufferSize = sizeof(WAVEHDR) + winmmSoundFrameSize;
	size = queuelen * winmmBufferSize;

	winmmStorage = (Uint8 *)malloc(size);
	winmmStorageEnd = winmmStorage + size;
	memset(winmmStorage, 0, size);

	return 0;
}

extern DECLSPEC void CALL winmmSetVolume(int left, int right)
{
	DWORD nVolume = left | right << 16;
	waveOutSetVolume(winmmHWO, nVolume);
}

extern DECLSPEC DWORD CALL winmmGetVolume(void)
{
	DWORD nVolume;
	waveOutGetVolume(winmmHWO, &nVolume);
	return nVolume;
}

extern DECLSPEC int CALL winmmEnqueue(Uint8 *stream, int len)
{
	WAVEHDR *WaveHdr;
	Uint8 *ptr;

	if (len != winmmSoundFrameSize) {
		return -1;  // bad enqueue request
	}

	for (ptr = winmmStorage; ptr < winmmStorageEnd; ptr += winmmBufferSize) {
		WaveHdr = (WAVEHDR *)ptr;
		if (WaveHdr->dwFlags == 0 || WaveHdr->dwFlags & WHDR_DONE) {
			waveOutUnprepareHeader(winmmHWO, WaveHdr, sizeof(WAVEHDR));
			WaveHdr->dwBufferLength = winmmSoundFrameSize;
			WaveHdr->dwFlags = 0;
			WaveHdr->lpData = (Uint8 *)WaveHdr + sizeof(WAVEHDR);
			waveOutPrepareHeader(winmmHWO, WaveHdr, sizeof(WAVEHDR));
			memcpy(WaveHdr->lpData, stream, winmmSoundFrameSize);
			waveOutWrite(winmmHWO, WaveHdr, sizeof(WAVEHDR));
			return 0;  // enqueue request complete
		}
	}

	return 1;  // full queue
}

extern DECLSPEC void CALL winmmClose()
{
	waveOutClose(winmmHWO);
	free(winmmStorage);
}


#include "sdl.h"
#include "sdl_audio.h"

static Uint8 *sdlStorage;
static int sdlSoundFrameSize, sdlQueueLen;
static int sdl_e, sdl_d, sdl_startflag;
static SDL_AudioSpec sdlAudioSpec;

static void _sdlDequeue(void *userdata, Uint8 *stream, int len)
{
	if (sdl_e == sdl_d) {
		// buffer underflow; write silence
		memset(stream, 0, len);
	} else {
		memcpy(stream, sdlStorage + sdl_d * sdlSoundFrameSize, len);
		sdl_d = (sdl_d + 1) % sdlQueueLen;
	}
}

extern DECLSPEC int CALL sdlOpen(int freq, int soundframesize, int queuelen) {
	sdlAudioSpec.freq = freq;
	sdlAudioSpec.format = AUDIO_U8;
	sdlAudioSpec.channels = 1;
	sdlAudioSpec.samples = soundframesize;
	sdlAudioSpec.callback = &_sdlDequeue;

	sdlSoundFrameSize = soundframesize;

	if (queuelen < 2) {
		sdlQueueLen = 2;
	} else if (queuelen > 16) {
		sdlQueueLen = 16;
	} else {
		sdlQueueLen = queuelen;
	}

	sdl_e = 0;
	sdl_d = 0;
	sdl_startflag = 1;

	sdlStorage = (Uint8 *)malloc(sdlQueueLen * sdlSoundFrameSize);
	memset(sdlStorage, 0, sdlQueueLen * sdlSoundFrameSize);

	return SDL_OpenAudio(&sdlAudioSpec, NULL);
}

extern DECLSPEC int CALL sdlEnqueue(Uint8 *stream, int len)
{
	int tmp_e, fullflag;

	if (len != sdlSoundFrameSize) {
		return -1;  // bad enqueue request
	}

	if (sdl_startflag) { // start sound after first enqueue after open
		SDL_PauseAudio(0);
		sdl_startflag = 0;
	}

	SDL_LockAudio();

	tmp_e = (sdl_e + 1) % sdlQueueLen;
	if (tmp_e == sdl_d) {
		fullflag = 1;  // full queue
	} else {
		memcpy(sdlStorage + sdl_e * sdlSoundFrameSize, stream, len);
		sdl_e = tmp_e;
		fullflag = 0;
	}

	SDL_UnlockAudio();

	return fullflag;  // enqueue request complete
}

extern DECLSPEC void CALL sdlClose()
{
	SDL_CloseAudio();
	free(sdlStorage);
}