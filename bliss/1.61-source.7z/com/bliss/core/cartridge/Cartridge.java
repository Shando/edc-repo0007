package com.bliss.core.cartridge;

import java.io.*;
import java.util.zip.*;
import com.bliss.core.*;
import com.bliss.core.devices.*;

public class Cartridge implements Peripheral
{

    public Cartridge(CartridgeType cartType, Memory[] memories) {
        this.cartType = cartType;
        this.memories = memories;
    }

    public void changePlugIn(PlugIn plugIn) {}

    public int getProcessorCount() {
        return 0;
    }

    public Processor getProcessor(int i) {
        return null;
    }

    public int getMemoryCount() {
        return memories.length;
    }

    public Memory getMemory(int i) {
        return memories[i];
    }

    public CartridgeType getType() {
        return cartType;
    }

    public boolean requiresECS() {
        return cartType.requiresECS();
    }

    public boolean usesIntellivoice() {
        return cartType.usesIntellivoice();
    }

    private CartridgeType   cartType;
    private Memory[]        memories;

    private static long getCrc(byte[] image) {
        CRC32 crc = new CRC32();
        crc.update(image, 0, image.length);
        return crc.getValue();
    }

    private static long getCrc(int[] image) {
        byte[] flatImage = new byte[image.length*2];
        for (int i = 0; i < image.length; i++) {
            flatImage[i<<1] = (byte)((image[i] & 0xFF00) >> 8);
            flatImage[(i<<1)+1] = (byte)(image[i] & 0x00FF);
        }
        CRC32 crc = new CRC32();
        crc.update(flatImage, 0, flatImage.length);
        return crc.getValue();
    }

    public static Cartridge loadCartridge(String resourceName)
            throws IOException
    {
        ClassLoader cl = Cartridge.class.getClassLoader();
        InputStream is;
        if (cl != null)
            is = cl.getResourceAsStream(resourceName);
        else
            is = ClassLoader.getSystemResourceAsStream(resourceName);

        BufferedInputStream bis = new BufferedInputStream(is, 4096);
        Cartridge cart = loadCartridge(bis);
        bis.close();
        return cart;
    }

    public static Cartridge loadCartridge(InputStream is) throws IOException {
        int[] image = ROM.loadROMImage(is, true);
        long crc = getCrc(image);
        CartridgeType cartType = CartridgeTypeFactory.getCartridgeType(crc);
        if (cartType == null)
            throw new IOException("Unknown cartridge type");
 
        CartridgeType.MemoryMap map = cartType.getMemoryMap();
        int segmentCount = map.getSegmentCount();
        Memory[] memories = new Memory[segmentCount];
        int nextOffset = 0;
        for (int i = 0; i < segmentCount; i++) {
            int segmentLocation = map.getSegmentLocation(i);
            if (segmentLocation == -8) {
               memories[i] = new RAM(map.getSegmentSize(i),
                       map.getSegmentStart(i), 8);
            }
            else if (segmentLocation == -16) {
               memories[i] = new RAM(map.getSegmentSize(i),
                       map.getSegmentStart(i), 16);
            }
            else {
                int[] nextImage = new int[map.getSegmentSize(i)];
                System.arraycopy(image, nextOffset, nextImage, 0,
                        map.getSegmentSize(i));
                nextOffset += map.getSegmentSize(i);
                memories[i] = new ROM(nextImage, map.getSegmentLocation(i),
                        map.getSegmentBank(i));
            }
        }
        return new Cartridge(cartType, memories);
    }

    public static Cartridge loadCartridge(CartridgeFile cartFile)
            throws IOException
    {
        File file = cartFile.getFile();
        BufferedInputStream bis;
        if (file.getName().toLowerCase().endsWith(".zip")) {
            ZipFile zipFile = new ZipFile(file);
            ZipEntry zipEntry = zipFile.getEntry(cartFile.getZipEntryName());
            bis = new BufferedInputStream(zipFile.getInputStream(zipEntry),
                    4096);
        }
        else
            bis = new BufferedInputStream(new FileInputStream(file), 4096);

        CartridgeType.MemoryMap map = cartFile.getType().getMemoryMap();
        int segmentCount = map.getSegmentCount();
        Memory[] memories = new Memory[segmentCount];
        for (int i = 0; i < segmentCount; i++) {
            int segmentLocation = map.getSegmentLocation(i);
            if (segmentLocation == -8) {
               memories[i] = new RAM(map.getSegmentSize(i),
                       map.getSegmentStart(i), 8);
            }
            else if (segmentLocation == -16) {
               memories[i] = new RAM(map.getSegmentSize(i),
                       map.getSegmentStart(i), 16);
            }
            else {
                int[] nextImage = new int[map.getSegmentSize(i)];
                for (int j = 0; j < nextImage.length; j++) {
                    int highByte = bis.read();
                    int lowByte = bis.read();
                    nextImage[j] = (highByte << 8) | lowByte;
                }
                memories[i] = new ROM(nextImage, map.getSegmentLocation(i),
                        map.getSegmentBank(i));
            }
        }
        bis.close();
        return new Cartridge(cartFile.getType(), memories);
    }


}
