unsigned char *mgettext(unsigned char *key);


#define _N(a) mgettext(a) 
