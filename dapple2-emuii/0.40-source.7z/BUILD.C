/*
 * EMU][ Apple ][-class emulator
 * Copyright (C) 2002- 2004 by the EMU][ Project/Dapple ][ Team
 *
 * Component:  Build: lots of include intruction to build the final emu2.exe
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 2.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *  Current exception for ASMLIB.O linkage, if Z80.C is not used
 *
 * 20040428  New headers generated for v0.4 release
 *           Z80 core development
 *
 */



/*----------------------------------------

Use this file to compile the whole source
in one go without an additional make file.
Just make sure that you link the resulting
object code with the asmlib.o to receive
the final executable.

----------------------------------------*/

#include "dapple.h"
#include "..\libs\general.c"
#ifdef CPU_CYCLEEXACT
#include "..\libs\raf.c"
#include "cpu6502.c"
#endif
#include "cpu65c02.c"
#include "dapple.c"
#include "disk.c"
#include "gui.c"
#include "ini.c"
#include "lldisk.c"
#include "memory.c"
#include "mkbmp.c"
#include "mouse.c"
#include "pic.c"
#include "rom.c"
#include "video.c"
#ifdef EMUZ80
#include "z80.c"
#endif
