package com.blissjx.plugin;

import java.awt.image.*;
import java.text.*;
import com.bliss.core.devices.*;
import com.bliss.core.*;

public class DirectXVideoOutputDevice implements VideoOutputDevice
{

    public final static int STRETCH_MODE_SOFTWARE   = 1;
    public final static int STRETCH_MODE_HARDWARE2D = 2;
    public final static int STRETCH_MODE_HARDWARE3D = 3;

    DirectXVideoOutputDevice() {
        nativeHandle = nativeDirectXVideoOutputDevice();
    }

    private native long nativeDirectXVideoOutputDevice();

    public native void init(String windowTitle);

    public native void displayImage(byte[] imageData, boolean hasChanged);

    public native void release();

    public native void setFullScreen(boolean b);

    public native boolean isFullScreen();

    public native void setStretchMode(int mode);

    public native int getStretchMode();

    public Option[] getOptions() {
        return controllers;
    }

    boolean stop;
    private long nativeHandle;

    private final static String[] errorMessageKeys = {
            "ErrorUnableToInitWindow",
            "ErrorUnableToRetrieveVideoMode",
            "ErrorUnableToSetRequestedVideoMode",
            "ErrorUnableToRequestForInMemoryTextureFailed",
            "ErrorUnableToRequestForHardwareTextureFailed",
            "ErrorUnableToRequestForVertexBufferFailed",
            "ErrorUnableToUnableToLockVertexBuffer",
            "ErrorUnableToUnableToClearBackBuffer"
        };

    private Option[] controllers = {
            new ChoiceOption() {
                public String getDescription() {
                    return description;
                }
                public Object[] getChoices() {
                    return allStretchModes;
                }
                public String getDescription(Object choice) {
                    return stretchModeDescriptions[((Integer)choice)
                            .intValue()-1];
                }
                public void setValue(Object choice) {
                    setStretchMode(((Integer)choice).intValue());;
                }
                public Object getValue() {
                    return new Integer(getStretchMode());
                }
                private String description = Win32PlugIn.RESOURCES.
                        getString("StretchModeLabel");
                private Integer[] allStretchModes = {
                        new Integer(STRETCH_MODE_SOFTWARE),
                        new Integer(STRETCH_MODE_HARDWARE2D),
                        new Integer(STRETCH_MODE_HARDWARE3D)
                    };
                private String[] stretchModeDescriptions = {
                        Win32PlugIn.RESOURCES.getString(
                                "SoftwareStretchModeDescription"),
                        Win32PlugIn.RESOURCES.getString(
                                "Hardware2DStretchModeDescription"),
                        Win32PlugIn.RESOURCES.getString(
                                "Hardware3DStretchModeDescription"),
                    };
            },
            new BooleanOption() {
                public String getDescription() {
                    return description;
                }
                public boolean isEnabled() {
                    return isFullScreen();
                }
                public void setEnabled(boolean enabled) {
                    setFullScreen(enabled);
                }
                private String description = Win32PlugIn.RESOURCES.
                        getString("FullScreenDescription");
            }
        };

/*
    static class DisplayMode
    {
        DisplayMode(int xres, int yres, int refreshRate, long format) {
            this.xres = xres;
            this.yres = yres;
            this.refreshRate = refreshRate;
            this.format = format;
        }

        final int xres;
        final int yres;
        final int refreshRate;
        final long format;
    }
*/

}
