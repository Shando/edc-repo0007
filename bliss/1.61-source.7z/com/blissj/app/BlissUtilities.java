package com.blissj.app;

import java.awt.*;

public class BlissUtilities
{

    public static void centerWindowOnScreen(Window w) {
        Dimension d1 = w.getToolkit().getScreenSize();
        Dimension d2 = w.getSize();
        w.setLocation((d1.width - d2.width)/2, (d1.height - d2.height)/2);
    }

    public static void centerWindowOverParent(Window w) {
        centerWindowOverParent(w, 0, 0);
    }

    public static void centerWindowOverParent(Window w, int offsetX,
            int offsetY)
    {
        Rectangle d1 = w.getOwner().getBounds();
        Dimension d2 = w.getSize();
        w.setLocation(d1.x + ((d1.width - d2.width)/2) + offsetX,
                d1.y + ((d1.height - d2.height)/2) + offsetY);
    }

    private BlissUtilities() { }

}
