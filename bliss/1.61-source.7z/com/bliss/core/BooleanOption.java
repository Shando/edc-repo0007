package com.bliss.core;

public abstract class BooleanOption implements Option
{

    public Object getValue() {
        return (isEnabled() ? Boolean.TRUE : Boolean.FALSE);
    }

    public void setValue(Object value) {
        setEnabled(Boolean.TRUE.equals(value));
    }

    public String getDescription(Object value) {
        return value.toString();
    }

    public abstract void setEnabled(boolean enabled);

    public abstract boolean isEnabled();

}
