package com.bliss.core;

import java.io.*;

public class ECS implements Peripheral
{

    public ECS(AudioMixer.AudioOutputLine aol, ECSKeyboard keyboard) {
        this.aol = aol;
        this.keyboard = keyboard;
        init();
    }

    public int getProcessorCount() {
        return psg2.getProcessorCount();
    }

    public Processor getProcessor(int i) {
        return psg2.getProcessor(i);
    }

    public int getMemoryCount() {
        return memorySegments.length;
    }

    public Memory getMemory(int i) {
        return memorySegments[i];
    }

    void setECSROMImage(int[] ecsImage) {
        System.arraycopy(ecsImage, 0, ecsImage0, 0, ecsImage0.length);
        System.arraycopy(ecsImage, 0x1000, ecsImage1, 0, ecsImage1.length);
        System.arraycopy(ecsImage, 0x2000, ecsImage2, 0, ecsImage2.length);
        hasECSROMImage = true;
    }

    boolean hasECSROMImage()  {
        return hasECSROMImage;
    }

    void setPSGClockDivisor(int divisor) {
        psg2.setClockDivisor(divisor);
    }

    private void init() {
        psg2 = new AY38914(aol, 0x00F0, keyboard, keyboard);
        int count = psg2.getMemoryCount();
        memorySegments = new Memory[count + 5];
        for (int i = 0; i < count; i++)
            memorySegments[i] = psg2.getMemory(i);

        ecsImage0 = new int[0x1000];
        memorySegments[count] = new ROM(ecsImage0, 0x2000, 1);

        ecsImage1 = new int[0x1000];
        memorySegments[count+1] = new ROM(ecsImage1, 0x7000, 0);

        ecsImage2 = new int[0x1000];
        memorySegments[count+2] = new ROM(ecsImage2, 0xE000, 1);

        //ramBank = new RAM(0x07C0, 0x4040, 8);
        ramBank = new RAM(0x0800, 0x4000, 8);
        memorySegments[count+3] = ramBank;

        memorySegments[count+4] = new RAM(4, 0xE0, 8);
    }

    ECSKeyboard keyboard;
    AY38914 psg2;
    private AudioMixer.AudioOutputLine aol;
    private int[] ecsImage0;
    private int[] ecsImage1;
    private int[] ecsImage2;
    private boolean hasECSROMImage = false;
    private RAM   ramBank;
    private Memory[] memorySegments;

}
