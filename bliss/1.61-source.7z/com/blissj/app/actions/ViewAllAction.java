package com.blissj.app.actions;

import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.blissj.app.*;

public class ViewAllAction extends AbstractAction
{

    public ViewAllAction(JTable table) {
        this.table = table;
        this.tableModel = (CartridgeTableModel)table.getModel();
        putValue(NAME, Bliss.RESOURCES.getString(
                "ActionViewAll"));
    }

    public void actionPerformed(ActionEvent ae) {
        table.clearSelection();
        tableModel.setView(CartridgeTableModel.VIEW_ALL);
    }

    private JTable              table;
    private CartridgeTableModel tableModel;

}
