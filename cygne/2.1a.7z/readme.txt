DISCLAIMERS

1. This emulator is not manufactured, sponsored or endorsed by Bandai.
2. Bandai and Wonderswan are trademarks of Bandai.
3. Created for educational purposes only.
4. Author is not responsible for anything bad that happens. You USE IT AT YOUR OWN RISK!
5. No animals were charmed during the work.
6. If you want to play the games - buy the real console.


The source code is distributed under the terms of the GNU General Public License.
The NEC CPU emulator code is taken from the MAME project, and terms of their use
are covered under the MAME license. (http://www.mame.net)


dox@space.pl