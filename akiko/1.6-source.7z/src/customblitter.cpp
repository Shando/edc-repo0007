typedef unsigned long           LxUInt32;

//*****************************************************************************
// lxBlitSimple
// ~~~~~~~~~~~~
//
// The lxBlitSimple() function blits a rectangular block of pixels from
// a source bitmap to a destination bitmap. This function does not care
// about anything... it doesn't even test for valid parameters, nor does
// if perform any clipping.
//-----------------------------------------------------------------------------
//
// PARAMETERS:
// ~~~~~~~~~~~
// p_destBits           <-- Address of the destination bits
// destPitch            <-- Pitch of the destination bitmap
// p_srcBits            <-- Address of the source bits
// srcPitch             <-- Pitch of the source bitmap
// width                <-- Number of pixels per row
// height               <-- Number of pixels per column
// bytesPerPixel        <-- Number of bytes per pixel
//
//*****************************************************************************
void lxBlitSimple(
    void * p_destBits,
    LxUInt32 destPitch,
    void * p_srcBits,
    LxUInt32 srcPitch,
    LxUInt32 width,
    LxUInt32 height,
    LxUInt32 bytesPerPixel)
{
	__asm
	{
				// Push flags and clear direction flag
				pushf
				cld

				// Calculate bytes per line and adjust pitches
				mov		eax, width
				mul		bytesPerPixel
				mov		width, eax

				mov		ebx, srcPitch
				mov		edx, destPitch
				sub		ebx, eax
				sub		edx, eax

				mov		esi, p_srcBits
				mov		edi, p_destBits
VerticalLoop:
				mov		ecx, width

HorizontalLoop:
				// Copy row
                // lea     ecx, [edi + edi * 2]
				mov		eax, ecx
				sub		ecx, edi
				sub		ecx, eax

				and		ecx, 3
				sub		eax, ecx
				jle		short EndBytes
				
				rep		movsb				// Copy leading bytes
				mov		ecx, eax
				and		eax, 3
				shr		ecx, 2
				rep		movsd				// Copy as much DWORDs as possible
EndBytes:					
				add		ecx, eax
				rep		movsb				// Copy trailing bytes

				add		esi, ebx
				add		edi, edx
				dec		height
				jnz		short VerticalLoop
Done:
				// Pop flags to restore direction flag
				popf
	}
}
