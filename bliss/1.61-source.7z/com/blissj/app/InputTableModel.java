package com.blissj.app;

import javax.swing.*;
import javax.swing.table.*;
import com.bliss.core.*;
import com.bliss.core.devices.*;

public class InputTableModel extends AbstractTableModel
{

    public void setIODevice(InputDevice inputDevice, IODevice ioDevice) {
        inputSignals = null;

        this.ioDevice = ioDevice;
        this.inputDevice = inputDevice;

        if (this.ioDevice != null) {
            int controlCount = ioDevice.getControlCount();
            inputSignals = new InputSignal[controlCount];
            for (int i = 0 ; i < controlCount; i++)
                inputSignals[i] = inputDevice.getInputSignal(
                        ioDevice.getControlID(i));
        }
        fireTableDataChanged();
    }

    public int getRowCount() {
        return (ioDevice == null ? 0 : ioDevice.getControlCount());
    }

    public int getColumnCount() {
        return 2;
    }

    public void reloadDevice() {
        for (int i = 0 ; i < inputSignals.length; i++)
            inputSignals[i] = inputDevice.getInputSignal(
                    ioDevice.getControlID(i));
        fireTableDataChanged();
    }

    public void commitToDevice() {
        for (int i = 0 ; i < inputSignals.length; i++)
            inputDevice.setInputSignal(ioDevice.getControlID(i),
                    inputSignals[i]);
    }

    public String getColumnName(int column) {
        if (column == 0)
            return Bliss.RESOURCES.getString("ColumnIntellivisionControl");
        else
            return Bliss.RESOURCES.getString("ColumnMapping");
    }

    public Object getValueAt(int row, int column) {
        if (column == 0)
            return ioDevice.getControlDescription(row);
        else {
            InputSignal signal = inputSignals[row];
            if (signal == null)
                return Bliss.RESOURCES.getString("InputUndefined");
            else
                return signal.getDescription();
        }
    }

    public void setControlInputSignal(int i, InputSignal inputSignal) {
        inputSignals[i] = inputSignal;
        fireTableCellUpdated(i, 1);
    }

    public int getInputID(int row) {
        return row;
    }

    private InputDevice inputDevice;
    private IODevice ioDevice;
    private InputSignal[] inputSignals;

    private final static String[] inputKeys = {
            "InputKeyPadOne",
            "InputKeyPadTwo",
            "InputKeyPadThree",
            "InputKeyPadFour",
            "InputKeyPadFive",
            "InputKeyPadSix",
            "InputKeyPadSeven",
            "InputKeyPadEight",
            "InputKeyPadNine",
            "InputKeyPadClear",
            "InputKeyPadZero",
            "InputKeyPadEnter",
            "InputActionButtonsTop",
            "InputActionButtonBottomLeft",
            "InputActionButtonBottomRight",
            "InputDiscNorth",
            "InputDiscNorthEast",
            "InputDiscEast",
            "InputDiscSouthEast",
            "InputDiscSouth",
            "InputDiscSouthWest",
            "InputDiscWest",
            "InputDiscNorthWest"
        };

}
