/*
 * HostBase.cs
 * 
 * Abstraction of an emulated machine host.
 * 
 * Copyright (c) 2004-2008 Mike Murphy
 * 
 */
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using EMU7800.Machine;

namespace EMU7800.Host
{
    public enum HostInput
    {
        End,
        Pause,
        Mute,
        Fire,
        Fire2, // booster
        Left,
        Right,
        Up,
        Down,
        NumPad1, NumPad2, NumPad3,
        NumPad4, NumPad5, NumPad6,
        NumPad7, NumPad8, NumPad9,
        NumPadMult, NumPad0, NumPadDiv,
        Reset,
        Select,
        Color,
        LeftDifficulty,
        RightDifficulty,
        SetKeyboardToPlayer1,
        SetKeyboardToPlayer2,
        SetKeyboardToPlayer3,
        SetKeyboardToPlayer4,
        PanLeft, PanRight, PanUp, PanDown,
        SaveMachine,
        Unknown,
    }

    public abstract class HostBase
    {
        #region Fields

        private static readonly Dictionary<string, HostBase> _RegisteredHosts = new Dictionary<string, HostBase>();

        private const int LIGHTGUN_LATENCY_CLKS = 25;  // 2600-specific, 7800 still needs to be determined

        protected MachineBase M { get; set; }

        private long _PostedMsgExpireFrameCount;
        private bool _AudioOpened;
        private string _PostedMsg = string.Empty;

        #endregion

        #region Public Properties

        public static ReadOnlyCollection<string> RegisteredHostNames
        {
            get
            {
                var hostList = new List<string>();
                foreach (var hostName in _RegisteredHosts.Keys)
                {
                    hostList.Add(hostName);
                }
                return new ReadOnlyCollection<string>(hostList);
            }
        }

        public string PostedMsg
        {
            [DebuggerStepThrough]
            get { return (_PostedMsgExpireFrameCount > M.FrameNumber) ? _PostedMsg : string.Empty; }
            [DebuggerStepThrough]
            set
            {
                if (value != null)
                {
                    _PostedMsg = value.PadRight(32);
                    _PostedMsgExpireFrameCount = M.FrameNumber + 3*M.FrameHZ;
                }
            }
        }

        public int EffectiveFPS
        {
            [DebuggerStepThrough]
            get { return M.FrameHZ + GlobalSettings.Instance.FrameRateAdjust; }
        }

        [SuppressMessage("Microsoft.Performance", "CA1822:MarkMembersAsStatic")]
        public bool DeactivateMouseInput
        {
            [DebuggerStepThrough]
            get { return GlobalSettings.Instance.DeactivateMouseInput; }
            [DebuggerStepThrough]
            set { GlobalSettings.Instance.DeactivateMouseInput = value; }
        }

        public int CurrentKeyboardPlayerNo { get; private set; }
        public bool Muted { get; private set; }
        public bool Paused { get; private set; }
        public bool Ended { get; private set; }
        public int ClipStart { get; private set; }
        public int LeftOffset { get; private set; }

        #endregion

        #region Public Methods

        public static HostBase New(string hostName)
        {
            foreach (var registeredHostName in _RegisteredHosts.Keys)
            {
                if (registeredHostName.Equals(hostName, StringComparison.OrdinalIgnoreCase))
                {
                    return _RegisteredHosts[hostName];
                }
            }
            throw new InvalidOperationException("Host name not registered: " + hostName);
        }

        public static void RegisterHost(string hostName, HostBase host)
        {
            _RegisteredHosts.Add(hostName, host);
        }

        public void RaiseInput(HostInput input, bool down)
        {
            RaiseInput(CurrentKeyboardPlayerNo, input, down);
        }

        public void RaiseInput(int playerNo, HostInput input, bool down)
        {
            var ia = M.InputAdapter;

            if (Paused && down)
            {
                switch (input)
                {
                    case HostInput.Pause:
                    case HostInput.PanLeft:
                    case HostInput.PanRight:
                    case HostInput.PanDown:
                    case HostInput.PanUp:
                    case HostInput.LeftDifficulty:
                    case HostInput.RightDifficulty:
                    case HostInput.Color:
                    case HostInput.SaveMachine:
                    case HostInput.Mute:
                    case HostInput.End:
                        break;
                    default:
                        Paused = false;
                        PostedMsg = "Resumed";
                        break;
                }
            }

            switch (input)
            {
                case HostInput.Fire:
                    ia[playerNo, ControllerAction.Trigger] = down;
                    break;
                case HostInput.Fire2:
                    ia[playerNo, ControllerAction.Trigger2] = down;
                    break;
                case HostInput.Left:
                    ia[playerNo, ControllerAction.Left] = down;
                    if (down)
                    {
                        ia[playerNo, ControllerAction.Right] = false;
                    }
                    break;
                case HostInput.Up:
                    ia[playerNo, ControllerAction.Up] = down;
                    if (down)
                    {
                        ia[playerNo, ControllerAction.Down] = false;
                    }
                    break;
                case HostInput.Right:
                    ia[playerNo, ControllerAction.Right] = down;
                    if (down)
                    {
                        ia[playerNo, ControllerAction.Left] = false;
                    }
                    break;
                case HostInput.Down:
                    ia[playerNo, ControllerAction.Down] = down;
                    if (down)
                    {
                        ia[playerNo, ControllerAction.Up] = false;
                    }
                    break;
                case HostInput.NumPad7:
                    ia[playerNo, ControllerAction.Keypad7] = down;
                    break;
                case HostInput.NumPad8:
                    ia[playerNo, ControllerAction.Keypad8] = down;
                    break;
                case HostInput.NumPad9:
                    ia[playerNo, ControllerAction.Keypad9] = down;
                    break;
                case HostInput.NumPad4:
                    ia[playerNo, ControllerAction.Keypad4] = down;
                    break;
                case HostInput.NumPad5:
                    ia[playerNo, ControllerAction.Keypad5] = down;
                    break;
                case HostInput.NumPad6:
                    ia[playerNo, ControllerAction.Keypad6] = down;
                    break;
                case HostInput.NumPad1:
                    ia[playerNo, ControllerAction.Keypad1] = down;
                    break;
                case HostInput.NumPad2:
                    ia[playerNo, ControllerAction.Keypad2] = down;
                    break;
                case HostInput.NumPad3:
                    ia[playerNo, ControllerAction.Keypad3] = down;
                    break;
                case HostInput.NumPadMult:
                    ia[playerNo, ControllerAction.KeypadA] = down;
                    break;
                case HostInput.NumPad0:
                    ia[playerNo, ControllerAction.Keypad0] = down;
                    break;
                case HostInput.NumPadDiv:
                    ia[playerNo, ControllerAction.KeypadP] = down;
                    break;
                case HostInput.Reset:
                    ia[ConsoleSwitch.GameReset] = down;
                    break;
                case HostInput.Select:
                    ia[ConsoleSwitch.GameSelect] = down;
                    break;
                case HostInput.Color:
                    if (down)
                    {
                        ia[ConsoleSwitch.GameBW] = !ia[ConsoleSwitch.GameBW];
                        PostedMsg = ia[ConsoleSwitch.GameBW] ? "B/W" : "Color";
                    }
                    break;
                case HostInput.LeftDifficulty:
                    if (down)
                    {
                        ia[ConsoleSwitch.LDifficultyA] = !ia[ConsoleSwitch.LDifficultyA];
                        PostedMsg = "Left Difficulty: " + (ia[ConsoleSwitch.LDifficultyA] ? "A (Pro)" : "B (Novice)");
                    }
                    break;
                case HostInput.RightDifficulty:
                    if (down)
                    {
                        ia[ConsoleSwitch.RDifficultyA] = !ia[ConsoleSwitch.RDifficultyA];
                        PostedMsg = "Right Difficulty: " + (ia[ConsoleSwitch.RDifficultyA] ? "A (Pro)" : "B (Novice)");
                    }
                    break;
                case HostInput.SetKeyboardToPlayer1:
                    if (down)
                    {
                        SetKeyboardToPlayerNo(0);
                    }
                    break;
                case HostInput.SetKeyboardToPlayer2:
                    if (down)
                    {
                        SetKeyboardToPlayerNo(1);
                    }
                    break;
                case HostInput.SetKeyboardToPlayer3:
                    if (down)
                    {
                        SetKeyboardToPlayerNo(2);
                    }
                    break;
                case HostInput.SetKeyboardToPlayer4:
                    if (down)
                    {
                        SetKeyboardToPlayerNo(3);
                    }
                    break;
                case HostInput.PanLeft:
                    if (down)
                    {
                        LeftOffset++;
                    }
                    break;
                case HostInput.PanRight:
                    if (down)
                    {
                        LeftOffset--;
                    }
                    break;
                case HostInput.PanDown:
                    if (down)
                    {
                        ClipStart--;
                    }
                    break;
                case HostInput.PanUp:
                    if (down)
                    {
                        ClipStart++;
                    }
                    break;
                case HostInput.SaveMachine:
                    if (down)
                    {
                        var fn = String.Format("machinestate {0:yyyy}.{0:MM}-{0:dd}.{0:HH}{0:mm}{0:ss}.emu", DateTime.Now);
                        try
                        {
                            M.Serialize(Path.Combine(GlobalSettings.Instance.OutputDirectory, fn));
                            Trace.WriteLine("machine state saved successfully.");
                            PostedMsg = "Machine state saved";
                        }
                        catch (IOException ex)
                        {
                            Trace.Write("machine state save error: ");
                            Trace.WriteLine(ex);
                            PostedMsg = "Error saving machine state";
                        }
                    }
                    break;
                case HostInput.Mute:
                    if (down)
                    {
                        Muted = !Muted;
                        PostedMsg = Muted ? "Mute" : "Mute Off";
                    }
                    break;
                case HostInput.Pause:
                    if (down && !Paused)
                    {
                        Paused = true;
                        PostedMsg = "Paused";
                    }
                    break;
                case HostInput.End:
                    if (down)
                    {
                        Ended = true;
                    }
                    break;
            }
        }

        public void RaiseLightGunInput(int screenWidth, int x, int y)
        {
            var scanline = (y + ClipStart) % M.Scanlines;
            var hpos = x * M.VisiblePitch / screenWidth + LIGHTGUN_LATENCY_CLKS;
            M.InputAdapter.SetLightgunPos(CurrentKeyboardPlayerNo, scanline, hpos);
        }

        public void RaisePaddleInput(int valMax, int val)
        {
            RaisePaddleInput(CurrentKeyboardPlayerNo, valMax, val);
        }

        public void RaisePaddleInput(int playerNo, int valMax, int val)
        {
            var ohms = InputAdapter.PaddleOhmMax - (InputAdapter.PaddleOhmMax - InputAdapter.PaddleOhmMin) / valMax * val;
            M.InputAdapter.SetOhms(playerNo, ohms);
        }

        public int EnqueueAudio(byte[] buf)
        {
            if (!_AudioOpened)
            {
                var NumSoundBuffers = GlobalSettings.Instance.NumSoundBuffers;
                var SoundSampleRate = M.SoundSampleRate * EffectiveFPS / M.FrameHZ;
                WinmmNativeMethods.Open(SoundSampleRate, M.Scanlines << 1, NumSoundBuffers);
                _AudioOpened = true;
            }
            return WinmmNativeMethods.Enqueue(buf);
        }

        public void CloseAudio()
        {
            WinmmNativeMethods.Close();
            _AudioOpened = false;
        }

        #endregion

        #region Virtual Members

        public virtual void Run(MachineBase m)
        {
            if (m == null) throw new ArgumentNullException("m");

            M = m;
            M.AssignToHost(this);
            Muted = false;
            Paused = false;
            Ended = false;
            _AudioOpened = false;
            CurrentKeyboardPlayerNo = 0;
            ClipStart = M.FirstScanline;
            LeftOffset = 0;
            _PostedMsgExpireFrameCount = 0;
        }

        #endregion

        #region Helpers

        private void SetKeyboardToPlayerNo(int playerNo)
        {
            foreach (ControllerAction ca in Enum.GetValues(typeof(ControllerAction)))
            {
                M.InputAdapter[playerNo, ca] = false;
            }
            CurrentKeyboardPlayerNo = playerNo;
            PostedMsg = String.Format("Keyboard to Player {0}", CurrentKeyboardPlayerNo + 1);
        }

        #endregion
    }
}
