         _
     x#######x    x########  x##x   :###x     x#######:
   x#####x#####   #######x   :###x   ###     x#######
  :###x          :###         ####x: ###    :######
  x###           x######x     ######x###     x######x
  x###     ##x   x######x     ### ######      x######x
  :###x      ##  :###         ###  #####      :######x
   x#####x####x   #######x   :###   ####:    #######x
     x#######x    x########  x###    ###x  :#######x

email:	stef_d@caramail.com
	stef0@multimania.com


Gens is a Win9X based emulator for sega genesis/megadrive system.
It was written for 25% in C (Watcom C 11.0 pour la version DOS et Visual C++ 5.0 pour
Win9X) and for 75% in Assembler (Nasm).

Disclaimer
----------

Gens (C)1999/2000 by St�phane Dallongeville
Sega and Genesis are trademarks of Sega Enterprises, Ltd.
Gens is freeware and can be distributed freely as long as it is not modified.
When you use this software you do so at your own risk.
The author is not responsible for any loss or damage resulting from the use
or misuse of this software.
If you do not agree with these terms delete this software now.


(24/02/2000) Changes Gens 0.2 <- Gens 0.141 :
-------------------------------------------------

- I've enterely rewritten the VDP render :
  - More optimised and so faster ;)
  - Fix Scroll A / Window conflit.
  - Added masks sprites features.
  - Added sprite limit feature (can show it on sonic 1 main screen)
    You can enable or disable it by 'Sprite Over' option in the 'graphics' menu.
  - Added 15 bits mode.
    No more bad colors on some videos cards :)
- Fix the VSRam read and write (verticals scrollings are now okay)
- I'm use RAZE (Richard Mitton richard.mitton@bigfoot.com) z80 emulator instead MZ80
 (Neil Bradley neil@synthcom.com) due to unworkings games with MZ80 (I may not use it correctly).
- Some changes in DMA transferts. (sprites of mario (no commercial) rom are okay).
- Full-Screen now works correctly.
  Full-Screen is faster than Windowed mode, just use it !
- Some others ...

Sorry, again once, the sound is not implemented, may be in the next release !

(08/02/2000) Changes Gens 0.141 <- Gens 0.12 Beta :
----------------------------------------------------------------

- Auto-FrameSkip added !
- correct some bugs on DMA (demos roms like super mario nott crashe any more ... )
- Keys setting for Player 1 & Player 2 added !
- I have change directdraw method to get faster transrencies effects.
- HalfBlur effect added for smooth graphics !


(03/02/2000) Changes Gens 0.12 Beta (Win9X) <- Gens 0.15b (DOS):
----------------------------------------------------------------

First important change: Gens works now under win9X and using DirectX ! Then some bugs appears
and some roms that work on Gens 0.15b not works anymore :(

- Screen size * 1; * 2; * 3; * 4.
- No V-Sync possibility for now.
- Debugger is miss because a lot of works is needed to make it work !
- Save/Load state added !
  I'm using Genecyst format, there are some bugs dus to lack of infos.
- the transparencies effects dus to palette changes during H-Blanking work !

No sound yet !


What I need to make Gens work ?
-------------------------------
On my machine (Celeron @464 Mhz & 64 Mo), most roms works at 60 FPS or more.
(20 FPS at less).

* Minimun Machine

- Pentium 200
- 16 Mo de Ram
- Windows95 / Windows98 OS
- DirectDraw, DirectInput


* Recommanded Machine

- Pentium II 300 Mhz
- 32 Mo de Ram
- Syst�me Windows95 / Windows98
- DirectX7


How play ?
---------------

(AZERTY keyboard)

		Player 1			Player 2

	Up		Z		Up		Up
	Down		S		Down		Down
	Left		Q		Left		Left
	right		D		Right		Right
	A		F		A		K
	B		G		B		L
	C		H		C		M
	X		R		X		I
	Y		T		X		O
	Z		Y		Z		P
	Start		E		Start		Enter
	Mode		A		Mode		Right Shift

Just redefine keys if you have problems :)



Technical part:
---------------

* 68000 CPU supported
* VDP supported: 
- DMA transfers (all modes)
- Scroll A plane with vertical scrolling (overall, 2 cells) and
  horizontal scrolling (overall, cell, dot)
- Scroll B plane with vertical scrolling (overall, 2 cells) and
  horizontal scrolling (overall, cell, dot)
- Window plane 
- Sprite plane 
- Vertical Interrupt 
- Horizontal Interrupt 
- Most of the rasters effects
- Highlight/Shadow effects
... 
* IO ports supported (controller 1 and controller 2)
* Z80 CPU core supported :
  Multi-Z80 CPU emulator by Neil Bradley (neil@synthcom.com)
* Frame Skip (Auto, 0, 1, 2, 3, 4)
* Save/Load State.


What is lack ?
--------------

* YM2612 support
* PSG-DAC support
* VDP Interlace Mode (in sonic2)
+ Save RAM support
* A fast and accurate 68k core :)
