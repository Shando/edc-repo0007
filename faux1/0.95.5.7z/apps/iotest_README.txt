iotest - Simple keyboard echo in ASCII and HEX

Display a user keypress as a characcter and as a two digit hexidecimal number.  Terminate once the user presses the <esc> key.

Usage:

To load:

Open iotest.woz with text editor and paste ASCII hex file into the WOZON.

-or-

Load ASCII (faux1 ony):
<control><L>  
Enter file name to load: apps/iotest.woz
Enter (A)scii or (B)inary: a
Filename 'apps/iotest.woz' loaded.\

-or-

Load ASCII (faux1 ony):
<control><L>  
Enter file name to load: apps/iotest.bin
Enter (A)scii or (B)inary: b
Enter Starting Address in Hex: 300
Filename 'apps/iotest.bin' loaded.\


Enter 300R to start.


2012-02-19
