==============================================

	P A L E

	Pete's Lynx Emulator

	Ver: 1.6

=============================================

date : 14/02/2004


*** Nouveaut� de la version 1.5 et 1.6 ***

1. Routine de vitesse automatique toujours exp�rimentale !
2. Routines du clavier - maintenant mieux �mul�e
3. R�ajustement de la taille d'�cran et option 'plein �cran' *** corrig�
*** (du moins je l'esp�re)
4. Quelques ajouts suppl�mentaires dans le GUI
5. Langage Francais - merci merci James Boillee :))


Lecture d'un programme
======================

Vous DEVEZ, commencer la lecture d'une cassette en tapant LOAD "" ou
MLOAD "" puis <return> avant de cliquer (avec le bouton droit sur l'�cran
de l'�mulateur) sur LOAD.
A ce moment l'�mulateur doit se trouver dans un �tat stable avant la
lecture du programme. Dans le cas contraire, red�marrez le.

Instructions pour lire 'Level 9 adventures'
===========================================


1. Ouvrir le fichier advent.tap en mode basic/binaire puis executez le
2. Ouvrir le fichier advent2.tap et executer le suivant le m�me principe.
3. Dans le menu "charger cassette" passer en mode 'level 9'

Le loader chargera automatiquement les donn�es des parties 3,4 et 5 et les
executera.


Clavier
========

J'ai laiss� la m�me disposition du clavier par rapport � l'original.
Dans le futur je mettrai probablement une option pour pouvoir en changer.


Son
===

Deux pilotes audio sont utilis�s. Le premier d�tecte une BEEP ou un SOUND
par la ROM. Le r�sultat produit est envoy� dans Windows.
Le second (pour les jeux MC et autre son) � besoin de plus de puissance
mais fait passer le son continuellement. Cela fonctionne correctement sur
ma machine mais sur une autre cela d�pendent de la vitesse d'horloge du
processeur.


Vitesse automatique
===================

Une premi�re tentative �tait d'obtenir une vitesse automatique
D'�mulation malgr� tout les non-sens que les fen�tres Windows jettent aux
temporisateurs : (


Probl�mes connus
================

1. �mulation inexacte du bank switching

2. Ajustement de la vitesse l�g�rement d�f�ctuseuse

3. Am�lioration des pilotes sonore.

4. La sauvegarde n'est pas support�e

5. Le plein �cran (fonctionnant correctement j'entend) n'est pas impl�ment�

6. 'bruit de fond du Z80 'manquant - d�s que quelqu'un m'enverra un
fichier wav �a fonctionnera :)

7. registre vid�o 6845 non impl�ment� - aucun "tremblement de terre" dans
'Air Raid'


Bugs
====

Bugs, conseils, suggestions sont les bienvenues.

Si vous utilisez le programme de lecture de bande avec vos logiciels,
envoyez moi une copie de la bande en fichier TAPE. Cet �mulateur a �t�
�crit sans avoir de lynx et avec seulement 'Power Blaster 'et le niveau 9
'Dungeon Adventure', la cassette de d�monstration (envoy�e avec courtoisie
par Paul Robson) et quelques vieilles cassettes de mon cru (le jeu level 9
semble avoir pris quelques "joyeuset�s" dans la lecture de la bande).

Afin d'examiner et am�liorer cet �mulateur j'ai besoin de PLUS de
logiciel. N'importe quelle aide ici serait beaucoup appr�ci�e, J'ai inclus
le logiciel de lecture de cassette ainsi que mon email :))


Mention L�gale
==============

J'ai inclus les ROM et les logiciels pour cet ordinateur parce que je ne
pense pas que quiconque aurait des programmes pour cette machine. J'esp�re
que les personnes qui ont d�velopp�es ces logiciels ne s'opposent pas �
leur distribution et, que s'ils sont contre, me le fasse savoir pour que
je les enl�ve.

Mes remerciements sp�ciale aux personnes concern� qui nous ont apporter un
Lynx, c'est est un micro �trange mais qui � sa place d'ordinateur culte dans
L'histoire de la micro informatique BRITANNIQUE.


A bient�t,
Pete
