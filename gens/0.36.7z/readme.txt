         _
     x#######x    x########  x##x   :###x     x#######:
   x#####x#####   #######x   :###x   ###     x#######
  :###x          :###         ####x: ###    :######
  x###           x######x     ######x###     x######x
  x###     ##x   x######x     ### ######      x######x
  :###x      ##  :###         ###  #####      :######x
   x#####x####x   #######x   :###   ####:    #######x
     x#######x    x########  x###    ###x  :#######x

http://www.emuforce.com/gens

email:	stef_d@caramail.com
	stef0@multimania.com

Gens is a Win9X based emulator for sega genesis/megadrive system.
It was written for 35% in C/CPP (Visual C++ 5.0) and for 65% in Assembler (Nasm).
Gens WORKS IN 15/16 BPP MODE and needs directx 3.0 or higher.

Disclaimer
----------

Gens (C)1999/2000 by St�phane Dallongeville
Sega and Genesis are trademarks of Sega Enterprises, Ltd.
Gens is freeware and can be distributed freely as long as it is not modified.
When you use this software you do so at your own risk.
The author is not responsible for any loss or damage resulting from the use
or misuse of this software.
If you do not agree with these terms delete this software now.


(27/03/2000) Changes Gens 0.36 <- Gens 0.34 :
---------------------------------------------

- Gens now uses the new MZ80 core of Neil Bradley (v3.4)
  and it corrects some sounds bugs !
- Fix special version auto-detection (Toy Story ...)
- SRAM implemented (Landstaker, Light Crusader ... now works correctly !)
  but not yet saved in file.
- Choice of the game speed added : NTSC (60 FPS) or PAL (50 FPS).
  If a game runs too fast, just switch to PAL version.
- Sound timing of some games (vector man ...) fixed.
- Fix switch state shortcut.
- Fix the stupid bug which exits after setting keys !
- Fix load state crashs with starscream.
- ...

Joystick support not yet available :(

(21/03/2000) Changes Gens 0.34 <- Gens 0.3 :
--------------------------------------------

- Starscream 68000 is available, changes :
  - More roms works fine (about 75% :)
  - Faster that mine !
  - Debugger not work with Starscream !
- RAZE Z80 core added, but there are some problems with certains roms aladdin, sonic ...)
  but it works better than MZ80 in others case (animaniacs, contra4 ...).
- Shortcuts added (Save / Load state, frame skip ... see below)
- Sound is now stopped when we click on menu or resizing the window ...
- Current directory stored (but not yet in file, just when you keep gens run)
- Some optimisations -> some more FPS :)
- Bugs fixs (directsound init, keys settings ...)
- others i can't remenber ....

(14/03/2000) Changes Gens 0.3 <- Gens 0.24 :
--------------------------------------------

- Starscream 68000 core (faster and more accurate that mine) is now
  implemented but desactived, it'll be active in the next version !
- DAC works now perfectly (can heard 'SEGA' chord in sonics games :)
- Many many fixs in sound and CPU timings:
  - All chips (68000, Z80, YM2612, PSG ...) are synchronised depending of
    game type (PAL 50Hz / SECAM 60Hz) and PAL games works at 50 FPS in
    auto-frameskip mode.
  - Fix YM2612 timers.
  - Fix PSG rate.
- Can choose sample rate of the sound (you must reload the rom for take effect !)
- some others little...

There are some glitch with the DAC speed with some games (just hear voices in
aladdin, cool-spot, lemmings ...)

(08/03/2000) Changes Gens 0.24 <- Gens 0.2 :
--------------------------------------------

- I'm return with MZ80 (Neil Bradley neil@synthcom.com) z80 emulator, it's now works correctly !<br>
- Prelemenary sound emulation :<br>
  - YM2612 works correctly :)<br>
  - PSG works strangly :o<br>
  - DAC not works and only does some noises :(<br>
  - Sound sync is not yet perfect !<br>
  - Sound is played slowly with certain roms<br>
- Fix a bug in the window plane (Zombie no crash any more ...)<br>
- Others ...<br>

Sorry, again once, the sound is not implemented, may be in the next release !

(24/02/2000) Changes Gens 0.2 <- Gens 0.141 :
---------------------------------------------

- I've enterely rewritten the VDP render :
  - More optimised and so faster ;)
  - Fix Scroll A / Window conflit.
  - Added masks sprites features.
  - Added sprite limit feature (can show it on sonic 1 main screen)
    You can enable or disable it by 'Sprite Over' option in the 'graphics' menu.
  - Added 15 bits mode.
    No more bad colors on some videos cards :)
- Fix the VSRam read and write (verticals scrollings are now okay)
- I'm use RAZE (Richard Mitton richard.mitton@bigfoot.com) z80 emulator instead MZ80
 (Neil Bradley neil@synthcom.com) due to unworkings games with MZ80 (I may not use it correctly).
- Some changes in DMA transferts. (sprites of mario (no commercial) rom are okay).
- Full-Screen now works correctly.
  Full-Screen is faster than Windowed mode, just use it !
- Some others ...

Sorry, again once, the sound is not implemented, may be in the next release !

(08/02/2000) Changes Gens 0.141 <- Gens 0.12 Beta :
----------------------------------------------------------------

- Auto-FrameSkip added !
- correct some bugs on DMA (demos roms like super mario nott crashe any more ... )
- Keys setting for Player 1 & Player 2 added !
- I have change directdraw method to get faster transrencies effects.
- HalfBlur effect added for smooth graphics !


(03/02/2000) Changes Gens 0.12 Beta (Win9X) <- Gens 0.15b (DOS):
----------------------------------------------------------------

First important change: Gens works now under win9X and using DirectX ! Then some bugs appears
and some roms that work on Gens 0.15b not works anymore :(

- Screen size * 1; * 2; * 3; * 4.
- No V-Sync possibility for now.
- Debugger is miss because a lot of works is needed to make it work !
- Save/Load state added !
  I'm using Genecyst format, there are some bugs dus to lack of infos.
- the transparencies effects dus to palette changes during H-Blanking work !

No sound yet !


What I need to make Gens work ?
-------------------------------
On my machine (Celeron @464 Mhz & 64 Mo), most roms works at 60 FPS or more.
(20 FPS when i use size * 3).

* Minimun Machine

- Pentium 200
- 16 Mo de Ram
- Video card that support directdraw and 15/16 bpp mode
- Windows95 / Windows98 OS (2000 - NT ?)
- DirectX 3.0


* Recommanded Machine

- Pentium II 300 Mhz
- A good video card like tnt or G400 ... (if you have a bad video card like
  SIS, Virge ... you must use full-screen to hope playing ;)
- 32 Mo de Ram
- Windows95 / Windows98 OS (2000 - NT ?)
- DirectX 3.0


How play ?
---------------

(QWERTY keyboard)

		Player 1			Player 2

	Up		UP		Up		Y
	Down		DOWN		Down		H
	Left		LEFT		Left		G
	right		RIGHT		Right		J
	A		A		A		K
	B		S		B		L
	C		D		C		?
	X		Z		X		I
	Y		X		X		O
	Z		C		Z		P
	Start		Return		Start		U
	Mode		RShift		Mode		T


Shortcuts :

	Save State				F5
	Load State				F7
	Switch State				F6
	Full-Screen / Window Mode		Alt + Return
	Frame-Skip X				X (keys 0 at 4)
	Auto Frame-Skip				9

Switch state is interesting for RPG game, it's just go on the next slot for load/save and
it's return at the first slot (slot 0) when you go after the last (slot 9).

Just redefine keys if you have problems :)


Technical part:
---------------

* 68000 CPU supported
  2 cores:
  - Mine (fast but no enough accurate)
  - Starscream 680x0 emulation library by Neill Corlett (corlett@elwha.nrrc.ncsu.edu)
   (very fast and more accurrate that mine)
* VDP supported: 
- DMA transfers (all modes)
- Scroll A plane with vertical scrolling (overall, 2 cells) and
  horizontal scrolling (overall, cell, dot)
- Scroll B plane with vertical scrolling (overall, 2 cells) and
  horizontal scrolling (overall, cell, dot)
- Window plane 
- Sprite plane 
- Vertical Interrupt 
- Horizontal Interrupt 
- All rasters effects
- Highlight/Shadow effects
* IO ports supported (controller 1 and controller 2)
* emulation du CPU Z80
  - MZ80 Multi-CPU emulator by Neil Bradley (neil@synthcom.com)
* YM2612 chip emulation by Tatsuyuki Satoh
* PSG 76489 emulation
* SRAM supported.
* Frame Skip (Auto, 0, 1, 2, 3, 4)
* Save/Load State.


What is lack ?
--------------

* VDP Interlace Mode (it's just partially implemented)
* Complete Save RAM support.
* Joysticks support.
* A '.ini' file.
* A very accurate 68k core !

Greetings :
-----------
Neill Corlett for his excellent 68000 Starscream emulator.
Neil Bradley for his very good and accurate MZ80 emulator.
Tatsuyuki Satoh for his Yamaha chips emulator (YM2612) which do very nice sound !
Nicolas BRAY <schtroumpf grognon@caramail.com>, NiNjA LEMoN, Arzeno Fabrice and DaGee The Big G for 
being Gens betas testers ! (the bugs list become higher and higher :)
Combacker for designing the new Gens site. (http://www.emuforce.com/gens)
All people have help or support me by mails !
