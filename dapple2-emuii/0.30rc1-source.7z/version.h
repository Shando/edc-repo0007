/* Version information to be included in DAPPLE.C and ROM.C */

#define DappleVersion "0.30 RC1"
