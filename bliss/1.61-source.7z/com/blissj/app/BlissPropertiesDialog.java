package com.blissj.app;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.bliss.core.cartridge.*;

public class BlissPropertiesDialog extends JDialog
{

    public BlissPropertiesDialog(BlissMainFrame frame) {
        super(frame);
        initUI();
        initListeners();
    }

    private void initUI() {
        setTitle(Bliss.RESOURCES.getString("PropertiesDialogTitle"));
        setModal(true);
        Container contentPane = getContentPane();
        contentPane.setLayout(new GridBagLayout());

        tabbedPane = new JTabbedPane();
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        gbc.ipadx = 200;
        gbc.ipady = 150;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(8, 8, 8, 8);
        contentPane.add(tabbedPane, gbc);

        generalPanel = new JPanel();
        generalPanel.setLayout(new GridBagLayout());
        tabbedPane.addTab(Bliss.RESOURCES.getString("GeneralTab"),
                generalPanel);

        nameLabel = new JLabel(Bliss.RESOURCES.getString("NameLabel") + ":");
        gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(12, 12, 8, 8);
        generalPanel.add(nameLabel, gbc);

        nameRenderer = new JLabel();
        nameRenderer.setForeground(Color.black);
        gbc = new GridBagConstraints();
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(12, 0, 8, 12);
        generalPanel.add(nameRenderer, gbc);

        producerLabel = new JLabel(Bliss.RESOURCES.getString("ProducerLabel")
                + ":");
        gbc = new GridBagConstraints();
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 12, 8, 8);
        generalPanel.add(producerLabel, gbc);

        producerRenderer = new JLabel();
        producerRenderer.setForeground(Color.black);
        gbc = new GridBagConstraints();
        gbc.gridy = 1;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 0, 8, 12);
        generalPanel.add(producerRenderer, gbc);

        yearLabel = new JLabel(Bliss.RESOURCES.getString("YearLabel") + ":");
        gbc = new GridBagConstraints();
        gbc.gridy = 2;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 12, 8, 8);
        generalPanel.add(yearLabel, gbc);

        yearRenderer = new JLabel();
        yearRenderer.setForeground(Color.black);
        gbc = new GridBagConstraints();
        gbc.gridy = 2;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 0, 8, 12);
        generalPanel.add(yearRenderer, gbc);

        sizeLabel = new JLabel(Bliss.RESOURCES.getString("SizeLabel") + ":");
        gbc = new GridBagConstraints();
        gbc.gridy = 3;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 12, 8, 8);
        generalPanel.add(sizeLabel, gbc);

        sizeRenderer = new JLabel();
        sizeRenderer.setForeground(Color.black);
        gbc = new GridBagConstraints();
        gbc.gridy = 3;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 0, 8, 12);
        generalPanel.add(sizeRenderer, gbc);

        checksumLabel = new JLabel(Bliss.RESOURCES.getString("ChecksumLabel")
                + ":");
        gbc = new GridBagConstraints();
        gbc.gridy = 4;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 12, 8, 8);
        generalPanel.add(checksumLabel, gbc);

        checksumRenderer = new JLabel();
        checksumRenderer.setForeground(Color.black);
        gbc = new GridBagConstraints();
        gbc.gridy = 4;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 0, 8, 12);
        generalPanel.add(checksumRenderer, gbc);

        memoryMapLabel = new JLabel(Bliss.RESOURCES.getString(
                "MemoryMapLabel") + ":");
        gbc = new GridBagConstraints();
        gbc.gridy = 5;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 12, 2, 8);
        generalPanel.add(memoryMapLabel, gbc);

        gbc = new GridBagConstraints();
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(0, 0, 2, 12);

        memoryMapRenderers = new JLabel[5];
        for (int i = 0; i < memoryMapRenderers.length; i++) {
            memoryMapRenderers[i] = new JLabel();
            memoryMapRenderers[i].setForeground(Color.black);
            if (i == memoryMapRenderers.length-1)
                gbc.insets.bottom = 8;
            generalPanel.add(memoryMapRenderers[i], gbc);
            gbc.gridy++;
        }

        JPanel strut = new JPanel();
        gbc = new GridBagConstraints();
        gbc.gridy = 5 + memoryMapRenderers.length;
        gbc.gridwidth = 2;
        gbc.weighty = 1.0;
        generalPanel.add(strut, gbc);

        closeButton = new JButton(Bliss.RESOURCES.getString("CloseButton"));
        gbc = new GridBagConstraints();
        gbc.gridy = 1;
        gbc.weightx = 1.0;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = new Insets(0, 8, 8, 8);
        contentPane.add(closeButton, gbc);

        pack();
    }

    private void initListeners() {
        closeButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent ae) {
                    dispose();
                }
            });
    }

    public void setCartridgeType(CartridgeType cartType) {
        this.cartType = cartType;
        loadData();
    }

    private void loadData() {
        nameRenderer.setText(cartType.getName());
        producerRenderer.setText(cartType.getProducer());
        yearRenderer.setText(cartType.getYear());
        sizeRenderer.setText(Integer.toString(cartType.getSize()));
        checksumRenderer.setText(Long.toString(cartType.getCrc(), 16).
                toUpperCase());
        CartridgeType.MemoryMap map = cartType.getMemoryMap();
        int segmentCount = map.getSegmentCount();
        for (int i = 0; i < memoryMapRenderers.length; i++) {
            if (i < segmentCount) {
                memoryMapRenderers[i].setText("$" +
                        formHex(map.getSegmentStart(i)) + " - $" +
                        formHex(map.getSegmentEnd(i)) + " = $" +
                        formHex(map.getSegmentLocation(i)));
            }
            else
                memoryMapRenderers[i].setText("");
        }
    }

    private String formHex(int mem) {
        String hex = "0000" + Integer.toString(mem, 16);
        return hex.substring(hex.length()-4).toUpperCase();
    }

    //instance data
    private CartridgeType cartType;

    //app components
    private JTabbedPane tabbedPane;
    private JPanel      generalPanel;
    private JLabel      nameLabel;
    private JLabel      nameRenderer;
    private JLabel      producerLabel;
    private JLabel      producerRenderer;
    private JLabel      yearLabel;
    private JLabel      yearRenderer;
    private JLabel      sizeLabel;
    private JLabel      sizeRenderer;
    private JLabel      checksumLabel;
    private JLabel      checksumRenderer;
    private JLabel      memoryMapLabel;
    private JLabel[]    memoryMapRenderers;
    private JButton     closeButton;

}
