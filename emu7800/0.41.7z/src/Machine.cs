/*
 * Machine.cs
 * 
 * Abstraction of an emulated machine.
 * 
 * Copyright (c) 2003 Mike Murphy
 * 
 */

using System;
using System.Drawing;
using System.IO;

namespace EMU7800 {

public enum MachineType {
	Null,
	A2600NTSC,
	A2600PAL
};

public abstract class Machine {
	public IHost H;

	public readonly InputAdapter InputAdapter;
	public virtual M6502 CPU {
		get {
			return null;
		}
	}

	// Current frame number
	private long frameNumber;
	public  long FrameNumber {
		get {
			return frameNumber;
		}
	}

	// Number of scanlines on the display
	private int scanlines;
	public  int Scanlines {
		get {
			return scanlines;
		}
	}

	// Default starting scanline
	private int firstScanline;
	public  int FirstScanline {
		get {
			return firstScanline;
		}
	}

	// Frame rate
	private int frameHZ;
	public  int FrameHZ {
		get {
			if (frameHZ < 1)
				frameHZ = 1;
			return frameHZ;
		}
		set {
			frameHZ = value;
			if (frameHZ < 1)
				frameHZ = 1;
		}
	}

	// ...in units of samples/sec
	private int soundSampleRate;
	public  int SoundSampleRate {
		get {
			return soundSampleRate;
		}
	}

	private int[] palette;
	public  int[] Palette {
		get {
			return palette;
		}
	}

	public static Machine New(GameSettings gs, Cart c, InputAdapter ia) {
		if (gs == null || c == null || ia == null) {
			return null;
		}
		
		Machine m;

		switch (gs.MachineType) {
		case MachineType.A2600NTSC:
			m = new Machine2600NTSC(c, ia);
			break;
		case MachineType.A2600PAL:
			m = new Machine2600PAL(c, ia);
			break;
		default:
			m = new Machine2600NTSC(c, ia);
			break;
		}
		m.InputAdapter.Controllers[0] = gs.LController;
		m.InputAdapter.Controllers[1] = gs.RController;

		return m;
	}

	public void Reset() {
		frameNumber = 0;
		InputAdapter.Reset();
		DoReset();
	}

	public void Run() {
		InputAdapter.CheckPoint(frameNumber);
		DoRun();
		frameNumber++;
	}

	public abstract bool ExecuteCommandLine(CommandLine cl);

	protected abstract void DoReset();
	protected abstract void DoRun();

	public Machine(InputAdapter ia, int slines, int startl, int fHZ, int sRate, int[] p) {
		InputAdapter = ia;
		scanlines = slines;
		firstScanline = startl;
		frameHZ = fHZ;
		soundSampleRate = sRate;
		palette = p;
	}
}
}
