package com.blissjx.plugin;

import java.util.*;
import com.bliss.core.*;
import com.bliss.core.devices.*;
import com.blissj.plugin.*;

public class Win32PlugIn implements PlugIn
{

    public void init(Intellivision inty) {
        vod.init(inty.getCartridge().getType().getName());
        aod.init();
        id.init();
    }

    public void release(Intellivision inty) {
        id.release();
        aod.release();
        vod.release();
    }

    public String getPlugInName() {
        return RESOURCES.getString("Win32PlugInName");
    }

    public String getPlugInDescription() {
        return RESOURCES.getString("Win32PlugInDescription");
    }

    public ClockDevice getClockDevice() {
        return cd;
    }

    public VideoOutputDevice getVideoOutputDevice() {
        return vod;
    }

    public AudioOutputDevice getAudioOutputDevice() {
        return aod;
    }

    public boolean stopRequested() {
        return (vod.stop || id.stop);
    }

    public InputDevice getInputDevice() {
        return id;
    }

    public static boolean isSupported() {
        return isSupported;
    }

    private Win32ClockDevice cd = new Win32ClockDevice();
    private DirectXVideoOutputDevice vod = new DirectXVideoOutputDevice();
    private AppAudioOutputDevice aod = new AppAudioOutputDevice();
    private DirectInputDevice id = new DirectInputDevice();

    final static ResourceBundle RESOURCES = ResourceBundle.getBundle(
            "i18n/Win32PlugInResources");

    private final static boolean isSupported;

    private static String[] win32OS = {"Windows 2000",
            "Windows Me", "Windows 98", "Windows 95" };

    static {
        String myos = System.getProperties().getProperty("os.name");
        //is Win32 based?
        boolean supported = false;
        if (myos != null && myos.indexOf("Windows") != -1) {
            try {
                System.loadLibrary("BlissNativeWin32");
                supported = true;
            }
            catch (UnsatisfiedLinkError usle) { }
        }
        isSupported = supported;
    }

}
