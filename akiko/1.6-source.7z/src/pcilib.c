 /*
  * UAE - The Un*x Amiga Emulator
  *
  * pci.library emulation - Linux
  *
  * Adapted from Carl Drougge's <carl.drougge@home.se> bsdsocket.c, as
  * is the Amiga-side E library
  */

#include "sysconfig.h"
#include "sysdeps.h"
#include "config.h"

#include "options.h"
#include "memory.h"
#include "custom.h"
#include "readcpu.h"
#include "newcpu.h"
#include "autoconf.h"
#include "pciemu.h"

#include "threaddep/penguin.h"
#include "native2amiga.h"

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>

#include <pthread.h>
#include <semaphore.h>
#include <signal.h>

/* We should be able to actually wake up and initialize the PCI cards.
   But for some reason, the Virge just doesn't wake up. So for the time
   being, we leave the initial job to XF86 4.0, and simply poke at the
   already established MMIO area. A bit of a copout, I admit, but it's
   better than staring at PCI configuration spaces that don't change,
   but magically allow the X server to do its thing anyway. *Grumble* */
#define USE_REAL_IO 0

/* This enables a truely evil hack. The Mediator only uses an 8M address
   window into PCI space. The memory mapped I/O of Virge cards can be
   found at base+16M, though, so for each I/O, the driver moves the window
   16M forward, does its access, and moves it back.
   Doing this the normal way means lots of calls to mmap and munmap, which
   isn't exactly fast.
   On the other hand, both UAE and the PC have lots of address space. With
   this hack enabled, we allocate a 32M window (the non-evil part), and
   (here comes the evil part) instead of moving the window, change the
   drivers own copy of the base-of-window address in UAE space.
   
   Fiddling with the internal variables of drivers is *BAD*, very *BAD*!
*/
#define EVIL_HACK 1

#define MAXDEVS 64 /* These are PCI devices as seen by the host */
#define MAX_ADAPTER 4 /* This is the maximum number of simulated Amiga-side
			PCI adapters. Each adapter can see all PCI devices */
/* The next two are intimately related! */
#define NUMBANKS 128
#define PCI_MEM_MASK 0x007fffff
#define PCI_IO_MASK  0x0000ffff

#if EVIL_HACK
#undef NUMBANKS
#undef PCI_MEM_MASK
#define NUMBANKS 512
#define PCI_MEM_MASK 0x01ffffff
#endif


#define ARG(x) (get_long (m68k_areg (regs, 7) + 4 * (x + 1)))

#define PCI_NONE -1
#define PCI_EXCLUSIVE -2

int oinka=0;
static uae_u32 FindDevInternal(uae_u32 n);
static uae_u32 SetBankInternal(uae_u32 bank, uae_u32 n);



typedef struct
{
    uae_u16 vendor;
    uae_u16 device;
    uae_u32 base;
    uae_u32 size; 
    uae_u16 state;
    uae_u16 orgstate;
    uae_u16 tmpstate;
    uae_u8 bus;
    uae_u8 id;
    uae_u8 function;
    uae_u8 primary;
    uae_u8 inuse;
} pci_device;


static pci_device devs[MAXDEVS];
static int numdevs=0;
static uae_s8 mem_dev[65536];
static uae_s8 io_mode[65536];
static uae_u32 adapters_used=0;


/* These should probably be in a kernel module. Even then, I am not
   sure that things would be safe on an SMP machine. Use at your own
   risk! */
static uae_u32 read_pci_config(int bus, int device, int function,
			       int offset, int size)
{
    char name[80];
    int fd;

    sprintf(name,"/proc/bus/pci/%02x/%02x.%x",bus,device,function);
    fd=open(name,O_RDONLY);
    if (fd==-1) {
	fprintf(stderr,"Could not open %s to find out about\n"
		"PCI device on bus %x, id %x, function %x\n",
		name,bus,device,function);
	abort();
    }
    lseek(fd,offset,SEEK_SET);
    switch(size) {
     case 1: {
	 uae_u8 b;
	 if (read(fd,&b,1)!=1) {
	     fprintf(stderr,"Failure reading PCI config space, offset %d for\n"
		     "PCI device on bus %x, id %x, function %x\n",
		     offset,bus,device,function);
	     abort();
	 }
	 close(fd);
	 return b;
     }
     case 2: {
	 uae_u16 w;
	 if (read(fd,&w,2)!=2) {
	     fprintf(stderr,"Failure reading PCI config space, offset %d for\n"
		     "PCI device on bus %x, id %x, function %x\n",
		     offset,bus,device,function);
	     abort();
	 }
	 close(fd);
	 return w;
     }
     case 4: {
	 uae_u32 l;
	 if (read(fd,&l,4)!=4) {
	     fprintf(stderr,"Failure reading PCI config space, offset %d for\n"
		     "PCI device on bus %x, id %x, function %x\n",
		     offset,bus,device,function);
	     abort();
	 }
	 close(fd);
	 return l;
     }
     default:
	fprintf(stderr,"Wrong size %d in read_pci_config\n",size);
	abort();
    }
    abort();  /* Unreachable */
    return 0;
}


static void write_pci_config(int bus, int device, int function,
			     uae_u32 val, int offset, int size)
{
    char name[80];
    int fd;

    sprintf(name,"/proc/bus/pci/%02x/%02x.%x",bus,device,function);
    fd=open(name,O_RDWR);
    if (fd==-1) {
	fprintf(stderr,"Could not open %s to configure\n"
		"PCI device on bus %x, id %x, function %x\n",
		name,bus,device,function);
	abort();
    }
    lseek(fd,offset,SEEK_SET);
    switch(size) {
     case 1: {
	 uae_u8 b=val;
	 if (write(fd,&b,1)!=1) {
	     fprintf(stderr,"Failure writing PCI config space, offset %d for\n"
		     "PCI device on bus %x, id %x, function %x\n",
		     offset,bus,device,function);
	     abort();
	 }
	 close(fd);
	 return;
     }
     case 2: {
	 uae_u16 w=val;
	 if (write(fd,&w,2)!=2) {
	     fprintf(stderr,"Failure writing PCI config space, offset %d for\n"
		     "PCI device on bus %x, id %x, function %x\n",
		     offset,bus,device,function);
	     abort();
	 }
	 close(fd);
	 return;
     }
     case 4: {
	 uae_u32 l=val;
	 if (write(fd,&l,4)!=4) {
	     fprintf(stderr,"Failure writing PCI config space, offset %d for\n"
		     "PCI device on bus %x, id %x, function %x\n",
		     offset,bus,device,function);
	     abort();
	 }
	 close(fd);
	 return;
     }
     default:
	fprintf(stderr,"Wrong size %d in write_pci_config\n",size);
	abort();
    }
    abort();  /* Unreachable */
}

static __inline__ void writeback_state(int i)
{
    write_pci_config(devs[i].bus,
		     devs[i].id,
		     devs[i].function,
		     devs[i].state,4,2);
}

static __inline__ uae_u16 read_state(int i)
{
    return read_pci_config(devs[i].bus,
			   devs[i].id,
			   devs[i].function,4,2);
}


/* Stuff that needs to be duplicated for each simulated adapter */

typedef struct {
#if EVIL_HACK
    uae_u32 saved_window_pos;
#endif
    uae_u32 global;
    uaecptr pcibase;
    uae_u32 pci_window_base;
    uae_u32 pci_io_base;
    uae_u8* pci_memory;
    uae_u8* pci_io;
    uae_u32 current_bank;
    uae_s8  current_dev;
    addrbank* pci_mem_bank;
    addrbank* pci_io_bank;
    void* FindDev;
    void* SetBank;
} pci_adapter;

pci_adapter pa[MAX_ADAPTER];




#if USE_REAL_IO
#include <asm/io.h>

static void prepare_io(uae_u32 addr)
{
    printf("Attempting I/O at address %04x\n",addr);
    if (addr>=0x1000) {
	printf("PCI: Broken I/O address %08x accessed\n",addr);
	abort();
    }
    if (io_mode[addr]==PCI_NONE) {
	printf("PCI: Invalid I/O address %08x accessed\n",addr);
	abort();
    }
    if (io_mode[addr]==PCI_EXCLUSIVE) {
	/* Oh my. Gotta disable I/O on the primary vga display[s], and
	   enable it on the current device. Also, note down that we did
	   just that */
	int i;

	if (pa[n].current_dev==PCI_NONE) {
	    fprintf(stderr,"PCI: Supposed to grant exclusive I/O access, but have no device!\n");
	    abort();
	}
	for (i=0;i<numdevs;i++) {
	    if (devs[i].primary) {
		devs[i].tmpstate=read_state(i);
		devs[i].state=devs[i].tmpstate&(~1);
		writeback_state(i);
	    }
	}
	i=pa[n].current_dev;
	devs[i].tmpstate=read_state(i);
	devs[i].state=devs[i].tmpstate|1;
	writeback_state(i);
	printf("changed state for device %d, now %x\n",i,read_state(i));
    }
}

static void done_io(uae_u32 addr)
{
    if (addr>=0x1000) {
	printf("PCI: Broken I/O address %08x accessed\n",addr);
	abort();
    }
    if (io_mode[addr]==PCI_NONE) {
	printf("PCI: Invalid I/O address %08x accessed\n",addr);
	abort();
    }
    if (io_mode[addr]==PCI_EXCLUSIVE) {
	/* Oh my. Gotta undo all the changes from prepare_io */
	int i;
	
	if (pa[n].current_dev==PCI_NONE) {
	    fprintf(stderr,"PCI: Supposed to revoke exclusive I/O access, but have no evice!\n");
	    abort();
	}

	i=pa[n].current_dev;
	devs[i].state=devs[i].tmpstate;
	writeback_state(i);

	for (i=0;i<numdevs;i++) {
	    if (devs[i].primary) {
		devs[i].state=devs[i].tmpstate;
		writeback_state(i);
	    }
	}
    }
}
#define pci_outb(v,a,n) outb(v,a)
#define pci_outw(v,a,n) outw(v,a)
#define pci_outl(v,a,n) outl(v,a)

#define pci_inb(a,n) inb(a)
#define pci_inw(a,n) inw(a)
#define pci_inl(a,n) inl(a)
#else
static __inline__ void prepare_io(uae_u32 addr) {}
static __inline__ void done_io(uae_u32 addr) {}

#define pci_outb(v,a,n) pa[n].pci_io[a]=v
#define pci_outw(v,a,n) do_put_mem_word((uae_u16*)(pa[n].pci_io+a),v)
#define pci_outl(v,a,n) do_put_mem_long((uae_u32*)(pa[n].pci_io+a),v)

#define pci_inb(a,n) pa[n].pci_io[a]
#define pci_inw(a,n) do_get_mem_word((uae_u16*)(pa[n].pci_io+a))
#define pci_inl(a,n) do_get_mem_long((uae_u32*)(pa[n].pci_io+a))
#endif





#if MAX_ADAPTER > 4
#error TOO MANY PCI ADAPTERS DEFINED
#endif

#if MAX_ADAPTER > 3
#define ADAPTER_NUM 3
#define MANGLE(x) x##3
#include "pcilib_adapter.c"
#undef MANGLE
#undef ADAPTER_NUM
#endif

#if MAX_ADAPTER > 2
#define ADAPTER_NUM 2
#define MANGLE(x) x##2
#include "pcilib_adapter.c"
#undef MANGLE
#undef ADAPTER_NUM
#endif

#if MAX_ADAPTER > 1
#define ADAPTER_NUM 1
#define MANGLE(x) x##1
#include "pcilib_adapter.c"
#undef MANGLE
#undef ADAPTER_NUM
#endif

#define ADAPTER_NUM 0
#define MANGLE(x) x##0
#include "pcilib_adapter.c"
#undef MANGLE
#undef ADAPTER_NUM





static uae_u32 SetBankInternal(uae_u32 bank, uae_u32 n)
{
    int i;
    int mem;

    
#if 0
    if (n==1) {
	printf("PCI: SetBank(%x, %d)\n",bank,n); 
	for (i=0;i<8;i++) {
	    printf("PCI: D%d=%08x  A%d=%08x\n",i,m68k_dreg(regs,i),i,m68k_areg(regs,i));
	}
	printf("PCI: A5 is %08x\n",m68k_areg(regs,5));
	printf("PCI: 86(A5) is %08x\n",get_long (m68k_areg (regs, 5)+86));
    }
#endif

    pa[n].current_dev=mem_dev[bank>>16];
    if (pa[n].current_dev==PCI_NONE) {
	fprintf(stderr,"PCI: Trying to switch to bank %08x, no such device\n");
	abort();
    }

#if EVIL_HACK
    if (pa[n].saved_window_pos &&
	pa[n].current_bank<=bank &&
	bank-pa[n].current_bank < ((NUMBANKS-128)<<16)) {
	/* We change the drivers own copy of pa[n].pci_window_base.
	   That is so evil that I barely dare admit to it, but given
	   the Virge driver's fondness for switching around the address
	   window.... */
	put_long(pa[n].saved_window_pos,pa[n].pci_window_base+(bank-pa[n].current_bank));
	return 0;
    }
    else {
	put_long(pa[n].saved_window_pos,pa[n].pci_window_base);
    }
#endif

    pa[n].current_bank=bank;

    if (pa[n].pci_memory) {
	munmap(pa[n].pci_memory,NUMBANKS<<16);
	pa[n].pci_memory=NULL;
    }
#if !USE_REAL_IO
    if (pa[n].pci_io) {
	munmap(pa[n].pci_io,1<<16);
	pa[n].pci_io=NULL;
    }
#endif

    mem=open("/dev/mem",O_RDWR);
    pa[n].pci_memory=mmap((void*)(NATMEM_OFFSET+pa[n].pci_window_base),
			  NUMBANKS<<16,PROT_READ|PROT_WRITE,
			  MAP_SHARED,mem,bank);
    if (pa[n].pci_memory==(void*)-1) {
	fprintf(stderr, "PCI: Could not map %08x to %08x\n",
		bank,NATMEM_OFFSET+pa[n].pci_window_base);
	abort();
    }

#if !USE_REAL_IO 
    /* This is absolutely Virge specific. See above for the explanation */
    pa[n].pci_io=mmap((void*)(NATMEM_OFFSET+pa[n].pci_io_base),
		   1<<16,PROT_READ|PROT_WRITE,
		   MAP_SHARED,mem,devs[pa[n].current_dev].base+0x01008000);
    if (pa[n].pci_io==(void*)-1) {
	fprintf(stderr, "PCI-IO: Could not map %08x to %08x\n",
		devs[pa[n].current_dev].base+0x01008000,
		NATMEM_OFFSET+pa[n].pci_io_base);
	abort();
    }
#endif
    close(mem);
    return 0;
}


/* FindDev gets two parameters, a vendor and a device ID. It returns a pointer
   to a struct. At index 0x1c in that struct, the base address of the device
   can be found (which will then be used for calls to SetBank) */

static uae_u32 FindDevInternal(uae_u32 n)
{
    int i;
    uae_u32 vendor=m68k_dreg(regs,0);
    uae_u32 device=m68k_dreg(regs,1);
    uae_u16 index=m68k_dreg(regs,2);

    printf("PCI: FindDev(%08x,%08x,%04x) called!\n",vendor,device,index);
    for (i=0;i<8;i++) {
	printf("PCI: D%d=%08x  A%d=%08x\n",i,m68k_dreg(regs,i),i,m68k_areg(regs,i));
    }

#if EVIL_HACK
    pa[n].saved_window_pos=m68k_areg (regs, 5)+86;
#endif
    for (i=0;i<numdevs;i++) {
	if (devs[i].vendor==vendor &&
	    devs[i].device==device &&
	    !devs[i].inuse) {
	    uae_u32 pos=pa[n].global+64; /* Stab in the dark; This should be fine */
	    
	    put_long(pos+0x1c,devs[i].base);
	    SetBankInternal(devs[i].base,n);
	    devs[i].inuse=1;
	    return pos;
	}
    }
    return 0;  /* Not found */
}

extern addrbank dummy_bank;

static void init_adapter(int n)
{
    pa[n].saved_window_pos=0;
    pa[n].pci_window_base=0;
    pa[n].pci_memory=NULL;
    pa[n].current_bank=0;
    pa[n].current_dev=PCI_NONE;
}

static uae_u32 find_window(uae_u32 size)
{
    uae_u32 i;
    uae_u32 count;
    uae_u32 base=0;

    count=0;
    for (i=0;i<65536;i++) {
	if (count==0)
	    base=i;
	if (mem_banks[i]==&dummy_bank) { /* empty */
	    count++;
	    if (count>=size) {
		return base<<16;
	    }
	}
	else {
	    count=0;
	}
    }
    return 0;
}


static void scan_pci(void)
{
    char* x=currprefs.pci_devices;
    int n=0;
    uae_u32 i;
    int j;

    while (strlen(x)) {
	int id,bus,function;
	char name[256];
	int fd;
	uae_u16 w;
	uae_u32 l;
	int force=0;
	int primary=0;

	while (*x=='!') {
	    force++;
	    x++;
	}
	while (*x=='*') {
	    primary++;
	    x++;
	}

	
	if (sscanf(x,"%x.%x.%x",&bus,&id,&function)!=3) {
	    fprintf(stderr,"Broken pci_devices string at or near \"%s\"\n",x);
	    abort();
	}
	while (*x && *x!=':')
	    x++;
	if (*x==':')
	    x++;
	devs[n].vendor=read_pci_config(bus,id,function,0,2);
	devs[n].device=read_pci_config(bus,id,function,2,2);
	devs[n].state=read_pci_config(bus,id,function,4,2);
	devs[n].orgstate=devs[n].state;

	devs[n].base=read_pci_config(bus,id,function,0x10,4);
	devs[n].bus=bus;
	devs[n].id=id;
	devs[n].function=function;
	devs[n].primary=primary;

	if (devs[n].state & 3) {
	    write_log("WARNING: PCI bus %x, id %x, function %x is already active!\n",bus,id,function);
	    if (devs[n].state & 1)
		write_log("  It is responding to I/O accesses\n");
	    if (devs[n].state & 2)
		write_log("  It is responding to memory accesses\n");
	    if (!force)
		abort();
	}
	if (!primary) {
	    write_pci_config(bus,id,function,0xffffffff,0x10,4);
	    devs[n].size=(read_pci_config(bus,id,function,0x10,4)^0xffffffff)+1;
	    write_pci_config(bus,id,function,devs[n].base,0x10,4);
	    
	    devs[n].state|=2;
	    write_pci_config(bus,id,function,devs[n].state,4,2);
	}

	write_log("PCI: Registered bus %x.%x.%x --> Vendor %04x, Device %04x, Base %08x/%08x\n",bus,id,function,devs[n].vendor,devs[n].device,devs[n].base,devs[n].size);
	devs[n].inuse=0;
	if (primary) { /* Don't make our primary VGA available */
	    devs[n].inuse=1;
	}
	n++;
    }
    numdevs=n;

    for (i=0;i<65536;i++) {
	io_mode[i]=PCI_NONE;
	mem_dev[i]=PCI_NONE;
    }
    for (i=0x3b0;i<0x3e0;i++)
	io_mode[i]=PCI_EXCLUSIVE;

    for (j=0;j<numdevs;j++) {
	for (i=0;i<devs[j].size;i+=65536) {
	    uae_u32 a=devs[j].base+i;
	    mem_dev[a>>16]=j;
	}
    }
}

static void map_mem(uae_u32 n)
{
    uae_u32 base=find_window(NUMBANKS);
    uae_u32 i;

    if (!base) {
	fprintf(stderr,"Could not find 8M window to map PCI bank to\n");
	abort();
    }
    pa[n].pci_window_base=base;
    map_banks(pa[n].pci_mem_bank,base>>16,NUMBANKS,0);

    base=find_window(1);
    if (!base) {
	fprintf(stderr,"Could not find 64k window to map PCI-IO bank to\n");
	abort();
    }
    pa[n].pci_io_base=base;
    map_banks(pa[n].pci_io_bank,base>>16,1,0);
}
	

static uae_u32 pcilib_install_handlers(uae_u32 in_global)
{
    int i;
    uae_u32 a7;
    int t;
    static uae_u32 ad30;
    static uae_u32 ad72;
    uae_u32 n=adapters_used++;

    if (adapters_used>MAX_ADAPTER) {
	fprintf(stderr,"Your Amiga opened pcilib more often than I can handle\n");
	abort();
    }

    pa[n].global=in_global;
    printf("PCI: Install(%08x) called\n",pa[n].global);
    /* Sigh... We need the base address of the library, and this seems
       to be the only way to get it :-( */
    a7=m68k_areg(regs,3)+0x2c;
    pa[n].pcibase=get_long(a7);
    printf("PCI: Base should be %08x\n",pa[n].pcibase);
    

    for (i=0;i<8;i++) {
	printf("PCI: D%d=%08x  A%d=%08x\n",i,m68k_dreg(regs,i),i,m68k_areg(regs,i));
    }
    printf("Going to patch\n");

    ad30=here();
    calltrap(deftrap2 (pa[n].FindDev, 0, ""));
    dw(RTS);
    
    ad72=here();
    calltrap(deftrap2 (pa[n].SetBank, TRAPFLAG_NO_RETVAL, ""));
    dw(RTS);
    
    map_mem(n);

    put_long(pa[n].pcibase-30+2,ad30);
    put_long(pa[n].pcibase-72+2,ad72);

    for (i=4;i<40;i++) {
	put_long(pa[n].pcibase+4*i,0xd00dbeef+0x00100001*i);
    }

    /* It seems as if this is where the driver expects to find the base */
    put_long(pa[n].pcibase+0x2a,pa[n].pci_window_base);

    /* This gets used, too. It's the Amiga windows for the I/O space.
     * For some stupid reason, the Virge driver accesses some registers
     * in I/O space. *Sigh*! */
    put_long(pa[n].pcibase+0x32,pa[n].pci_io_base);

    

    return 0;
}
    
static uae_u32 pcilib_demux (void)
{
    int i;

    printf ("pcilib_demux: %d\n", ARG (0));
    switch (ARG (0)) {

     case 0:
     case 1:
     case 2:
     case 3:
     case 4:
     case 5:
     case 6:
     case 7:
     case 8:
     case 9:
     case 10:
     case 11:
     case 12:
     case 13:
     case 14:
     case 15:
     case 16:
     case 17:
     case 18:
     case 19: 
	write_log("PCI: Dummy %d was called\n",ARG(0)); 
	for (i=0;i<8;i++) {
	    printf("PCI: D%d=%08x  A%d=%08x\n",i,m68k_dreg(regs,i),i,m68k_areg(regs,i));
	}
	return 0;
	abort();

     case 1001: fprintf (stderr, "PCI: ### Amiga says: '%s'\n", get_real_address (ARG (1))); return 0;

     case 4711:
	pcilib_install_handlers(ARG(1));
	break;
     case 4712:
	pcilib_install_handlers(ARG(1));
	break;
     default: write_log ("PCI: Unknown trap #%d.\n", ARG (0)); abort();
    }
    return 0;
}

void pcilib_install (void)
{
    int foo;
    uaecptr a = here ();
    org (0xF0FFC0);
    calltrap (deftrap (pcilib_demux));
    dw (RTS);
    org (a);          

#if MAX_ADAPTER >3
    pa[3].FindDev=FindDev3;
    pa[3].SetBank=SetBank3;
    pa[3].pci_mem_bank=&pci_mem_bank3;
    pa[3].pci_io_bank=&pci_io_bank3;
#endif
#if MAX_ADAPTER >2
    pa[2].FindDev=FindDev2;
    pa[2].SetBank=SetBank2;
    pa[2].pci_mem_bank=&pci_mem_bank2;
    pa[2].pci_io_bank=&pci_io_bank2;
#endif
#if MAX_ADAPTER >1
    pa[1].FindDev=FindDev1;
    pa[1].SetBank=SetBank1;
    pa[1].pci_mem_bank=&pci_mem_bank1;
    pa[1].pci_io_bank=&pci_io_bank1;
#endif
    pa[0].FindDev=FindDev0;
    pa[0].SetBank=SetBank0;
    pa[0].pci_mem_bank=&pci_mem_bank0;
    pa[0].pci_io_bank=&pci_io_bank0;

    scan_pci();
}

/* @@@ This should do something */
void pcilib_reset (void)
{
}
