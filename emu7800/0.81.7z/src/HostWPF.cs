/*
 * HostWPF
 *
 * A WPF-based Host.
 *
 * Copyright (c) 2007 Mike Murphy
 *
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace EMU7800
{
	public class HostWpfWindow : Window
	{
		private const int WIDTH = 320, HEIGHT = 240;

		private Machine M;

		private byte[] _FrameBuffer;
		private byte[] _AudioBuffer;
		private FontRenderer _FontRenderer;

		private Image _Image;
		private WriteableBitmap _Wb;
		private byte[] _Fb;
		private int _Stride;
		private Int32Rect _Rect;

		private DispatcherFrame _Frame;
		private DispatcherOperationCallback _PullFrameCallback;
		private Thread _CycleThread;

		private Size _CurrentWindowSize;

		private Dictionary<Key, HostInput> _KeyBindings;

		private Stopwatch _Stopwatch;
		private const int FRAME_SAMPLES = 120;
		private long _startOfCycleTick, _endOfCycleTick;
		private long _frameBudgetTicks, _sleepableTicks;
		private long _ticksPerMillisec = Stopwatch.Frequency / 1000;
		private int[] _RunMachineTicks = new int[FRAME_SAMPLES];
		private int[] _WaitTicks = new int[FRAME_SAMPLES];

		private DirectInput _DirectInput;
		private bool _JoysticksSwapped, _LeftPaddlesSwapped, _RightPaddlesSwapped;
		private int MouseX, MouseY;
		private bool ShowMouseCursor;	// For lightgun emulation

		public HostWpfWindow()
		{
			Title = EMU7800App.Title;
			Background = Brushes.Black.Clone();
			Icon = BitmapFrame.Create(Assembly.GetExecutingAssembly().GetManifestResourceStream("EMU7800.Icon1.ico"));

			_Frame = new DispatcherFrame();
			_PullFrameCallback = new DispatcherOperationCallback(PullFrame);
			_CycleThread = new Thread(new ThreadStart(RunCycles));

			_Wb = new WriteableBitmap(WIDTH, HEIGHT, 96, 96, PixelFormats.Bgr32, null);
			int bytesPerPixel = (_Wb.Format.BitsPerPixel + 7) / 8;
			_Stride = _Wb.PixelWidth * bytesPerPixel;
			_Rect = new Int32Rect(0, 0, _Wb.PixelWidth, _Wb.PixelHeight);
			_Fb = new byte[_Stride * _Wb.PixelHeight];

			_Image = new Image();
			_Image.Stretch = Stretch.Uniform;
			_Image.Source = _Wb;

			Content = _Image;
		}

		public void Run(Machine m)
		{
			Trace.WriteLine("WPF Host startup");

			M = m;

			try
			{
				_DirectInput = new DirectInput(new WindowInteropHelper(this).Handle);
			}
			catch
			{
				_DirectInput = null;
			}

			_FrameBuffer = new byte[M.VisiblePitch * M.Scanlines];
			_AudioBuffer = new byte[2 * M.Scanlines];
			_FontRenderer = new FontRenderer(_FrameBuffer, M.VisiblePitch, M.Palette, 0);
			ShowMouseCursor = M.InputAdapter.Controllers[0] == Controller.Lightgun;

			InitializeKeyBindings();

			Deactivated += delegate { M.H.RaiseInput(HostInput.Pause, true); };
			Closing += OnClosing;
			KeyUp += OnKeyPress;
			KeyDown += OnKeyPress;
			MouseDown += OnMouseButtonPressed;
			MouseUp += OnMouseButtonPressed;
			SizeChanged += delegate(object sender, SizeChangedEventArgs e) { _CurrentWindowSize = e.NewSize; };

			if (_DirectInput != null)
			{
				AssignDirectInputDelegates(0);
				AssignDirectInputDelegates(1);
			}

			Show();

			_CycleThread.Start();

			_Frame.Continue = true;
			Dispatcher.PushFrame(_Frame);

			if (_DirectInput != null)
			{
				_DirectInput.Dispose();
			}

			Close();

			Trace.WriteLine("WPF Host shutdown");
		}

		private object ExitFrame(object ignoredArg)
		{
			_Frame.Continue = false;
			return null;
		}

		private void OnClosing(object sender, CancelEventArgs e)
		{
			if (!M.H.Ended)
			{
				e.Cancel = true;
				M.H.RaiseInput(HostInput.End, true);
			}
		}

		private void RunCycles()
		{
			_frameBudgetTicks = Stopwatch.Frequency / M.FrameHZ;
			_sleepableTicks = _frameBudgetTicks - EMU7800App.Instance.Settings.CpuSpin * _ticksPerMillisec;

			_Stopwatch = new Stopwatch();
			_Stopwatch.Start();

			_endOfCycleTick = _Stopwatch.ElapsedTicks;

			while (!M.H.Ended && !M.MachineHalt)
			{
				RunCycle();
			}

			M.H.CloseAudio();

			_Frame.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new DispatcherOperationCallback(ExitFrame), _Frame);
		}

		private void RunCycle()
		{
			_startOfCycleTick = _endOfCycleTick;

			if (M.H.Paused)
			{
				for (int i = 0; i < _AudioBuffer.Length; i++)
				{
					_AudioBuffer[i] = 0;
				}
			}
			else
			{
				M.Run();
			}

			_Frame.Dispatcher.BeginInvoke(DispatcherPriority.Normal, _PullFrameCallback, _Frame);

			long endOfRunMachineTick = _Stopwatch.ElapsedTicks;

			int sleepTicks = (int)((_sleepableTicks - (endOfRunMachineTick - _startOfCycleTick)) / _ticksPerMillisec);
			if (sleepTicks > 0)
			{
				Thread.Sleep(sleepTicks);
			}

			while (M.H.EnqueueAudio(_AudioBuffer) == 1)
			{
			}

			_endOfCycleTick = _Stopwatch.ElapsedTicks;

			int statIndex = (int)M.FrameNumber % FRAME_SAMPLES;
			_RunMachineTicks[statIndex] = (int)(endOfRunMachineTick - _startOfCycleTick);
			_WaitTicks[statIndex] = (int)(_endOfCycleTick - endOfRunMachineTick);
		}

		private void InitializeKeyBindings()
		{
			_KeyBindings = new Dictionary<Key, HostInput>();
			_KeyBindings.Add(Key.Escape, HostInput.End);
			_KeyBindings.Add(Key.LeftCtrl, HostInput.Fire);
			_KeyBindings.Add(Key.RightCtrl, HostInput.Fire);
			_KeyBindings.Add(Key.System, HostInput.Fire2);
			_KeyBindings.Add(Key.Left, HostInput.Left);
			_KeyBindings.Add(Key.Up, HostInput.Up);
			_KeyBindings.Add(Key.Right, HostInput.Right);
			_KeyBindings.Add(Key.Down, HostInput.Down);
			_KeyBindings.Add(Key.NumPad7, HostInput.NumPad7);
			_KeyBindings.Add(Key.NumPad8, HostInput.NumPad8);
			_KeyBindings.Add(Key.NumPad9, HostInput.NumPad9);
			_KeyBindings.Add(Key.NumPad4, HostInput.NumPad4);
			_KeyBindings.Add(Key.NumPad5, HostInput.NumPad5);
			_KeyBindings.Add(Key.NumPad6, HostInput.NumPad6);
			_KeyBindings.Add(Key.NumPad1, HostInput.NumPad1);
			_KeyBindings.Add(Key.NumPad2, HostInput.NumPad2);
			_KeyBindings.Add(Key.NumPad3, HostInput.NumPad3);
			_KeyBindings.Add(Key.Multiply, HostInput.NumPadMult);
			_KeyBindings.Add(Key.NumPad0, HostInput.NumPad0);
			_KeyBindings.Add(Key.Divide, HostInput.NumPadDiv);
			_KeyBindings.Add(Key.D1, HostInput.LeftDifficulty);
			_KeyBindings.Add(Key.D2, HostInput.RightDifficulty);
			_KeyBindings.Add(Key.F1, HostInput.SetKeyboardToPlayer1);
			_KeyBindings.Add(Key.F2, HostInput.SetKeyboardToPlayer2);
			_KeyBindings.Add(Key.F3, HostInput.SetKeyboardToPlayer3);
			_KeyBindings.Add(Key.F4, HostInput.SetKeyboardToPlayer4);
			_KeyBindings.Add(Key.F5, HostInput.PanLeft);
			_KeyBindings.Add(Key.F6, HostInput.PanRight);
			_KeyBindings.Add(Key.F7, HostInput.PanUp);
			_KeyBindings.Add(Key.F8, HostInput.PanDown);
			_KeyBindings.Add(Key.F11, HostInput.SaveMachine);
			_KeyBindings.Add(Key.F12, HostInput.Unknown);
			_KeyBindings.Add(Key.C, HostInput.Color);
			_KeyBindings.Add(Key.F, HostInput.Unknown);
			_KeyBindings.Add(Key.M, HostInput.Mute);
			_KeyBindings.Add(Key.P, HostInput.Pause);
			_KeyBindings.Add(Key.R, HostInput.Reset);
			_KeyBindings.Add(Key.S, HostInput.Select);
			_KeyBindings.Add(Key.Q, HostInput.Unknown);
			_KeyBindings.Add(Key.W, HostInput.Unknown);
			_KeyBindings.Add(Key.E, HostInput.Unknown);
		}

		private void OnKeyPress(object sender, KeyEventArgs e)
		{
			if (_KeyBindings.ContainsKey(e.Key))
			{
				switch (e.Key)
				{
					case Key.F:
						if (e.IsDown)
						{
							double rmTicks = 0.0, wTicks = 0.0;
							for (int i = 0; i < FRAME_SAMPLES; i++)
							{
								rmTicks += _RunMachineTicks[i];
								wTicks += _WaitTicks[i];
							}
							rmTicks = rmTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
							wTicks = wTicks * 1000 / Stopwatch.Frequency / FRAME_SAMPLES;
							double fps = 1000.0 / (rmTicks + wTicks);
							M.H.PostedMsg = string.Format("{0}/{1} FPS {2:0.0}+{3:0.0}={4:0.0}/{5:0.0} ms", Math.Round(fps, 0), M.H.EffectiveFPS, rmTicks, wTicks, rmTicks + wTicks, 1000.0 / M.H.EffectiveFPS);
						}
						break;
					case Key.Q:
						if (e.IsDown && _DirectInput != null && _DirectInput.IsStelladaptor(0))
						{
							_LeftPaddlesSwapped = !_LeftPaddlesSwapped;
							M.H.PostedMsg = String.Format("Left Paddles {0}wapped", _LeftPaddlesSwapped ? "S" : "Uns");
						}
						break;
					case Key.W:
						if (e.IsDown)
						{
							_JoysticksSwapped = !_JoysticksSwapped;
							M.H.PostedMsg = String.Format("Game Controllers {0}wapped", _JoysticksSwapped ? "S" : "Uns");
						}
						break;
					case Key.E:
						if (e.IsDown)
						{
							_RightPaddlesSwapped = !_RightPaddlesSwapped;
							M.H.PostedMsg = String.Format("Right Paddles {0}wapped", _RightPaddlesSwapped ? "S" : "Uns");
						}
						break;
					case Key.F12:
						if (e.IsDown)
						{
							try
							{
								string fn = String.Format("screenshot {0:yyyy} {0:MM}-{0:dd} {0:HH}{0:mm}{0:ss}.bmp", DateTime.Now);
								using (FileStream fs = new FileStream(Path.Combine(EMU7800App.Instance.Settings.OutputDirectory, fn), FileMode.Create))
								{
									BitmapSource src = BitmapSource.Create(WIDTH, HEIGHT, 96, 96, PixelFormats.Bgr32, null, _Fb, _Stride);
									BmpBitmapEncoder encoder = new BmpBitmapEncoder();
									encoder.Frames.Add(BitmapFrame.Create(BitmapFrame.Create(src)));
									encoder.Save(fs);
								}
								Trace.Write("Screenshot taken: ");
								Trace.WriteLine(fn);
								M.H.PostedMsg = "Screenshot taken";
							}
							catch (Exception ex)
							{
								Trace.Write("Error while taking screenshot: ");
								Trace.WriteLine(ex.Message);
								M.H.PostedMsg = "Screenshot failed";
							}
						}
						break;
					default:
						M.H.RaiseInput(_KeyBindings[e.Key], e.IsDown);
						break;
				}
			}
			else
			{
				M.H.RaiseInput(HostInput.Unknown, e.IsDown);
			}
			e.Handled = true;
		}

		private void OnMouseButtonPressed(object sender, MouseButtonEventArgs e)
		{
			if (!M.H.Paused)
			{
				M.H.RaiseInput(HostInput.Fire, e.LeftButton.Equals(MouseButtonState.Pressed));
			}
		}

		private object PullFrame(object ignoredArg)
		{
			if (M.H.PostedMsg.Length > 0)
			{
				_FontRenderer.DrawText(M.H.PostedMsg, 2, M.H.ClipStart + 4, 10, 0);
			}

			int si = M.H.ClipStart * M.VisiblePitch + M.H.LeftOffset;
			int di = 0;

			for (int i = 0; i < HEIGHT; i++)
			{
				int dj = di;
				for (int j = 0; j < M.VisiblePitch; j++)
				{
					while (si < 0)
					{
						si += _FrameBuffer.Length;
					}
					while (si >= _FrameBuffer.Length)
					{
						si -= _FrameBuffer.Length;
					}
					int pixel = M.Palette[_FrameBuffer[si++]];
					byte r = (byte)((pixel & 0xff0000) >> 16);
					byte g = (byte)((pixel & 0xff00) >> 8);
					byte b = (byte)((pixel & 0xff));
					_Fb[dj++] = b;
					_Fb[dj++] = g;
					_Fb[dj++] = r;
					dj++;
					if (M.VisiblePitch == (WIDTH >> 1))
					{
						_Fb[dj++] = b;
						_Fb[dj++] = g;
						_Fb[dj++] = r;
						dj++;
					}
				}
				di += _Stride;
			}

			if (ShowMouseCursor)
			{
				di = (MouseY * WIDTH + MouseX) << 2;
				_Fb[di+0] = 0xff;
				_Fb[di+1] = 0xff;
				_Fb[di+2] = 0xff;
			}

			_Wb.WritePixels(_Rect, _Fb, _Stride, 0);

			// this probably should have its own dispatched method, but we'll just sneek it in here instead
			if (_DirectInput != null)
			{
				_DirectInput.Poll();
			}

			return null;
		}

		public void UpdateDisplay(byte[] buf, int scanline, int xstart, int len)
		{
			if (M.H.PostedMsg.Length > 0 && scanline <= M.H.ClipStart + 12)
			{
				// do not overwrite the rendered text of the posted message
			}
			else
			{
				int i = scanline * M.VisiblePitch + xstart;
				int x = xstart;
				while (len-- > 0)
				{
					if (i >= _FrameBuffer.Length)
					{
						i -= _FrameBuffer.Length;
					}
					_FrameBuffer[i++] = buf[x++];
				}
			}
		}

		public void UpdateSound(byte[] buf)
		{
			if (M.H.Muted)
			{
				for (int i = 0; i < buf.Length; i++)
				{
					buf[i] = 0;
				}
			}
			_AudioBuffer = buf;
		}

		void AssignDirectInputDelegates(int deviceno)
		{
			switch (M.InputAdapter.Controllers[deviceno])
			{
				case Controller.Joystick:
				case Controller.ProLineJoystick:
				case Controller.BoosterGrip:
				case Controller.Driving:
					_DirectInput.JoystickChanged = OnJoystickChanged;
					break;
				case Controller.Lightgun:
					_DirectInput.MouseChanged = OnMouseChanged;
					break;
				case Controller.Paddles:
					if (_DirectInput.IsStelladaptor(deviceno))
					{
						_DirectInput.MousePaddleChanged = null;
						_DirectInput.MouseChanged = null;
						_DirectInput.StelladaptorPaddleChanged = OnStelladaptorPaddleChanged;
					}
					else
					{
						_DirectInput.MousePaddleChanged = OnMousePaddleChanged;
					}
					break;
			}
		}

		void OnJoystickChanged(int deviceno, bool left, bool right, bool up, bool down, bool fire, bool fire2)
		{
			deviceno ^= (_JoysticksSwapped ? 1 : 0);
			M.H.RaiseInput(deviceno, HostInput.Left, left);
			M.H.RaiseInput(deviceno, HostInput.Right, right);
			M.H.RaiseInput(deviceno, HostInput.Up, up);
			M.H.RaiseInput(deviceno, HostInput.Down, down);
			M.H.RaiseInput(deviceno, HostInput.Fire, fire);
			M.H.RaiseInput(deviceno, HostInput.Fire2, fire2);
		}

		void OnMouseChanged(int x, int y, bool fire)
		{
			MouseX += x;
			if (MouseX < 0)
			{
				MouseX = 0;
			}
			else
			{
				MouseX %= WIDTH;
			}
			MouseY += y;
			if (MouseY < 0)
			{
				MouseY = 0;
			}
			else
			{
				MouseY %= HEIGHT;
			}
			M.H.RaiseLightGunInput((int)_CurrentWindowSize.Width, MouseX, MouseY);
		}

		void OnStelladaptorPaddleChanged(int paddleno, int val, bool fire)
		{
			paddleno ^= (_JoysticksSwapped ? 2 : 0);
			if (paddleno <= 1)
			{
				paddleno ^= (_LeftPaddlesSwapped ? 1 : 0);
			}
			else
			{
				paddleno ^= (_RightPaddlesSwapped ? 1 : 0);
			}
			M.H.RaisePaddleInput(paddleno, _DirectInput.StelladaptorPaddleRange, val);
			M.H.RaiseInput(paddleno, HostInput.Fire, fire);
		}

		void OnMousePaddleChanged(int val, bool fire)
		{
			M.H.RaisePaddleInput(_DirectInput.MousePaddleRange, val);
			M.H.RaiseInput(HostInput.Fire, fire);
		}
	}

	public class HostWpf : Host
	{
		HostWpfWindow W;

		public static readonly HostWpf Instance = new HostWpf();
		private HostWpf() { }

		public override void Run(Machine m)
		{
			InitializeInputSystem(m);
			W = new HostWpfWindow();
			W.Run(m);
		}
		public override void UpdateDisplay(byte[] buf, int scanline, int start, int len)
		{
			W.UpdateDisplay(buf, scanline, start, len);
		}
		public override void UpdateSound(byte[] buf)
		{
			W.UpdateSound(buf);
		}
	}
}
