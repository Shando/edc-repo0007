package com.blissjweb.plugin;

import java.io.*;
import com.bliss.core.*;
import com.bliss.core.devices.*;
import sun.audio.*;

public class AppletAudioOutputDevice implements AudioOutputDevice
{

    public final static int SAMPLE_RATE_8000  = 8000;
    public final static int SAMPLE_RATE_11025 = 11025;
    public final static int SAMPLE_RATE_22050 = 22050;
    public final static int SAMPLE_RATE_44100 = 44100;

    public void init() {
        stream = new FifoInputStream();
        AudioPlayer.player.start(stream);
    }

    public Option[] getOptions() {
        return Option.EMPTY_CONTROLLER_ARRAY;
    }

    public void playSamples(int[] samples, int numSamples) {
        for (int i = 0; i < numSamples; i++)
            playSample(samples[i]);
    }

    public void playSample(int sample) {
        stream.write((sample & 0xFF00) >> 8);
    }

    public int getSampleRate() {
        return sampleRate;
    }

    public void release() {
        AudioPlayer.player.stop(stream);
        stream = null;
    }

    private int sampleRate = SAMPLE_RATE_8000;
    private FifoInputStream stream;

}
